package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.LearningLevel
import com.example.data.local.SentenceEntity
import com.example.data.local.UserProgressEntity
import com.example.ui.components.LevelSelectorBar
import com.example.ui.components.OnlineStatusBadge
import com.example.ui.viewmodel.OnlineUpdateUiState

@Composable
fun HomeScreen(
    isOnline: Boolean,
    progress: UserProgressEntity,
    dailySentences: List<SentenceEntity>,
    totalSentenceCount: Int,
    onlineUpdateState: OnlineUpdateUiState,
    onSelectLevel: (LearningLevel) -> Unit,
    onRefreshDaily10: () -> Unit,
    onSpeakSentence: (String, Boolean) -> Unit,
    onToggleDailyMastered: (SentenceEntity) -> Unit,
    onPracticeDailySentence: (SentenceEntity) -> Unit,
    onNavigateToLearnTab: (Int) -> Unit,
    onNavigateToPracticeTab: (Int) -> Unit,
    onNavigateToGrammarBook: () -> Unit,
    onNavigateToVocabBook: () -> Unit,
    onNavigateToAiTeacher: () -> Unit,
    onNavigateToProgress: () -> Unit,
    onDownloadOnlineUpdates: () -> Unit,
    onDismissUpdateStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedLevel = LearningLevel.fromCode(progress.selectedLevel)
    val dailyDoneCount = dailySentences.count { it.isMastered }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_lazy_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Row with Official Uploaded Logo
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFFDFDFD),
                    shadowElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.size(52.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.bolo_english_logo),
                        contentDescription = stringResource(R.string.cd_bolo_english_logo),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(2.dp)
                            .testTag("home_header_logo"),
                        contentScale = ContentScale.Fit
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "बोलो इंग्लिश (Bolo English)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "हिंदी से आसान अंग्रेज़ी बोलना सीखें",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                OnlineStatusBadge(isOnline = isOnline)
            }
        }

        // Official Logo Showcase & Daily Goal Hero Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column {
                    // Clean uncropped showcase of the user's original Bolo English logo
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFFDFDFD))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.bolo_english_logo),
                            contentDescription = stringResource(R.string.cd_bolo_english_logo),
                            modifier = Modifier
                                .height(220.dp)
                                .aspectRatio(1231f / 1278f)
                                .testTag("home_hero_logo"),
                            contentScale = ContentScale.Fit
                        )
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Filled.LocalFireDepartment,
                                    contentDescription = "लगातार दिन",
                                    tint = Color(0xFFFFB703),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "${progress.streakDays} दिन स्ट्रीक",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                contentColor = Color.White,
                                shape = RoundedCornerShape(50.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.Star,
                                        contentDescription = "XP अंक",
                                        tint = Color(0xFFFFD166),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "${progress.xpPoints} XP",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "आज का लक्ष्य: 10 वाक्य बोलकर सीखें",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$totalSentenceCount+ ऑफलाइन वाक्य • बिना इंटरनेट भी सब कुछ चलता है",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.88f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { (dailyDoneCount / 10f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(50.dp)),
                            color = Color(0xFFFF9F1C),
                            trackColor = Color.White.copy(alpha = 0.25f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "$dailyDoneCount / ${dailySentences.size.coerceAtLeast(10)} वाक्य आज पूरे हुए",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Level Selector
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "अपना स्तर चुनें (Learning Level)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                LevelSelectorBar(
                    selectedLevel = selectedLevel,
                    onSelectLevel = onSelectLevel
                )
                Text(
                    text = selectedLevel.subtitleHindi,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Daily 10 Sentences Carousel
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "आज के 10 विशेष वाक्य",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "दैनिक अभ्यास • हिंदी अर्थ और उच्चारण के साथ",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(
                        onClick = onRefreshDaily10,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("refresh_daily10_btn")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("नए 10", style = MaterialTheme.typography.labelMedium)
                    }
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(dailySentences, key = { it.id }) { sentence ->
                        DailySentenceMiniCard(
                            sentence = sentence,
                            onSpeak = { onSpeakSentence(sentence.english, false) },
                            onToggleMastered = { onToggleDailyMastered(sentence) },
                            onPracticeMic = { onPracticeDailySentence(sentence) }
                        )
                    }
                }
            }
        }

        // Big Action Feature Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "अध्ययन केंद्र (मुख्य सुविधाएँ)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // New Dedicated Book Options
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FeatureTile(
                        title = "Grammar Book",
                        subtitle = "अंग्रेज़ी व्याकरण • 25 अध्याय",
                        icon = Icons.Filled.School,
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_grammar_book"),
                        onClick = onNavigateToGrammarBook
                    )
                    FeatureTile(
                        title = "Vocabulary Book",
                        subtitle = "शब्दावली • 2000+ शब्द",
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        containerColor = MaterialTheme.colorScheme.tertiary,
                        contentColor = MaterialTheme.colorScheme.onTertiary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_vocab_book"),
                        onClick = onNavigateToVocabBook
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FeatureTile(
                        title = "5000+ वाक्य",
                        subtitle = "ऑफलाइन दैनिक वाक्य",
                        icon = Icons.Filled.Translate,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_sentences"),
                        onClick = { onNavigateToLearnTab(0) }
                    )
                    FeatureTile(
                        title = "माइक अभ्यास",
                        subtitle = "बोलकर सही उच्चारण जांचें",
                        icon = Icons.Filled.Mic,
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_speaking"),
                        onClick = { onNavigateToPracticeTab(0) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FeatureTile(
                        title = "शब्दावली",
                        subtitle = "अंग्रेज़ी शब्द व हिंदी अर्थ",
                        icon = Icons.AutoMirrored.Filled.MenuBook,
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_vocab"),
                        onClick = { onNavigateToLearnTab(1) }
                    )
                    FeatureTile(
                        title = "व्याकरण (हिंदी)",
                        subtitle = "आसान नियमों से सीखें",
                        icon = Icons.Filled.School,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_grammar"),
                        onClick = { onNavigateToLearnTab(2) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FeatureTile(
                        title = "दैनिक संवाद",
                        subtitle = "रियल लाइफ बातचीत",
                        icon = Icons.Filled.Forum,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_conversations"),
                        onClick = { onNavigateToLearnTab(3) }
                    )
                    FeatureTile(
                        title = "क्विज़ व टेस्ट",
                        subtitle = "अपनी तैयारी परखें",
                        icon = Icons.Filled.Quiz,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_quiz"),
                        onClick = { onNavigateToPracticeTab(1) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FeatureTile(
                        title = "AI टीचर",
                        subtitle = if (isOnline) "ऑनलाइन लाइव बातचीत" else "इंटरनेट आवश्यक",
                        icon = Icons.AutoMirrored.Filled.Chat,
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor = MaterialTheme.colorScheme.onSecondary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_ai_teacher"),
                        onClick = onNavigateToAiTeacher
                    )
                    FeatureTile(
                        title = "मेरी प्रगति",
                        subtitle = "स्कोर, स्ट्रीक और रिपोर्ट",
                        icon = Icons.Filled.BarChart,
                        containerColor = MaterialTheme.colorScheme.tertiary,
                        contentColor = MaterialTheme.colorScheme.onTertiary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tile_progress"),
                        onClick = onNavigateToProgress
                    )
                }
            }
        }

        // Online Lesson Update Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "नए पाठ और अभ्यास डाउनलोड करें",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isOnline) {
                                    "ऑनलाइन से नए वाक्य, शब्द और क्विज़ जोड़ें (ऑफलाइन भी सेव रहेंगे)"
                                } else {
                                    "अभी आप ऑफलाइन हैं — इंटरनेट आने पर नए पाठ यहाँ से डाउनलोड करें"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    when (onlineUpdateState) {
                        is OnlineUpdateUiState.Loading -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Text(
                                    text = "AI नए पाठ तैयार कर रहा है...",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                        is OnlineUpdateUiState.Success -> {
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = onlineUpdateState.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "ठीक है",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier
                                            .clickable { onDismissUpdateStatus() }
                                            .padding(start = 8.dp)
                                    )
                                }
                            }
                        }
                        is OnlineUpdateUiState.Error -> {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = onlineUpdateState.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "बंद करें",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.error,
                                        modifier = Modifier
                                            .clickable { onDismissUpdateStatus() }
                                            .padding(start = 8.dp)
                                    )
                                }
                            }
                        }
                        OnlineUpdateUiState.Idle -> {}
                    }

                    Button(
                        onClick = onDownloadOnlineUpdates,
                        enabled = onlineUpdateState !is OnlineUpdateUiState.Loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("download_updates_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isOnline) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Icon(Icons.Filled.CloudDownload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isOnline) "ऑनलाइन अपडेट प्राप्त करें" else "ऑनलाइन होने पर अपडेट करें",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DailySentenceMiniCard(
    sentence: SentenceEntity,
    onSpeak: () -> Unit,
    onToggleMastered: () -> Unit,
    onPracticeMic: () -> Unit
) {
    Card(
        modifier = Modifier.width(278.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (sentence.isMastered) {
                MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = sentence.english,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = sentence.hindi,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = sentence.pronunciationHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = onSpeak,
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    modifier = Modifier.height(42.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "सुनें", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("सुनें")
                }
                FilledTonalButton(
                    onClick = onPracticeMic,
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    modifier = Modifier.height(42.dp)
                ) {
                    Icon(Icons.Filled.Mic, contentDescription = "बोलें", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("बोलें")
                }
                Spacer(modifier = Modifier.weight(1f))
                FilledTonalButton(
                    onClick = onToggleMastered,
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier.height(42.dp)
                ) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = "सीखा",
                        tint = if (sentence.isMastered) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FeatureTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() },
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = contentColor.copy(alpha = 0.85f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
