package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GrammarLessonEntity
import com.example.ui.components.OnlineStatusBadge
import com.example.ui.components.levelHindiLabel
import com.example.ui.viewmodel.GrammarBookFilter

private data class GrammarExerciseItem(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanationHindi: String
)

private fun parseExercises(encoded: String): List<GrammarExerciseItem> {
    if (encoded.isBlank()) return emptyList()
    return encoded.split(";;").mapNotNull { block ->
        val parts = block.split("|")
        if (parts.size >= 7) {
            GrammarExerciseItem(
                question = parts[0],
                options = listOf(parts[1], parts[2], parts[3], parts[4]),
                correctIndex = parts[5].toIntOrNull()?.coerceIn(0, 3) ?: 0,
                explanationHindi = parts[6]
            )
        } else null
    }
}

@Composable
fun GrammarBookScreen(
    isOnline: Boolean,
    chapters: List<GrammarLessonEntity>,
    filter: GrammarBookFilter,
    textScale: Float,
    lastChapterNumber: Int,
    completedCount: Int,
    totalCount: Int,
    onUpdateFilter: ((GrammarBookFilter) -> GrammarBookFilter) -> Unit,
    onUpdateTextScale: (Float) -> Unit,
    onSelectChapterNumber: (Int) -> Unit,
    onToggleCompleted: (GrammarLessonEntity) -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onSpeakEnglish: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showIndex by rememberSaveable { mutableStateOf(true) }
    var activeChapterId by rememberSaveable { mutableStateOf<Int?>(null) }

    BackHandler {
        if (!showIndex) {
            showIndex = true
        } else {
            onBack()
        }
    }

    val activeIndex = chapters.indexOfFirst { it.id == activeChapterId }.let { idx ->
        if (idx >= 0) idx else chapters.indexOfFirst { it.chapterNumber == lastChapterNumber }.coerceAtLeast(0)
    }
    val activeChapter = chapters.getOrNull(activeIndex)

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("grammar_book_screen")
    ) {
        // Book Top Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (!showIndex) showIndex = true else onBack()
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("grammar_book_back_btn")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं"
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "अंग्रेज़ी व्याकरण किताब",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "English Grammar Book • $completedCount/$totalCount अध्याय पूर्ण",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OnlineStatusBadge(isOnline = isOnline)
                }

                // Book Toolbar: Index/Reader Toggle + Text Size Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FilterChip(
                        selected = showIndex,
                        onClick = { showIndex = !showIndex },
                        label = { Text(if (showIndex) "अध्याय सूची (${chapters.size})" else "सूची देखें") },
                        leadingIcon = {
                            Icon(
                                imageVector = if (showIndex) Icons.AutoMirrored.Filled.MenuBook else Icons.Filled.Menu,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        modifier = Modifier.testTag("grammar_index_toggle")
                    )

                    // Text Size Adjuster
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Filled.FormatSize,
                            contentDescription = "फ़ॉन्ट आकार",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        listOf(0.9f to "A-", 1.0f to "A", 1.2f to "A+").forEach { (scale, label) ->
                            val isSelected = kotlin.math.abs(textScale - scale) < 0.06f
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .clickable { onUpdateTextScale(scale) }
                                    .testTag("grammar_text_scale_$label")
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showIndex) {
            // Search & Bookmark Filters
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = filter.query,
                    onValueChange = { q -> onUpdateFilter { it.copy(query = q) } },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("grammar_search_input"),
                    placeholder = { Text("अध्याय या विषय खोजें (जैसे Noun, Tense, Preposition)...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "खोजें") },
                    trailingIcon = {
                        if (filter.query.isNotEmpty()) {
                            IconButton(onClick = { onUpdateFilter { it.copy(query = "") } }) {
                                Icon(Icons.Filled.Clear, contentDescription = "साफ़ करें")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = filter.bookmarkedOnly,
                        onClick = { onUpdateFilter { it.copy(bookmarkedOnly = !it.bookmarkedOnly) } },
                        label = { Text("बुकमार्क किए गए") },
                        leadingIcon = {
                            Icon(Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        modifier = Modifier.testTag("grammar_bookmark_filter")
                    )

                    if (totalCount > 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LinearProgressIndicator(
                                progress = { (completedCount.toFloat() / totalCount).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .width(90.dp)
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(50.dp))
                            )
                            Text(
                                text = "${(completedCount * 100 / totalCount)}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            if (chapters.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "कोई अध्याय नहीं मिला",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = { onUpdateFilter { GrammarBookFilter() } }) {
                            Text("सभी अध्याय दिखाएँ")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("grammar_chapter_list"),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chapters, key = { it.id }) { chapter ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    activeChapterId = chapter.id
                                    onSelectChapterNumber(chapter.chapterNumber)
                                    showIndex = false
                                }
                                .testTag("grammar_chapter_card_${chapter.chapterNumber}"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (chapter.isCompleted) {
                                    MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f)
                                } else {
                                    MaterialTheme.colorScheme.surface
                                }
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (chapter.isCompleted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = if (chapter.isCompleted) MaterialTheme.colorScheme.onTertiary else MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${chapter.chapterNumber.coerceAtLeast(1)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = chapter.titleHindi,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${chapter.titleEnglish} • ${levelHindiLabel(chapter.level)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = { onToggleBookmark(chapter.id) },
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Icon(
                                        imageVector = if (chapter.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                        contentDescription = "बुकमार्क करें",
                                        tint = if (chapter.isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else if (activeChapter != null) {
            // Book Reading Page
            GrammarChapterBookPage(
                chapter = activeChapter,
                textScale = textScale,
                hasPrevious = activeIndex > 0,
                hasNext = activeIndex < chapters.lastIndex,
                onPrevious = {
                    val prev = chapters.getOrNull(activeIndex - 1)
                    if (prev != null) {
                        activeChapterId = prev.id
                        onSelectChapterNumber(prev.chapterNumber)
                    }
                },
                onNext = {
                    val next = chapters.getOrNull(activeIndex + 1)
                    if (next != null) {
                        activeChapterId = next.id
                        onSelectChapterNumber(next.chapterNumber)
                    }
                },
                onToggleBookmark = { onToggleBookmark(activeChapter.id) },
                onToggleCompleted = { onToggleCompleted(activeChapter) },
                onSpeakEnglish = onSpeakEnglish
            )
        }
    }
}

@Composable
private fun GrammarChapterBookPage(
    chapter: GrammarLessonEntity,
    textScale: Float,
    hasPrevious: Boolean,
    hasNext: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleCompleted: () -> Unit,
    onSpeakEnglish: (String) -> Unit
) {
    val exercises = remember(chapter.id, chapter.exercisesEncoded) {
        parseExercises(chapter.exercisesEncoded)
    }
    val selectedAnswers = remember(chapter.id) { mutableStateMapOf<Int, Int>() }
    var showAllAnswers by remember(chapter.id) { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Book Page Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "अध्याय ${chapter.chapterNumber.coerceAtLeast(1)} • ${levelHindiLabel(chapter.level)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }

                            IconButton(
                                onClick = onToggleBookmark,
                                modifier = Modifier
                                    .size(44.dp)
                                    .testTag("grammar_reader_bookmark_btn")
                            ) {
                                Icon(
                                    imageVector = if (chapter.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                    contentDescription = "अध्याय बुकमार्क करें",
                                    tint = if (chapter.isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text(
                            text = chapter.titleHindi,
                            fontSize = (20f * textScale).sp,
                            lineHeight = (27f * textScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = chapter.titleEnglish,
                            fontSize = (14f * textScale).sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.SemiBold
                        )
                        HorizontalDivider()
                        Text(
                            text = chapter.summaryHindi,
                            fontSize = (15f * textScale).sp,
                            lineHeight = (22f * textScale).sp
                        )
                    }
                }
            }

            // Formula Card
            item {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "मुख्य सूत्र (Formula)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = chapter.formula,
                            fontSize = (16f * textScale).sp,
                            lineHeight = (23f * textScale).sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Detailed Hindi Rules Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "सरल नियम (Easy Rules in Hindi)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = chapter.explanationHindi,
                            fontSize = (15f * textScale).sp,
                            lineHeight = (24f * textScale).sp
                        )
                    }
                }
            }

            // English to Hindi Examples
            item {
                Text(
                    text = "English से Hindi अनुवाद और उदाहरण",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            val examplePairs = chapter.examplesEncoded.split(";;").mapNotNull {
                val p = it.split("|")
                if (p.size == 2) p[0] to p[1] else null
            }
            items(examplePairs) { (eng, hin) ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = eng,
                                fontSize = (16f * textScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = hin,
                                fontSize = (14f * textScale).sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        IconButton(
                            onClick = { onSpeakEnglish(eng) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "उदाहरण सुनें",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Tip Card
            item {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            Icons.Filled.Lightbulb,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Column {
                            Text(
                                text = "विशेष गुरु मंत्र (Tip)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = chapter.tipHindi,
                                fontSize = (14f * textScale).sp,
                                lineHeight = (20f * textScale).sp,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }

            // Interactive Practice Exercises & Answers
            if (exercises.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Filled.Quiz, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "अभ्यास प्रश्न और उत्तर",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(onClick = { showAllAnswers = !showAllAnswers }) {
                            Text(if (showAllAnswers) "उत्तर छुपाएं" else "सभी उत्तर देखें")
                        }
                    }
                }

                items(exercises.indices.toList()) { qIdx ->
                    val ex = exercises[qIdx]
                    val chosen = selectedAnswers[qIdx]
                    val reveal = chosen != null || showAllAnswers

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "प्रश्न ${qIdx + 1}: ${ex.question}",
                                fontSize = (15f * textScale).sp,
                                fontWeight = FontWeight.Bold
                            )

                            ex.options.forEachIndexed { optIdx, optText ->
                                val isCorrectOpt = optIdx == ex.correctIndex
                                val isChosen = chosen == optIdx
                                val bg = when {
                                    reveal && isCorrectOpt -> MaterialTheme.colorScheme.tertiaryContainer
                                    reveal && isChosen && !isCorrectOpt -> MaterialTheme.colorScheme.errorContainer
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                }
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { selectedAnswers[qIdx] = optIdx },
                                    color = bg,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "${'A' + optIdx}. $optText",
                                        fontSize = (14f * textScale).sp,
                                        fontWeight = if (reveal && isCorrectOpt) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                    )
                                }
                            }

                            if (reveal) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "उत्तर: ${ex.options[ex.correctIndex]} — ${ex.explanationHindi}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Mark Complete Button
            item {
                Button(
                    onClick = onToggleCompleted,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("grammar_mark_complete_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (chapter.isCompleted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (chapter.isCompleted) "अध्याय पूरा हो गया ✓ (बदलें)"
                        else "अध्याय पूरा चिह्नित करें (+20 XP)"
                    )
                }
            }
        }

        // Bottom Book Page Navigation: Previous & Next Chapter
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onPrevious,
                    enabled = hasPrevious,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("grammar_prev_chapter_btn")
                ) {
                    Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("पिछला अध्याय")
                }

                Button(
                    onClick = onNext,
                    enabled = hasNext,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("grammar_next_chapter_btn")
                ) {
                    Text("अगला अध्याय")
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = null)
                }
            }
        }
    }
}
