package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.VocabularyEntity
import com.example.ui.components.OnlineStatusBadge
import com.example.ui.components.levelHindiLabel
import com.example.ui.viewmodel.VocabBookFilter

val VOCAB_BOOK_CHAPTERS = listOf(
    "Daily Use Words",
    "घर और परिवार",
    "खाने-पीने की चीजें",
    "फल और सब्जियाँ",
    "शरीर के अंग",
    "रंग",
    "जानवर और पक्षी",
    "स्कूल और पढ़ाई",
    "बाजार और यात्रा",
    "भावनाएँ",
    "समय और मौसम",
    "काम और व्यवसाय",
    "Verbs और Adjectives",
    "महत्वपूर्ण English Words"
)

@Composable
fun VocabBookScreen(
    isOnline: Boolean,
    words: List<VocabularyEntity>,
    availableChapters: List<String>,
    filter: VocabBookFilter,
    textScale: Float,
    totalVocabCount: Int,
    masteredVocabCount: Int,
    onUpdateFilter: ((VocabBookFilter) -> VocabBookFilter) -> Unit,
    onSelectChapter: (String) -> Unit,
    onUpdateTextScale: (Float) -> Unit,
    onToggleMastered: (VocabularyEntity) -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onSpeakEnglish: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val orderedChapters = VOCAB_BOOK_CHAPTERS.filter { it in availableChapters }
        .ifEmpty { availableChapters.ifEmpty { VOCAB_BOOK_CHAPTERS } }

    val currentChapterIdx = orderedChapters.indexOf(filter.chapter)
    val hasPrev = currentChapterIdx > 0
    val hasNext = currentChapterIdx in 0 until orderedChapters.lastIndex

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("vocab_book_screen")
    ) {
        // Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("vocab_book_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "वापस जाएं")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "शब्दावली किताब (Vocabulary Book)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "$totalVocabCount+ शब्द (14 अध्याय) • $masteredVocabCount याद किए",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OnlineStatusBadge(isOnline = isOnline)
                }

                // Search Bar
                OutlinedTextField(
                    value = filter.query,
                    onValueChange = { q ->
                        onUpdateFilter {
                            // Search across all chapters when typing a search query
                            it.copy(query = q, chapter = if (q.isNotBlank()) "ALL" else it.chapter)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("vocab_book_search_input"),
                    placeholder = { Text("2000+ शब्दों में English या हिंदी अर्थ खोजें...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "खोजें") },
                    trailingIcon = {
                        if (filter.query.isNotEmpty()) {
                            IconButton(onClick = {
                                onUpdateFilter { it.copy(query = "", chapter = orderedChapters.firstOrNull() ?: "Daily Use Words") }
                            }) {
                                Icon(Icons.Filled.Clear, contentDescription = "साफ़ करें")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                // Bookmark filter + Text size adjuster
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = filter.bookmarkedOnly,
                            onClick = {
                                onUpdateFilter {
                                    val nextBookmarked = !it.bookmarkedOnly
                                    it.copy(
                                        bookmarkedOnly = nextBookmarked,
                                        chapter = if (nextBookmarked) "ALL" else (orderedChapters.firstOrNull() ?: "Daily Use Words")
                                    )
                                }
                            },
                            label = { Text("बुकमार्क") },
                            leadingIcon = {
                                Icon(Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            modifier = Modifier.testTag("vocab_book_bookmark_filter")
                        )
                        FilterChip(
                            selected = filter.chapter == "ALL" && !filter.bookmarkedOnly && filter.query.isBlank(),
                            onClick = {
                                onUpdateFilter {
                                    it.copy(chapter = if (it.chapter == "ALL") orderedChapters.firstOrNull() ?: "Daily Use Words" else "ALL")
                                }
                            },
                            label = { Text("सभी अध्याय") },
                            leadingIcon = {
                                Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Filled.FormatSize,
                            contentDescription = "फ़ॉन्ट आकार",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        listOf(0.9f to "A-", 1.0f to "A", 1.2f to "A+").forEach { (scale, label) ->
                            val isSelected = kotlin.math.abs(textScale - scale) < 0.06f
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .clickable { onUpdateTextScale(scale) }
                                    .testTag("vocab_text_scale_$label")
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Words List
        if (words.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "इस अध्याय या खोज में कोई शब्द नहीं मिला",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        onUpdateFilter { VocabBookFilter(chapter = orderedChapters.firstOrNull() ?: "Daily Use Words") }
                    }) {
                        Text("अध्याय 1 दिखाएँ")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("vocab_word_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(orderedChapters) { ch ->
                            FilterChip(
                                selected = filter.chapter == ch,
                                onClick = { onSelectChapter(ch) },
                                label = { Text(ch) },
                                modifier = Modifier.testTag("vocab_chapter_chip_$ch")
                            )
                        }
                    }
                }
                item {
                    val chLabel = if (filter.chapter == "ALL") "सभी अध्याय" else filter.chapter
                    Text(
                        text = "$chLabel • ${words.size} शब्द प्रदर्शित",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                items(words, key = { it.id }) { word ->
                    VocabBookWordCard(
                        word = word,
                        textScale = textScale,
                        onSpeak = onSpeakEnglish,
                        onToggleBookmark = { onToggleBookmark(word.id) },
                        onToggleMastered = { onToggleMastered(word) }
                    )
                }
            }
        }

        // Bottom Previous & Next Chapter Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (hasPrev) onSelectChapter(orderedChapters[currentChapterIdx - 1])
                    },
                    enabled = hasPrev,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("vocab_prev_chapter_btn")
                ) {
                    Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("पिछला अध्याय")
                }

                Button(
                    onClick = {
                        if (hasNext) {
                            onSelectChapter(orderedChapters[currentChapterIdx + 1])
                        } else if (filter.chapter == "ALL" && orderedChapters.isNotEmpty()) {
                            onSelectChapter(orderedChapters.first())
                        }
                    },
                    enabled = hasNext || (filter.chapter == "ALL" && orderedChapters.isNotEmpty()),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("vocab_next_chapter_btn")
                ) {
                    Text(if (filter.chapter == "ALL") "अध्याय 1 खोलें" else "अगला अध्याय")
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = null)
                }
            }
        }
    }
}

@Composable
private fun VocabBookWordCard(
    word: VocabularyEntity,
    textScale: Float,
    onSpeak: (String) -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleMastered: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (word.isMastered) {
                MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = word.word,
                            fontSize = (20f * textScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = levelHindiLabel(word.level),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Text(
                        text = "${word.partOfSpeech} • उच्चारण: ${word.pronunciation}",
                        fontSize = (12f * textScale).sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleBookmark,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = if (word.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "बुकमार्क करें",
                            tint = if (word.isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = { onSpeak(word.word) },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "शब्द सुनें",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Text(
                text = "अर्थ: ${word.hindiMeaning}",
                fontSize = (16f * textScale).sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = word.exampleEnglish,
                            fontSize = (14f * textScale).sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { onSpeak(word.exampleEnglish) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "उदाहरण सुनें",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Text(
                        text = word.exampleHindi,
                        fontSize = (13f * textScale).sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = word.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                AssistChip(
                    onClick = onToggleMastered,
                    label = { Text(if (word.isMastered) "याद हो गया ✓" else "याद किया चिह्नित करें") },
                    leadingIcon = {
                        Icon(
                            if (word.isMastered) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                            contentDescription = null,
                            tint = if (word.isMastered) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
            }
        }
    }
}
