package com.example.data.seed

import com.example.data.local.GrammarLessonEntity

object GrammarSeed {
    fun getLessons(): List<GrammarLessonEntity> =
        GrammarBookPart1Seed.getChapters() + GrammarBookPart2Seed.getChapters()
}
