package com.example.data.seed

import com.example.data.local.GrammarLessonEntity

object GrammarBookPart1Seed {
    fun getChapters(): List<GrammarLessonEntity> = listOf(
        GrammarLessonEntity(
            chapterNumber = 1,
            titleHindi = "अध्याय 1: English Alphabet (अंग्रेज़ी वर्णमाला)",
            titleEnglish = "English Alphabet",
            level = "BEGINNER",
            summaryHindi = "अंग्रेज़ी भाषा की शुरुआत 26 अक्षरों (Letters) से होती है। इन्हें बड़े (Capital) और छोटे (Small) दोनों रूपों में लिखा जाता है।",
            formula = "26 Letters = 5 Vowels (स्वर) + 21 Consonants (व्यंजन)",
            explanationHindi = "• अंग्रेज़ी वर्णमाला में कुल 26 अक्षर होते हैं: A से Z तक।\n" +
                "• बड़े अक्षर (Capital Letters): A B C D E F G H I J K L M N O P Q R S T U V W X Y Z\n" +
                "• छोटे अक्षर (Small Letters): a b c d e f g h i j k l m n o p q r s t u v w x y z\n" +
                "• किसी भी वाक्य का पहला अक्षर और किसी व्यक्ति या स्थान के नाम का पहला अक्षर हमेशा Capital लिखा जाता है।",
            examplesEncoded = "Apple starts with A.|सेब (Apple) A से शुरू होता है।;;My name is Rohan.|मेरा नाम रोहन है। (M और R बड़े अक्षर हैं);;India is a great country.|भारत एक महान देश है।;;Zebra ends the alphabet.|ज़ेबरा वर्णमाला के अंतिम अक्षर Z से है।",
            tipHindi = "लिखते समय ध्यान दें: 'I' (मैं) जब अकेला आता है तो हमेशा Capital ही लिखा जाता है।",
            exercisesEncoded = "अंग्रेज़ी वर्णमाला में कुल कितने अक्षर (Letters) होते हैं?|24|25|26|28|2|अंग्रेज़ी वर्णमाला में A से Z तक कुल 26 अक्षर होते हैं।;;वाक्य के पहले शब्द का पहला अक्षर कैसा होना चाहिए?|हमेशा छोटा (Small)|हमेशा बड़ा (Capital)|तिरछा (Italic)|कोई भी|1|हर नए अंग्रेज़ी वाक्य की शुरुआत Capital Letter से होती है।;;'delhi' को सही तरीके से कैसे लिखेंगे?|delhi|DELHI|Delhi|dELHI|2|शहर या व्यक्ति के नाम का केवल पहला अक्षर बड़ा (Capital) होता है: Delhi।"
        ),
        GrammarLessonEntity(
            chapterNumber = 2,
            titleHindi = "अध्याय 2: Vowels और Consonants (स्वर व व्यंजन)",
            titleEnglish = "Vowels and Consonants",
            level = "BEGINNER",
            summaryHindi = "26 अक्षरों को उनकी ध्वनि के आधार पर दो भागों में बांटा गया है—5 Vowels (स्वर) और 21 Consonants (व्यंजन)।",
            formula = "Vowels = A, E, I, O, U | बाकी सभी 21 अक्षर = Consonants",
            explanationHindi = "• Vowels (स्वर): A, E, I, O, U — बिना इनकी मदद के लगभग कोई भी सामान्य शब्द नहीं बनता।\n" +
                "• Consonants (व्यंजन): B, C, D, F, G, H, J, K, L, M, N, P, Q, R, S, T, V, W, X, Y, Z।\n" +
                "• विशेष ध्यान: Y कभी-कभी स्वर की तरह आवाज़ देता है (जैसे Sky, Happy में ई/आई की ध्वनि), इसलिए इसे Semi-Vowel भी कहा जाता है।",
            examplesEncoded = "Elephant begins with vowel E.|एलीफेंट स्वर E से शुरू होता है।;;Book begins with consonant B.|बुक व्यंजन B से शुरू होता है।;;Orange starts with vowel O.|ऑरेंज स्वर O से शुरू होता है।;;Sky uses Y for vowel sound.|स्काई में Y स्वर जैसी ध्वनि देता है।",
            tipHindi = "Article 'An' लगाने के लिए अक्षर नहीं बल्कि स्वर की ध्वनि (अ, आ, इ, उ, ए, ओ) देखी जाती है।",
            exercisesEncoded = "निम्नलिखित में से कौन-सा अक्षर Vowel (स्वर) है?|B|E|M|T|1|A, E, I, O, U पाँच Vowels हैं, इसलिए E सही उत्तर है।;;अंग्रेज़ी में कुल कितने Consonants (व्यंजन) होते हैं?|5|20|21|26|2|26 कुल अक्षरों में से 5 Vowels हटाने पर 21 Consonants बचते हैं।;;'Umbrella' शब्द किससे शुरू होता है?|Consonant से|Vowel से|Number से|Symbol से|1|'Umbrella' का पहला अक्षर U एक Vowel (स्वर) है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 3,
            titleHindi = "अध्याय 3: Noun (संज्ञा)",
            titleEnglish = "Noun (Naming Words)",
            level = "BEGINNER",
            summaryHindi = "किसी व्यक्ति, स्थान, वस्तु, जानवर या भावना के नाम को Noun (संज्ञा) कहते हैं। आसान शब्दों में: जो भी नाम है, वह Noun है।",
            formula = "Noun = Person (व्यक्ति) + Place (स्थान) + Thing (वस्तु) + Idea (भाव)",
            explanationHindi = "• Proper Noun (व्यक्तिवाचक): विशेष नाम जैसे Ram, Delhi, Ganga।\n" +
                "• Common Noun (जातिवाचक): सामान्य नाम जैसे Boy, City, Book, River।\n" +
                "• Collective Noun (समूहवाचक): झुंड/समूह जैसे Team, Class, Crowd।\n" +
                "• Material Noun (द्रव्यवाचक): धातु/पदार्थ जैसे Gold, Water, Milk।\n" +
                "• Abstract Noun (भाववाचक): जिसे छू नहीं सकते, केवल महसूस करते हैं जैसे Honesty, Love, Happiness।",
            examplesEncoded = "Priya lives in Jaipur.|प्रिया जयपुर में रहती है। (Priya, Jaipur = Proper Noun);;A book is on the table.|मेज़ पर एक किताब है। (book, table = Common Noun);;Honesty is the best policy.|ईमानदारी सबसे अच्छी नीति है। (Honesty = Abstract Noun);;Our team won the match.|हमारी टीम ने मैच जीता। (team = Collective Noun)",
            tipHindi = "आसान पहचान: 'यह क्या है?' या 'यह कौन है?' पूछने पर जो नाम जवाब में आए, वही Noun होता है।",
            exercisesEncoded = "'My brother lives in Mumbai.' वाक्य में Proper Noun कौन-सा है?|brother|lives|Mumbai|in|2|Mumbai एक विशेष शहर का नाम है, इसलिए यह Proper Noun है।;;'Kindness' किस प्रकार का Noun है?|Material Noun|Abstract Noun|Collective Noun|Proper Noun|1|दयालुता (Kindness) एक गुण/भावना है जिसे देखा या छुआ नहीं जा सकता, इसलिए Abstract Noun है।;;इनमें से कौन-सा शब्द Collective Noun है?|Apple|Class|Gold|Chair|1|Class छात्रों के समूह को दर्शाता है, इसलिए यह Collective Noun है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 4,
            titleHindi = "अध्याय 4: Pronoun (सर्वनाम)",
            titleEnglish = "Pronoun",
            level = "BEGINNER",
            summaryHindi = "संज्ञा (Noun) के स्थान पर बार-बार नाम दोहराने से बचने के लिए जिन शब्दों का उपयोग होता है, उन्हें Pronoun कहते हैं।",
            formula = "I, We, You, He, She, It, They + Me, Him, Her, Us, Them",
            explanationHindi = "• बार-बार 'Rahul went... Rahul ate...' कहने के बजाय हम 'He' का उपयोग करते हैं।\n" +
                "• Subject Pronouns (कर्ता): I (मैं), We (हम), You (तुम/आप), He (वह पुरुष), She (वह स्त्री), It (यह निर्जीव/जानवर), They (वे)।\n" +
                "• Object Pronouns (कर्म): Me (मुझे), Us (हमें), You (तुम्हें), Him (उसे), Her (उसे), Them (उन्हें)।\n" +
                "• Possessive (अधिकार): My/Mine (मेरा), Our (हमारा), Your (आपका), His/Her/Their।",
            examplesEncoded = "Ravi is my friend. He is kind.|रवि मेरा दोस्त है। वह दयालु है।;;She gave me a nice pen.|उसने मुझे एक अच्छा पेन दिया।;;They are practicing English together.|वे साथ में अंग्रेज़ी का अभ्यास कर रहे हैं।;;This notebook is mine.|यह कॉपी मेरी है।",
            tipHindi = "दो लोगों के लिए बोलते समय 'Me and Ravi' की जगह 'Ravi and I' बोलना ज़्यादा शुद्ध माना जाता है।",
            exercisesEncoded = "'Sita is a singer. ___ sings well.' खाली जगह में सही Pronoun भरें:|He|She|It|They|1|Sita स्त्रीलिंग एकवचन है, इसलिए 'She' सही Pronoun है।;;'Give the book to ___.' सही Object Pronoun चुनें:|I|He|Me|They|2|Preposition 'to' के बाद Object Pronoun 'Me' का प्रयोग होता है।;;निम्नलिखित में से कौन-सा Pronoun नहीं है?|We|They|School|Them|2|'School' एक स्थान का नाम (Noun) है, Pronoun नहीं।"
        ),
        GrammarLessonEntity(
            chapterNumber = 5,
            titleHindi = "अध्याय 5: Verb (क्रिया)",
            titleEnglish = "Verb (Action & State Words)",
            level = "BEGINNER",
            summaryHindi = "जिस शब्द से किसी काम के करने, होने या किसी स्थिति का पता चले, उसे Verb (क्रिया) कहते हैं। बिना Verb के कोई वाक्य पूरा नहीं होता।",
            formula = "V1 (Base) -> V2 (Past) -> V3 (Past Participle) -> V-ing",
            explanationHindi = "• Action Verbs (कार्य क्रियाएँ): Eat (खाना), Go (जाना), Speak (बोलना), Write (लिखना), Play (खेलना)।\n" +
                "• State/Being Verbs: Is, Am, Are, Was, Were (होना दर्शाती हैं)।\n" +
                "• Regular Verbs में -ed जुड़ता है (Work -> Worked -> Worked)।\n" +
                "• Irregular Verbs का रूप बदलता है (Go -> Went -> Gone; Speak -> Spoke -> Spoken)।",
            examplesEncoded = "Children play in the park.|बच्चे पार्क में खेलते हैं। (play = Action Verb);;She spoke very clearly.|वह बहुत स्पष्ट बोली। (spoke = V2 Past Verb);;I have written two pages.|मैंने दो पन्ने लिख लिए हैं। (written = V3);;We are learning grammar now.|हम अभी व्याकरण सीख रहे हैं।",
            tipHindi = "रोज़ाना कम से कम 5 नई Verbs के तीनों रूप (V1-V2-V3) ज़रूर याद करें—इससे Tenses आसान हो जाते हैं।",
            exercisesEncoded = "'Speak' क्रिया की 2nd Form (V2) क्या होती है?|Speaked|Spoke|Spoken|Speaking|1|'Speak' एक Irregular Verb है जिसकी V2 'Spoke' और V3 'Spoken' होती है।;;'The baby sleeps peacefully.' इस वाक्य में Verb कौन-सी है?|baby|sleeps|peacefully|The|1|'sleeps' (सोती है) काम दर्शाने वाला शब्द यानी Verb है।;;'Go' की 3rd Form (V3) चुनें:|Went|Going|Gone|Goes|2|Go (V1) -> Went (V2) -> Gone (V3)।"
        ),
        GrammarLessonEntity(
            chapterNumber = 6,
            titleHindi = "अध्याय 6: Adjective (विशेषण)",
            titleEnglish = "Adjective (Describing Words)",
            level = "BEGINNER",
            summaryHindi = "जो शब्द Noun या Pronoun की विशेषता (गुण, दोष, रंग, संख्या, आकार) बताते हैं, उन्हें Adjective (विशेषण) कहते हैं।",
            formula = "Adjective + Noun (जैसे: Good boy) | Subject + is + Adjective",
            explanationHindi = "• गुण/दोष: Good (अच्छा), Honest (ईमानदार), Brave (बहादुर), Kind (दयालु)।\n" +
                "• आकार/रंग: Big (बड़ा), Small (छोटा), Red (लाल), Tall (लंबा)।\n" +
                "• संख्या/मात्रा: Two (दो), Many (कई), Some (कुछ), Enough (पर्याप्त)।\n" +
                "• तुलना (Degrees): Positive (Tall), Comparative (Taller - दो में तुलना), Superlative (Tallest - सबसे ऊँचा)।",
            examplesEncoded = "This is an easy lesson.|यह एक आसान पाठ है। (easy = Adjective);;She wore a blue saree.|उसने नीली साड़ी पहनी। (blue = Adjective);;Rohan is taller than Aman.|रोहन अमन से लंबा है। (taller = Comparative);;Mount Everest is the highest peak.|माउंट एवरेस्ट सबसे ऊँची चोटी है।",
            tipHindi = "दो लोगों की तुलना करते समय 'more' और '-er' दोनों एक साथ कभी न लगाएँ—'more better' गलत है, केवल 'better' बोलें।",
            exercisesEncoded = "'She has a red umbrella.' वाक्य में Adjective क्या है?|She|has|red|umbrella|2|'red' शब्द 'umbrella' (छाते) के रंग की विशेषता बता रहा है।;;'Good' की Comparative Degree क्या है?|Gooder|More good|Better|Best|2|Good -> Better (दो की तुलना) -> Best (सर्वश्रेष्ठ)।;;Superlative Degree से पहले आमतौर पर कौन-सा शब्द आता है?|A|An|The|In|2|Superlative Degree (जैसे the best, the tallest) से पहले हमेशा 'The' लगता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 7,
            titleHindi = "अध्याय 7: Adverb (क्रिया विशेषण)",
            titleEnglish = "Adverb",
            level = "BEGINNER",
            summaryHindi = "जो शब्द किसी Verb (क्रिया), Adjective (विशेषण) या दूसरे Adverb की विशेषता बताते हैं—कैसे, कब, कहाँ, कितनी बार—उन्हें Adverb कहते हैं।",
            formula = "अक्सर Adjective + -ly = Adverb (जैसे: Slow + ly = Slowly)",
            explanationHindi = "• Adverb of Manner (कैसे?): Slowly (धीरे से), Carefully (सावधानी से), Politely (विनम्रता से), Well (अच्छी तरह)।\n" +
                "• Adverb of Time (कब?): Today, Yesterday, Now, Soon, Early।\n" +
                "• Adverb of Place (कहाँ?): Here, There, Inside, Outside, Everywhere।\n" +
                "• Adverb of Frequency (कितनी बार?): Always, Often, Sometimes, Never, Daily।",
            examplesEncoded = "Please speak slowly and clearly.|कृपया धीरे और स्पष्ट बोलें।;;We practice English daily.|हम रोज़ाना अंग्रेज़ी का अभ्यास करते हैं।;;Come inside right away.|तुरंत अंदर आइए।;;He answered the question politely.|उसने विनम्रता से प्रश्न का उत्तर दिया।",
            tipHindi = "याद रखें: 'Good' एक Adjective है (He is a good speaker), लेकिन क्रिया के लिए 'Well' (Adverb) लगता है (He speaks well)।",
            exercisesEncoded = "'Quick' शब्द से बनने वाला सही Adverb क्या है?|Quicker|Quickly|Quickness|Quickest|1|Adjective 'Quick' में '-ly' जोड़कर Adverb 'Quickly' बनता है।;;'She always wakes up early.' इसमें 'always' किस प्रकार का Adverb है?|Frequency (कितनी बार)|Place (कहाँ)|Color (रंग)|Number|0|'Always' बताता है कि काम कितनी बार होता है (Adverb of Frequency)।;;सही वाक्य चुनें:|He sings good.|He sings well.|He well sings.|He goodly sings.|1|'Sings' एक Verb है जिसकी विशेषता Adverb 'well' से बताई जाती है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 8,
            titleHindi = "अध्याय 8: Preposition (संबंधबोधक अव्यय)",
            titleEnglish = "Prepositions (In, On, At, Under, With)",
            level = "BEGINNER",
            summaryHindi = "Preposition वे छोटे शब्द हैं जो Noun/Pronoun से पहले लगकर समय, स्थान या दिशा का संबंध बताते हैं।",
            formula = "Preposition + Noun/Pronoun (जैसे: On the table, At 7 AM)",
            explanationHindi = "• At: निश्चित समय (at 6 PM), छोटा स्थान (at the door, at school)।\n" +
                "• On: दिन/तारीख (on Monday), सतह के ऊपर (on the desk)।\n" +
                "• In: महीना/साल/अंदर (in July, in 2026, in the room)।\n" +
                "• Under (नीचे), Behind (पीछे), Between (दो के बीच), Among (अनेक के बीच), With (के साथ), For (के लिए), From (से)।",
            examplesEncoded = "The cat is under the chair.|बिल्ली कुर्सी के नीचे है।;;My birthday is in October.|मेरा जन्मदिन अक्टूबर में है।;;Sit between Priya and Neha.|प्रिया और नेहा के बीच बैठो।;;I travel to office by metro.|मैं मेट्रो से ऑफिस जाता हूँ।",
            tipHindi = "यात्रा के साधन के साथ हमेशा 'by' लगता है (by bus, by train), लेकिन पैदल चलने के लिए 'on foot' बोलते हैं!",
            exercisesEncoded = "'The meeting starts ___ 10 AM.' सही Preposition चुनें:|in|on|at|between|2|घड़ी के निश्चित समय से पहले हमेशा 'at' लगता है।;;'Keep the phone ___ the table.' (मेज़ की सतह पर):|in|on|at|under|1|किसी सतह के ऊपर रखी वस्तु के लिए 'on' का प्रयोग होता है।;;'Share these sweets ___ all five friends.':|between|among|at|on|1|दो से अधिक लोगों के बीच बांटने के लिए 'among' लगता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 9,
            titleHindi = "अध्याय 9: Conjunction (समुच्चयबोधक शब्द)",
            titleEnglish = "Conjunctions (Joining Words)",
            level = "INTERMEDIATE",
            summaryHindi = "दो शब्दों, वाक्यांशों या वाक्यों को आपस में जोड़ने वाले शब्दों को Conjunction कहते हैं।",
            formula = "Clause 1 + Conjunction (and / but / because / so / or) + Clause 2",
            explanationHindi = "• And (और): दो समान बातें जोड़ने के लिए।\n" +
                "• But (लेकिन/परंतु): विपरीत बात जोड़ने के लिए।\n" +
                "• Or (या/अथवा): विकल्प दिखाने के लिए।\n" +
                "• Because (क्योंकि): कारण बताने के लिए।\n" +
                "• So (इसलिए): परिणाम बताने के लिए।\n" +
                "• Although / Though (यद्यपि/भले ही) और If (यदि)।",
            examplesEncoded = "I like tea and biscuits.|मुझे चाय और बिस्कुट पसंद हैं।;;He studied hard, so he passed.|उसने मेहनत की, इसलिए वह पास हो गया।;;She is tired, but she keeps smiling.|वह थकी है, फिर भी मुस्कुराती रहती है।;;Stay home because it is raining.|घर पर रहें क्योंकि बारिश हो रही है।",
            tipHindi = "'Although' के साथ कभी भी 'but' न लगाएं! 'Although he tried, he failed' सही है ('but' गलत होगा)।",
            exercisesEncoded = "'Would you like tea ___ coffee?' सही विकल्प चुनें:|and|but|or|so|2|दो में से एक विकल्प चुनने के लिए 'or' का प्रयोग होता है।;;'I stayed inside ___ it was raining heavily.':|because|or|but|and|0|कारण बताने के लिए 'because' (क्योंकि) का प्रयोग होता है।;;'She worked hard ___ won the prize.':|or|and|because|although|1|दो जुड़े हुए सकारात्मक कार्यों के लिए 'and' आता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 10,
            titleHindi = "अध्याय 10: Interjection (विस्मयादिबोधक शब्द)",
            titleEnglish = "Interjections",
            level = "BEGINNER",
            summaryHindi = "अचानक मन में उठने वाली खुशी, दुख, आश्चर्य, प्रशंसा या चेतावनी की भावना को दर्शाने वाले शब्दों को Interjection कहते हैं।",
            formula = "Interjection + Exclamation Mark (!) + Sentence",
            explanationHindi = "• खुशी/जीत: Hurrah! (वाह! हम जीत गए!), Yay!।\n" +
                "• प्रशंसा: Bravo! (शाबाश!), Well done! (बहुत बढ़िया!), Awesome!।\n" +
                "• आश्चर्य: Wow! (अरे वाह!), Oh! (ओह!), What! (क्या!)।\n" +
                "• दुख: Alas! (हाय/अफसोस!), Oh no! (अरे नहीं!)।\n" +
                "• गलती/ध्यान: Oops! (ओह गलती हो गई!), Hush! / Shh! (चुप रहो!)।",
            examplesEncoded = "Wow! Your pronunciation is great.|वाह! आपका उच्चारण बहुत बढ़िया है।;;Bravo! You completed ten chapters.|शाबाश! आपने दस अध्याय पूरे कर लिए।;;Oops! I dropped my pen.|उफ़! मेरा पेन गिर गया।;;Alas! We missed the morning train.|अफसोस! हमारी सुबह की ट्रेन छूट गई।",
            tipHindi = "Interjection के तुरंत बाद हमेशा विस्मयादिबोधक चिह्न (!) लगाया जाता है।",
            exercisesEncoded = "जीत या बड़ी खुशी व्यक्त करने के लिए कौन-सा Interjection सही है?|Alas!|Hurrah!|Oops!|Hush!|1|'Hurrah!' खुशी और उत्साह व्यक्त करने के लिए उपयोग होता है।;;छोटी गलती होने पर अचानक मुँह से क्या निकलता है?|Bravo!|Oops!|Hurrah!|Cheers!|1|'Oops!' किसी छोटी चूक या गलती पर बोला जाता है।;;किसी की तारीफ करने के लिए क्या कहेंगे?|Alas!|Well done!|Oh no!|Hush!|1|'Well done!' या 'Bravo!' किसी के अच्छे काम की सराहना के लिए होता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 11,
            titleHindi = "अध्याय 11: Articles (A, An और The)",
            titleEnglish = "Articles: A, An, The",
            level = "BEGINNER",
            summaryHindi = "Noun से पहले A, An और The का सही चुनाव बोलचाल और परीक्षा दोनों में अत्यंत आवश्यक है।",
            formula = "A (व्यंजन ध्वनि) | An (स्वर ध्वनि) | The (निश्चित/विशेष वस्तु)",
            explanationHindi = "• A और An केवल एकवचन गणनीय संज्ञा (Singular Countable Noun) के साथ आते हैं।\n" +
                "• शब्द के पहले अक्षर पर नहीं, उसकी **पहली ध्वनि (Sound)** पर ध्यान दें:\n" +
                "  - An hour (ऑवर - अ की ध्वनि), An honest man, An umbrella।\n" +
                "  - A university (यूनिवर्सिटी - य की ध्वनि), A one-rupee note (व की ध्वनि)।\n" +
                "• The: जब कोई चीज़ निश्चित हो, पहले बात हो चुकी हो, या दुनिया में अनूठी हो (the sun, the moon, the Taj Mahal)।",
            examplesEncoded = "Wait for an hour please.|कृपया एक घंटे प्रतीक्षा करें।;;He reads in a university.|वह एक विश्वविद्यालय में पढ़ता है।;;The sun rises in the east.|सूर्य पूर्व में उगता है।;;I saw a dog. The dog was friendly.|मैंने एक कुत्ता देखा। वह कुत्ता मिलनसार था।",
            tipHindi = "किसी देश के सामान्य नाम (India, Nepal) या व्यक्ति के नाम (Rahul) से पहले कभी 'The' न लगाएं।",
            exercisesEncoded = "'He is ___ honest officer.' खाली स्थान भरें:|a|an|the|no article|1|'Honest' का उच्चारण 'ऑनेस्ट' (स्वर ध्वनि) से शुरू होता है, इसलिए 'an' आएगा।;;'She studies in ___ European college.':|an|a|the|many|1|'European' की पहली ध्वनि 'य' (व्यंजन) है, इसलिए 'a' लगेगा।;;'___ Moon shines at night.':|A|An|The|None|2|अद्वितीय खगोलीय पिंडों (Moon, Sun, Earth) के साथ 'The' लगता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 12,
            titleHindi = "अध्याय 12: Is, Am, Are (वर्तमान होना)",
            titleEnglish = "Use of Is, Am, Are",
            level = "BEGINNER",
            summaryHindi = "वर्तमान समय (है, हूँ, हैं, हो) में किसी की पहचान, गुण, स्थिति या जगह बताने के लिए Is, Am, Are का उपयोग करते हैं।",
            formula = "Subject + is / am / are + Complement | Negative: + not",
            explanationHindi = "• I + am (मैं हूँ): I am ready. / I am not tired.\n" +
                "• He / She / It / एक नाम + is (है): She is a doctor. / The tea is hot.\n" +
                "• You / We / They / बहुवचन + are (हैं/हो): You are smart. / We are Indians.\n" +
                "• प्रश्न बनाने के लिए Is/Am/Are को आगे लाएं: Are you busy? / Is he at home?",
            examplesEncoded = "I am confident today.|मैं आज आत्मविश्वासी हूँ।;;My father is very punctual.|मेरे पिता समय के बहुत पाबंद हैं।;;They are from Jaipur.|वे जयपुर से हैं।;;Are you ready to practice?|क्या आप अभ्यास के लिए तैयार हैं?",
            tipHindi = "बोलचाल में संक्षिप्त रूप (Contractions) बोलें: I'm, He's, She's, You're, We're, Isn't, Aren't।",
            exercisesEncoded = "'You ___ my best friend.' सही क्रिया चुनें:|is|am|are|was|2|'You' के साथ वर्तमान काल में हमेशा 'are' का प्रयोग होता है।;;'I ___ learning English offline.':|is|am|are|be|1|'I' के साथ हमेशा 'am' लगता है।;;'The water bottle ___ empty.':|am|are|is|were|2|'water bottle' एकवचन (Singular) है, इसलिए 'is' सही है।"
        )
    )
}
