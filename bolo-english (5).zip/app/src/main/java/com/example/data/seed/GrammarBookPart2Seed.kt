package com.example.data.seed

import com.example.data.local.GrammarLessonEntity

object GrammarBookPart2Seed {
    fun getChapters(): List<GrammarLessonEntity> = listOf(
        GrammarLessonEntity(
            chapterNumber = 13,
            titleHindi = "अध्याय 13: Was और Were (भूतकाल होना)",
            titleEnglish = "Use of Was and Were",
            level = "BEGINNER",
            summaryHindi = "बीते हुए समय (था, थी, थे) में किसी की स्थिति, अवस्था या उपस्थिति बताने के लिए Was और Were का प्रयोग होता है।",
            formula = "Subject + was / were + Noun / Adjective / Place",
            explanationHindi = "• I, He, She, It और एकवचन नाम + was: I was busy yesterday.\n" +
                "• You, We, They और बहुवचन + were: We were in Delhi last week.\n" +
                "• Negative: was not (wasn't) / were not (weren't).\n" +
                "• Question: Was/Were + Subject...? जैसे: Were you at home?",
            examplesEncoded = "I was tired last night.|कल रात मैं थका हुआ था।;;The market was very crowded.|बाज़ार में बहुत भीड़ थी।;;They were happy with the result.|वे परिणाम से खुश थे।;;Were you present in class?|क्या आप कक्षा में उपस्थित थे?",
            tipHindi = "भूलकर भी 'You was' या 'We was' न बोलें—'You' और 'We' हमेशा 'were' लेते हैं।",
            exercisesEncoded = "'Yesterday, the weather ___ very pleasant.':|were|was|are|am|1|एकवचन कर्ता 'weather' और बीते कल के लिए 'was' लगेगा।;;'Where ___ you yesterday evening?':|was|is|were|am|2|'You' के साथ भूतकाल में हमेशा 'were' लगता है।;;'We ___ not late for the train.':|was|were|is|am|1|बहुवचन कर्ता 'We' के साथ 'were' का प्रयोग होता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 14,
            titleHindi = "अध्याय 14: Has, Have और Had (पास होना)",
            titleEnglish = "Use of Has, Have, Had",
            level = "BEGINNER",
            summaryHindi = "जब किसी के पास कोई वस्तु, रिश्ता, बीमारी या गुण हो (या भूतकाल में था), तो Has, Have और Had का प्रयोग किया जाता है।",
            formula = "Present: has / have | Past: had + Object",
            explanationHindi = "• I, You, We, They (वर्तमान) -> have (पास है): I have a grammar book.\n" +
                "• He, She, It, एक नाम (वर्तमान) -> has (पास है): She has two brothers.\n" +
                "• सभी कर्ताओं (भूतकाल - पास था) -> had: We had an old scooter.\n" +
                "• Negative (वर्तमान): do not have / does not have (ध्यान दें: doesn't के साथ 'have' आता है, 'has' नहीं!)।",
            examplesEncoded = "I have an important meeting today.|आज मेरी एक महत्वपूर्ण मीटिंग है।;;He has a new smartphone.|उसके पास एक नया स्मार्टफोन है।;;Do you have an extra pen?|क्या आपके पास एक अतिरिक्त पेन है?;;They had a big garden earlier.|पहले उनके पास एक बड़ा बगीचा था।",
            tipHindi = "'She doesn't has' गलत वाक्य है—सही होगा 'She doesn't have'! 'does' के बाद हमेशा 'have' आता है।",
            exercisesEncoded = "'Riya ___ a red bicycle.' सही शब्द चुनें:|have|has|having|are|1|एकवचन नाम 'Riya' के साथ वर्तमान में 'has' लगता है।;;'He does not ___ enough time.':|has|had|have|having|2|'does not' के साथ हमेशा क्रिया का मूल रूप 'have' आता है।;;'We ___ a great picnic last Sunday.':|has|have|had|are|2|पिछले रविवार (Past) के लिए 'had' का उपयोग होगा।"
        ),
        GrammarLessonEntity(
            chapterNumber = 15,
            titleHindi = "अध्याय 15: This, That, These, Those",
            titleEnglish = "Demonstratives: This, That, These, Those",
            level = "BEGINNER",
            summaryHindi = "पास या दूर स्थित एक या अनेक वस्तुओं की ओर इशारा करने के लिए इन चार शब्दों का उपयोग किया जाता है।",
            formula = "पास: This (1) / These (अनेक) | दूर: That (1) / Those (अनेक)",
            explanationHindi = "• This (यह): पास की 1 चीज़/व्यक्ति -> This is my phone.\n" +
                "• That (वह): दूर की 1 चीज़/व्यक्ति -> That mountain is high.\n" +
                "• These (ये): पास की अनेक चीज़ें -> These apples are sweet.\n" +
                "• Those (वे): दूर की अनेक चीज़ें -> Those stars shine brightly.",
            examplesEncoded = "This is a useful vocabulary book.|यह एक उपयोगी शब्दावली किताब है।;;That building near the bridge is old.|पुल के पास वह इमारत पुरानी है।;;These flowers smell wonderful.|इन फूलों की खुशबू शानदार है।;;Those mangoes on the top branch are ripe.|ऊपर वाली डाली के वे आम पके हुए हैं।",
            tipHindi = "This और That हमेशा 'is' लेते हैं, जबकि These और Those हमेशा 'are' लेते हैं।",
            exercisesEncoded = "पास रखी कई किताबों की तरफ इशारा करने के लिए क्या कहेंगे?|This books|That books|These books|Those books|2|पास और बहुवचन के लिए 'These' का उपयोग होता है।;;'___ is my school across the road.' (सड़क के उस पार - दूर, एक):|This|That|These|Those|1|दूर स्थित एक चीज़ के लिए 'That' लगता है।;;सही जोड़ी चुनें:|This are|These is|Those are|That are|2|'Those' बहुवचन है इसलिए इसके साथ 'are' आता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 16,
            titleHindi = "अध्याय 16: Singular और Plural (एकवचन व बहुवचन)",
            titleEnglish = "Singular and Plural Nouns",
            level = "BEGINNER",
            summaryHindi = "एक वस्तु (Singular) से अनेक वस्तुएँ (Plural) बनाने के आसान नियम समझें ताकि गिनती बोलते समय गलती न हो।",
            formula = "सामान्य: + s | s/sh/ch/x/o: + es | व्यंजन+y: ies | कुछ अनियमित",
            explanationHindi = "• नियम 1 (सामान्य): +s -> Book -> Books, Pen -> Pens।\n" +
                "• नियम 2 (अंत में s, sh, ch, x, o): +es -> Bus -> Buses, Box -> Boxes, Mango -> Mangoes।\n" +
                "• नियम 3 (व्यंजन + y): y हटाकर +ies -> Baby -> Babies, City -> Cities (लेकिन Boy -> Boys)।\n" +
                "• नियम 4 (अंत में f / fe): +ves -> Leaf -> Leaves, Knife -> Knives।\n" +
                "• नियम 5 (Irregular): Child -> Children, Man -> Men, Tooth -> Teeth, Foot -> Feet।",
            examplesEncoded = "One book, many books.|एक किताब, कई किताबें।;;Two tomatoes and three mangoes.|दो टमाटर और तीन आम।;;All the cities look clean.|सभी शहर साफ़ दिखते हैं।;;Children love colorful stories.|बच्चों को रंगीन कहानियाँ पसंद हैं।",
            tipHindi = "कुछ शब्द Singular और Plural में एक जैसे रहते हैं—जैसे Sheep, Deer, Information, Hair, Furniture (कभी 'informations' न कहें)।",
            exercisesEncoded = "'City' का सही बहुवचन (Plural) क्या है?|Citys|Cities|Cityes|Citis|1|व्यंजन 't' के बाद 'y' होने पर y हटाकर 'ies' जुड़ता है: Cities।;;'Child' का सही Plural चुनें:|Childs|Childes|Children|Childrens|2|'Child' का अनियमित बहुवचन 'Children' होता है ('Childrens' गलत है)।;;'Box' का सही बहुवचन क्या होगा?|Boxs|Boxes|Boxies|Boxen|1|अंत में 'x' होने के कारण '-es' जुड़ेगा: Boxes।"
        ),
        GrammarLessonEntity(
            chapterNumber = 17,
            titleHindi = "अध्याय 17: Gender (लिंग)",
            titleEnglish = "Gender in English Grammar",
            level = "BEGINNER",
            summaryHindi = "अंग्रेज़ी में संज्ञा (Noun) के लिंग को चार वर्गों में बांटा गया है: Masculine (पुल्लिंग), Feminine (स्त्रीलिंग), Common और Neuter।",
            formula = "Masculine (पुरुष) | Feminine (स्त्री) | Common (दोनों) | Neuter (निर्जीव)",
            explanationHindi = "• Masculine (पुल्लिंग): Boy, Father, King, Lion, Uncle, Husband, Actor।\n" +
                "• Feminine (स्त्रीलिंग): Girl, Mother, Queen, Lioness, Aunt, Wife, Actress।\n" +
                "• Common Gender (उभयलिंग - पुरुष व स्त्री दोनों के लिए): Teacher, Doctor, Student, Friend, Child, Neighbor।\n" +
                "• Neuter Gender (निर्जीव वस्तुएँ): Table, Book, Phone, Tree, Car (इनके लिए 'It' लगता है)।",
            examplesEncoded = "The king and queen greeted people.|राजा और रानी ने लोगों का अभिवादन किया।;;My friend is a clever doctor.|मेरा मित्र एक कुशल डॉक्टर है। (friend, doctor = Common);;This chair is very comfortable.|यह कुर्सी बहुत आरामदायक है। (chair = Neuter);;The lioness protected her cubs.|शेरनी ने अपने शावकों की रक्षा की।",
            tipHindi = "हिंदी के उलट, अंग्रेज़ी में निर्जीव चीजों (जैसे कार, किताब, नदी, पंखा) का कोई पुल्लिंग/स्त्रीलिंग भेद क्रिया में नहीं होता!",
            exercisesEncoded = "'Doctor' किस Gender श्रेणी में आता है?|Masculine|Feminine|Common|Neuter|2|Doctor महिला या पुरुष कोई भी हो सकता है, इसलिए यह Common Gender है।;;'King' का सही Feminine (स्त्रीलिंग) शब्द क्या है?|Princess|Queen|Empress|Lady|1|'King' (राजा) का स्त्रीलिंग 'Queen' (रानी) होता है।;;निम्नलिखित में से कौन-सा Neuter Gender है?|Sister|Teacher|Notebook|Lion|2|'Notebook' एक निर्जीव वस्तु है, इसलिए Neuter Gender है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 18,
            titleHindi = "अध्याय 18: सभी 12 Tenses (काल का संपूर्ण चार्ट)",
            titleEnglish = "All 12 Tenses Complete Guide",
            level = "INTERMEDIATE",
            summaryHindi = "Tenses से पता चलता है कि काम कब हुआ और कितना पूरा हुआ। 3 समय (Present, Past, Future) × 4 प्रकार = कुल 12 Tenses।",
            formula = "Simple | Continuous | Perfect | Perfect Continuous (× Present, Past, Future)",
            explanationHindi = "【A. PRESENT (वर्तमान)】\n" +
                "1. Simple: Sub + V1(s/es) — I read daily. (मैं रोज़ पढ़ता हूँ।)\n" +
                "2. Continuous: is/am/are + V-ing — I am reading. (मैं पढ़ रहा हूँ।)\n" +
                "3. Perfect: has/have + V3 — I have read. (मैंने पढ़ लिया है।)\n" +
                "4. Perfect Cont.: has/have been + V-ing + since/for — I have been reading for an hour.\n\n" +
                "【B. PAST (भूतकाल)】\n" +
                "5. Simple: Sub + V2 — I read yesterday. (मैंने कल पढ़ा।)\n" +
                "6. Continuous: was/were + V-ing — I was reading. (मैं पढ़ रहा था।)\n" +
                "7. Perfect: had + V3 — I had read before 8 PM. (मैं 8 बजे से पहले पढ़ चुका था।)\n" +
                "8. Perfect Cont.: had been + V-ing — I had been reading since morning.\n\n" +
                "【C. FUTURE (भविष्य)】\n" +
                "9. Simple: will + V1 — I will read tomorrow. (मैं कल पढूँगा।)\n" +
                "10. Continuous: will be + V-ing — I will be reading.\n" +
                "11. Perfect: will have + V3 — I will have finished by Monday.\n" +
                "12. Perfect Cont.: will have been + V-ing + for/since।",
            examplesEncoded = "She speaks English clearly.|वह स्पष्ट अंग्रेज़ी बोलती है। (Present Simple);;They were waiting at the gate.|वे गेट पर इंतज़ार कर रहे थे। (Past Continuous);;I have completed five lessons.|मैंने पाँच पाठ पूरे कर लिए हैं। (Present Perfect);;We will start early tomorrow.|हम कल जल्दी शुरू करेंगे। (Future Simple)",
            tipHindi = "निश्चित समय के बिंदु (morning, Monday, 2020) के लिए 'since' और समय की अवधि (2 hours, 5 days) के लिए 'for' लगाएं।",
            exercisesEncoded = "'She is writing a letter.' यह वाक्य किस Tense में है?|Present Simple|Present Continuous|Past Continuous|Present Perfect|1|'is + V-ing' Present Continuous Tense की पहचान है।;;'I went to Pune yesterday.' यहाँ 'went' किस Tense को दर्शाता है?|Simple Present|Simple Past|Simple Future|Past Perfect|1|'went' क्रिया की 2nd Form (V2) है जो Simple Past दर्शाती है।;;अनिश्चित अवधि जैसे '2 hours' के साथ कौन-सा शब्द लगता है?|since|for|at|from|1|समय की अवधि (2 hours, 3 days) के साथ 'for' लगता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 19,
            titleHindi = "अध्याय 19: Helping Verbs (सहायक क्रियाएँ)",
            titleEnglish = "Helping Verbs (Auxiliary Verbs)",
            level = "BEGINNER",
            summaryHindi = "जो क्रियाएँ मुख्य क्रिया (Main Verb) के साथ लगकर Tense, प्रश्न या नकारात्मक वाक्य बनाने में मदद करती हैं, उन्हें Helping Verbs कहते हैं।",
            formula = "Be (is/am/are/was/were) | Do (do/does/did) | Have (has/have/had)",
            explanationHindi = "• Do / Does / Did: Present और Past Simple में प्रश्न और 'not' बनाने में मदद करती हैं।\n" +
                "• Is / Am / Are / Was / Were: Continuous Tenses और Passive Voice बनाती हैं।\n" +
                "• Has / Have / Had: Perfect Tenses (V3 के साथ) बनाती हैं।\n" +
                "• Will / Shall: भविष्य काल (Future) बनाती हैं।",
            examplesEncoded = "Do you speak Hindi?|क्या आप हिंदी बोलते हैं? (Do = Helping Verb);;He did not attend the class.|उसने कक्षा में भाग नहीं लिया।;;They are preparing for exams.|वे परीक्षा की तैयारी कर रहे हैं।;;We have saved all chapters offline.|हमने सभी अध्याय ऑफलाइन सेव कर लिए हैं।",
            tipHindi = "जब किसी वाक्य में 'do / does / did' आ जाए, तो मुख्य क्रिया हमेशा अपने मूल रूप (V1) में लौट आती है!",
            exercisesEncoded = "'___ she know the answer?' सही Helping Verb चुनें:|Do|Does|Are|Is|1|एकवचन कर्ता 'She' के साथ Present Simple प्रश्न में 'Does' लगता है।;;'They ___ not go to school yesterday.':|do|does|did|were|2|बीते कल (yesterday) के लिए V1 'go' के साथ 'did' लगता है।;;'I ___ finished my homework.':|am|has|have|was|2|Present Perfect (finished = V3) में 'I' के साथ 'have' आता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 20,
            titleHindi = "अध्याय 20: Modal Verbs (Can, Could, May, Must, Should)",
            titleEnglish = "Modal Verbs",
            level = "INTERMEDIATE",
            summaryHindi = "Modal Verbs का उपयोग क्षमता, अनुमति, संभावना, सलाह, अनुरोध और कर्तव्य दर्शाने के लिए किया जाता है।",
            formula = "Subject + Modal (can/could/may/might/should/must/would) + V1",
            explanationHindi = "• Can (सकना - क्षमता): I can speak English.\n" +
                "• Could (सका / विनम्र अनुरोध): Could you please help me?\n" +
                "• May (औपचारिक अनुमति / संभावना): May I come in? / It may rain.\n" +
                "• Should (चाहिए - सलाह): You should sleep on time.\n" +
                "• Must (अवश्य चाहिए - अनिवार्यता): We must follow traffic rules.\n" +
                "• Would (चाहूँगा / विनम्र पसंद): I would like some water.",
            examplesEncoded = "Can you pronounce this word?|क्या आप इस शब्द का उच्चारण कर सकते हैं?;;May I ask a grammar question?|क्या मैं व्याकरण का एक प्रश्न पूछ सकता हूँ?;;You should revise daily.|आपको रोज़ाना दोहराना चाहिए।;;Could you please repeat that?|क्या आप कृपया उसे दोहरा सकते हैं?",
            tipHindi = "सभी Modal Verbs के बाद हमेशा V1 (Verb की पहली फॉर्म) लगती है—कभी 'to', '-ing' या '-s' न जोड़ें।",
            exercisesEncoded = "'You ___ wash your hands before eating.' (अच्छी सलाह):|should|would|might|did|0|सलाह देने के लिए 'should' (चाहिए) का प्रयोग किया जाता है।;;बड़ों या शिक्षक से विनम्र अनुमति लेने के लिए कौन-सा Modal श्रेष्ठ है?|Must|May|Should|Had|1|'May I...' औपचारिक और विनम्र अनुमति मांगने का सही तरीका है।;;Modal Verb के बाद क्रिया का कौन-सा रूप लगता है?|V1|V2|V3|V-ing|0|किसी भी Modal (can, should, must आदि) के बाद हमेशा V1 आता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 21,
            titleHindi = "अध्याय 21: Active और Passive Voice",
            titleEnglish = "Active and Passive Voice",
            level = "ADVANCED",
            summaryHindi = "Active Voice में कर्ता (Subject) प्रमुख होता है, जबकि Passive Voice में कार्य (Object/Action) प्रमुख होता है।",
            formula = "Active: Sub + Verb + Obj -> Passive: Obj + be (is/was/will be) + V3 + by Sub",
            explanationHindi = "• Active: Priya wrote a letter. (प्रिया ने पत्र लिखा।)\n" +
                "• Passive: A letter was written by Priya. (प्रिया के द्वारा पत्र लिखा गया।)\n" +
                "• नियम: Active का Object -> Passive का Subject बन जाता है।\n" +
                "• Passive में हमेशा Verb की 3rd Form (V3) का ही प्रयोग होता है!",
            examplesEncoded = "English is spoken worldwide.|पूरी दुनिया में अंग्रेज़ी बोली जाती है।;;The cake was baked by mother.|केक माँ द्वारा बनाया गया था।;;Your parcel will be delivered soon.|आपका पार्सल जल्द पहुंचाया जाएगा।;;The room is cleaned daily.|कमरा रोज़ साफ़ किया जाता है।",
            tipHindi = "अखबार की सुर्खियाँ और ऑफिस नोटिस (जैसे: 'Smoking is prohibited') ज़्यादातर Passive Voice में होते हैं।",
            exercisesEncoded = "'Ram helps Mohan.' का सही Passive Voice चुनें:|Mohan is helped by Ram.|Mohan was helped by Ram.|Ram is helped by Mohan.|Mohan helping Ram.|0|Present Simple Active का Passive 'is/am/are + V3' से बनता है: Mohan is helped by Ram.।;;Passive Voice में मुख्य क्रिया किस रूप में रहती है?|V1|V2|V3|V-ing|2|हर Tense के Passive Voice में हमेशा V3 (Past Participle) लगती है।;;'The letter ___ posted yesterday.' (Passive):|is|was|will be|are|1|भूतकाल (yesterday) के Passive में एकवचन के साथ 'was' आता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 22,
            titleHindi = "अध्याय 22: Direct और Indirect Speech",
            titleEnglish = "Direct and Indirect Speech",
            level = "ADVANCED",
            summaryHindi = "किसी की कही हुई बात को ज्यों का त्यों कहना Direct Speech है, और उसे अपने शब्दों में बताना Indirect (Reported) Speech है।",
            formula = "Direct: He said, \"I am happy.\" -> Indirect: He said that he was happy.",
            explanationHindi = "• Direct Speech में उद्धरण चिह्न (\"...\") का प्रयोग होता है।\n" +
                "• Indirect Speech में चिह्न हटकर अक्सर 'that' जुड़ता है और Reporting Verb भूतकाल (said) में होने पर अंदर का Tense एक कदम पीछे (Present -> Past) चला जाता है।\n" +
                "• बदलाव: today -> that day, tomorrow -> the next day, here -> there, now -> then।",
            examplesEncoded = "She said, \"I like tea.\"|उसने कहा, \"मुझे चाय पसंद है।\" (Direct);;She said that she liked tea.|उसने कहा कि उसे चाय पसंद थी। (Indirect);;Ravi told me that he was busy.|रवि ने मुझे बताया कि वह व्यस्त था।;;The teacher asked me my name.|शिक्षक ने मुझसे मेरा नाम पूछा।",
            tipHindi = "यदि बात कोई सार्वभौमिक सत्य (Universal Truth) हो जैसे 'The sun rises in the east', तो Indirect में Tense नहीं बदलता!",
            exercisesEncoded = "'He said, \"I am busy.\"' का सही Indirect Speech चुनें:|He said that I am busy.|He said that he was busy.|He said he is busy.|He tells he was busy.|1|'I' का 'he' और 'am' का भूतकाल 'was' हो जाता है।;;Indirect Speech में 'tomorrow' किसमें बदल जाता है?|that day|yesterday|the next day|today|2|Indirect Speech में tomorrow -> the next day (या the following day) बनता है।;;'The teacher said, \"The Earth is round.\"' का Indirect होगा:|...the Earth was round.|...the Earth is round.|...the Earth had round.|...the Earth will round.|1|सार्वभौमिक सत्य (Universal Truth) का Tense Indirect Speech में नहीं बदलता।"
        ),
        GrammarLessonEntity(
            chapterNumber = 23,
            titleHindi = "अध्याय 23: Sentence Formation (वाक्य निर्माण)",
            titleEnglish = "Sentence Formation",
            level = "BEGINNER",
            summaryHindi = "सही क्रम में शब्दों को रखकर सार्थक अंग्रेज़ी वाक्य बनाना सीखें—हिंदी और अंग्रेज़ी के वाक्य क्रम में बड़ा अंतर होता है।",
            formula = "English Order: Subject + Verb + Object (SVO)",
            explanationHindi = "• हिंदी क्रम: कर्ता + कर्म + क्रिया (मैं + सेब + खाता हूँ)।\n" +
                "• अंग्रेज़ी क्रम: Subject + Verb + Object (I + eat + an apple)।\n" +
                "• वाक्य के 4 मुख्य प्रकार: Declarative (साधारण), Interrogative (प्रश्न), Imperative (आदेश/निवेदन), Exclamatory (भाव)।\n" +
                "• समय और स्थान बताने वाले शब्द (today, at school) अक्सर वाक्य के अंत में रखे जाते हैं।",
            examplesEncoded = "I drink warm milk daily.|मैं रोज़ गुनगुना दूध पीता हूँ।;;She speaks polite English.|वह विनम्र अंग्रेज़ी बोलती है।;;Please open your grammar book.|कृपया अपनी व्याकरण किताब खोलें। (Imperative);;We learn new words at night.|हम रात को नए शब्द सीखते हैं।",
            tipHindi = "जब भी हिंदी वाक्य को अंग्रेज़ी में बदलें, पहले 'कौन' (Subject), फिर 'क्या काम' (Verb), और फिर 'किस पर/क्या' (Object) सोचें।",
            exercisesEncoded = "अंग्रेज़ी के साधारण वाक्य का सही क्रम क्या होता है?|Subject + Object + Verb|Subject + Verb + Object|Verb + Subject + Object|Object + Verb + Subject|1|अंग्रेज़ी में Subject के तुरंत बाद Verb और फिर Object आता है (SVO)।;;सही वाक्य क्रम चुनें:|Apples eats Riya.|Riya apples eats.|Riya eats apples.|Eats Riya apples.|2|'Riya (Subject) + eats (Verb) + apples (Object)' सही क्रम है।;;आदेश या अनुरोध वाले वाक्य (जैसे Open the door) क्या कहलाते हैं?|Imperative Sentence|Interrogative Sentence|Exclamatory Sentence|Negative Sentence|0|आदेश, सलाह या विनती वाले वाक्यों को Imperative Sentence कहते हैं।"
        ),
        GrammarLessonEntity(
            chapterNumber = 24,
            titleHindi = "अध्याय 24: Question Formation (प्रश्न बनाना)",
            titleEnglish = "Question Formation (Yes/No & WH Questions)",
            level = "INTERMEDIATE",
            summaryHindi = "बातचीत जारी रखने के लिए सवाल पूछना सबसे ज़रूरी कौशल है। अंग्रेज़ी में प्रश्न दो मुख्य तरीकों से बनाए जाते हैं।",
            formula = "1. Helping Verb + Sub + Main Verb? | 2. WH-Word + Helping Verb + Sub + Verb?",
            explanationHindi = "• प्रकार 1 (हाँ/नहीं वाले सवाल): Helping Verb को Subject से पहले रखें:\n" +
                "  - Are you tired? / Do you speak English? / Did he come?\n" +
                "• प्रकार 2 (WH-Questions): What (क्या), Where (कहाँ), When (कब), Why (क्यों), Who (कौन), How (कैसे):\n" +
                "  - Where do you live? / Why are you late? / How did you learn this?",
            examplesEncoded = "Do you practice English every day?|क्या आप रोज़ अंग्रेज़ी का अभ्यास करते हैं?;;Where is the nearest metro station?|सबसे नज़दीकी मेट्रो स्टेशन कहाँ है?;;What are you reading right now?|आप अभी क्या पढ़ रहे हैं?;;How can I improve my speaking?|मैं अपनी बोलचाल कैसे सुधार सकता हूँ?",
            tipHindi = "सबसे आम गलती: 'Where you are going?' गलत है! सही होगा: 'Where are you going?' (WH-word के तुरंत बाद 'are' आएगा)।",
            exercisesEncoded = "सही प्रश्न वाक्य चुनें:|Where you live?|Where do you live?|Where live you?|Do where you live?|1|WH-word 'Where' के तुरंत बाद Helping Verb 'do' और फिर Subject 'you' आता है।;;'क्या वह चाय पीती है?' का सही अनुवाद क्या होगा?|Is she drink tea?|Does she drink tea?|Does she drinks tea?|Do she drink tea?|1|He/She के साथ Present Simple प्रश्न में 'Does' और V1 'drink' लगता है।;;समय पूछने के लिए कौन-सा WH-word प्रयोग होता है?|Where|Why|When|Who|2|'When' का अर्थ 'कब' होता है, जो समय पूछने के काम आता है।"
        ),
        GrammarLessonEntity(
            chapterNumber = 25,
            titleHindi = "अध्याय 25: Negative Sentences (नकारात्मक वाक्य)",
            titleEnglish = "Negative Sentences",
            level = "BEGINNER",
            summaryHindi = "'नहीं' या मनाही वाले वाक्य (Negative Sentences) बनाने के लिए 'not', 'no' या 'never' को सही स्थान पर रखना सीखें।",
            formula = "Subject + Helping Verb + not + Main Verb + Object",
            explanationHindi = "• Is/Am/Are/Was/Were के बाद सीधे 'not' लगाएं: I am not hungry.\n" +
                "• Modal Verbs (can/should/must) के बाद 'not' लगाएं: You should not worry.\n" +
                "• Present Simple (बिना is/are वाले काम): do not (don't) / does not (doesn't) + V1 लगाएं!\n" +
                "• Past Simple (बीता समय): did not (didn't) + V1 लगाएं! (जैसे: He did not go.)",
            examplesEncoded = "I do not understand this word.|मुझे यह शब्द समझ नहीं आता।;;She is not feeling well today.|आज उनकी तबीयत ठीक नहीं लग रही है।;;We did not watch TV last night.|कल रात हमने टीवी नहीं देखा।;;Do not waste clean water.|साफ़ पानी बर्बाद न करें।",
            tipHindi = "कभी भी एक ही वाक्य में दो बार नकारात्मक शब्द न लगाएं—'I didn't see nothing' गलत है; सही वाक्य 'I didn't see anything' है।",
            exercisesEncoded = "'She knows the answer.' का सही Negative वाक्य क्या है?|She not knows the answer.|She does not know the answer.|She do not knows the answer.|She is not know the answer.|1|He/She के Present Simple Negative में 'does not + V1 (know)' लगता है।;;'I went there.' का Negative रूप चुनें:|I didn't went there.|I didn't go there.|I not went there.|I don't went there.|1|'did not' के बाद हमेशा क्रिया की पहली फॉर्म (go) लगती है।;;आदेशात्मक नकारात्मक वाक्य ('वहाँ मत जाओ') की शुरुआत किससे होती है?|No|Not|Do not|Never not|2|किसी काम से मना करने के लिए 'Do not' (Don't) + V1 लगता है: Do not go there."
        )
    )
}
