package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SentenceDao {
    @Query("SELECT COUNT(*) FROM sentences")
    suspend fun getCount(): Int

    @Query("SELECT COUNT(*) FROM sentences")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sentences WHERE isMastered = 1")
    fun observeMasteredCount(): Flow<Int>

    @Query("SELECT * FROM sentences WHERE isDailyBatch = 1 ORDER BY id ASC LIMIT 10")
    fun observeDailySentences(): Flow<List<SentenceEntity>>

    @Query(
        """
        SELECT * FROM sentences
        WHERE (:level = 'ALL' OR level = :level)
          AND (:category = 'ALL' OR category = :category)
          AND (:bookmarkedOnly = 0 OR isBookmarked = 1)
          AND (:query = '' OR english LIKE '%' || :query || '%' OR hindi LIKE '%' || :query || '%')
        ORDER BY isOnlineUpdate DESC, id ASC
        LIMIT 300
        """
    )
    fun observeFilteredSentences(
        level: String,
        category: String,
        bookmarkedOnly: Boolean,
        query: String
    ): Flow<List<SentenceEntity>>

    @Query("SELECT DISTINCT category FROM sentences ORDER BY category ASC")
    fun observeCategories(): Flow<List<String>>

    @Query("SELECT * FROM sentences ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomSentences(limit: Int): List<SentenceEntity>

    @Query("SELECT * FROM sentences WHERE level = :level ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomSentencesForLevel(level: String, limit: Int): List<SentenceEntity>

    @Query("UPDATE sentences SET isDailyBatch = 0 WHERE isDailyBatch = 1")
    suspend fun clearDailyBatch()

    @Query("UPDATE sentences SET isDailyBatch = 1 WHERE id IN (:ids)")
    suspend fun markDailyBatch(ids: List<Int>)

    @Query("UPDATE sentences SET isBookmarked = NOT isBookmarked WHERE id = :id")
    suspend fun toggleBookmark(id: Int)

    @Query("UPDATE sentences SET isMastered = :mastered, practiceCount = practiceCount + 1 WHERE id = :id")
    suspend fun setMastered(id: Int, mastered: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<SentenceEntity>)
}

@Dao
interface VocabularyDao {
    @Query("SELECT COUNT(*) FROM vocabulary")
    suspend fun getCount(): Int

    @Query("SELECT COUNT(*) FROM vocabulary")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM vocabulary WHERE isMastered = 1")
    fun observeMasteredCount(): Flow<Int>

    @Query(
        """
        SELECT * FROM vocabulary
        WHERE (:level = 'ALL' OR level = :level)
          AND (:category = 'ALL' OR category = :category)
          AND (:query = '' OR word LIKE '%' || :query || '%' OR hindiMeaning LIKE '%' || :query || '%')
        ORDER BY isOnlineUpdate DESC, id ASC
        LIMIT 300
        """
    )
    fun observeFilteredVocabulary(level: String, category: String, query: String): Flow<List<VocabularyEntity>>

    @Query(
        """
        SELECT * FROM vocabulary
        WHERE (:chapter = 'ALL' OR category = :chapter)
          AND (:bookmarkedOnly = 0 OR isBookmarked = 1)
          AND (:query = '' OR word LIKE '%' || :query || '%' OR hindiMeaning LIKE '%' || :query || '%' OR exampleEnglish LIKE '%' || :query || '%')
        ORDER BY id ASC
        LIMIT 350
        """
    )
    fun observeVocabBookWords(chapter: String, bookmarkedOnly: Boolean, query: String): Flow<List<VocabularyEntity>>

    @Query("SELECT DISTINCT category FROM vocabulary ORDER BY id ASC")
    fun observeCategories(): Flow<List<String>>

    @Query("UPDATE vocabulary SET isMastered = NOT isMastered WHERE id = :id")
    suspend fun toggleMastered(id: Int)

    @Query("UPDATE vocabulary SET isBookmarked = NOT isBookmarked WHERE id = :id")
    suspend fun toggleBookmark(id: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<VocabularyEntity>)
}

@Dao
interface GrammarDao {
    @Query("SELECT COUNT(*) FROM grammar_lessons")
    suspend fun getCount(): Int

    @Query("SELECT COUNT(*) FROM grammar_lessons")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM grammar_lessons WHERE isCompleted = 1")
    fun observeCompletedCount(): Flow<Int>

    @Query(
        """
        SELECT * FROM grammar_lessons
        WHERE (:level = 'ALL' OR level = :level)
        ORDER BY isOnlineUpdate DESC, chapterNumber ASC, id ASC
        """
    )
    fun observeLessons(level: String): Flow<List<GrammarLessonEntity>>

    @Query(
        """
        SELECT * FROM grammar_lessons
        WHERE (:bookmarkedOnly = 0 OR isBookmarked = 1)
          AND (:query = '' OR titleHindi LIKE '%' || :query || '%' OR titleEnglish LIKE '%' || :query || '%' OR summaryHindi LIKE '%' || :query || '%' OR explanationHindi LIKE '%' || :query || '%')
        ORDER BY chapterNumber ASC, id ASC
        """
    )
    fun observeBookChapters(bookmarkedOnly: Boolean, query: String): Flow<List<GrammarLessonEntity>>

    @Query("UPDATE grammar_lessons SET isCompleted = NOT isCompleted WHERE id = :id")
    suspend fun toggleCompleted(id: Int)

    @Query("UPDATE grammar_lessons SET isBookmarked = NOT isBookmarked WHERE id = :id")
    suspend fun toggleBookmark(id: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<GrammarLessonEntity>)
}

@Dao
interface ConversationDao {
    @Query("SELECT COUNT(*) FROM conversations")
    suspend fun getCount(): Int

    @Query(
        """
        SELECT * FROM conversations
        WHERE (:level = 'ALL' OR level = :level)
        ORDER BY id ASC
        """
    )
    fun observeConversations(level: String): Flow<List<ConversationEntity>>

    @Query("UPDATE conversations SET isCompleted = 1 WHERE id = :id")
    suspend fun markCompleted(id: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ConversationEntity>)
}

@Dao
interface QuizDao {
    @Query("SELECT COUNT(*) FROM quiz_questions")
    suspend fun getCount(): Int

    @Query(
        """
        SELECT * FROM quiz_questions
        WHERE (:level = 'ALL' OR level = :level)
        ORDER BY isOnlineUpdate DESC, RANDOM()
        LIMIT :limit
        """
    )
    suspend fun getQuizQuestions(level: String, limit: Int): List<QuizQuestionEntity>

    @Query("SELECT * FROM quiz_questions ORDER BY isOnlineUpdate DESC, id DESC LIMIT 30")
    fun observeRecentQuestions(): Flow<List<QuizQuestionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<QuizQuestionEntity>)
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1")
    fun observeProgress(): Flow<UserProgressEntity?>

    @Query("SELECT * FROM user_progress WHERE id = 1")
    suspend fun getProgressOnce(): UserProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(progress: UserProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttempt(attempt: PracticeAttemptEntity)

    @Query("SELECT * FROM practice_attempts ORDER BY timestamp DESC LIMIT 15")
    fun observeRecentAttempts(): Flow<List<PracticeAttemptEntity>>
}
