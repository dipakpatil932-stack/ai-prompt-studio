package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SentenceEntity::class,
        VocabularyEntity::class,
        GrammarLessonEntity::class,
        ConversationEntity::class,
        QuizQuestionEntity::class,
        PracticeAttemptEntity::class,
        UserProgressEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class BoloDatabase : RoomDatabase() {
    abstract fun sentenceDao(): SentenceDao
    abstract fun vocabularyDao(): VocabularyDao
    abstract fun grammarDao(): GrammarDao
    abstract fun conversationDao(): ConversationDao
    abstract fun quizDao(): QuizDao
    abstract fun progressDao(): ProgressDao

    companion object {
        @Volatile
        private var INSTANCE: BoloDatabase? = null

        fun getInstance(context: Context): BoloDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BoloDatabase::class.java,
                    "bolo_english.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
