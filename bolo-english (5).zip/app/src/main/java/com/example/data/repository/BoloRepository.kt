package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.ai.AiTeacherRepository
import com.example.data.ai.MistakeAnalysis
import com.example.data.ai.TeacherChatTurn
import com.example.data.local.BoloDatabase
import com.example.data.local.ConversationEntity
import com.example.data.local.DatabaseInitializer
import com.example.data.local.GrammarLessonEntity
import com.example.data.local.LearningLevel
import com.example.data.local.PracticeAttemptEntity
import com.example.data.local.QuizQuestionEntity
import com.example.data.local.SentenceEntity
import com.example.data.local.UserProgressEntity
import com.example.data.local.VocabularyEntity
import com.example.data.network.ConnectivityObserver
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map

class BoloRepository(
    private val database: BoloDatabase,
    private val initializer: DatabaseInitializer,
    private val connectivityObserver: ConnectivityObserver,
    private val aiRepository: AiTeacherRepository
) {
    private val sentenceDao = database.sentenceDao()
    private val vocabDao = database.vocabularyDao()
    private val grammarDao = database.grammarDao()
    private val conversationDao = database.conversationDao()
    private val quizDao = database.quizDao()
    private val progressDao = database.progressDao()

    val isOnline: StateFlow<Boolean> = connectivityObserver.isOnline

    val progress: Flow<UserProgressEntity> = progressDao.observeProgress()
        .map { it ?: UserProgressEntity() }

    val dailySentences: Flow<List<SentenceEntity>> = sentenceDao.observeDailySentences()
    val totalSentenceCount: Flow<Int> = sentenceDao.observeTotalCount()
    val masteredSentenceCount: Flow<Int> = sentenceDao.observeMasteredCount()
    val sentenceCategories: Flow<List<String>> = sentenceDao.observeCategories()

    val totalVocabCount: Flow<Int> = vocabDao.observeTotalCount()
    val masteredVocabCount: Flow<Int> = vocabDao.observeMasteredCount()
    val vocabCategories: Flow<List<String>> = vocabDao.observeCategories()

    val totalGrammarCount: Flow<Int> = grammarDao.observeTotalCount()
    val completedGrammarCount: Flow<Int> = grammarDao.observeCompletedCount()

    val recentAttempts: Flow<List<PracticeAttemptEntity>> = progressDao.observeRecentAttempts()

    suspend fun initializeOfflineData() {
        initializer.ensureInitialized()
    }

    fun observeSentences(
        level: String,
        category: String,
        bookmarkedOnly: Boolean,
        query: String
    ): Flow<List<SentenceEntity>> =
        sentenceDao.observeFilteredSentences(level, category, bookmarkedOnly, query)

    fun observeVocabulary(level: String, category: String, query: String): Flow<List<VocabularyEntity>> =
        vocabDao.observeFilteredVocabulary(level, category, query)

    fun observeVocabBookWords(chapter: String, bookmarkedOnly: Boolean, query: String): Flow<List<VocabularyEntity>> =
        vocabDao.observeVocabBookWords(chapter, bookmarkedOnly, query)

    fun observeGrammarLessons(level: String): Flow<List<GrammarLessonEntity>> =
        grammarDao.observeLessons(level)

    fun observeGrammarBookChapters(bookmarkedOnly: Boolean, query: String): Flow<List<GrammarLessonEntity>> =
        grammarDao.observeBookChapters(bookmarkedOnly, query)

    fun observeConversations(level: String): Flow<List<ConversationEntity>> =
        conversationDao.observeConversations(level)

    suspend fun getQuizRound(level: String, count: Int = 8): List<QuizQuestionEntity> {
        val levelItems = quizDao.getQuizQuestions(level, count)
        return if (levelItems.size >= 5) levelItems else quizDao.getQuizQuestions("ALL", count)
    }

    suspend fun getRandomPracticeSentences(level: String, limit: Int = 20): List<SentenceEntity> {
        return sentenceDao.getRandomSentencesForLevel(level, limit)
            .ifEmpty { sentenceDao.getRandomSentences(limit) }
    }

    suspend fun toggleSentenceBookmark(id: Int) {
        sentenceDao.toggleBookmark(id)
    }

    suspend fun setSentenceMastered(id: Int, mastered: Boolean) {
        sentenceDao.setMastered(id, mastered)
        if (mastered) awardXp(10)
    }

    suspend fun toggleVocabMastered(id: Int, currentlyMastered: Boolean) {
        vocabDao.toggleMastered(id)
        if (!currentlyMastered) awardXp(10)
    }

    suspend fun toggleVocabBookmark(id: Int) {
        vocabDao.toggleBookmark(id)
    }

    suspend fun toggleGrammarCompleted(id: Int, currentlyCompleted: Boolean) {
        grammarDao.toggleCompleted(id)
        if (!currentlyCompleted) awardXp(20)
    }

    suspend fun toggleGrammarBookmark(id: Int) {
        grammarDao.toggleBookmark(id)
    }

    suspend fun markConversationCompleted(id: Int) {
        conversationDao.markCompleted(id)
        awardXp(20)
    }

    suspend fun updateSelectedLevel(level: LearningLevel) {
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(current.copy(selectedLevel = level.code))
    }

    suspend fun refreshDaily10ForLevel(level: LearningLevel) {
        initializer.refreshDailyBatchForLevel(level.code)
    }

    suspend fun updateTtsSpeed(speed: Float) {
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(current.copy(ttsSpeed = speed.coerceIn(0.6f, 1.4f)))
    }

    suspend fun updateGrammarBookPreferences(textScale: Float? = null, lastChapter: Int? = null) {
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(
            current.copy(
                grammarBookTextScale = textScale?.coerceIn(0.85f, 1.4f) ?: current.grammarBookTextScale,
                lastGrammarChapter = lastChapter ?: current.lastGrammarChapter
            )
        )
    }

    suspend fun updateVocabBookPreferences(textScale: Float? = null, lastChapter: String? = null) {
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(
            current.copy(
                vocabBookTextScale = textScale?.coerceIn(0.85f, 1.4f) ?: current.vocabBookTextScale,
                lastVocabChapter = lastChapter ?: current.lastVocabChapter
            )
        )
    }

    suspend fun recordQuizCompletion(score: Int, totalQuestions: Int) {
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(
            current.copy(
                quizzesTaken = current.quizzesTaken + 1,
                totalQuizScore = current.totalQuizScore + score,
                totalQuizQuestions = current.totalQuizQuestions + totalQuestions,
                xpPoints = current.xpPoints + (score * 5) + 10
            )
        )
    }

    suspend fun recordSpeakingAttempt(
        targetEnglish: String,
        spokenText: String,
        accuracyPercent: Int,
        aiFeedbackHindi: String = ""
    ) {
        progressDao.insertAttempt(
            PracticeAttemptEntity(
                targetEnglish = targetEnglish,
                spokenText = spokenText,
                accuracyPercent = accuracyPercent,
                aiFeedbackHindi = aiFeedbackHindi
            )
        )
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(
            current.copy(
                speakingAttempts = current.speakingAttempts + 1,
                totalSpeakingScore = current.totalSpeakingScore + accuracyPercent,
                xpPoints = current.xpPoints + if (accuracyPercent >= 70) 15 else 8
            )
        )
    }

    private suspend fun awardXp(points: Int) {
        val current = progressDao.getProgressOnce() ?: UserProgressEntity()
        progressDao.upsertProgress(current.copy(xpPoints = current.xpPoints + points))
    }

    // Online AI Features (always check connectivity safely)
    fun checkOnlineNow(): Boolean = connectivityObserver.checkOnlineNow()

    fun streamTeacherChat(
        history: List<TeacherChatTurn>,
        message: String,
        level: LearningLevel
    ): Flow<String> = aiRepository.streamTeacherReply(history, message, level)

    suspend fun explainMistakeInHindi(
        userSentence: String,
        targetSentence: String?,
        level: LearningLevel
    ): Result<MistakeAnalysis> {
        if (!connectivityObserver.checkOnlineNow()) {
            return Result.failure(
                Exception("अभी इंटरनेट उपलब्ध नहीं है। ऑफलाइन बोलने के स्कोर ऊपर दिखाए गए हैं; इंटरनेट आने पर AI हिंदी में विस्तार से समझाएगा।")
            )
        }
        return aiRepository.explainMistakeInHindi(userSentence, targetSentence, level)
    }

    suspend fun downloadOnlineLessonUpdates(level: LearningLevel): Result<String> {
        if (!connectivityObserver.checkOnlineNow()) {
            return Result.failure(
                Exception("इंटरनेट कनेक्शन नहीं है। ऑफलाइन पाठ बिना इंटरनेट के चलते रहेंगे!")
            )
        }
        val result = aiRepository.fetchOnlineLessonUpdate(level)
        return result.map { bundle ->
            database.withTransaction {
                sentenceDao.insertAll(bundle.sentences)
                vocabDao.insertAll(bundle.vocabulary)
                quizDao.insertAll(bundle.quizQuestions)
            }
            "${bundle.sentences.size} नए वाक्य, ${bundle.vocabulary.size} नए शब्द और ${bundle.quizQuestions.size} नए क्विज़ प्रश्न ऑफलाइन के लिए सेव हो गए!"
        }
    }
}
