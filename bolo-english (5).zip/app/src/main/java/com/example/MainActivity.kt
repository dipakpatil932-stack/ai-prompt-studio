package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ai.configureAppCheck
import com.example.data.local.LearningLevel
import com.example.data.local.SentenceEntity
import com.example.ui.screens.AiTeacherScreen
import com.example.ui.screens.GrammarBookScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LearnScreen
import com.example.ui.screens.PracticeScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VocabBookScreen
import com.example.ui.theme.BoloEnglishTheme
import com.example.ui.viewmodel.BoloViewModel

object Routes {
    const val HOME = "home"
    const val LEARN = "learn"
    const val PRACTICE = "practice"
    const val AI_TEACHER = "ai_teacher"
    const val PROGRESS = "progress"
    const val GRAMMAR_BOOK = "grammar_book"
    const val VOCAB_BOOK = "vocab_book"
}

private data class NavDestination(
    val route: String,
    val labelHindi: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val navDestinations = listOf(
    NavDestination(Routes.HOME, "होम", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    NavDestination(Routes.LEARN, "सीखें", Icons.AutoMirrored.Filled.MenuBook, Icons.AutoMirrored.Outlined.MenuBook, "nav_learn"),
    NavDestination(Routes.PRACTICE, "अभ्यास", Icons.Filled.Mic, Icons.Outlined.Mic, "nav_practice"),
    NavDestination(Routes.AI_TEACHER, "AI टीचर", Icons.AutoMirrored.Filled.Chat, Icons.AutoMirrored.Outlined.Chat, "nav_ai_teacher"),
    NavDestination(Routes.PROGRESS, "प्रगति", Icons.Filled.BarChart, Icons.Outlined.BarChart, "nav_progress")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before UI, ViewModels, or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            BoloEnglishTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BoloEnglishApp()
                }
            }
        }
    }
}

@Composable
fun BoloEnglishApp(viewModel: BoloViewModel = viewModel()) {
    val isInitializing by viewModel.isInitializing.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    val dailySentences by viewModel.dailySentences.collectAsStateWithLifecycle()
    val totalSentenceCount by viewModel.totalSentenceCount.collectAsStateWithLifecycle()
    val masteredSentenceCount by viewModel.masteredSentenceCount.collectAsStateWithLifecycle()
    val totalVocabCount by viewModel.totalVocabCount.collectAsStateWithLifecycle()
    val masteredVocabCount by viewModel.masteredVocabCount.collectAsStateWithLifecycle()
    val totalGrammarCount by viewModel.totalGrammarCount.collectAsStateWithLifecycle()
    val completedGrammarCount by viewModel.completedGrammarCount.collectAsStateWithLifecycle()

    val sentences by viewModel.filteredSentences.collectAsStateWithLifecycle()
    val sentenceCategories by viewModel.sentenceCategories.collectAsStateWithLifecycle()
    val sentenceFilter by viewModel.sentenceFilter.collectAsStateWithLifecycle()

    val vocabulary by viewModel.filteredVocabulary.collectAsStateWithLifecycle()
    val vocabCategories by viewModel.vocabCategories.collectAsStateWithLifecycle()
    val vocabFilter by viewModel.vocabFilter.collectAsStateWithLifecycle()

    val grammarLessons by viewModel.grammarLessons.collectAsStateWithLifecycle()
    val grammarLevelFilter by viewModel.grammarLevelFilter.collectAsStateWithLifecycle()

    val grammarBookChapters by viewModel.grammarBookChapters.collectAsStateWithLifecycle()
    val grammarBookFilter by viewModel.grammarBookFilter.collectAsStateWithLifecycle()

    val vocabBookWords by viewModel.vocabBookWords.collectAsStateWithLifecycle()
    val vocabBookFilter by viewModel.vocabBookFilter.collectAsStateWithLifecycle()

    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val conversationLevelFilter by viewModel.conversationLevelFilter.collectAsStateWithLifecycle()

    val practiceSentence by viewModel.practiceSentence.collectAsStateWithLifecycle()
    val speechState by viewModel.speechManager.state.collectAsStateWithLifecycle()
    val spokenInputText by viewModel.spokenInputText.collectAsStateWithLifecycle()
    val evaluation by viewModel.evaluation.collectAsStateWithLifecycle()
    val mistakeState by viewModel.mistakeState.collectAsStateWithLifecycle()

    val quizState by viewModel.quizState.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val aiChatState by viewModel.aiChatState.collectAsStateWithLifecycle()
    val onlineUpdateState by viewModel.onlineUpdateState.collectAsStateWithLifecycle()
    val recentAttempts by viewModel.recentAttempts.collectAsStateWithLifecycle()

    var learnTab by rememberSaveable { mutableIntStateOf(0) }
    var practiceTab by rememberSaveable { mutableIntStateOf(0) }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: Routes.HOME

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    var showSplash by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(isInitializing) {
        if (!isInitializing && showSplash) {
            delay(1500L)
            showSplash = false
        }
    }

    if (showSplash || isInitializing) {
        SplashScreen(
            isInitializing = isInitializing,
            onContinue = {
                if (!isInitializing) {
                    showSplash = false
                }
            }
        )
        return
    }

    val showMainChrome = currentRoute !in setOf(Routes.GRAMMAR_BOOK, Routes.VOCAB_BOOK)

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail && showMainChrome) {
                    NavigationBar {
                        navDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.labelHindi
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.labelHindi,
                                        maxLines = 1,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && showMainChrome) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        navDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.labelHindi
                                    )
                                },
                                label = { Text(dest.labelHindi) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = Routes.HOME,
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 840.dp)
                    ) {
                        composable(Routes.HOME) {
                            HomeScreen(
                                isOnline = isOnline,
                                progress = progress,
                                dailySentences = dailySentences,
                                totalSentenceCount = totalSentenceCount,
                                onlineUpdateState = onlineUpdateState,
                                onSelectLevel = { lvl ->
                                    viewModel.selectLearningLevel(lvl)
                                },
                                onRefreshDaily10 = { viewModel.refreshDailySentences() },
                                onSpeakSentence = { text, slow -> viewModel.speakEnglish(text, slow) },
                                onToggleDailyMastered = { s ->
                                    viewModel.setSentenceMastered(s.id, !s.isMastered)
                                },
                                onPracticeDailySentence = { s ->
                                    viewModel.setPracticeSentence(s)
                                    practiceTab = 0
                                    navigateToTab(Routes.PRACTICE)
                                },
                                onNavigateToLearnTab = { tab ->
                                    learnTab = tab
                                    navigateToTab(Routes.LEARN)
                                },
                                onNavigateToPracticeTab = { tab ->
                                    practiceTab = tab
                                    navigateToTab(Routes.PRACTICE)
                                },
                                onNavigateToGrammarBook = {
                                    navController.navigate(Routes.GRAMMAR_BOOK) { launchSingleTop = true }
                                },
                                onNavigateToVocabBook = {
                                    navController.navigate(Routes.VOCAB_BOOK) { launchSingleTop = true }
                                },
                                onNavigateToAiTeacher = { navigateToTab(Routes.AI_TEACHER) },
                                onNavigateToProgress = { navigateToTab(Routes.PROGRESS) },
                                onDownloadOnlineUpdates = { viewModel.downloadOnlineUpdates() },
                                onDismissUpdateStatus = { viewModel.dismissOnlineUpdateStatus() }
                            )
                        }

                        composable(Routes.LEARN) {
                            LearnScreen(
                                selectedTab = learnTab,
                                onSelectTab = { learnTab = it },
                                isOnline = isOnline,
                                totalSentenceCount = totalSentenceCount,
                                sentences = sentences,
                                sentenceCategories = sentenceCategories,
                                sentenceFilter = sentenceFilter,
                                onUpdateSentenceFilter = { viewModel.updateSentenceFilter(it) },
                                onToggleSentenceBookmark = { viewModel.toggleSentenceBookmark(it) },
                                onToggleSentenceMastered = { s ->
                                    viewModel.setSentenceMastered(s.id, !s.isMastered)
                                },
                                onPracticeSentenceMic = { s ->
                                    viewModel.setPracticeSentence(s)
                                    practiceTab = 0
                                    navigateToTab(Routes.PRACTICE)
                                },
                                vocabulary = vocabulary,
                                vocabCategories = vocabCategories,
                                vocabFilter = vocabFilter,
                                onUpdateVocabFilter = { viewModel.updateVocabFilter(it) },
                                onToggleVocabMastered = { viewModel.toggleVocabMastered(it) },
                                grammarLessons = grammarLessons,
                                grammarLevelFilter = grammarLevelFilter,
                                onSelectGrammarLevel = { viewModel.setGrammarLevelFilter(it) },
                                onToggleGrammarCompleted = { viewModel.toggleGrammarCompleted(it) },
                                conversations = conversations,
                                conversationLevelFilter = conversationLevelFilter,
                                onSelectConversationLevel = { viewModel.setConversationLevelFilter(it) },
                                onMarkConversationCompleted = { viewModel.markConversationCompleted(it) },
                                onPracticeConversationLine = { eng, hin ->
                                    viewModel.setPracticeSentence(
                                        SentenceEntity(
                                            english = eng,
                                            hindi = hin,
                                            pronunciationHint = "",
                                            category = "Conversation",
                                            level = progress.selectedLevel
                                        )
                                    )
                                    practiceTab = 0
                                    navigateToTab(Routes.PRACTICE)
                                },
                                onSpeakEnglish = { text, slow -> viewModel.speakEnglish(text, slow) }
                            )
                        }

                        composable(Routes.PRACTICE) {
                            PracticeScreen(
                                selectedTab = practiceTab,
                                onSelectTab = { practiceTab = it },
                                isOnline = isOnline,
                                targetSentence = practiceSentence,
                                speechState = speechState,
                                spokenInputText = spokenInputText,
                                evaluation = evaluation,
                                mistakeState = mistakeState,
                                onSpeakEnglish = { text, slow -> viewModel.speakEnglish(text, slow) },
                                onNextSentence = { viewModel.loadNextPracticeSentence() },
                                onStartMic = { viewModel.startMicPractice() },
                                onStopMic = { viewModel.stopMicPractice() },
                                onUpdateSpokenText = { viewModel.updateSpokenInputText(it) },
                                onEvaluateText = { viewModel.evaluateSpokenText() },
                                onExplainMistakeWithAi = { custom, cmp ->
                                    viewModel.explainMistakeWithAi(custom, cmp)
                                },
                                quizState = quizState,
                                onStartQuiz = { lvl -> viewModel.startNewQuiz(lvl) },
                                onSelectQuizOption = { opt -> viewModel.selectQuizAnswer(opt) },
                                onNextQuizQuestion = { viewModel.nextQuizQuestion() }
                            )
                        }

                        composable(Routes.AI_TEACHER) {
                            AiTeacherScreen(
                                isOnline = isOnline,
                                selectedLevel = LearningLevel.fromCode(progress.selectedLevel),
                                messages = chatMessages,
                                chatState = aiChatState,
                                speechState = speechState,
                                mistakeState = mistakeState,
                                onSendMessage = { viewModel.sendTeacherMessage(it) },
                                onSpeakText = { viewModel.speakEnglish(it, false) },
                                onStartVoiceInput = { viewModel.startMicPractice() },
                                onCheckSentenceMistake = { text ->
                                    viewModel.explainMistakeWithAi(text, compareWithTarget = false)
                                },
                                onClearError = { viewModel.clearAiChatError() },
                                onOpenOfflineSentences = {
                                    learnTab = 0
                                    navigateToTab(Routes.LEARN)
                                },
                                onOpenOfflineSpeaking = {
                                    practiceTab = 0
                                    navigateToTab(Routes.PRACTICE)
                                }
                            )
                        }

                        composable(Routes.PROGRESS) {
                            ProgressScreen(
                                isOnline = isOnline,
                                progress = progress,
                                totalSentences = totalSentenceCount,
                                masteredSentences = masteredSentenceCount,
                                totalVocab = totalVocabCount,
                                masteredVocab = masteredVocabCount,
                                totalGrammar = totalGrammarCount,
                                completedGrammar = completedGrammarCount,
                                recentAttempts = recentAttempts,
                                onUpdateTtsSpeed = { viewModel.updateTtsSpeed(it) }
                            )
                        }

                        composable(Routes.GRAMMAR_BOOK) {
                            GrammarBookScreen(
                                isOnline = isOnline,
                                chapters = grammarBookChapters,
                                filter = grammarBookFilter,
                                textScale = progress.grammarBookTextScale,
                                lastChapterNumber = progress.lastGrammarChapter,
                                completedCount = completedGrammarCount,
                                totalCount = totalGrammarCount,
                                onUpdateFilter = { viewModel.updateGrammarBookFilter(it) },
                                onUpdateTextScale = { viewModel.updateGrammarBookTextScale(it) },
                                onSelectChapterNumber = { viewModel.setLastGrammarChapter(it) },
                                onToggleCompleted = { viewModel.toggleGrammarCompleted(it) },
                                onToggleBookmark = { viewModel.toggleGrammarBookmark(it) },
                                onSpeakEnglish = { text -> viewModel.speakEnglish(text, false) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(Routes.VOCAB_BOOK) {
                            VocabBookScreen(
                                isOnline = isOnline,
                                words = vocabBookWords,
                                availableChapters = vocabCategories,
                                filter = vocabBookFilter,
                                textScale = progress.vocabBookTextScale,
                                totalVocabCount = totalVocabCount,
                                masteredVocabCount = masteredVocabCount,
                                onUpdateFilter = { viewModel.updateVocabBookFilter(it) },
                                onSelectChapter = { viewModel.setLastVocabChapter(it) },
                                onUpdateTextScale = { viewModel.updateVocabBookTextScale(it) },
                                onToggleMastered = { viewModel.toggleVocabMastered(it) },
                                onToggleBookmark = { viewModel.toggleVocabBookmark(it) },
                                onSpeakEnglish = { text -> viewModel.speakEnglish(text, false) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
