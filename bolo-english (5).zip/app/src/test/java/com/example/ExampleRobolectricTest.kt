package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.BoloDatabase
import com.example.data.local.DatabaseInitializer
import com.example.data.local.LearningLevel
import com.example.data.local.SentenceEntity
import com.example.data.local.UserProgressEntity
import com.example.ui.screens.AiTeacherScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.BoloEnglishTheme
import com.example.ui.viewmodel.AiChatUiState
import com.example.ui.viewmodel.ChatMessageUi
import com.example.ui.viewmodel.MistakeCheckUiState
import com.example.ui.viewmodel.OnlineUpdateUiState
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `read string from context returns Bolo English`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Bolo English", appName)
    }

    @Test
    fun `offline room database seeds 5000 sentences and daily 10`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, BoloDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val initializer = DatabaseInitializer(context, db)
            initializer.ensureInitialized()

            assertEquals(5000, db.sentenceDao().getCount())
            assertTrue(db.vocabularyDao().getCount() >= 2000)
            assertEquals(25, db.grammarDao().getCount())
            assertTrue(db.conversationDao().getCount() >= 8)
            assertTrue(db.quizDao().getCount() >= 25)

            val daily = db.sentenceDao().observeDailySentences().first()
            assertEquals(10, daily.size)

            // Test offline search query
            val searchRes = db.sentenceDao().observeFilteredSentences("ALL", "ALL", false, "water").first()
            assertTrue(searchRes.isNotEmpty())

            // Test vocabulary book chapters & search
            val vocabCats = db.vocabularyDao().observeCategories().first()
            assertEquals(14, vocabCats.size)
            val vocabSearch = db.vocabularyDao().observeVocabBookWords("ALL", false, "Mango").first()
            assertTrue(vocabSearch.any { it.word.equals("Mango", ignoreCase = true) })
        } finally {
            db.close()
        }
    }

    @Test
    fun `home screen renders offline status badge daily 10 and both new book options`() {
        val sampleDaily = listOf(
            SentenceEntity(
                id = 1,
                english = "Good morning, how are you?",
                hindi = "सुप्रभात, आप कैसे हैं?",
                pronunciationHint = "गुड मॉर्निंग, हाउ आर यू?",
                category = "Greetings",
                level = "BEGINNER",
                isDailyBatch = true
            )
        )
        var selectedLevel = LearningLevel.BEGINNER
        var openedGrammarBook = false
        var openedVocabBook = false

        composeTestRule.setContent {
            BoloEnglishTheme {
                HomeScreen(
                    isOnline = false,
                    progress = UserProgressEntity(xpPoints = 120, streakDays = 3),
                    dailySentences = sampleDaily,
                    totalSentenceCount = 5000,
                    onlineUpdateState = OnlineUpdateUiState.Idle,
                    onSelectLevel = { selectedLevel = it },
                    onRefreshDaily10 = {},
                    onSpeakSentence = { _, _ -> },
                    onToggleDailyMastered = {},
                    onPracticeDailySentence = {},
                    onNavigateToLearnTab = {},
                    onNavigateToPracticeTab = {},
                    onNavigateToGrammarBook = { openedGrammarBook = true },
                    onNavigateToVocabBook = { openedVocabBook = true },
                    onNavigateToAiTeacher = {},
                    onNavigateToProgress = {},
                    onDownloadOnlineUpdates = {},
                    onDismissUpdateStatus = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("home_header_logo").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_hero_logo").assertIsDisplayed()
        composeTestRule.onNodeWithTag("online_status_badge").assertIsDisplayed()
        composeTestRule.onNodeWithText("ऑफलाइन").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("level_pill_intermediate"))
        composeTestRule.onNodeWithTag("level_pill_intermediate").performClick()
        assertEquals(LearningLevel.INTERMEDIATE, selectedLevel)

        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("tile_grammar_book"))
        composeTestRule.onNodeWithTag("tile_grammar_book").performClick()
        assertTrue(openedGrammarBook)

        composeTestRule.onNodeWithTag("tile_vocab_book").performClick()
        assertTrue(openedVocabBook)
    }

    @Test
    fun `grammar book screen opens chapter reading view and exercises`() {
        val chapters = com.example.data.seed.GrammarSeed.getLessons().mapIndexed { idx, ch ->
            ch.copy(id = idx + 1)
        }
        var selectedChNum = 1

        composeTestRule.setContent {
            BoloEnglishTheme {
                com.example.ui.screens.GrammarBookScreen(
                    isOnline = false,
                    chapters = chapters,
                    filter = com.example.ui.viewmodel.GrammarBookFilter(),
                    textScale = 1.0f,
                    lastChapterNumber = 1,
                    completedCount = 0,
                    totalCount = chapters.size,
                    onUpdateFilter = {},
                    onUpdateTextScale = {},
                    onSelectChapterNumber = { selectedChNum = it },
                    onToggleCompleted = {},
                    onToggleBookmark = {},
                    onSpeakEnglish = {},
                    onBack = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("grammar_book_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("grammar_chapter_card_1").performClick()
        composeTestRule.waitForIdle()
        assertEquals(1, selectedChNum)
        composeTestRule.onNodeWithTag("grammar_next_chapter_btn").performClick()
        assertEquals(2, selectedChNum)
    }

    @Test
    fun `vocab book screen renders chapters and words`() {
        val sampleWords = listOf(
            com.example.data.local.VocabularyEntity(
                id = 1,
                word = "Always",
                hindiMeaning = "हमेशा",
                pronunciation = "ऑलवेज़",
                partOfSpeech = "Adverb",
                exampleEnglish = "Always speak the truth.",
                exampleHindi = "हमेशा सच बोलो।",
                category = "Daily Use Words",
                level = "BEGINNER"
            )
        )
        var selectedChapter = "Daily Use Words"

        composeTestRule.setContent {
            BoloEnglishTheme {
                com.example.ui.screens.VocabBookScreen(
                    isOnline = false,
                    words = sampleWords,
                    availableChapters = com.example.ui.screens.VOCAB_BOOK_CHAPTERS,
                    filter = com.example.ui.viewmodel.VocabBookFilter(),
                    textScale = 1.0f,
                    totalVocabCount = 2067,
                    masteredVocabCount = 0,
                    onUpdateFilter = {},
                    onSelectChapter = { selectedChapter = it },
                    onUpdateTextScale = {},
                    onToggleMastered = {},
                    onToggleBookmark = {},
                    onSpeakEnglish = {},
                    onBack = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("vocab_book_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("vocab_word_list")
            .performScrollToNode(androidx.compose.ui.test.hasText("Always"))
        composeTestRule.onNodeWithText("Always").assertIsDisplayed()
        composeTestRule.onNodeWithTag("vocab_word_list")
            .performScrollToNode(androidx.compose.ui.test.hasText("अर्थ: हमेशा"))
        composeTestRule.onNodeWithText("अर्थ: हमेशा").assertIsDisplayed()
        composeTestRule.onNodeWithTag("vocab_next_chapter_btn").performClick()
        assertEquals("घर और परिवार", selectedChapter)
    }

    @Test
    fun `ai teacher screen handles offline and online states gracefully`() {
        var sentMessage = ""
        composeTestRule.setContent {
            BoloEnglishTheme {
                AiTeacherScreen(
                    isOnline = false,
                    selectedLevel = LearningLevel.BEGINNER,
                    messages = listOf(
                        ChatMessageUi("1", true, "नमस्ते! मैं प्रिया मैम हूँ।")
                    ),
                    chatState = AiChatUiState.Idle,
                    speechState = com.example.data.speech.SpeechUiState.Idle,
                    mistakeState = MistakeCheckUiState.Idle,
                    onSendMessage = { sentMessage = it },
                    onSpeakText = {},
                    onStartVoiceInput = {},
                    onCheckSentenceMistake = {},
                    onClearError = {},
                    onOpenOfflineSentences = {},
                    onOpenOfflineSpeaking = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("ऑफलाइन मोड सक्रिय है").assertIsDisplayed()
        composeTestRule.onNodeWithText("5000 वाक्य पढ़ें").assertIsDisplayed()
    }

    @Test
    fun `ai teacher screen sends message when online`() {
        var sentMessage = ""
        composeTestRule.setContent {
            BoloEnglishTheme {
                AiTeacherScreen(
                    isOnline = true,
                    selectedLevel = LearningLevel.INTERMEDIATE,
                    messages = listOf(
                        ChatMessageUi("1", true, "Hello! How can I help you today?")
                    ),
                    chatState = AiChatUiState.Idle,
                    speechState = com.example.data.speech.SpeechUiState.Idle,
                    mistakeState = MistakeCheckUiState.Idle,
                    onSendMessage = { sentMessage = it },
                    onSpeakText = {},
                    onStartVoiceInput = {},
                    onCheckSentenceMistake = {},
                    onClearError = {},
                    onOpenOfflineSentences = {},
                    onOpenOfflineSpeaking = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("ऑनलाइन").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_chat_input").performTextInput("Hello teacher")
        composeTestRule.onNodeWithTag("ai_chat_send_btn").performClick()
        assertEquals("Hello teacher", sentMessage)
    }

    @Test
    fun `splash screen renders uploaded Bolo English logo and continues on tap when ready`() {
        var continued = false
        composeTestRule.setContent {
            BoloEnglishTheme {
                SplashScreen(
                    isInitializing = false,
                    onContinue = { continued = true }
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("splash_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("splash_logo_image").assertIsDisplayed()
        composeTestRule.onNodeWithTag("splash_continue_btn").performClick()
        assertTrue(continued)
    }
}
