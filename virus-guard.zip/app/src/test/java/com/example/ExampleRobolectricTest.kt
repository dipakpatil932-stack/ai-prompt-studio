package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.security.analyzer.MobileHackingEngine
import com.example.security.analyzer.NetworkAnalyzer
import com.example.security.analyzer.PermissionRiskAnalyzer
import com.example.security.analyzer.RecommendationEngine
import com.example.security.analyzer.RiskScoreEngine
import com.example.security.analyzer.SafeLinkAnalyzer
import com.example.security.analyzer.SecurityCheckEngine
import com.example.security.model.CheckStatus
import com.example.security.model.CompromiseStatus
import com.example.security.model.RiskLevel
import com.example.security.model.ScanType
import com.example.security.scanner.OfflineThreatIntelligenceProvider
import com.example.security.scanner.SignatureDatabase
import com.example.ui.viewmodel.AppFilter
import com.example.ui.viewmodel.HackingSolutionTab
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.SecurityViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.security.MessageDigest

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private val testDispatcher = StandardTestDispatcher()

  @Before
  fun setUp() {
    Dispatchers.setMain(testDispatcher)
  }

  @After
  fun tearDown() {
    Dispatchers.resetMain()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Virus Guard", appName)
  }

  @Test
  fun `verify signature database status disclosure`() {
    assertTrue(SignatureDatabase.STATUS_DISCLOSURE.contains("No external threat intelligence database"))
    val offlineProvider = OfflineThreatIntelligenceProvider()
    assertFalse(offlineProvider.isConnected)
    assertEquals("Offline Analysis Engine", offlineProvider.providerName)
  }

  @Test
  fun `permission analyzer flags sensitive combinations`() {
    val result = PermissionRiskAnalyzer.analyze(
      packageName = "com.sample.suspicious",
      appName = "Sample App",
      requestedPermissions = listOf(
        "android.permission.RECEIVE_SMS",
        "android.permission.SEND_SMS",
        "android.permission.READ_PHONE_STATE"
      ),
      isSystemApp = false
    )
    assertEquals(RiskLevel.REVIEW_RECOMMENDED, result.riskLevel)
    assertTrue(result.highRiskCombinations.isNotEmpty())
  }

  @Test
  fun `legitimate apps like whatsapp and chrome are never falsely flagged`() {
    val whatsappResult = PermissionRiskAnalyzer.analyze(
      packageName = "com.whatsapp",
      appName = "WhatsApp",
      requestedPermissions = listOf(
        "android.permission.CAMERA",
        "android.permission.RECORD_AUDIO",
        "android.permission.READ_CONTACTS",
        "android.permission.ACCESS_FINE_LOCATION"
      ),
      isSystemApp = false
    )
    assertEquals(RiskLevel.NORMAL, whatsappResult.riskLevel)
    assertEquals(0, whatsappResult.highRiskCombinations.size)
    assertTrue(SignatureDatabase.isRecognizedLegitimateApp("com.whatsapp"))
    assertTrue(SignatureDatabase.isRecognizedLegitimateApp("com.android.chrome"))
  }

  @Test
  fun `security score calculator produces transparent bounded score`() {
    val pendingScore = com.example.security.model.SecurityScoreCalculator.calculate(
      apps = emptyList(),
      hasBeenScanned = false
    )
    assertEquals(80, pendingScore.score)
    assertTrue(pendingScore.factors.isNotEmpty())

    val evaluatedScore = com.example.security.model.SecurityScoreCalculator.calculate(
      apps = emptyList(),
      hasBeenScanned = true
    )
    assertEquals(100, evaluatedScore.score)
  }

  // ==========================================
  // Safe Link Analyzer QA Tests
  // ==========================================
  @Test
  fun `safe link analyzer passes legitimate HTTPS URL`() {
    val analyzer = SafeLinkAnalyzer()
    val result = analyzer.analyzeUrl("https://www.example.com")
    assertEquals(RiskLevel.NORMAL, result.riskLevel)
    assertTrue(result.isHttps)
    assertFalse(result.hasIpHost)
    assertFalse(result.hasPunycode)
    assertFalse(result.hasEmbeddedCredentials)
    assertFalse(result.hasNonStandardPort)
  }

  @Test
  fun `safe link analyzer detects numeric IP hosts and non standard ports`() {
    val analyzer = SafeLinkAnalyzer()
    val result = analyzer.analyzeUrl("http://192.168.1.1:8080/login")
    assertEquals(RiskLevel.REVIEW_RECOMMENDED, result.riskLevel)
    assertFalse(result.isHttps)
    assertTrue(result.hasIpHost)
    assertTrue(result.hasNonStandardPort)
    assertTrue(result.reasons.isNotEmpty())
  }

  @Test
  fun `safe link analyzer detects punycode and embedded credentials`() {
    val analyzer = SafeLinkAnalyzer()
    val result = analyzer.analyzeUrl("https://user:password@xn--pple-43d.com")
    assertEquals(RiskLevel.REVIEW_RECOMMENDED, result.riskLevel)
    assertTrue(result.hasPunycode)
    assertTrue(result.hasEmbeddedCredentials)
  }

  // ==========================================
  // Hash Computation QA Tests
  // ==========================================
  @Test
  fun `hash computation creates valid SHA-256 string`() {
    val testData = "Hello Virus Guard".toByteArray(Charsets.UTF_8)
    val digest = MessageDigest.getInstance("SHA-256")
    val hashBytes = digest.digest(testData)
    val hash = hashBytes.joinToString("") { "%02x".format(it) }
    assertEquals(64, hash.length)
  }

  // ==========================================
  // Security Checkup Engine QA Tests
  // ==========================================
  @Test
  fun `security check engine audits device and generates valid items`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = SecurityCheckEngine(context)
    val result = engine.performCheckup(installedApps = emptyList(), hasScannedRecently = false)
    assertNotNull(result)
    assertTrue(result.score in 0..100)
    assertTrue(result.items.isNotEmpty())
    result.items.forEach { item ->
      assertTrue(item.title.isNotBlank())
      assertTrue(item.category.isNotBlank())
      assertTrue(item.explanation.isNotBlank())
      assertTrue(item.recommendation.isNotBlank())
      assertNotNull(item.status)
    }
  }

  // ==========================================
  // Risk Score Engine QA Tests
  // ==========================================
  @Test
  fun `risk score engine provides transparent deductions without fake threats`() {
    val eval = RiskScoreEngine.evaluateRule("RULE_UNSCANNED", true, "Never scanned")
    assertNotNull(eval)
    assertEquals(20, eval?.penaltyPoints)
    assertEquals(RiskLevel.REVIEW_RECOMMENDED, eval?.severity)

    val triggeredHarmful = RiskScoreEngine.evaluateRule("RULE_HARMFUL_APP", true, "Suspicious combo")
    assertNotNull(triggeredHarmful)
    assertEquals(25, triggeredHarmful?.penaltyPoints)
    assertEquals(RiskLevel.POTENTIALLY_HARMFUL, triggeredHarmful?.severity)

    val notTriggered = RiskScoreEngine.evaluateRule("RULE_HARMFUL_APP", false, "Clean")
    assertEquals(null, notTriggered)
  }

  // ==========================================
  // Recommendation Engine QA Tests
  // ==========================================
  @Test
  fun `recommendation engine creates actionable recommendations`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = RecommendationEngine(context)
    val recs = engine.generateRecommendations(apps = emptyList(), hasScanned = false)
    assertNotNull(recs)
    // When hasScanned is false, should recommend running scan
    assertTrue(recs.any { it.id == "rec_run_scan" })
  }

  // ==========================================
  // Network Safety QA Tests
  // ==========================================
  @Test
  fun `network analyzer inspects connectivity without traffic interception`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val analyzer = NetworkAnalyzer(context)
    val netInfo = analyzer.analyzeNetwork()
    assertNotNull(netInfo)
    assertTrue(netInfo.connectionType.isNotBlank())
    assertTrue(netInfo.notes.isNotEmpty())
  }

  // ==========================================
  // Language Configuration QA Tests
  // ==========================================
  @Test
  fun `viewmodel language update persists language preference`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)
    vm.setLanguage("hi")
    assertEquals("hi", vm.preferences.value.languageCode)
    vm.setLanguage("en")
    assertEquals("en", vm.preferences.value.languageCode)
  }

  // ==========================================
  // Mobile Hacking Solution QA Tests
  // ==========================================
  @Test
  fun `mobile hacking engine runs defensive audit with evidence based findings and sandbox disclosures`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val engine = MobileHackingEngine(context)
    val result = engine.runCompromiseAudit()

    assertNotNull(result)
    assertNotNull(result.overallStatus)
    assertTrue(result.headline.isNotBlank())
    assertTrue(result.hindiHeadline.isNotBlank())
    assertTrue(result.summaryExplanation.isNotBlank())
    assertTrue(result.hindiSummaryExplanation.isNotBlank())

    // Must never claim hacked without evidence - overall status must be one of the defined statuses
    assertTrue(
      result.overallStatus == CompromiseStatus.NO_OBVIOUS_ISSUE ||
      result.overallStatus == CompromiseStatus.REVIEW_RECOMMENDED ||
      result.overallStatus == CompromiseStatus.ACTION_RECOMMENDED
    )

    // Android sandbox limitations disclosures must be present and transparent
    assertTrue(result.androidLimitationsDisclosures.isNotEmpty())
    assertTrue(result.androidLimitationsDisclosures.any { it.contains("sandbox") || it.contains("traffic") || it.contains("private") || it.contains("Android") })

    // Indicators must have structured findings: WHAT WAS FOUND, WHY IT MATTERS, WHAT USER CAN DO
    assertTrue(result.indicators.isNotEmpty())
    result.indicators.forEach { ind ->
      assertTrue(ind.title.isNotBlank())
      assertTrue(ind.hindiTitle.isNotBlank())
      assertTrue(ind.whatWasFound.isNotBlank())
      assertTrue(ind.hindiWhatWasFound.isNotBlank())
      assertTrue(ind.whyItMatters.isNotBlank())
      assertTrue(ind.hindiWhyItMatters.isNotBlank())
      assertTrue(ind.whatUserCanDo.isNotBlank())
      assertTrue(ind.hindiWhatUserCanDo.isNotBlank())
    }

    // Privacy audit groups
    assertTrue(result.privacyAuditGroups.isNotEmpty())
  }

  @Test
  fun `mobile hacking solution tabs and check phone button function properly in viewmodel`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    // Verify navigation tabs
    vm.selectTab(NavigationTab.CYBER_CENTER)
    assertEquals(NavigationTab.CYBER_CENTER, vm.currentTab.value)

    vm.selectTab(NavigationTab.HACKING_SOLUTION)
    assertEquals(NavigationTab.HACKING_SOLUTION, vm.currentTab.value)

    // Verify Mobile Hacking Solution sub-tabs
    assertEquals(HackingSolutionTab.DASHBOARD, vm.activeHackingTab.value)

    val expectedTabs = listOf(
      HackingSolutionTab.CHECK_PHONE,
      HackingSolutionTab.SUSPICIOUS_APPS,
      HackingSolutionTab.ACCOUNT_SECURITY,
      HackingSolutionTab.PRIVACY_CHECK,
      HackingSolutionTab.RECOVERY_ASSISTANT,
      HackingSolutionTab.SECURITY_REPORT,
      HackingSolutionTab.EMERGENCY_CHECKLIST,
      HackingSolutionTab.DASHBOARD
    )

    expectedTabs.forEach { tab ->
      vm.selectHackingTab(tab)
      assertEquals(tab, vm.activeHackingTab.value)
    }

    // Trigger Check My Phone audit
    vm.runHackingAudit(testDispatcher)
    advanceUntilIdle()

    val result = vm.hackingAuditResult.value
    assertNotNull(result)
    assertFalse(vm.isHackingAuditing.value)
  }

  // ==========================================
  // ViewModel & Scan State QA Tests
  // ==========================================
  @Test
  fun `viewmodel manages app filters and search query correctly`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    vm.setAppFilter(AppFilter.USER_APPS)
    assertEquals(AppFilter.USER_APPS, vm.appFilter.value)

    vm.setAppFilter(AppFilter.NEEDS_REVIEW)
    assertEquals(AppFilter.NEEDS_REVIEW, vm.appFilter.value)

    vm.setSearchQuery("TestSearch")
    assertEquals("TestSearch", vm.searchQuery.value)
    vm.setSearchQuery("")
    assertEquals("", vm.searchQuery.value)
  }

  @Test
  fun `viewmodel cancel scan resets scanning state immediately`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    vm.startQuickScan()
    vm.cancelScan()
    advanceUntilIdle()

    val scanState = vm.scanState.value
    assertFalse(scanState.isScanning)
  }

  @Test
  fun `viewmodel deep scan initiates successfully`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    vm.startDeepScan()
    val currentState = vm.scanState.value
    assertEquals(ScanType.DEEP, currentState.scanType)
    vm.cancelScan()
  }

  @Test
  fun `viewmodel alert dismissal removes alert from active list`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    val initialAlerts = vm.alerts.value
    if (initialAlerts.isNotEmpty()) {
      val firstId = initialAlerts.first().id
      vm.dismissAlert(firstId)
      assertFalse(vm.alerts.value.any { it.id == firstId })
    }
  }

  @Test
  fun `viewmodel simple mode toggles successfully`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    vm.setSimpleMode(true)
    advanceUntilIdle()
    assertTrue(vm.preferences.value.isSimpleMode)

    vm.setSimpleMode(false)
    advanceUntilIdle()
    assertFalse(vm.preferences.value.isSimpleMode)
  }

  @Test
  fun `viewmodel alerts provide evidence and action explanations`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)
    advanceUntilIdle()

    val alerts = vm.alerts.value
    for (alert in alerts) {
      assertTrue(alert.whatWasFound.isNotBlank())
      assertTrue(alert.whyItMatters.isNotBlank())
      assertTrue(alert.whatToDo.isNotBlank())
    }
  }

  @Test
  fun `runCheckMyPhone generates valid result and resets checking state`() = runTest {
    val application = ApplicationProvider.getApplicationContext<android.app.Application>()
    val vm = SecurityViewModel(application)

    vm.runCheckMyPhone(testDispatcher)
    advanceUntilIdle()

    val result = vm.checkPhoneResult.value
    assertNotNull(result)
    assertFalse(vm.isCheckingPhone.value)
    assertTrue(result!!.score in 0..100)
    assertTrue(result.headline.isNotBlank())
    assertTrue(result.subHeadline.isNotBlank())
    assertTrue(result.stats.appsCheckedCount >= 0)

    vm.clearCheckPhoneResult()
    assertEquals(null, vm.checkPhoneResult.value)
  }
}
