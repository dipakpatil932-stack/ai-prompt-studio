package com.example

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppDetailDialog
import com.example.ui.screens.AppSafetyScreen
import com.example.ui.screens.CheckupScreen
import com.example.ui.screens.CyberSecurityCenterScreen
import com.example.ui.screens.FileScanScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MobileHackingSolutionScreen
import com.example.ui.screens.ScanScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SmartSecurityMonitorScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.VirusGuardTheme
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.SecurityViewModel
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val viewModel: SecurityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val preferences by viewModel.preferences.collectAsStateWithLifecycle()
            val currentLanguage = preferences.languageCode

            val currentContext = LocalContext.current
            val localizedContext = remember(currentLanguage) {
                createLocalizedContext(currentContext, currentLanguage)
            }
            val localizedConfig = remember(currentLanguage) {
                Configuration(localizedContext.resources.configuration)
            }

            CompositionLocalProvider(
                LocalContext provides localizedContext,
                LocalConfiguration provides localizedConfig
            ) {
                VirusGuardTheme {
                    VirusGuardMainApp(viewModel = viewModel)
                }
            }
        }
    }

    private fun createLocalizedContext(context: Context, languageCode: String): Context {
        val locale = Locale.forLanguageTag(languageCode)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        return context.createConfigurationContext(config)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirusGuardMainApp(viewModel: SecurityViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedApp by viewModel.selectedApp.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Handle back button when inside Scan, Cyber Center or Hacking Solution screen
    BackHandler(enabled = currentTab == NavigationTab.SCAN || currentTab == NavigationTab.CYBER_CENTER || currentTab == NavigationTab.HACKING_SOLUTION) {
        viewModel.selectTab(NavigationTab.HOME)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentTab) {
                            NavigationTab.HOME -> stringResource(R.string.app_name)
                            NavigationTab.CHECKUP -> stringResource(R.string.security_checkup)
                            NavigationTab.SCAN -> stringResource(R.string.nav_scan)
                            NavigationTab.APPS -> stringResource(R.string.nav_apps)
                            NavigationTab.TOOLS -> "Security Tools"
                            NavigationTab.SETTINGS -> stringResource(R.string.settings_title)
                            NavigationTab.CYBER_CENTER -> "Cyber Security Center"
                            NavigationTab.HACKING_SOLUTION -> "Mobile Hacking Solution"
                            NavigationTab.SECURITY_MONITOR -> "Smart Security Monitor"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (currentTab == NavigationTab.SCAN || currentTab == NavigationTab.CYBER_CENTER || currentTab == NavigationTab.HACKING_SOLUTION || currentTab == NavigationTab.SECURITY_MONITOR) {
                        IconButton(onClick = { viewModel.selectTab(NavigationTab.HOME) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Home"
                            )
                        }
                    } else {
                        IconButton(onClick = { viewModel.selectTab(NavigationTab.HOME) }) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                actions = {
                    if (currentTab != NavigationTab.SETTINGS) {
                        IconButton(
                            onClick = { viewModel.selectTab(NavigationTab.SETTINGS) },
                            modifier = Modifier.testTag("top_bar_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Settings,
                                contentDescription = "Settings"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_navigation_bar"),
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                NavigationBarItem(
                    selected = currentTab == NavigationTab.HOME,
                    onClick = { viewModel.selectTab(NavigationTab.HOME) },
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                    label = { Text(stringResource(R.string.nav_home)) },
                    modifier = Modifier.testTag("nav_item_home")
                )
                NavigationBarItem(
                    selected = currentTab == NavigationTab.CHECKUP,
                    onClick = { viewModel.selectTab(NavigationTab.CHECKUP) },
                    icon = { Icon(Icons.Filled.CheckCircle, contentDescription = "Checkup") },
                    label = { Text("Checkup") },
                    modifier = Modifier.testTag("nav_item_checkup")
                )
                NavigationBarItem(
                    selected = currentTab == NavigationTab.SCAN,
                    onClick = { viewModel.selectTab(NavigationTab.SCAN) },
                    icon = { Icon(Icons.Filled.Search, contentDescription = "Scan") },
                    label = { Text(stringResource(R.string.nav_scan)) },
                    modifier = Modifier.testTag("nav_item_scan")
                )
                NavigationBarItem(
                    selected = currentTab == NavigationTab.APPS,
                    onClick = { viewModel.selectTab(NavigationTab.APPS) },
                    icon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = "App Safety") },
                    label = { Text(stringResource(R.string.nav_apps)) },
                    modifier = Modifier.testTag("nav_item_apps")
                )
                NavigationBarItem(
                    selected = currentTab == NavigationTab.TOOLS,
                    onClick = { viewModel.selectTab(NavigationTab.TOOLS) },
                    icon = { Icon(Icons.Filled.Build, contentDescription = "Tools") },
                    label = { Text("Tools") },
                    modifier = Modifier.testTag("nav_item_tools")
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentTab) {
                NavigationTab.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateTab = { viewModel.selectTab(it) },
                        onStartQuickScan = {
                            viewModel.selectTab(NavigationTab.SCAN)
                            viewModel.startQuickScan()
                        },
                        onStartDeepScan = {
                            viewModel.selectTab(NavigationTab.SCAN)
                            viewModel.startDeepScan()
                        }
                    )
                }
                NavigationTab.CHECKUP -> {
                    CheckupScreen(viewModel = viewModel)
                }
                NavigationTab.SCAN -> {
                    ScanScreen(
                        viewModel = viewModel,
                        onSelectAppPackage = { pkg ->
                            val found = viewModel.installedApps.value.firstOrNull { it.packageName == pkg }
                            if (found != null) {
                                viewModel.selectApp(found)
                            }
                        }
                    )
                }
                NavigationTab.APPS -> {
                    AppSafetyScreen(
                        viewModel = viewModel,
                        onSelectApp = { viewModel.selectApp(it) }
                    )
                }
                NavigationTab.TOOLS -> {
                    ToolsScreen(viewModel = viewModel)
                }
                NavigationTab.SETTINGS -> {
                    SettingsScreen(
                        viewModel = viewModel,
                        onLanguageSelected = { langCode ->
                            viewModel.setLanguage(langCode)
                        }
                    )
                }
                NavigationTab.CYBER_CENTER -> {
                    CyberSecurityCenterScreen(viewModel = viewModel)
                }
                NavigationTab.HACKING_SOLUTION -> {
                    MobileHackingSolutionScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.selectTab(NavigationTab.HOME) }
                    )
                }
                NavigationTab.SECURITY_MONITOR -> {
                    SmartSecurityMonitorScreen(
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.selectTab(NavigationTab.HOME) }
                    )
                }
            }
        }

        // App Detail & Action Dialog
        selectedApp?.let { app ->
            AppDetailDialog(
                app = app,
                onDismiss = { viewModel.selectApp(null) },
                onUninstall = { pkg: String -> viewModel.uninstallApp(context, pkg) },
                onOpenSettings = { pkg: String -> viewModel.openAppSettings(context, pkg) }
            )
        }
    }
}
