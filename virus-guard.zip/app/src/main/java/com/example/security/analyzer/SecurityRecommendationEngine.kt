package com.example.security.analyzer

import android.content.Context
import android.provider.Settings
import com.example.data.database.SecurityRecommendationEntity
import com.example.security.model.AppAuditRiskLevel
import com.example.security.model.AppSecurityAuditItem
import com.example.security.model.CheckState
import com.example.security.model.DeviceSecurityCheck

class SecurityRecommendationEngine(private val context: Context) {

    fun generateRecommendations(
        deviceChecks: List<DeviceSecurityCheck>,
        appAudits: List<AppSecurityAuditItem>,
        isVpnActive: Boolean,
        isScreenLocked: Boolean
    ): List<SecurityRecommendationEntity> {
        val recs = mutableListOf<SecurityRecommendationEntity>()

        // 1. Screen lock recommendation
        if (!isScreenLocked) {
            recs.add(
                SecurityRecommendationEntity(
                    recommendationId = "rec_screen_lock",
                    title = "Enable Secure Screen Lock",
                    description = "Set up a PIN, biometric fingerprint, or password to lock your phone and encrypt device hardware keys.",
                    category = "Device Security",
                    priority = "HIGH",
                    actionLabel = "Open Security Settings"
                )
            )
        }

        // 2. High risk apps recommendation
        val highRiskApps = appAudits.filter { it.riskLevel == AppAuditRiskLevel.HIGH }
        if (highRiskApps.isNotEmpty()) {
            recs.add(
                SecurityRecommendationEntity(
                    recommendationId = "rec_high_risk_apps",
                    title = "Audit High-Risk Applications",
                    description = "${highRiskApps.size} installed app(s) hold sensitive combination permissions (e.g., overlay + accessibility). Review their usage or remove unneeded apps.",
                    category = "App Security",
                    priority = "HIGH",
                    actionLabel = "Review Apps"
                )
            )
        }

        // 3. System updates recommendation
        val patchCheck = deviceChecks.find { it.id == "device_sec_patch" }
        if (patchCheck?.state == CheckState.REVIEW) {
            recs.add(
                SecurityRecommendationEntity(
                    recommendationId = "rec_sys_update",
                    title = "Check for Android Firmware Updates",
                    description = "Your device security patch is older than recommended. Check system settings for manufacturer updates.",
                    category = "System Updates",
                    priority = "REVIEW",
                    actionLabel = "Check Updates"
                )
            )
        }

        // 4. Developer options & ADB recommendation
        val devCheck = deviceChecks.find { it.id == "device_dev_options" }
        val adbCheck = deviceChecks.find { it.id == "device_adb" }
        if (adbCheck?.state == CheckState.REVIEW) {
            recs.add(
                SecurityRecommendationEntity(
                    recommendationId = "rec_disable_adb",
                    title = "Turn Off USB Debugging (ADB)",
                    description = "ADB debugging is enabled, exposing low-level command interfaces over USB cables. Disable it when not developing.",
                    category = "System Integrity",
                    priority = "REVIEW",
                    actionLabel = "Developer Settings"
                )
            )
        } else if (devCheck?.state == CheckState.REVIEW) {
            recs.add(
                SecurityRecommendationEntity(
                    recommendationId = "rec_disable_dev",
                    title = "Review Developer Options",
                    description = "Developer options are enabled. Disable developer mode if not running development tools.",
                    category = "System Integrity",
                    priority = "NORMAL",
                    actionLabel = "Developer Settings"
                )
            )
        }

        // 5. Account 2FA & Password Hygiene
        recs.add(
            SecurityRecommendationEntity(
                recommendationId = "rec_account_2fa",
                title = "Enable Two-Factor Authentication (2FA)",
                description = "Protect your primary email and cloud accounts with authenticator apps or hardware security keys to prevent unauthorized logins.",
                category = "Account Security",
                priority = "NORMAL",
                actionLabel = "Learn 2FA"
            )
        )

        // 6. Public Wi-Fi protection
        if (!isVpnActive) {
            recs.add(
                SecurityRecommendationEntity(
                    recommendationId = "rec_network_trust",
                    title = "Protect Traffic on Public Networks",
                    description = "When connecting to open public Wi-Fi hotspots, avoid performing banking or entering credentials without a verified VPN tunnel.",
                    category = "Network Safety",
                    priority = "NORMAL",
                    actionLabel = "Network Advice"
                )
            )
        }

        return recs
    }
}
