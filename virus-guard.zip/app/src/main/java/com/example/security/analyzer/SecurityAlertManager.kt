package com.example.security.analyzer

import android.provider.Settings
import com.example.data.database.SecurityAlertEntity
import com.example.security.model.AlertSeverity
import com.example.security.model.AppAuditRiskLevel
import com.example.security.model.AppSecurityAuditItem
import com.example.security.model.CheckState
import com.example.security.model.CyberSecurityAlertItem
import com.example.security.model.DeviceSecurityCheck

class SecurityAlertManager {

    fun generateAlerts(
        deviceChecks: List<DeviceSecurityCheck>,
        appAudits: List<AppSecurityAuditItem>
    ): List<CyberSecurityAlertItem> {
        val alerts = mutableListOf<CyberSecurityAlertItem>()

        // 1. Screen lock alert
        val lockCheck = deviceChecks.find { it.id == "device_screen_lock" }
        if (lockCheck?.state == CheckState.REVIEW) {
            alerts.add(
                CyberSecurityAlertItem(
                    id = "alert_no_screen_lock",
                    title = "Screen Lock Is Not Configured",
                    reason = "No PIN, pattern, password, or biometric credential protects the physical device.",
                    evidence = "KeyguardManager reports isDeviceSecure == false",
                    recommendedAction = "Open Android Settings and configure a secure screen lock immediately to protect device data partitions.",
                    severity = AlertSeverity.HIGH
                )
            )
        }

        // 2. High-risk app alerts (only from real audit findings)
        val highRiskApps = appAudits.filter { it.riskLevel == AppAuditRiskLevel.HIGH }
        for (app in highRiskApps) {
            alerts.add(
                CyberSecurityAlertItem(
                    id = "alert_app_${app.packageName}",
                    title = "High-Risk Permission Combo: ${app.appName}",
                    reason = "Application requests powerful combination of sensitive capabilities (${app.riskIndicators.joinToString("; ")}).",
                    evidence = "Package: ${app.packageName} (${app.installerDisplayName})",
                    recommendedAction = "Inspect app permissions in Android Settings or uninstall if unneeded.",
                    severity = AlertSeverity.HIGH
                )
            )
        }

        // 3. USB debugging active
        val adbCheck = deviceChecks.find { it.id == "device_adb" }
        if (adbCheck?.state == CheckState.REVIEW) {
            alerts.add(
                CyberSecurityAlertItem(
                    id = "alert_adb_enabled",
                    title = "USB Debugging Bridge Active",
                    reason = "ADB interface is open to any connected computer or charging cable.",
                    evidence = "Settings.Global.ADB_ENABLED == 1",
                    recommendedAction = "Turn off USB Debugging under Developer Options unless actively debugging software.",
                    severity = AlertSeverity.MEDIUM
                )
            )
        }

        // 4. Developer options active
        val devCheck = deviceChecks.find { it.id == "device_dev_options" }
        if (devCheck?.state == CheckState.REVIEW && adbCheck?.state != CheckState.REVIEW) {
            alerts.add(
                CyberSecurityAlertItem(
                    id = "alert_dev_mode_enabled",
                    title = "Developer Mode Active",
                    reason = "System settings allow experimental developer flags and mock location hooks.",
                    evidence = "Settings.Global.DEVELOPMENT_SETTINGS_ENABLED == 1",
                    recommendedAction = "Disable Developer Options in Android Settings to restore standard operating profile.",
                    severity = AlertSeverity.INFO
                )
            )
        }

        // 5. Outdated security patch
        val patchCheck = deviceChecks.find { it.id == "device_sec_patch" }
        if (patchCheck?.state == CheckState.REVIEW) {
            alerts.add(
                CyberSecurityAlertItem(
                    id = "alert_patch_outdated",
                    title = "Security Patch Review Recommended",
                    reason = "The device security patch is over 12 months old, which may lack the latest platform security fixes.",
                    evidence = patchCheck.evidence,
                    recommendedAction = "Check System > System Updates for pending manufacturer security updates.",
                    severity = AlertSeverity.MEDIUM
                )
            )
        }

        // 6. Sideloaded apps alert
        val sideloadedApps = appAudits.filter {
            !it.isSystemApp && it.installerPackageName != "com.android.vending" &&
                    it.installerPackageName != "com.google.android.feedback" &&
                    it.installerPackageName != "com.amazon.venezia" &&
                    it.installerPackageName != "com.sec.android.app.samsungapps"
        }
        if (sideloadedApps.size >= 3) {
            alerts.add(
                CyberSecurityAlertItem(
                    id = "alert_sideloaded_volume",
                    title = "Multiple Non-Store Applications Present",
                    reason = "${sideloadedApps.size} apps were installed from external APK files or unknown package installers.",
                    evidence = "Apps: ${sideloadedApps.take(4).joinToString { it.appName }}",
                    recommendedAction = "Ensure external APK downloads come from authentic developer websites.",
                    severity = AlertSeverity.INFO
                )
            )
        }

        return alerts
    }

    fun toEntity(item: CyberSecurityAlertItem): SecurityAlertEntity {
        return SecurityAlertEntity(
            alertId = item.id,
            timestamp = item.timestamp,
            title = item.title,
            reason = item.reason,
            evidence = item.evidence,
            severity = item.severity.name,
            recommendedAction = item.recommendedAction,
            isAcknowledged = item.isAcknowledged
        )
    }
}
