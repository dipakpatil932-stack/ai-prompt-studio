package com.example.security.analyzer

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.app.NotificationManagerCompat
import com.example.security.model.AccountSecurityCheckItem
import com.example.security.model.CompromiseIndicator
import com.example.security.model.CompromiseStatus
import com.example.security.model.EmergencyActionItem
import com.example.security.model.HackingPrivacyGroup
import com.example.security.model.MobileHackingAuditResult
import com.example.security.model.RecoveryStep
import com.example.security.model.SuspiciousAppDetail
import com.example.security.model.SuspiciousAppItemWrapper
import com.example.security.scanner.SignatureDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MobileHackingEngine(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val keyguardManager: KeyguardManager? =
        context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
    private val connectivityManager: ConnectivityManager? =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val devicePolicyManager: DevicePolicyManager? =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    private val accessibilityManager: AccessibilityManager? =
        context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager

    fun runCompromiseAudit(): MobileHackingAuditResult {
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        val formattedDate = dateFormat.format(Date(now))

        val indicators = mutableListOf<CompromiseIndicator>()
        val limitationsList = mutableListOf<String>()

        // 1. Audit Installed Packages
        val installedPackages = try {
            packageManager.getInstalledPackages(
                PackageManager.GET_PERMISSIONS or
                        PackageManager.GET_SERVICES or
                        PackageManager.GET_RECEIVERS
            )
        } catch (_: Exception) {
            emptyList()
        }

        // Detect enabled Accessibility services
        val enabledAccessibilityPackages = getEnabledAccessibilityPackages()

        // Detect enabled Notification Listeners
        val enabledNotificationListenerPackages = getEnabledNotificationListeners()

        // Detect active Device Administrators
        val activeDeviceAdmins = getActiveDeviceAdminPackages()

        // Check for Sideloaded & High-Risk Apps
        val auditedApps = installedPackages.map { pkg ->
            auditSingleApp(
                pkgInfo = pkg,
                currentTime = now,
                enabledAccessibilityPackages = enabledAccessibilityPackages,
                enabledNotificationPackages = enabledNotificationListenerPackages,
                activeAdmins = activeDeviceAdmins
            )
        }

        val suspiciousApps = auditedApps
            .filter { it.riskLevel != CompromiseStatus.NO_OBVIOUS_ISSUE }
            .sortedByDescending { if (it.riskLevel == CompromiseStatus.ACTION_RECOMMENDED) 2 else 1 }

        val recentlyInstalledApps = auditedApps
            .filter { it.isRecentlyInstalled && !it.isSystemApp }
            .sortedByDescending { it.installTimeMillis }

        // ==========================================
        // 1. CHECK: Suspicious Installed Applications
        // ==========================================
        val highRiskApps = auditedApps.filter { it.riskLevel == CompromiseStatus.ACTION_RECOMMENDED }
        val reviewApps = auditedApps.filter { it.riskLevel == CompromiseStatus.REVIEW_RECOMMENDED }

        if (highRiskApps.isNotEmpty()) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_suspicious_apps_high",
                    title = "Suspicious Application Privileges",
                    hindiTitle = "संदिग्ध एप्लिकेशन अनुमतियाँ",
                    category = "App Integrity",
                    status = CompromiseStatus.ACTION_RECOMMENDED,
                    whatWasFound = "${highRiskApps.size} installed application(s) combine high-risk privileges (such as screen overlay, accessibility binding, or installation rights) outside official store verification.",
                    hindiWhatWasFound = "${highRiskApps.size} ऐप में उच्च जोखिम वाली अनुमतियां (जैसे ओवरले, एक्सेसिबिलिटी या अज्ञात इंस्टॉलेशन) पाई गईं।",
                    whyItMatters = "Malicious or untrusted apps often request accessibility or overlay permissions to view screen content, capture keystrokes, or intercept SMS verification codes.",
                    hindiWhyItMatters = "संदिग्ध ऐप्स स्क्रीन देखने, कीस्ट्रोक रिकॉर्ड करने या ओटीपी पढ़ने के लिए इन अनुमतियों का दुरुपयोग कर सकते हैं।",
                    whatUserCanDo = "Review the flagged apps in the Suspicious Apps tab below. If you do not recognize or actively use them, uninstall them immediately.",
                    hindiWhatUserCanDo = "संदिग्ध ऐप्स टैब में जाकर इन ऐप्स की समीक्षा करें और यदि आवश्यक न हो तो तुरंत अनइंस्टॉल करें।"
                )
            )
        } else if (reviewApps.isNotEmpty()) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_suspicious_apps_review",
                    title = "Applications Requiring Review",
                    hindiTitle = "समीक्षा योग्य एप्लिकेशन",
                    category = "App Integrity",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "${reviewApps.size} non-system application(s) have requested sensitive hardware permissions or were installed from non-Play Store sources.",
                    hindiWhatWasFound = "${reviewApps.size} ऐप्स ने संवेदनशील हार्डवेयर अनुमतियों का अनुरोध किया है या वे प्ले स्टोर से बाहर से स्थापित हैं।",
                    whyItMatters = "Sideloaded apps bypass Google Play Protect cloud pre-screening and should be verified for legitimate origin.",
                    hindiWhyItMatters = "बाहरी स्रोतों से इंस्टॉल किए गए ऐप्स की उत्पत्ति की पुष्टि करना सुरक्षित रहने के लिए आवश्यक है।",
                    whatUserCanDo = "Verify each app in the Suspicious Apps list and remove any software you do not remember installing.",
                    hindiWhatUserCanDo = "सूची की जाँच करें और किसी भी अज्ञात एप्लिकेशन को हटा दें।"
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_suspicious_apps_ok",
                    title = "No Suspicious App Anomalies",
                    hindiTitle = "कोई संदिग्ध ऐप नहीं मिला",
                    category = "App Integrity",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "No non-system applications exhibit recognized high-risk privilege combinations or suspicious stealth signatures.",
                    hindiWhatWasFound = "किसी भी ऐप में असामान्य या खतरनाक अनुमति संयोजन नहीं मिले।",
                    whyItMatters = "Standard apps operating within standard sandbox boundaries without excessive privileges cannot secretly control the device.",
                    hindiWhyItMatters = "सीमित अनुमतियों वाले ऐप्स बिना अनुमति के आपके डिवाइस को नियंत्रित नहीं कर सकते।",
                    whatUserCanDo = "Continue installing applications only from verified official sources such as Google Play.",
                    hindiWhatUserCanDo = "हमेशा केवल आधिकारिक Google Play Store से ही ऐप्स इंस्टॉल करें।"
                )
            )
        }

        // ==========================================
        // 2. CHECK: Accessibility-Related Access
        // ==========================================
        val appsWithAccessibility = auditedApps.filter { it.hasAccessibilityAccess }
        if (enabledAccessibilityPackages.isNotEmpty()) {
            val nonSystemEnabled = enabledAccessibilityPackages.filter { pkg ->
                auditedApps.none { it.packageName == pkg && it.isSystemApp }
            }
            if (nonSystemEnabled.isNotEmpty()) {
                indicators.add(
                    CompromiseIndicator(
                        id = "ind_accessibility_enabled",
                        title = "Active Accessibility Service Detected",
                        hindiTitle = "एक्टिव एक्सेसिबिलिटी सर्विस का पता चला",
                        category = "System Control",
                        status = CompromiseStatus.ACTION_RECOMMENDED,
                        whatWasFound = "Active third-party Accessibility Service enabled for: ${nonSystemEnabled.joinToString(", ")}.",
                        hindiWhatWasFound = "तृतीय-पक्ष एक्सेसिबिलिटी सेवा सक्रिय है: ${nonSystemEnabled.joinToString(", ")}।",
                        whyItMatters = "Accessibility access gives an app the ability to read any text displayed on the screen (including passwords and chats) and perform touch taps automatically.",
                        hindiWhyItMatters = "एक्सेसिबिलिटी अनुमति से कोई ऐप स्क्रीन पर लिखे टेक्स्ट (पासवर्ड, चैट) पढ़ सकता है और अपने आप क्लिक कर सकता है।",
                        whatUserCanDo = "Open Accessibility Settings and turn off accessibility access for any application that is not an assistive tool you explicitly trust.",
                        hindiWhatUserCanDo = "एक्सेसिबिलिटी सेटिंग्स खोलें और किसी भी गैर-भरोसेमंद ऐप के लिए इसे तुरंत बंद करें।",
                        intentAction = Settings.ACTION_ACCESSIBILITY_SETTINGS
                    )
                )
            } else {
                indicators.add(
                    CompromiseIndicator(
                        id = "ind_accessibility_ok",
                        title = "Accessibility Services Safe",
                        hindiTitle = "एक्सेसिबिलिटी सेवाएं सुरक्षित",
                        category = "System Control",
                        status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                        whatWasFound = "Only certified OEM/system accessibility tools are active on this device.",
                        hindiWhatWasFound = "केवल सिस्टम एक्सेसिबिलिटी सेवाएं सक्रिय हैं। कोई अनधिकृत ऐप सक्रिय नहीं है।",
                        whyItMatters = "Restricting accessibility access prevents malicious automated interaction and screen sniffing.",
                        hindiWhyItMatters = "यह स्क्रीन को गुप्त रूप से पढ़े जाने से बचाता है।",
                        whatUserCanDo = "Never grant Accessibility permission to apps that prompt for it without clear assistive necessity.",
                        hindiWhatUserCanDo = "बिना स्पष्ट आवश्यकता के किसी भी नए ऐप को एक्सेसिबिलिटी की अनुमति न दें।"
                    )
                )
            }
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_accessibility_none",
                    title = "Accessibility Services Inactive",
                    hindiTitle = "कोई एक्सेसिबिलिटी सेवा सक्रिय नहीं",
                    category = "System Control",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "No third-party apps have active Accessibility control permissions.",
                    hindiWhatWasFound = "किसी भी ऐप के पास एक्टिव स्क्रीन एक्सेस या कंट्रोल नहीं है।",
                    whyItMatters = "Screen reading and automated tap injection are completely blocked.",
                    hindiWhyItMatters = "स्क्रीन पढ़ने और स्वचालित टैप के जोखिम पूरी तरह बंद हैं।",
                    whatUserCanDo = "Maintain current settings.",
                    hindiWhatUserCanDo = "वर्तमान सेटिंग्स बनाए रखें।"
                )
            )
        }

        // ==========================================
        // 3. CHECK: Notification Access (OTP / 2FA Reading)
        // ==========================================
        val nonSystemNotifListeners = enabledNotificationListenerPackages.filter { pkg ->
            auditedApps.none { it.packageName == pkg && it.isSystemApp }
        }
        if (nonSystemNotifListeners.isNotEmpty()) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_notif_listeners",
                    title = "Notification Listener Access Active",
                    hindiTitle = "अधिसूचना सुनने की अनुमति सक्रिय",
                    category = "Privacy & OTP",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "Notification listener privilege is enabled for: ${nonSystemNotifListeners.joinToString(", ")}.",
                    hindiWhatWasFound = "सूचनाएँ पढ़ने की अनुमति इन ऐप्स के पास सक्रिय है: ${nonSystemNotifListeners.joinToString(", ")}।",
                    whyItMatters = "Notification listeners can intercept incoming two-factor verification SMS codes, WhatsApp notifications, and banking alert details.",
                    hindiWhyItMatters = "यह अनुमति आने वाले बैंक ओटीपी, निजी संदेश और अलर्ट पढ़ सकती है।",
                    whatUserCanDo = "Open Notification Access settings and disable any third-party app that does not require notification mirroring.",
                    hindiWhatUserCanDo = "नोटिफिकेशन एक्सेस सेटिंग्स खोलें और गैर-ज़रूरी ऐप्स की अनुमति बंद करें।",
                    intentAction = Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_notif_listeners_ok",
                    title = "Notification Interception Protected",
                    hindiTitle = "अधिसूचना सुरक्षा सुरक्षित",
                    category = "Privacy & OTP",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "No third-party applications have permission to read incoming system notifications.",
                    hindiWhatWasFound = "किसी भी तृतीय-पक्ष ऐप के पास आपके नोटिफिकेशन पढ़ने की अनुमति नहीं है।",
                    whyItMatters = "Incoming verification codes, one-time passwords (OTPs), and private alerts cannot be scraped from notification shade.",
                    hindiWhyItMatters = "आपके ओटीपी और संदेश नोटिफिकेशन से सुरक्षित हैं।",
                    whatUserCanDo = "Keep notification access restricted.",
                    hindiWhatUserCanDo = "इस अनुमति को प्रतिबंधित रखें।"
                )
            )
        }

        // ==========================================
        // 4. CHECK: Device Administrator Status
        // ==========================================
        val nonSystemAdmins = activeDeviceAdmins.filter { pkg ->
            auditedApps.none { it.packageName == pkg && it.isSystemApp }
        }
        if (nonSystemAdmins.isNotEmpty()) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_device_admin",
                    title = "Active Device Administrator Apps",
                    hindiTitle = "डिवाइस एडमिनिस्ट्रेटर ऐप्स सक्रिय",
                    category = "Device Governance",
                    status = CompromiseStatus.ACTION_RECOMMENDED,
                    whatWasFound = "Device Administrator privileges granted to: ${nonSystemAdmins.joinToString(", ")}.",
                    hindiWhatWasFound = "डिवाइस एडमिनिस्ट्रेटर की उच्च शक्ति इन ऐप्स को दी गई है: ${nonSystemAdmins.joinToString(", ")}।",
                    whyItMatters = "Device Administrator privilege allows an application to lock the screen, enforce password rules, erase user data, or prevent its own uninstallation.",
                    hindiWhyItMatters = "डिवाइस एडमिनिस्ट्रेटर ऐप स्क्रीन लॉक कर सकता है, डेटा मिटा सकता है या खुद को अनइंस्टॉल होने से रोक सकता है।",
                    whatUserCanDo = "Open Device Admin Apps in Android Settings and deactivate any app that is not a work-mandated MDM solution.",
                    hindiWhatUserCanDo = "डिवाइस एडमिन सेटिंग्स में जाकर अनजान ऐप्स को तुरंत डीएक्टिवेट करें।",
                    intentAction = Settings.ACTION_SECURITY_SETTINGS
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_device_admin_ok",
                    title = "No Suspicious Device Admins",
                    hindiTitle = "कोई संदिग्ध डिवाइस एडमिन नहीं",
                    category = "Device Governance",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "No non-system third-party applications have Device Administrator control over this phone.",
                    hindiWhatWasFound = "किसी भी बाहरी ऐप के पास डिवाइस एडमिनिस्ट्रेटर नियंत्रण नहीं है।",
                    whyItMatters = "Device cannot be remotely locked or blocked from normal uninstallation by malicious apps.",
                    hindiWhyItMatters = "कोई भी ऐप आपके फोन को लॉक या मिटा नहीं सकता।",
                    whatUserCanDo = "Never activate Device Admin for apps downloaded from unknown links.",
                    hindiWhatUserCanDo = "अज्ञात लिंक से डाउनलोड किए गए ऐप्स को कभी एडमिन न बनाएं।"
                )
            )
        }

        // ==========================================
        // 5. CHECK: VPN & Traffic Redirection Status
        // ==========================================
        val isVpn = checkVpnStatus()
        val connectionType = getActiveConnectionType()
        if (isVpn) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_vpn_active",
                    title = "Active VPN Tunnel Detected",
                    hindiTitle = "एक्टिव वीपीएन (VPN) का पता चला",
                    category = "Network Traffic",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "An active virtual private network (VPN) interface is currently routing internet traffic from this phone.",
                    hindiWhatWasFound = "इस समय फ़ोन का इंटरनेट ट्रैफ़िक एक सक्रिय VPN टनल के माध्यम से जा रहा है।",
                    whyItMatters = "Legitimate VPNs protect your traffic on public Wi-Fi, but a rogue or unfamiliar VPN app can log network destinations and DNS lookups.",
                    hindiWhyItMatters = "यदि यह आपका अपना VPN नहीं है, तो कोई अज्ञात ऐप आपकी ऑनलाइन गतिविधियों पर नज़र रख सकता है।",
                    whatUserCanDo = "If you did not turn on a trusted VPN service, disconnect the VPN immediately in Android Network Settings.",
                    hindiWhatUserCanDo = "यदि आपने खुद VPN चालू नहीं किया है, तो नेटवर्क सेटिंग्स में जाकर इसे तुरंत डिस्कनेक्ट करें।",
                    intentAction = Settings.ACTION_VPN_SETTINGS
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_vpn_normal",
                    title = "Direct Network Connection (No VPN)",
                    hindiTitle = "सामान्य सीधा नेटवर्क कनेक्शन",
                    category = "Network Traffic",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "Internet traffic connects directly via $connectionType with no active third-party VPN redirecting requests.",
                    hindiWhatWasFound = "इंटरनेट बिना किसी बाहरी VPN के सीधे $connectionType से जुड़ा है।",
                    whyItMatters = "Traffic flows directly through standard carrier or local router gateways.",
                    hindiWhyItMatters = "कोई गुप्त वीपीएन आपके डेटा को रीडायरेक्ट नहीं कर रहा है।",
                    whatUserCanDo = "Use a trusted VPN when connecting to untrusted public Wi-Fi hotspots.",
                    hindiWhatUserCanDo = "असुरक्षित सार्वजनिक वाई-फ़ाई पर हमेशा विश्वसनीय VPN का उपयोग करें।"
                )
            )
        }

        // ==========================================
        // 6. CHECK: Screen-Lock Protection
        // ==========================================
        val isDeviceSecure = keyguardManager?.isDeviceSecure ?: false
        if (!isDeviceSecure) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_screen_lock",
                    title = "No Secure Screen Lock Configured",
                    hindiTitle = "कोई सुरक्षित स्क्रीन लॉक सेट नहीं है",
                    category = "Physical Access",
                    status = CompromiseStatus.ACTION_RECOMMENDED,
                    whatWasFound = "The phone currently has no PIN, password, pattern, or biometric lock protection.",
                    hindiWhatWasFound = "फ़ोन पर कोई पिन, पासवर्ड, पैटर्न या बायोमेट्रिक लॉक सक्रिय नहीं है।",
                    whyItMatters = "Anyone who physically handles your phone can open apps, read messages, install malicious tools, and access banking or email accounts.",
                    hindiWhyItMatters = "फ़ोन हाथ में लेने वाला कोई भी व्यक्ति आपके संदेश, बैंक खाते और निजी फ़ोटो सीधे खोल सकता है।",
                    whatUserCanDo = "Set up a strong screen lock (PIN, Password, or Biometric) in Android Security Settings right now.",
                    hindiWhatUserCanDo = "एंड्रॉइड सुरक्षा सेटिंग्स में जाकर अभी एक मजबूत पिन या बायोमेट्रिक लॉक सेट करें।",
                    intentAction = Settings.ACTION_SECURITY_SETTINGS
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_screen_lock_ok",
                    title = "Screen Lock Protection Active",
                    hindiTitle = "स्क्रीन लॉक सुरक्षा सक्रिय",
                    category = "Physical Access",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "Device lock screen is safeguarded with hardware-backed credentials (PIN, Password, Pattern, or Biometrics).",
                    hindiWhatWasFound = "डिवाइस एक सुरक्षित क्रेडेंशियल (पिन, पासवर्ड या बायोमेट्रिक) से सुरक्षित है।",
                    whyItMatters = "Storage encryption keys are tied to the lock screen, preventing unauthorized physical data theft.",
                    hindiWhyItMatters = "फ़ोन खो जाने या चोरी होने पर भी आपका निजी डेटा सुरक्षित रहता है।",
                    whatUserCanDo = "Ensure your PIN is unique and never share it with anyone.",
                    hindiWhatUserCanDo = "अपना पिन किसी के साथ साझा न करें।"
                )
            )
        }

        // ==========================================
        // 7. CHECK: Unknown-Source Sideloading Setting
        // ==========================================
        val canRequestInstalls = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                packageManager.canRequestPackageInstalls()
            } catch (_: Exception) {
                false
            }
        } else {
            @Suppress("DEPRECATION")
            try {
                Settings.Secure.getInt(context.contentResolver, Settings.Secure.INSTALL_NON_MARKET_APPS, 0) == 1
            } catch (_: Exception) {
                false
            }
        }

        val appsWithInstallPerm = auditedApps.filter { it.hasInstallPackagesAccess && !it.isSystemApp }
        if (canRequestInstalls || appsWithInstallPerm.isNotEmpty()) {
            val names = appsWithInstallPerm.take(3).joinToString(", ") { it.appName }
            indicators.add(
                CompromiseIndicator(
                    id = "ind_install_unknown",
                    title = "Install Unknown Apps Permission Granted",
                    hindiTitle = "अज्ञात ऐप्स इंस्टॉल करने की अनुमति सक्रिय",
                    category = "App Boundary",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = if (appsWithInstallPerm.isNotEmpty())
                        "${appsWithInstallPerm.size} user application(s) have permission to prompt package installations (e.g. $names)."
                    else "Unknown Sources installation setting is enabled.",
                    hindiWhatWasFound = "कुछ ऐप्स के पास बाहरी पैकेज इंस्टॉल करने की अनुमति सक्रिय है।",
                    whyItMatters = "Apps with install permissions can download and prompt you to install secondary APKs that may carry malicious payloads.",
                    hindiWhyItMatters = "यह अनुमति ऐप्स को सीधे नए सॉफ़्टवेयर डाउनलोड और इंस्टॉल करने की सुविधा देती है।",
                    whatUserCanDo = "Open 'Special App Access > Install Unknown Apps' in Settings and revoke this permission from untrusted apps.",
                    hindiWhatUserCanDo = "विशेष ऐप एक्सेस सेटिंग्स में जाकर अनजान ऐप्स से यह अनुमति हटा दें।",
                    intentAction = Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_install_unknown_ok",
                    title = "Unknown Source Sideloading Restricted",
                    hindiTitle = "अज्ञात स्रोतों से इंस्टॉलेशन प्रतिबंधित",
                    category = "App Boundary",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "Direct sideloading permission is disabled or restricted to certified system package managers.",
                    hindiWhatWasFound = "अज्ञात स्रोतों से सीधे ऐप इंस्टॉल करने की अनुमति बंद है।",
                    whyItMatters = "Prevents malicious apps from silently fetching and offering unauthorized secondary APK packages.",
                    hindiWhyItMatters = "यह अनधिकृत सॉफ़्टवेयर के बैकग्राउंड इंस्टॉलेशन को रोकता है।",
                    whatUserCanDo = "Keep sideloading permissions disabled.",
                    hindiWhatUserCanDo = "इसे हमेशा बंद रखें।"
                )
            )
        }

        // ==========================================
        // 8. CHECK: Android Security Patch & Update Information
        // ==========================================
        val patchString = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH
        } else null
        val osVersion = Build.VERSION.RELEASE

        val isPatchRecent = try {
            if (!patchString.isNullOrBlank()) {
                val year = patchString.substring(0, 4).toInt()
                year >= 2024
            } else true
        } catch (_: Exception) {
            true
        }

        if (!patchString.isNullOrBlank() && !isPatchRecent) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_security_patch_old",
                    title = "Outdated Android Security Patch",
                    hindiTitle = "पुराना एंड्रॉइड सुरक्षा पैच",
                    category = "Firmware",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "Security patch date is $patchString on Android $osVersion.",
                    hindiWhatWasFound = "सुरक्षा पैच की तारीख $patchString है (Android $osVersion)।",
                    whyItMatters = "Older security patch levels leave known operating system and kernel vulnerabilities unpatched against modern exploits.",
                    hindiWhyItMatters = "पुराने सुरक्षा पैच में ज्ञात कमियां हो सकती हैं जिनका हमलावर लाभ उठा सकते हैं।",
                    whatUserCanDo = "Check System Settings > System Update to see if a newer firmware or patch is available from your phone maker.",
                    hindiWhatUserCanDo = "फ़ोन सेटिंग्स > सिस्टम अपडेट में जाकर नया अपडेट चेक करें।",
                    intentAction = Settings.ACTION_SYSTEM_UPDATE_SETTINGS
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_security_patch_ok",
                    title = "Android System Update Status",
                    hindiTitle = "एंड्रॉइड सिस्टम अपडेट स्थिति",
                    category = "Firmware",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "Running Android $osVersion with patch dated ${patchString ?: "OEM Vendor Managed"}.",
                    hindiWhatWasFound = "Android $osVersion पर चल रहा है (सुरक्षा पैच: ${patchString ?: "निर्माता प्रबंधित"})।",
                    whyItMatters = "System contains modern sandbox barriers, runtime permission gating, and scoped storage protections.",
                    hindiWhyItMatters = "सिस्टम में आधुनिक सुरक्षा नियंत्रण और सैंडबॉक्सिंग सक्रिय हैं।",
                    whatUserCanDo = "Install manufacturer updates whenever they become available.",
                    hindiWhatUserCanDo = "उपलब्ध होने पर हमेशा नए अपडेट इंस्टॉल करें।"
                )
            )
        }

        // ==========================================
        // 9. CHECK: Suspicious Configuration Indicators (ADB / Dev Options / Root Binaries)
        // ==========================================
        val isDevOptions = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        val isUsbDebugging = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        val suBinaryExists = checkSuBinaryPresence()
        val isTestKeys = Build.TAGS?.contains("test-keys") == true

        if (suBinaryExists || isTestKeys) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_root_indicators",
                    title = "Elevated System Privileges Detected",
                    hindiTitle = "उच्च सिस्टम विशेषाधिकार (रूट) का पता चला",
                    category = "System Integrity",
                    status = CompromiseStatus.ACTION_RECOMMENDED,
                    whatWasFound = if (suBinaryExists) "Su execution binary discovered in standard executable paths." else "Build firmware signed with test-keys.",
                    hindiWhatWasFound = "डिवाइस में रूट/सुपरयूज़र बाइनरी या टेस्ट-कुंजियाँ पाई गईं।",
                    whyItMatters = "Rooted or test-key firmware disables Android's kernel sandbox isolation, allowing any application to access all private files and credentials.",
                    hindiWhyItMatters = "रूट किए गए फ़ोन में ऐप सैंडबॉक्स सुरक्षा समाप्त हो जाती है और निजी डेटा चोरी हो सकता है।",
                    whatUserCanDo = "If this device was intentionally rooted, exercise extreme caution with third-party APKs. Otherwise, restore official OEM factory firmware.",
                    hindiWhatUserCanDo = "यदि आपने इसे जानबूझकर नहीं किया है, तो आधिकारिक फ़ैक्टरी फ़र्मवेयर पुनर्स्थापित करें।"
                )
            )
        } else if (isUsbDebugging) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_usb_debugging",
                    title = "USB Debugging (ADB) Active",
                    hindiTitle = "यूएसबी डिबगिंग (ADB) चालू है",
                    category = "System Integrity",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "USB Debugging bridge is currently turned ON in Developer Options.",
                    hindiWhatWasFound = "डेवलपर विकल्पों में USB डिबगिंग सक्रिय है।",
                    whyItMatters = "A connected computer, public charging kiosk, or accessory could execute shell commands on your device over the USB cable.",
                    hindiWhyItMatters = "सार्वजनिक चार्जिंग पोर्ट या कंप्यूटर से कनेक्ट होने पर फ़ोन में कमांड चलाए जा सकते हैं।",
                    whatUserCanDo = "Turn off USB Debugging in Developer Options unless actively testing apps with a trusted development workstation.",
                    hindiWhatUserCanDo = "डेवलपर विकल्पों में जाकर USB डिबगिंग को बंद करें।",
                    intentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                )
            )
        } else if (isDevOptions) {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_dev_options",
                    title = "Developer Options Enabled",
                    hindiTitle = "डेवलपर विकल्प सक्षम हैं",
                    category = "System Integrity",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "Android Developer Options menu is turned ON.",
                    hindiWhatWasFound = "फ़ोन सेटिंग्स में डेवलपर विकल्प चालू हैं।",
                    whyItMatters = "Developer Options unlock testing features that can modify system runtime behavior if misconfigured.",
                    hindiWhyItMatters = "गलत कॉन्फ़िगरेशन से सिस्टम सुरक्षा प्रभावित हो सकती है।",
                    whatUserCanDo = "Turn off Developer Options if you are not an Android developer.",
                    hindiWhatUserCanDo = "यदि आप ऐप डेवलपर नहीं हैं तो इसे बंद कर दें।",
                    intentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                )
            )
        } else {
            indicators.add(
                CompromiseIndicator(
                    id = "ind_config_ok",
                    title = "Standard Production Configuration",
                    hindiTitle = "मानक सुरक्षित कॉन्फ़िगरेशन",
                    category = "System Integrity",
                    status = CompromiseStatus.NO_OBVIOUS_ISSUE,
                    whatWasFound = "Developer options, ADB debugging, and root binaries are absent. Standard production mode.",
                    hindiWhatWasFound = "कोई डिबगिंग या रूट परिवर्तन नहीं पाया गया। फ़ोन मानक सुरक्षित मोड में है।",
                    whyItMatters = "USB cable attacks and shell-level interference are locked out.",
                    hindiWhyItMatters = "केबल के ज़रिए अनधिकृत पहुंच बंद है।",
                    whatUserCanDo = "No action required.",
                    hindiWhatUserCanDo = "किसी कार्रवाई की आवश्यकता नहीं है।"
                )
            )
        }

        // ==========================================
        // 10. CHECK: Recently Installed Applications
        // ==========================================
        if (recentlyInstalledApps.isNotEmpty()) {
            val count = recentlyInstalledApps.size
            val recentNames = recentlyInstalledApps.take(3).joinToString(", ") { it.appName }
            indicators.add(
                CompromiseIndicator(
                    id = "ind_recent_installs",
                    title = "$count Apps Installed Recently (Last 30 Days)",
                    hindiTitle = "हाल ही में इंस्टॉल किए गए $count ऐप्स (पिछले 30 दिन)",
                    category = "App Lifecycle",
                    status = CompromiseStatus.REVIEW_RECOMMENDED,
                    whatWasFound = "$count application(s) were added or updated recently ($recentNames...).",
                    hindiWhatWasFound = "पिछले 30 दिनों में $count नए ऐप्स जोड़े या अपडेट किए गए हैं।",
                    whyItMatters = "Sudden battery drain, popups, or unexpected activity is frequently caused by software installed right before the issues began.",
                    hindiWhyItMatters = "अचानक बैटरी खत्म होना या पॉप-अप आना अक्सर हाल ही में इंस्टॉल किए गए ऐप के कारण होता है।",
                    whatUserCanDo = "Review recently installed applications in the Suspicious Apps tab and uninstall any tool you don't recall installing.",
                    hindiWhatUserCanDo = "हाल ही में इंस्टॉल किए गए ऐप्स की समीक्षा करें और अनजान ऐप्स को तुरंत हटा दें।"
                )
            )
        }

        // ==========================================
        // 11. PRIVACY CHECK (9 Groups required by Prompt)
        // ==========================================
        val privacyGroups = buildPrivacyAuditGroups(auditedApps)

        // ==========================================
        // 12. ANDROID LIMITATIONS DISCLOSURE
        // ==========================================
        limitationsList.add("Android does not provide memory inspection of other applications to normal apps.")
        limitationsList.add("Android does not allow third-party apps to inspect cellular baseband or low-level kernel firmware.")
        limitationsList.add("Android sandboxing prevents reading other apps' private database contents without root access.")
        limitationsList.add("Virus Guard strictly adheres to Google Play privacy policies: we never ask for root privileges.")

        // Determine Overall Compromise Status
        // False Positive Prevention Directive:
        // "Possible Security Issue Detected" must ONLY appear when an actual implemented security rule
        // has supporting concrete evidence (e.g., active root binaries, untrusted accessibility injection,
        // or non-system apps with high-risk privilege combinations).
        // If there is only configuration advice or insufficient evidence, display "Security Review Recommended".
        val hasSupportingEvidenceAction = indicators.any {
            it.status == CompromiseStatus.ACTION_RECOMMENDED && (
                it.id == "ind_root_indicators" ||
                it.id == "ind_accessibility_enabled" ||
                it.id == "ind_suspicious_apps_high" ||
                it.id == "ind_device_admin"
            )
        }
        val hasAction = indicators.any { it.status == CompromiseStatus.ACTION_RECOMMENDED }
        val hasReview = indicators.any { it.status == CompromiseStatus.REVIEW_RECOMMENDED }

        val overallStatus = when {
            hasSupportingEvidenceAction -> CompromiseStatus.ACTION_RECOMMENDED
            hasAction || hasReview -> CompromiseStatus.REVIEW_RECOMMENDED
            else -> CompromiseStatus.NO_OBVIOUS_ISSUE
        }

        val headline = when (overallStatus) {
            CompromiseStatus.ACTION_RECOMMENDED -> "Possible Security Issue Detected"
            CompromiseStatus.REVIEW_RECOMMENDED -> "Security Review Recommended"
            CompromiseStatus.NO_OBVIOUS_ISSUE -> "No Obvious Compromise Indicators Found"
        }

        val hindiHeadline = when (overallStatus) {
            CompromiseStatus.ACTION_RECOMMENDED -> "संभावित सुरक्षा समस्या का पता चला"
            CompromiseStatus.REVIEW_RECOMMENDED -> "सुरक्षा समीक्षा की सिफारिश की जाती है"
            CompromiseStatus.NO_OBVIOUS_ISSUE -> "कोई स्पष्ट सुरक्षा समस्या नहीं मिली"
        }

        val summaryExplanation = when (overallStatus) {
            CompromiseStatus.ACTION_RECOMMENDED ->
                "One or more critical security settings or app privileges require immediate attention. Review the flagged items below to protect your device."
            CompromiseStatus.REVIEW_RECOMMENDED ->
                "The device is operating normally, but several configurations or recently installed applications are worth reviewing for peace of mind."
            CompromiseStatus.NO_OBVIOUS_ISSUE ->
                "All legitimate Android security checks are operating within normal parameters. No overt signs of device compromise were discovered."
        }

        val hindiSummaryExplanation = when (overallStatus) {
            CompromiseStatus.ACTION_RECOMMENDED ->
                "कुछ महत्वपूर्ण सुरक्षा सेटिंग्स या ऐप अनुमतियों पर तत्काल ध्यान देने की आवश्यकता है। नीचे दिए गए उपायों का पालन करें।"
            CompromiseStatus.REVIEW_RECOMMENDED ->
                "डिवाइस सामान्य रूप से चल रहा है, लेकिन कुछ सेटिंग्स या हाल ही में इंस्टॉल किए गए ऐप्स की समीक्षा करना बेहतर होगा।"
            CompromiseStatus.NO_OBVIOUS_ISSUE ->
                "सभी उपलब्ध एंड्रॉइड सुरक्षा जांच सामान्य स्थिति में हैं। किसी भी स्पष्ट हैकिंग या छेड़छाड़ के संकेत नहीं मिले हैं।"
        }

        // Generate Structured Plain Text Report
        val plainTextReport = generatePlainTextReport(
            timestamp = formattedDate,
            headline = headline,
            status = overallStatus,
            indicators = indicators,
            suspiciousApps = suspiciousApps,
            privacyGroups = privacyGroups,
            connectionType = connectionType,
            isVpn = isVpn
        )

        return MobileHackingAuditResult(
            timestamp = now,
            formattedDate = formattedDate,
            overallStatus = overallStatus,
            headline = headline,
            hindiHeadline = hindiHeadline,
            summaryExplanation = summaryExplanation,
            hindiSummaryExplanation = hindiSummaryExplanation,
            indicators = indicators,
            suspiciousApps = suspiciousApps.map { SuspiciousAppItemWrapper(it) },
            recentlyInstalledApps = recentlyInstalledApps.map { SuspiciousAppItemWrapper(it) },
            privacyAuditGroups = privacyGroups,
            connectionType = connectionType,
            isVpnActive = isVpn,
            vpnDetails = if (isVpn) "VPN tunnel currently encrypting or routing network traffic" else "Direct network connection",
            networkSecuritySummary = "Wi-Fi / Cellular interface operating under standard Android network stack rules.",
            androidLimitationsDisclosures = limitationsList,
            plainTextReport = plainTextReport
        )
    }

    private fun auditSingleApp(
        pkgInfo: PackageInfo,
        currentTime: Long,
        enabledAccessibilityPackages: Set<String>,
        enabledNotificationPackages: Set<String>,
        activeAdmins: Set<String>
    ): SuspiciousAppDetail {
        val appInfo = pkgInfo.applicationInfo
        val appName = try {
            appInfo?.loadLabel(packageManager)?.toString() ?: pkgInfo.packageName
        } catch (_: Exception) {
            pkgInfo.packageName
        }

        val isSystem = if (appInfo != null) {
            (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        } else false

        val installTime = pkgInfo.firstInstallTime
        val thirtyDaysMillis = 30L * 24L * 60L * 60L * 1000L
        val isRecent = (currentTime - installTime) < thirtyDaysMillis && installTime > 0

        val installerPkg = getInstallerPackage(pkgInfo.packageName)
        val isSideloaded = !isSystem && installerPkg != "com.android.vending" && installerPkg != "com.google.android.feedback"
        val installerName = formatInstallerName(installerPkg, isSystem)

        val requestedPermissions = pkgInfo.requestedPermissions?.toList() ?: emptyList()
        val sensitivePerms = filterSensitive(requestedPermissions)

        val hasAccessibility = enabledAccessibilityPackages.contains(pkgInfo.packageName) ||
                requestedPermissions.contains("android.permission.BIND_ACCESSIBILITY_SERVICE")

        val hasNotificationAccess = enabledNotificationPackages.contains(pkgInfo.packageName) ||
                requestedPermissions.contains("android.permission.BIND_NOTIFICATION_LISTENER_SERVICE")

        val hasDeviceAdmin = activeAdmins.contains(pkgInfo.packageName) ||
                requestedPermissions.contains("android.permission.BIND_DEVICE_ADMIN")

        val hasOverlay = requestedPermissions.contains("android.permission.SYSTEM_ALERT_WINDOW")
        val hasInstall = requestedPermissions.contains("android.permission.REQUEST_INSTALL_PACKAGES")

        val isRecognizedLegit = SignatureDatabase.isRecognizedLegitimateApp(pkgInfo.packageName)

        val riskFactors = mutableListOf<String>()
        val hindiRiskFactors = mutableListOf<String>()

        if (!isSystem && !isRecognizedLegit) {
            if (hasAccessibility) {
                riskFactors.add("Holds Accessibility Service capability (can read screen & automate taps)")
                hindiRiskFactors.add("एक्सेसिबिलिटी सर्विस की अनुमति (स्क्रीन पढ़ सकता है)")
            }
            if (hasNotificationAccess) {
                riskFactors.add("Notification Listener capability (can read incoming SMS & 2FA codes)")
                hindiRiskFactors.add("नोटिफिकेशन सुनने की अनुमति (ओटीपी पढ़ सकता है)")
            }
            if (hasDeviceAdmin) {
                riskFactors.add("Device Administrator privilege (can lock or manage device policies)")
                hindiRiskFactors.add("डिवाइस एडमिनिस्ट्रेटर की उच्च शक्ति")
            }
            if (hasOverlay && requestedPermissions.any { it.contains("SMS", ignoreCase = true) }) {
                riskFactors.add("Overlay permission combined with SMS text message access")
                hindiRiskFactors.add("ओवरले और एसएमएस दोनों की अनुमति")
            }
            if (hasInstall) {
                riskFactors.add("Can request secondary APK package installations")
                hindiRiskFactors.add("अन्य ऐप्स इंस्टॉल करने की अनुमति")
            }
            if (isSideloaded) {
                riskFactors.add("Installed from third-party source ($installerName)")
                hindiRiskFactors.add("बाहरी स्रोत से स्थापित ($installerName)")
            }
            if (isRecent && sensitivePerms.size >= 3) {
                riskFactors.add("Recently installed with 3+ sensitive permissions")
                hindiRiskFactors.add("हाल ही में 3 से अधिक संवेदनशील अनुमतियों के साथ स्थापित")
            }
        }

        val riskLevel = when {
            isSystem -> CompromiseStatus.NO_OBVIOUS_ISSUE
            isRecognizedLegit -> CompromiseStatus.NO_OBVIOUS_ISSUE
            hasAccessibility || hasDeviceAdmin || (hasOverlay && hasNotificationAccess) -> CompromiseStatus.ACTION_RECOMMENDED
            riskFactors.isNotEmpty() -> CompromiseStatus.REVIEW_RECOMMENDED
            else -> CompromiseStatus.NO_OBVIOUS_ISSUE
        }

        val whatWasFound = if (riskFactors.isNotEmpty()) {
            riskFactors.joinToString("; ")
        } else {
            "Standard application permissions without abnormal privilege combinations."
        }

        val hindiWhatWasFound = if (hindiRiskFactors.isNotEmpty()) {
            hindiRiskFactors.joinToString("; ")
        } else {
            "सामान्य अनुमतियां, कोई संदिग्ध गतिविधि नहीं।"
        }

        val whyItMatters = when (riskLevel) {
            CompromiseStatus.ACTION_RECOMMENDED ->
                "High-level system privileges (such as Accessibility or Device Admin) can be abused to control the screen, steal sensitive credentials, or prevent uninstallation."
            CompromiseStatus.REVIEW_RECOMMENDED ->
                "Sideloaded apps or apps with sensitive permissions should be reviewed to verify they genuinely require these access rights."
            CompromiseStatus.NO_OBVIOUS_ISSUE ->
                "App operates within standard Android application isolation bounds."
        }

        val hindiWhyItMatters = when (riskLevel) {
            CompromiseStatus.ACTION_RECOMMENDED ->
                "ये अनुमतियां स्क्रीन देखने, पासवर्ड चुराने या ऐप को हटने से रोकने में सक्षम हैं।"
            CompromiseStatus.REVIEW_RECOMMENDED ->
                "बाहरी स्रोतों से आए ऐप्स की जांच करना सुरक्षित रहने के लिए आवश्यक है।"
            CompromiseStatus.NO_OBVIOUS_ISSUE ->
                "ऐप सामान्य सुरक्षा सीमाओं के भीतर काम कर रहा है।"
        }

        val whatUserCanDo = when (riskLevel) {
            CompromiseStatus.ACTION_RECOMMENDED ->
                "Review permissions in App Info. If you did not install this app for explicit assistive purposes, uninstall it immediately."
            CompromiseStatus.REVIEW_RECOMMENDED ->
                "Confirm that you recognize this application. If you no longer use it, remove it to reduce attack surface."
            CompromiseStatus.NO_OBVIOUS_ISSUE ->
                "No action required."
        }

        val hindiWhatUserCanDo = when (riskLevel) {
            CompromiseStatus.ACTION_RECOMMENDED ->
                "ऐप जानकारी में अनुमतियां देखें। यदि यह भरोसेमंद नहीं है तो तुरंत अनइंस्टॉल करें।"
            CompromiseStatus.REVIEW_RECOMMENDED ->
                "जाँचें कि क्या आप इस ऐप को पहचानते हैं। अनुपयोगी होने पर हटा दें।"
            CompromiseStatus.NO_OBVIOUS_ISSUE ->
                "किसी कार्रवाई की आवश्यकता नहीं है।"
        }

        val installDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val formattedInstall = if (installTime > 0) installDateFormat.format(Date(installTime)) else "Pre-installed"

        return SuspiciousAppDetail(
            appName = appName,
            packageName = pkgInfo.packageName,
            versionName = pkgInfo.versionName ?: "1.0",
            isSystemApp = isSystem,
            installTimeMillis = installTime,
            formattedInstallDate = formattedInstall,
            isRecentlyInstalled = isRecent,
            installerName = installerName,
            isSideloaded = isSideloaded,
            hasAccessibilityAccess = hasAccessibility,
            hasNotificationAccess = hasNotificationAccess,
            hasDeviceAdminAccess = hasDeviceAdmin,
            hasOverlayAccess = hasOverlay,
            hasInstallPackagesAccess = hasInstall,
            sensitivePermissions = sensitivePerms,
            riskFactors = riskFactors,
            hindiRiskFactors = hindiRiskFactors,
            riskLevel = riskLevel,
            whatWasFound = whatWasFound,
            hindiWhatWasFound = hindiWhatWasFound,
            whyItMatters = whyItMatters,
            hindiWhyItMatters = hindiWhyItMatters,
            whatUserCanDo = whatUserCanDo,
            hindiWhatUserCanDo = hindiWhatUserCanDo
        )
    }

    private fun buildPrivacyAuditGroups(apps: List<SuspiciousAppDetail>): List<HackingPrivacyGroup> {
        val list = mutableListOf<HackingPrivacyGroup>()

        // 1. Camera
        val cameraApps = getAppsWithPermission(apps, "android.permission.CAMERA")
        list.add(
            HackingPrivacyGroup(
                id = "priv_camera",
                name = "Camera Access",
                hindiName = "कैमरा एक्सेस",
                iconName = "camera",
                description = "Apps with permission to capture photographs and video recordings.",
                hindiDescription = "फ़ोटो और वीडियो रिकॉर्ड करने की अनुमति वाले ऐप्स।",
                permittedAppsCount = cameraApps.size,
                permittedApps = cameraApps
            )
        )

        // 2. Microphone
        val micApps = getAppsWithPermission(apps, "android.permission.RECORD_AUDIO")
        list.add(
            HackingPrivacyGroup(
                id = "priv_mic",
                name = "Microphone Access",
                hindiName = "माइक्रोफ़ोन एक्सेस",
                iconName = "mic",
                description = "Apps permitted to record live ambient sound and conversations.",
                hindiDescription = "आस-पास की आवाजें और बातचीत रिकॉर्ड करने की अनुमति वाले ऐप्स।",
                permittedAppsCount = micApps.size,
                permittedApps = micApps
            )
        )

        // 3. Location
        val locationApps = apps.filter { app ->
            app.sensitivePermissions.any { it.contains("LOCATION", ignoreCase = true) }
        }.map { it.appName }
        list.add(
            HackingPrivacyGroup(
                id = "priv_location",
                name = "Location Tracking",
                hindiName = "लोकेशन (स्थान) ट्रैकिंग",
                iconName = "location",
                description = "Apps with access to GPS satellites or cell tower coordinates.",
                hindiDescription = "जीपीएस या मोबाइल नेटवर्क से आपके स्थान को जानने वाले ऐप्स।",
                permittedAppsCount = locationApps.size,
                permittedApps = locationApps
            )
        )

        // 4. Contacts
        val contactsApps = getAppsWithPermission(apps, "android.permission.READ_CONTACTS")
        list.add(
            HackingPrivacyGroup(
                id = "priv_contacts",
                name = "Contacts & Address Book",
                hindiName = "संपर्क (Contacts) सूची",
                iconName = "contacts",
                description = "Apps capable of reading saved phone numbers and email addresses.",
                hindiDescription = "फ़ोन में सहेजे गए संपर्क और फ़ोन नंबर पढ़ने वाले ऐप्स।",
                permittedAppsCount = contactsApps.size,
                permittedApps = contactsApps
            )
        )

        // 5. SMS & Messages
        val smsApps = apps.filter { app ->
            app.sensitivePermissions.any { it.contains("SMS", ignoreCase = true) }
        }.map { it.appName }
        list.add(
            HackingPrivacyGroup(
                id = "priv_sms",
                name = "SMS & Verification Codes",
                hindiName = "एसएमएस और ओटीपी",
                iconName = "sms",
                description = "Apps that can view or send text messages, including banking OTPs.",
                hindiDescription = "टेक्स्ट मैसेज और बैंक ओटीपी पढ़ने में सक्षम ऐप्स।",
                permittedAppsCount = smsApps.size,
                permittedApps = smsApps
            )
        )

        // 6. Phone & Call Logs
        val phoneApps = apps.filter { app ->
            app.sensitivePermissions.any { it.contains("CALL", ignoreCase = true) || it.contains("PHONE_STATE", ignoreCase = true) }
        }.map { it.appName }
        list.add(
            HackingPrivacyGroup(
                id = "priv_phone",
                name = "Phone & Call Logs",
                hindiName = "फ़ोन और कॉल लॉग",
                iconName = "phone",
                description = "Apps permitted to initiate calls or read caller history logs.",
                hindiDescription = "कॉल करने या कॉल इतिहास देखने की अनुमति वाले ऐप्स।",
                permittedAppsCount = phoneApps.size,
                permittedApps = phoneApps
            )
        )

        // 7. Files & Storage / Media
        val storageApps = apps.filter { app ->
            app.sensitivePermissions.any { it.contains("STORAGE", ignoreCase = true) || it.contains("MEDIA", ignoreCase = true) }
        }.map { it.appName }
        list.add(
            HackingPrivacyGroup(
                id = "priv_storage",
                name = "Files & Media Storage",
                hindiName = "फ़ाइलें और मीडिया स्टोरेज",
                iconName = "folder",
                description = "Apps with access to downloaded documents, images, and device storage.",
                hindiDescription = "फ़ोटो, दस्तावेज़ और आंतरिक स्टोरेज पढ़ने वाले ऐप्स।",
                permittedAppsCount = storageApps.size,
                permittedApps = storageApps
            )
        )

        // 8. Notifications
        val notifApps = apps.filter { app ->
            app.sensitivePermissions.contains("android.permission.POST_NOTIFICATIONS") || app.hasNotificationAccess
        }.map { it.appName }
        list.add(
            HackingPrivacyGroup(
                id = "priv_notifications",
                name = "Notifications & Alerts",
                hindiName = "नोटिफिकेशन और अलर्ट",
                iconName = "notifications",
                description = "Apps permitted to display alerts or listen to incoming notifications.",
                hindiDescription = "अलर्ट भेजने या आने वाले नोटिफिकेशन को पढ़ने की अनुमति।",
                permittedAppsCount = notifApps.size,
                permittedApps = notifApps
            )
        )

        // 9. Accessibility
        val accessApps = apps.filter { it.hasAccessibilityAccess }.map { it.appName }
        list.add(
            HackingPrivacyGroup(
                id = "priv_accessibility",
                name = "Accessibility Control",
                hindiName = "एक्सेसिबिलिटी नियंत्रण",
                iconName = "accessibility",
                description = "Apps permitted deep screen observation and automated interaction.",
                hindiDescription = "स्क्रीन पढ़ने और स्वचालित क्रियाएं करने की विशेष अनुमति।",
                permittedAppsCount = accessApps.size,
                permittedApps = accessApps
            )
        )

        return list
    }

    private fun getAppsWithPermission(apps: List<SuspiciousAppDetail>, perm: String): List<String> {
        return apps.filter { it.sensitivePermissions.contains(perm) }.map { it.appName }
    }

    private fun filterSensitive(permissions: List<String>): List<String> {
        val targets = setOf(
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.READ_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.SEND_SMS",
            "android.permission.READ_PHONE_STATE",
            "android.permission.CALL_PHONE",
            "android.permission.SYSTEM_ALERT_WINDOW",
            "android.permission.REQUEST_INSTALL_PACKAGES",
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
            "android.permission.POST_NOTIFICATIONS",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_MEDIA_IMAGES",
            "android.permission.READ_MEDIA_VIDEO"
        )
        return permissions.filter { it in targets }
    }

    private fun getEnabledAccessibilityPackages(): Set<String> {
        val result = mutableSetOf<String>()
        try {
            val list = accessibilityManager?.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK
            ) ?: emptyList()
            for (service in list) {
                val serviceInfo = service.resolveInfo?.serviceInfo
                if (serviceInfo != null) {
                    result.add(serviceInfo.packageName)
                }
            }
        } catch (_: Exception) {}
        return result
    }

    private fun getEnabledNotificationListeners(): Set<String> {
        return try {
            NotificationManagerCompat.getEnabledListenerPackages(context)
        } catch (_: Exception) {
            emptySet()
        }
    }

    private fun getActiveDeviceAdminPackages(): Set<String> {
        val result = mutableSetOf<String>()
        try {
            val admins = devicePolicyManager?.activeAdmins ?: emptyList<ComponentName>()
            for (cn in admins) {
                result.add(cn.packageName)
            }
        } catch (_: Exception) {}
        return result
    }

    private fun checkVpnStatus(): Boolean {
        return try {
            val activeNetwork = connectivityManager?.activeNetwork ?: return false
            val caps = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        } catch (_: Exception) {
            false
        }
    }

    private fun getActiveConnectionType(): String {
        return try {
            val activeNetwork = connectivityManager?.activeNetwork ?: return "Disconnected"
            val caps = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return "Unknown"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular Mobile Data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN Tunnel"
                else -> "Active Network"
            }
        } catch (_: Exception) {
            "Network Available"
        }
    }

    private fun checkSuBinaryPresence(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/data/local/su"
        )
        return try {
            paths.any { File(it).exists() }
        } catch (_: Exception) {
            false
        }
    }

    private fun getInstallerPackage(packageName: String): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                packageManager.getInstallSourceInfo(packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                packageManager.getInstallerPackageName(packageName)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun formatInstallerName(installer: String?, isSystem: Boolean): String {
        return when {
            isSystem -> "System Partition (Pre-installed)"
            installer == null -> "Unknown / Direct Sideload"
            installer == "com.android.vending" -> "Google Play Store"
            installer == "com.google.android.feedback" -> "Google Play Services"
            installer == "com.amazon.venezia" -> "Amazon Appstore"
            installer == "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
            installer == "com.android.packageinstaller" -> "Package Installer (Manual APK)"
            installer == "com.google.android.packageinstaller" -> "Android Package Installer"
            else -> installer
        }
    }

    private fun generatePlainTextReport(
        timestamp: String,
        headline: String,
        status: CompromiseStatus,
        indicators: List<CompromiseIndicator>,
        suspiciousApps: List<SuspiciousAppDetail>,
        privacyGroups: List<HackingPrivacyGroup>,
        connectionType: String,
        isVpn: Boolean
    ): String {
        val sb = StringBuilder()
        sb.append("=========================================\n")
        sb.append("🚨 MOBILE HACKING SOLUTION AUDIT REPORT\n")
        sb.append("Virus Guard - Mobile Security Assistant\n")
        sb.append("=========================================\n")
        sb.append("Date & Time: $timestamp\n")
        sb.append("Overall Posture: $headline\n")
        sb.append("Rating: ${status.name}\n\n")

        sb.append("-----------------------------------------\n")
        sb.append("1. SECURITY FINDINGS & COMPROMISE CHECKS\n")
        sb.append("-----------------------------------------\n")
        for (ind in indicators) {
            sb.append("• [${ind.status}] ${ind.title}\n")
            sb.append("  WHAT WAS FOUND: ${ind.whatWasFound}\n")
            sb.append("  WHY IT MATTERS: ${ind.whyItMatters}\n")
            sb.append("  ACTION: ${ind.whatUserCanDo}\n\n")
        }

        sb.append("-----------------------------------------\n")
        sb.append("2. SUSPICIOUS & SIDELOADED APPLICATIONS\n")
        sb.append("-----------------------------------------\n")
        if (suspiciousApps.isEmpty()) {
            sb.append("No applications flagged for high-risk permissions or suspicious origins.\n\n")
        } else {
            for (app in suspiciousApps.take(10)) {
                sb.append("• ${app.appName} (${app.packageName})\n")
                sb.append("  Source: ${app.installerName} | Installed: ${app.formattedInstallDate}\n")
                sb.append("  Risk Factors: ${app.riskFactors.joinToString(", ")}\n\n")
            }
        }

        sb.append("-----------------------------------------\n")
        sb.append("3. PRIVACY & SENSITIVE PERMISSION GROUPS\n")
        sb.append("-----------------------------------------\n")
        for (group in privacyGroups) {
            sb.append("• ${group.name}: ${group.permittedAppsCount} apps holding permission\n")
            if (group.permittedApps.isNotEmpty()) {
                sb.append("  (${group.permittedApps.take(5).joinToString(", ")}${if (group.permittedApps.size > 5) "..." else ""})\n")
            }
        }
        sb.append("\n")

        sb.append("-----------------------------------------\n")
        sb.append("4. NETWORK SAFETY POSTURE\n")
        sb.append("-----------------------------------------\n")
        sb.append("Connection: $connectionType\n")
        sb.append("VPN Status: ${if (isVpn) "ACTIVE (Traffic Encrypted or Routed through tunnel)" else "INACTIVE (Direct connection)"}\n")
        sb.append("Network Inspection: Virus Guard does NOT intercept passwords, bypass HTTPS, or capture private payloads.\n\n")

        sb.append("-----------------------------------------\n")
        sb.append("5. RECOMMENDED NEXT STEPS\n")
        sb.append("-----------------------------------------\n")
        sb.append("1. Review and remove unknown applications.\n")
        sb.append("2. Verify active Accessibility Services in Android Settings.\n")
        sb.append("3. Enable Two-Factor Authentication (2FA) on your Google and banking accounts.\n")
        sb.append("4. Ensure device screen lock (PIN/Password) is enabled.\n")
        sb.append("5. Keep Android and Google Play apps updated to latest versions.\n\n")

        sb.append("-----------------------------------------\n")
        sb.append("6. ANDROID PRIVACY & LIMITATIONS NOTICE\n")
        sb.append("-----------------------------------------\n")
        sb.append("Android does not provide memory inspection of other applications to normal apps.\n")
        sb.append("Virus Guard runs within standard user boundaries. No passwords or OTPs were collected.\n")
        sb.append("Report generated securely on-device.\n")

        return sb.toString()
    }

    companion object {
        fun getRecoverySteps(): List<RecoveryStep> {
            return listOf(
                RecoveryStep(
                    stepNumber = 1,
                    title = "Review Suspicious Applications",
                    hindiTitle = "कदम 1: संदिग्ध ऐप्स की समीक्षा करें",
                    summary = "Inspect recently installed or sideloaded apps that hold elevated access rights.",
                    hindiSummary = "हाल ही में इंस्टॉल किए गए या अनजान ऐप्स की जांच करें।",
                    detailedInstructions = listOf(
                        "Open the 'Suspicious Apps' list in Virus Guard.",
                        "Look for apps you do not remember downloading or that have unusual names/icons.",
                        "Tap 'Uninstall' on any application you don't trust or need.",
                        "Never allow apps you downloaded from links or browser popups to stay installed."
                    ),
                    hindiInstructions = listOf(
                        "संदिग्ध ऐप्स सूची देखें।",
                        "ऐसे ऐप्स पहचानें जिन्हें आपने खुद इंस्टॉल नहीं किया था।",
                        "अविश्वसनीय ऐप्स पर 'Uninstall' दबाकर उन्हें हटा दें।"
                    ),
                    actionLabel = "Open App Settings",
                    intentAction = Settings.ACTION_APPLICATION_SETTINGS
                ),
                RecoveryStep(
                    stepNumber = 2,
                    title = "Review Sensitive Permissions",
                    hindiTitle = "कदम 2: संवेदनशील अनुमतियों की जांच करें",
                    summary = "Revoke Accessibility, Notification Access, and Device Admin from untrusted tools.",
                    hindiSummary = "एक्सेसिबिलिटी और नोटिफिकेशन पढ़ने की अनुमतियां बंद करें।",
                    detailedInstructions = listOf(
                        "Go to Android Settings > Accessibility and turn off all services except official Google tools (e.g. TalkBack).",
                        "Go to Settings > Special App Access > Device Admin Apps and disable unknown administrators.",
                        "Go to Settings > Special App Access > Notification Access and remove unauthorized apps.",
                        "Revoke Camera, Microphone, and Location access from apps that don't need them."
                    ),
                    hindiInstructions = listOf(
                        "सेटिंग्स > एक्सेसिबिलिटी में जाकर अज्ञात सेवाएं बंद करें।",
                        "सेटिंग्स > डिवाइस एडमिन में अनजान ऐप्स को निष्क्रिय करें।",
                        "नोटिफिकेशन एक्सेस से अनजान ऐप्स हटाएं।"
                    ),
                    actionLabel = "Open Accessibility Settings",
                    intentAction = Settings.ACTION_ACCESSIBILITY_SETTINGS
                ),
                RecoveryStep(
                    stepNumber = 3,
                    title = "Update Android & Installed Apps",
                    hindiTitle = "कदम 3: एंड्रॉइड और ऐप्स अपडेट करें",
                    summary = "Install official firmware patches and Google Play updates.",
                    hindiSummary = "फ़ोन और प्ले स्टोर के सभी ऐप्स को नवीनतम संस्करण में अपडेट करें।",
                    detailedInstructions = listOf(
                        "Open Settings > System > System Update and download any pending OEM firmware updates.",
                        "Open Google Play Store > Profile Icon > Manage apps & device > Update all.",
                        "Official updates patch known security exploits used by malware to gain persistence."
                    ),
                    hindiInstructions = listOf(
                        "सेटिंग्स > सिस्टम अपडेट में जाकर नया अपडेट इंस्टॉल करें।",
                        "गूगल प्ले स्टोर में जाकर सभी ऐप्स अपडेट करें।"
                    ),
                    actionLabel = "Check System Updates",
                    intentAction = Settings.ACTION_SYSTEM_UPDATE_SETTINGS
                ),
                RecoveryStep(
                    stepNumber = 4,
                    title = "Secure Important Online Accounts",
                    hindiTitle = "कदम 4: अपने ऑनलाइन खाते सुरक्षित करें",
                    summary = "Change credentials from a trusted device and enable Two-Factor Authentication (2FA).",
                    hindiSummary = "किसी सुरक्षित डिवाइस से पासवर्ड बदलें और 2FA चालू करें।",
                    detailedInstructions = listOf(
                        "Use a trusted secondary device (e.g. laptop or another clean phone) if you suspect your phone is monitored.",
                        "Change passwords for your primary Google account, bank accounts, and email services.",
                        "Turn on Two-Factor Authentication (2FA) using an authenticator app rather than SMS where possible.",
                        "Review active login sessions and tap 'Sign Out of all other sessions'.",
                        "Never share verification codes or OTPs with anyone, even if they claim to be support staff."
                    ),
                    hindiInstructions = listOf(
                        "यदि समझौता होने का संदेह हो तो किसी अन्य सुरक्षित फ़ोन या कंप्यूटर से पासवर्ड बदलें।",
                        "गूगल और बैंक खातों पर टू-फैक्टर ऑथेंटिकेशन (2FA) सक्षम करें।",
                        "अज्ञात एक्टिव सेशन्स से तुरंत साइन आउट करें।"
                    )
                ),
                RecoveryStep(
                    stepNumber = 5,
                    title = "Enable Android Built-in Protections",
                    hindiTitle = "कदम 5: एंड्रॉइड सुरक्षा सुविधाएं चालू करें",
                    summary = "Set up screen locks, verify Google Play Protect, and disable ADB debugging.",
                    hindiSummary = "स्क्रीन लॉक लगाएं, प्ले प्रोटेक्ट चालू करें और USB डिबगिंग बंद करें।",
                    detailedInstructions = listOf(
                        "Enable a strong PIN or biometric screen lock in Settings > Security.",
                        "Open Google Play Store > Profile > Play Protect and tap 'Scan'.",
                        "Ensure Developer Options > USB Debugging is turned OFF.",
                        "Turn off 'Install Unknown Apps' permissions in Special App Access."
                    ),
                    hindiInstructions = listOf(
                        "सेटिंग्स > सुरक्षा में जाकर मजबूत पिन या फिंगरप्रिंट लॉक लगाएं।",
                        "गूगल प्ले प्रोटेक्ट स्कैन चलाएं।",
                        "USB डिबगिंग को बंद रखें।"
                    ),
                    actionLabel = "Open Security Settings",
                    intentAction = Settings.ACTION_SECURITY_SETTINGS
                ),
                RecoveryStep(
                    stepNumber = 6,
                    title = "Factory Reset (Official Recovery Option)",
                    hindiTitle = "कदम 6: फ़ैक्टरी रीसेट (अंतिम रिकवरी विकल्प)",
                    summary = "If serious compromise or persistent spyware is suspected, use Android's official reset.",
                    hindiSummary = "यदि गंभीर समझौता या लगातार जासूसी का संदेह हो, तो फ़ैक्टरी रीसेट का उपयोग करें।",
                    detailedInstructions = listOf(
                        "CRITICAL WARNING: A factory reset completely ERASES all photos, messages, apps, and accounts from this phone.",
                        "Before resetting, safely copy essential photos and personal files to trusted cloud storage or a clean computer.",
                        "Do not back up APK installation files from unknown sources.",
                        "Open Settings > System > Reset options > Erase all data (factory reset).",
                        "After reset, set up the phone as a new device and download apps only from Google Play Store."
                    ),
                    hindiInstructions = listOf(
                        "⚠️ महत्वपूर्ण चेतावनी: फ़ैक्टरी रीसेट करने से आपके फ़ोन का सारा डेटा, फ़ोटो, संदेश और ऐप्स मिट जाएंगे।",
                        "रीसेट करने से पहले अपने महत्वपूर्ण फ़ोटो और दस्तावेज़ों का सुरक्षित बैकअप लें।",
                        "सेटिंग्स > सिस्टम > रीसेट विकल्प > सारा डेटा मिटाएं (Factory Reset) चुनें।"
                    ),
                    isWarning = true,
                    warningText = "⚠️ FACTORY RESET WARNING: This will erase ALL data, downloaded files, photos, contacts, and apps permanently. Ensure your important data is backed up before proceeding.",
                    hindiWarningText = "⚠️ चेतावनी: इससे फ़ोन का सारा डेटा हमेशा के लिए मिट जाएगा। कृपया पहले बैकअप ले लें।",
                    actionLabel = "Open Reset Settings",
                    intentAction = Settings.ACTION_SETTINGS
                )
            )
        }

        fun getAccountSecurityChecklist(): List<AccountSecurityCheckItem> {
            return listOf(
                AccountSecurityCheckItem(
                    id = "acc_pwd",
                    title = "Change Important Passwords",
                    hindiTitle = "महत्वपूर्ण पासवर्ड बदलें",
                    description = "Change passwords for your Google account, primary email, banking apps, and social accounts.",
                    hindiDescription = "यदि समझौता होने का संदेह हो तो गूगल, बैंक और सोशल मीडिया के पासवर्ड बदलें।",
                    actionAdvice = "If you suspect this phone is monitored, change passwords from a separate, trusted device (such as a family member's phone or desktop computer).",
                    hindiActionAdvice = "यदि फ़ोन पर जासूसी का संदेह है, तो किसी अन्य सुरक्षित कंप्यूटर या फ़ोन से पासवर्ड बदलें।"
                ),
                AccountSecurityCheckItem(
                    id = "acc_2fa",
                    title = "Enable Two-Factor Authentication (2FA)",
                    hindiTitle = "टू-फ़ैक्टर प्रमाणीकरण (2FA) चालू करें",
                    description = "Require a second verification step when logging in to your accounts from new devices.",
                    hindiDescription = "किसी भी नए डिवाइस से लॉगिन करते समय दूसरे सत्यापन चरण की आवश्यकता बनाएं।",
                    actionAdvice = "Enable 2FA on your Google Account and banking profiles. Prefer Authenticator apps (like Google Authenticator) over SMS codes where available.",
                    hindiActionAdvice = "अपने Google खाते पर 2-Step Verification सक्षम करें। एसएमएस की तुलना में ऑथेंटिकेटर ऐप अधिक सुरक्षित है।"
                ),
                AccountSecurityCheckItem(
                    id = "acc_sessions",
                    title = "Review Active Login Sessions",
                    hindiTitle = "सक्रिय लॉगिन सत्रों की समीक्षा करें",
                    description = "Inspect which phones, computers, and locations are currently logged into your accounts.",
                    hindiDescription = "जाँचें कि कौन से डिवाइस और शहर आपके खातों में लॉगिन हैं।",
                    actionAdvice = "Visit myaccount.google.com/device-activity and sign out of any device, browser, or city you do not recognize.",
                    hindiActionAdvice = "myaccount.google.com/device-activity पर जाएं और किसी भी अनजान डिवाइस को तुरंत साइन आउट करें।"
                ),
                AccountSecurityCheckItem(
                    id = "acc_signout",
                    title = "Sign Out Unknown Sessions",
                    hindiTitle = "अज्ञात सेशन्स से तुरंत साइन आउट करें",
                    description = "Terminate open sessions on unfamiliar computers or old devices.",
                    hindiDescription = "पुराने या अनजान कंप्यूटरों पर खुले सत्रों को बंद करें।",
                    actionAdvice = "Use the 'Sign out of all sessions' button in Google, WhatsApp Web, Telegram, and banking web portals.",
                    hindiActionAdvice = "Google, WhatsApp Web, और बैंकिंग पोर्टल्स में 'Sign out all sessions' चुनें।"
                ),
                AccountSecurityCheckItem(
                    id = "acc_otp",
                    title = "Never Share OTPs or Security Codes",
                    hindiTitle = "ओटीपी या सुरक्षा कोड कभी साझा न करें",
                    description = "One-Time Passwords (OTPs) grant total access to your accounts and financial transfers.",
                    hindiDescription = "वन-टाइम पासवर्ड (OTP) आपके खाते और पैसों की कुंजी है।",
                    actionAdvice = "Bank staff, tech support, and law enforcement will NEVER ask you for an OTP. Never enter codes on links sent via SMS.",
                    hindiActionAdvice = "बैंक या पुलिस कभी भी आपसे फ़ोन पर ओटीपी नहीं मांगते। किसी को भी ओटीपी न बताएं।"
                ),
                AccountSecurityCheckItem(
                    id = "acc_recovery",
                    title = "Review Recovery Email & Phone Number",
                    hindiTitle = "रिकवरी ईमेल और फ़ोन नंबर की पुष्टि करें",
                    description = "Attackers often replace recovery details to prevent the legitimate owner from regaining access.",
                    hindiDescription = "हमलावर अक्सर आपका नियंत्रण छीनने के लिए रिकवरी फ़ोन नंबर बदल देते हैं।",
                    actionAdvice = "Check Google Account Security > Ways we can verify it's you. Verify that the recovery phone number and backup email belong strictly to you.",
                    hindiActionAdvice = "अपने Google खाते में जाकर सुनिश्चित करें कि रिकवरी मोबाइल नंबर और ईमेल केवल आपका ही है।"
                ),
                AccountSecurityCheckItem(
                    id = "acc_provider",
                    title = "Contact Service Provider If Compromised",
                    hindiTitle = "खाता हैक होने पर सेवा प्रदाता से संपर्क करें",
                    description = "Reach out to official support channels if you are locked out or notice unauthorized financial transactions.",
                    hindiDescription = "यदि कोई अनधिकृत लेन-देन हुआ है तो तुरंत अपने बैंक और सेवा प्रदाता को सूचित करें।",
                    actionAdvice = "Immediately call your bank's 24x7 fraud prevention helpline to freeze compromised credit/debit cards or net banking access.",
                    hindiActionAdvice = "अपने बैंक के कस्टमर केयर पर तुरंत कॉल करके अपने कार्ड या नेट बैंकिंग को ब्लॉक करवाएं।"
                )
            )
        }

        fun getEmergencyChecklist(): List<EmergencyActionItem> {
            return listOf(
                EmergencyActionItem(
                    stepNumber = 1,
                    actionText = "Stop interacting with suspicious messages or links immediately.",
                    hindiActionText = "संदिग्ध संदेशों या अज्ञात लिंक पर क्लिक करना तुरंत बंद करें।",
                    explanation = "Do not open forwarded links, download attachments, or call phone numbers mentioned in unexpected urgent alerts.",
                    hindiExplanation = "किसी भी अज्ञात संदेश में आए लिंक या फ़ाइल को न खोलें।"
                ),
                EmergencyActionItem(
                    stepNumber = 2,
                    actionText = "Review and uninstall suspicious applications.",
                    hindiActionText = "संदिग्ध ऐप्स की समीक्षा करें और उन्हें अनइंस्टॉल करें।",
                    explanation = "Check the 'Suspicious Apps' list in this app and delete any software you did not deliberately install from Google Play.",
                    hindiExplanation = "अवांछित या हाल ही में आए अनजान ऐप्स को तुरंत फ़ोन से हटा दें।"
                ),
                EmergencyActionItem(
                    stepNumber = 3,
                    actionText = "Secure important online accounts from a clean device.",
                    hindiActionText = "किसी अन्य सुरक्षित डिवाइस से अपने मुख्य खाते सुरक्षित करें।",
                    explanation = "If you suspect keystroke monitoring, use another phone or laptop to change your primary email and banking passwords.",
                    hindiExplanation = "यदि फ़ोन पर संदेह हो, तो दूसरे फ़ोन या कंप्यूटर से गूगल और बैंक पासवर्ड बदलें।"
                ),
                EmergencyActionItem(
                    stepNumber = 4,
                    actionText = "Enable Two-Factor Authentication (2FA).",
                    hindiActionText = "टू-फ़ैक्टर ऑथेंटिकेशन (2FA) तुरंत चालू करें।",
                    explanation = "Add authenticator app verification or prompt-based approval to all sensitive accounts.",
                    hindiExplanation = "अपने मुख्य खातों पर अतिरिक्त सुरक्षा कोड चालू करें।"
                ),
                EmergencyActionItem(
                    stepNumber = 5,
                    actionText = "Update the device operating system.",
                    hindiActionText = "डिवाइस ऑपरेटिंग सिस्टम को तुरंत अपडेट करें।",
                    explanation = "Check Settings > System Update. Installing official firmware patches closes known operating system security holes.",
                    hindiExplanation = "फ़ोन सेटिंग्स में जाकर नए सॉफ़्टवेयर अपडेट इंस्टॉल करें।"
                ),
                EmergencyActionItem(
                    stepNumber = 6,
                    actionText = "Use official Android security and recovery options.",
                    hindiActionText = "आधिकारिक एंड्रॉइड सुरक्षा और रिकवरी विकल्पों का उपयोग करें।",
                    explanation = "If unexplainable behavior or persistent popups continue, back up essential photos safely and consider an official factory reset.",
                    hindiExplanation = "यदि समस्या बनी रहती है, तो डेटा का बैकअप लेकर फ़ैक्टरी रीसेट पर विचार करें।"
                ),
                EmergencyActionItem(
                    stepNumber = 7,
                    actionText = "Contact relevant service providers if financial compromise occurred.",
                    hindiActionText = "वित्तीय नुकसान की स्थिति में तुरंत बैंक से संपर्क करें।",
                    explanation = "Notify your bank's fraud prevention helpline to block cards, freeze unauthorized UPI transfers, and report cyber fraud to local authorities.",
                    hindiExplanation = "अपने बैंक को तुरंत सूचित करके कार्ड ब्लॉक करवाएं और साइबर हेल्पलाइन पर रिपोर्ट दर्ज करें।"
                )
            )
        }
    }
}
