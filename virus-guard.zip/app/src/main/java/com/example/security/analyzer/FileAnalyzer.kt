package com.example.security.analyzer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.security.model.FileSecurityInfo
import com.example.security.model.RiskLevel
import com.example.security.scanner.SignatureDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.security.MessageDigest

class FileAnalyzer(private val context: Context) {

    suspend fun analyzeUri(uri: Uri): FileSecurityInfo = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver

        var fileName = "unknown_file"
        var sizeBytes = 0L

        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: fileName
                    if (sizeIndex != -1) sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {
            // Gracefully handle if query fails
        }

        val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"
        val lowerName = fileName.lowercase()
        val extension = lowerName.substringAfterLast('.', "")

        val sha256 = calculateSha256(uri)

        val reasons = mutableListOf<String>()
        var isApk = extension == "apk" || mimeType == "application/vnd.android.package-archive"

        // Double extension check (e.g. invoice.pdf.apk)
        val hasDoubleExtension = SignatureDatabase.SUSPICIOUS_DOUBLE_EXTENSIONS.any { lowerName.endsWith(it) }
        if (hasDoubleExtension) {
            reasons.add("File uses a deceptive double extension (e.g. disguised as a document or image).")
        }

        // Suspicious executable or script formats
        if (SignatureDatabase.SUSPICIOUS_EXTENSIONS.contains(extension)) {
            if (isApk) {
                reasons.add("Android application package (.apk). Sideloading apps can bypass Play Protect policy checks.")
            } else {
                reasons.add("Executable or script file type (.$extension). Inspect origin carefully.")
            }
        }

        // Oversized or zero-byte file anomaly
        if (sizeBytes == 0L) {
            reasons.add("File is empty (0 bytes).")
        }

        val riskLevel = when {
            hasDoubleExtension -> RiskLevel.POTENTIALLY_HARMFUL
            reasons.isNotEmpty() -> RiskLevel.REVIEW_RECOMMENDED
            else -> RiskLevel.NORMAL
        }

        FileSecurityInfo(
            fileName = fileName,
            sizeBytes = sizeBytes,
            mimeType = mimeType,
            extension = extension,
            sha256Hash = sha256,
            riskLevel = riskLevel,
            reasons = reasons,
            isApk = isApk
        )
    }

    private fun calculateSha256(uri: Uri): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            context.contentResolver.openInputStream(uri)?.use { inputStream: InputStream ->
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    digest.update(buffer, 0, bytesRead)
                }
            } ?: return "Unavailable"
            val hashBytes = digest.digest()
            hashBytes.joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            "Error calculating hash"
        }
    }
}
