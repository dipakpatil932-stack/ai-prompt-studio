package com.example.security.analyzer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.security.model.CheckState
import com.example.security.model.NetworkSecurityInfo
import com.example.security.model.RiskLevel

data class NetworkSafetyReport(
    val isConnected: Boolean,
    val connectionType: String,
    val isVpnActive: Boolean,
    val isMetered: Boolean,
    val isInternetValidated: Boolean,
    val securityStatus: CheckState,
    val summary: String,
    val recommendations: List<String>,
    val defensiveNotice: String = "Defensive Analysis: Evaluates standard OS network capabilities without intercepting or sniffing packet payloads."
)

class NetworkSafetyAnalyzer(private val context: Context) {

    fun evaluateNetworkSafety(): NetworkSafetyReport {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return NetworkSafetyReport(
                isConnected = false,
                connectionType = "Unavailable",
                isVpnActive = false,
                isMetered = false,
                isInternetValidated = false,
                securityStatus = CheckState.NOT_AVAILABLE,
                summary = "ConnectivityManager service is not available on this device.",
                recommendations = listOf("Check Android device networking settings.")
            )

        val activeNetwork = cm.activeNetwork
        if (activeNetwork == null) {
            return NetworkSafetyReport(
                isConnected = false,
                connectionType = "Offline",
                isVpnActive = false,
                isMetered = false,
                isInternetValidated = false,
                securityStatus = CheckState.GOOD,
                summary = "Device is currently offline. No active network transmission interfaces are transmitting.",
                recommendations = listOf("Connect to a secure, password-protected Wi-Fi or cellular network when online access is needed.")
            )
        }

        val capabilities = cm.getNetworkCapabilities(activeNetwork)
        val isVpnActive = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val isMetered = cm.isActiveNetworkMetered
        val isInternetValidated = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

        val connectionType = when {
            capabilities == null -> "Unknown Network"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "Virtual Private Network (VPN)"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi Network"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular Mobile Data"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Active Connection"
        }

        val recommendations = mutableListOf<String>()
        recommendations.add("Use a trusted network for sensitive activity like banking and private logins.")

        if (!isVpnActive && connectionType.contains("Wi-Fi", ignoreCase = true)) {
            recommendations.add("When connecting to public or unencrypted Wi-Fi hotspots, consider using a reputable VPN to encrypt data transit.")
        }
        if (isVpnActive) {
            recommendations.add("VPN tunnel is actively encrypting network routes between your device and gateway.")
        }
        if (isMetered) {
            recommendations.add("Connection is flagged as metered; background app sync is throttled by Android to preserve data.")
        }

        val summary = buildString {
            append("Connected to $connectionType.")
            if (isVpnActive) append(" Encrypted VPN routing is active.")
            if (isInternetValidated) append(" Internet access verified.")
            if (isMetered) append(" Connection is metered.")
        }

        return NetworkSafetyReport(
            isConnected = true,
            connectionType = connectionType,
            isVpnActive = isVpnActive,
            isMetered = isMetered,
            isInternetValidated = isInternetValidated,
            securityStatus = if (isVpnActive) CheckState.GOOD else CheckState.GOOD,
            summary = summary,
            recommendations = recommendations
        )
    }
}
