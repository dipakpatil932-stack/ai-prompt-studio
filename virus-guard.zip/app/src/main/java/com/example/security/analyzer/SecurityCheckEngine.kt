package com.example.security.analyzer

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.example.security.model.AppSecurityInfo
import com.example.security.model.CheckStatus
import com.example.security.model.CheckupItem
import com.example.security.model.CheckupResult
import com.example.security.model.RiskLevel

class SecurityCheckEngine(private val context: Context) {

    fun performCheckup(
        installedApps: List<AppSecurityInfo>,
        hasScannedRecently: Boolean
    ): CheckupResult {
        val items = mutableListOf<CheckupItem>()

        // 1. Device Screen Lock Check
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isDeviceSecure = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            keyguardManager?.isDeviceSecure == true
        } else {
            @Suppress("DEPRECATION")
            keyguardManager?.isKeyguardSecure == true
        }

        if (isDeviceSecure) {
            items.add(
                CheckupItem(
                    id = "check_screen_lock",
                    title = "Screen Lock Protection",
                    category = "Device Security",
                    status = CheckStatus.PASSED,
                    explanation = "A secure screen lock (PIN, password, pattern, or biometrics) is configured on this device.",
                    recommendation = "Device storage is hardware-encrypted when locked.",
                    intentAction = Settings.ACTION_SECURITY_SETTINGS
                )
            )
        } else {
            items.add(
                CheckupItem(
                    id = "check_screen_lock",
                    title = "Screen Lock Protection",
                    category = "Device Security",
                    status = CheckStatus.ACTION_NEEDED,
                    explanation = "No secure PIN, password, pattern, or biometric lock is detected on this device.",
                    recommendation = "Enable a PIN or biometric screen lock in Android Settings to prevent unauthorized physical access.",
                    intentAction = Settings.ACTION_SECURITY_SETTINGS
                )
            )
        }

        // 2. Developer Options & USB Debugging Status
        val devOptionsEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        val adbEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        if (adbEnabled) {
            items.add(
                CheckupItem(
                    id = "check_usb_debugging",
                    title = "USB Debugging (ADB)",
                    category = "Device Configuration",
                    status = CheckStatus.REVIEW,
                    explanation = "USB debugging is currently active. When connected to a computer, low-level bridge commands can be executed.",
                    recommendation = "Turn off USB debugging in Developer Options when not actively testing software.",
                    intentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                )
            )
        } else if (devOptionsEnabled) {
            items.add(
                CheckupItem(
                    id = "check_dev_options",
                    title = "Developer Options",
                    category = "Device Configuration",
                    status = CheckStatus.REVIEW,
                    explanation = "Developer options are enabled in system settings.",
                    recommendation = "Review developer settings if you enabled them for experimental testing.",
                    intentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                )
            )
        } else {
            items.add(
                CheckupItem(
                    id = "check_dev_options",
                    title = "Developer Mode",
                    category = "Device Configuration",
                    status = CheckStatus.PASSED,
                    explanation = "Developer options are disabled, minimizing unauthorized ADB debugging connections.",
                    recommendation = "Maintains standard user security boundary."
                )
            )
        }

        // 3. Notification Protection Settings
        val notificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        if (notificationsEnabled) {
            items.add(
                CheckupItem(
                    id = "check_notifications",
                    title = "Security Alert Notifications",
                    category = "System Alerts",
                    status = CheckStatus.PASSED,
                    explanation = "Notifications are enabled, allowing Virus Guard to alert you of critical security scans.",
                    recommendation = "Notification channels are active."
                )
            )
        } else {
            items.add(
                CheckupItem(
                    id = "check_notifications",
                    title = "Security Alert Notifications",
                    category = "System Alerts",
                    status = CheckStatus.REVIEW,
                    explanation = "App notifications are disabled. You will not receive background reminders for scan alerts.",
                    recommendation = "Enable notifications in App Info settings.",
                    intentAction = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                )
            )
        }

        // 4. Installed Apps Risk Analysis
        val potentiallyHarmfulApps = installedApps.filter { it.riskLevel == RiskLevel.POTENTIALLY_HARMFUL }
        val reviewApps = installedApps.filter { it.riskLevel == RiskLevel.REVIEW_RECOMMENDED }

        if (potentiallyHarmfulApps.isNotEmpty()) {
            items.add(
                CheckupItem(
                    id = "check_harmful_apps",
                    title = "Application Safety Status",
                    category = "App Safety",
                    status = CheckStatus.ACTION_NEEDED,
                    explanation = "${potentiallyHarmfulApps.size} installed app(s) display high-risk combinations (e.g. background overlay + accessibility).",
                    recommendation = "Review and consider uninstalling unverified apps: ${potentiallyHarmfulApps.joinToString { it.appName }}."
                )
            )
        } else if (reviewApps.isNotEmpty()) {
            items.add(
                CheckupItem(
                    id = "check_review_apps",
                    title = "Application Safety Status",
                    category = "App Safety",
                    status = CheckStatus.REVIEW,
                    explanation = "${reviewApps.size} installed app(s) request sensitive permissions or originated outside the official store.",
                    recommendation = "Inspect permissions in the App Safety tab to ensure each app needs the access it requests."
                )
            )
        } else if (installedApps.isNotEmpty()) {
            items.add(
                CheckupItem(
                    id = "check_apps_normal",
                    title = "Application Safety Status",
                    category = "App Safety",
                    status = CheckStatus.PASSED,
                    explanation = "All ${installedApps.size} installed applications analyzed conform to standard permission guidelines.",
                    recommendation = "No suspicious permission combinations detected."
                )
            )
        }

        // 5. Sideloaded Application Check
        val sideloadedApps = installedApps.filter {
            !it.isSystemApp && it.installerPackageName != "com.android.vending" &&
                    it.installerPackageName != "com.google.android.feedback" &&
                    it.installerPackageName != "com.amazon.venezia"
        }
        if (sideloadedApps.isNotEmpty()) {
            items.add(
                CheckupItem(
                    id = "check_sideloaded_sources",
                    title = "App Installation Sources",
                    category = "Install Origins",
                    status = CheckStatus.REVIEW,
                    explanation = "${sideloadedApps.size} app(s) were installed via external APKs or package installers outside Google Play Store.",
                    recommendation = "Confirm that you trust the developers and source websites of these sideloaded apps.",
                    intentAction = Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                )
            )
        } else {
            items.add(
                CheckupItem(
                    id = "check_sideloaded_sources",
                    title = "App Installation Sources",
                    category = "Install Origins",
                    status = CheckStatus.PASSED,
                    explanation = "All user applications were installed through official verified application stores.",
                    recommendation = "Play Protect and store verification are utilized."
                )
            )
        }

        // 6. Scan Recency Check
        if (hasScannedRecently) {
            items.add(
                CheckupItem(
                    id = "check_scan_recency",
                    title = "Security Scan Currency",
                    category = "Monitoring",
                    status = CheckStatus.PASSED,
                    explanation = "A security scan has been completed recently.",
                    recommendation = "Regular scans keep security metrics up to date."
                )
            )
        } else {
            items.add(
                CheckupItem(
                    id = "check_scan_recency",
                    title = "Security Scan Currency",
                    category = "Monitoring",
                    status = CheckStatus.REVIEW,
                    explanation = "No comprehensive scan has been recorded recently.",
                    recommendation = "Run a Quick Scan or Deep Scan to update your threat assessment."
                )
            )
        }

        val passedCount = items.count { it.status == CheckStatus.PASSED }
        val reviewCount = items.count { it.status == CheckStatus.REVIEW }
        val actionNeededCount = items.count { it.status == CheckStatus.ACTION_NEEDED }

        var score = 100
        score -= (actionNeededCount * 25)
        score -= (reviewCount * 10)
        score = score.coerceIn(0, 100)

        return CheckupResult(
            timestamp = System.currentTimeMillis(),
            score = score,
            passedCount = passedCount,
            reviewCount = reviewCount,
            actionNeededCount = actionNeededCount,
            items = items
        )
    }
}
