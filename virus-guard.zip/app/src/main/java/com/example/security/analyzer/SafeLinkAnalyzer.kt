package com.example.security.analyzer

import android.net.Uri
import com.example.security.model.LinkSecurityInfo
import com.example.security.model.RiskLevel
import com.example.security.scanner.OfflineThreatIntelligenceProvider
import com.example.security.scanner.ThreatIntelligenceProvider
import java.util.regex.Pattern

class SafeLinkAnalyzer(
    private val threatIntelProvider: ThreatIntelligenceProvider = OfflineThreatIntelligenceProvider()
) {

    private val ipv4Pattern = Pattern.compile("^([0-9]{1,3}\\.){3}[0-9]{1,3}$")

    private val suspiciousSubdomainKeywords = listOf(
        "login", "signin", "verify", "secure", "update", "account",
        "banking", "paypal", "appleid", "google-support", "wallet", "recovery"
    )

    private val suspiciousTlds = setOf(
        "xyz", "top", "work", "loan", "club", "stream", "gq", "cf", "tk", "ml", "ga"
    )

    fun analyzeUrl(rawUrl: String): LinkSecurityInfo {
        val trimmed = rawUrl.trim()
        val formattedUrl = if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            "https://$trimmed"
        } else {
            trimmed
        }

        val uri = try {
            Uri.parse(formattedUrl)
        } catch (_: Exception) {
            null
        }

        val host = uri?.host ?: ""
        val scheme = uri?.scheme?.lowercase() ?: ""
        val isHttps = scheme == "https"
        val port = uri?.port ?: -1

        val reasons = mutableListOf<String>()

        if (uri == null || host.isBlank()) {
            return LinkSecurityInfo(
                url = rawUrl,
                host = "Invalid URL",
                isHttps = false,
                hasIpHost = false,
                hasPunycode = false,
                hasEmbeddedCredentials = false,
                hasNonStandardPort = false,
                riskLevel = RiskLevel.REVIEW_RECOMMENDED,
                reasons = listOf("Invalid or malformed URL syntax.")
            )
        }

        // Scheme check
        if (!isHttps) {
            reasons.add("Uses unencrypted HTTP connection. Traffic and data entered can be intercepted on open networks.")
        }

        // IP address as host
        val hasIpHost = ipv4Pattern.matcher(host).matches()
        if (hasIpHost) {
            reasons.add("Host is a numeric IP address ($host) instead of a registered domain name. Commonly used by deceptive servers.")
        }

        // Punycode / Internationalized Domain Name spoofing
        val hasPunycode = host.contains("xn--", ignoreCase = true)
        if (hasPunycode) {
            reasons.add("Uses Punycode (xn--) encoding. Often used in visual homograph attacks to impersonate familiar websites.")
        }

        // Embedded credentials (e.g. user:pass@example.com)
        val hasEmbeddedCredentials = !uri.encodedUserInfo.isNullOrEmpty()
        if (hasEmbeddedCredentials) {
            reasons.add("URL contains embedded authentication userinfo (${uri.encodedUserInfo}). Legitimate sites do not format links with credentials.")
        }

        // Non-standard port check
        val hasNonStandardPort = port != -1 && port != 80 && port != 443
        if (hasNonStandardPort) {
            reasons.add("Connects to a non-standard web port ($port). Standard web traffic operates over port 443 (HTTPS) or 80 (HTTP).")
        }

        // Subdomain deceptive keywords check
        val hostParts = host.split('.')
        if (hostParts.size > 2) {
            val apexDomain = hostParts.takeLast(2).joinToString(".")
            val subdomains = hostParts.dropLast(2)
            for (sub in subdomains) {
                for (kw in suspiciousSubdomainKeywords) {
                    if (sub.contains(kw, ignoreCase = true)) {
                        reasons.add("Subdomain contains security keyword '$kw' on apex domain '$apexDomain'. Check whether this matches the intended official organization.")
                        break
                    }
                }
            }
        }

        // Suspicious TLD check
        val tld = hostParts.lastOrNull()?.lowercase() ?: ""
        if (tld in suspiciousTlds && hostParts.size > 3) {
            reasons.add("Uses top-level domain (.$tld) with multiple subdomains.")
        }

        val riskLevel = when {
            hasIpHost || hasEmbeddedCredentials || hasPunycode -> RiskLevel.REVIEW_RECOMMENDED
            !isHttps -> RiskLevel.REVIEW_RECOMMENDED
            reasons.isNotEmpty() -> RiskLevel.REVIEW_RECOMMENDED
            else -> RiskLevel.NORMAL
        }

        return LinkSecurityInfo(
            url = formattedUrl,
            host = host,
            isHttps = isHttps,
            hasIpHost = hasIpHost,
            hasPunycode = hasPunycode,
            hasEmbeddedCredentials = hasEmbeddedCredentials,
            hasNonStandardPort = hasNonStandardPort,
            riskLevel = riskLevel,
            reasons = reasons
        )
    }

    private val Uri.userInfo: String?
        get() = try {
            val raw = toString()
            val schemeEnd = raw.indexOf("://")
            if (schemeEnd != -1) {
                val afterScheme = raw.substring(schemeEnd + 3)
                val atIndex = afterScheme.indexOf('@')
                val slashIndex = afterScheme.indexOf('/')
                if (atIndex != -1 && (slashIndex == -1 || atIndex < slashIndex)) {
                    afterScheme.substring(0, atIndex)
                } else null
            } else null
        } catch (_: Exception) {
            null
        }
}
