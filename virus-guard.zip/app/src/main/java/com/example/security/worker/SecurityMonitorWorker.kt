package com.example.security.worker

import android.app.KeyguardManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.database.AppDatabase
import com.example.data.database.ScanHistoryEntity
import com.example.data.repository.ScanHistoryRepository
import com.example.data.repository.SecurityPreferencesRepository
import com.example.security.notification.SecurityNotificationHelper
import java.util.concurrent.TimeUnit

class SecurityMonitorWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val prefsRepo = SecurityPreferencesRepository(context)
            val prefs = prefsRepo.preferences.value

            if (!prefs.smartMonitorEnabled || prefs.autoCheckFrequency.equals("OFF", ignoreCase = true)) {
                return Result.success()
            }

            val startTime = System.currentTimeMillis()
            val db = AppDatabase.getDatabase(context)
            val historyRepo = ScanHistoryRepository(db.scanHistoryDao())

            // 1. Audit Installed Packages & Detect New Apps
            val pm = context.packageManager
            val installedPackages = try {
                pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
            } catch (_: Exception) {
                emptyList()
            }

            val currentPackageNames = installedPackages.map { it.packageName }.toSet()
            val previousKnownPackages = prefs.knownPackages

            val newAppPackages = if (previousKnownPackages.isNotEmpty()) {
                currentPackageNames.filter { pkg ->
                    !previousKnownPackages.contains(pkg) &&
                            (installedPackages.find { it.packageName == pkg }?.applicationInfo?.flags?.and(ApplicationInfo.FLAG_SYSTEM) == 0)
                }.toSet()
            } else {
                emptySet()
            }

            // 2. Real System Checks (Device & Settings)
            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            val isDeviceSecure = keyguardManager?.isDeviceSecure ?: true

            val adbEnabled = try {
                Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
            } catch (_: Exception) {
                false
            }

            // 3. Count Actionable Items
            val actionableFindings = mutableListOf<String>()
            var primaryTitle: String? = null

            if (!isDeviceSecure) {
                actionableFindings.add("Screen Lock Not Set")
                primaryTitle = "Screen Lock Not Set"
            }
            if (adbEnabled) {
                actionableFindings.add("USB Debugging Active")
                if (primaryTitle == null) primaryTitle = "USB Debugging Active"
            }
            for (newPkg in newAppPackages) {
                val appLabel = try {
                    val appInfo = pm.getApplicationInfo(newPkg, 0)
                    pm.getApplicationLabel(appInfo).toString()
                } catch (_: Exception) {
                    newPkg
                }
                actionableFindings.add("New app detected — Review recommended: $appLabel")
                if (primaryTitle == null) primaryTitle = "New app detected: $appLabel"
            }

            // Compute score
            var score = 100
            if (!isDeviceSecure) score -= 15
            if (adbEnabled) score -= 10
            if (newAppPackages.isNotEmpty()) score -= minOf(15, newAppPackages.size * 5)
            score = maxOf(0, score)

            // 4. Record to Database (Security History)
            val duration = System.currentTimeMillis() - startTime
            val summaryText = buildString {
                append("Score: $score/100 • ")
                if (actionableFindings.isEmpty()) {
                    append("All security controls optimal • No obvious issues")
                } else {
                    append("${actionableFindings.size} item(s) to review: ")
                    append(actionableFindings.take(2).joinToString(", "))
                }
            }

            val historyEntity = ScanHistoryEntity(
                timestamp = System.currentTimeMillis(),
                scanType = "AUTO_CHECK",
                itemsChecked = installedPackages.size,
                warningsCount = if (newAppPackages.isNotEmpty()) newAppPackages.size else 0,
                threatsFound = if (!isDeviceSecure || adbEnabled) 1 else 0,
                permissionsAnalyzed = installedPackages.size * 2,
                overallRisk = if (actionableFindings.isEmpty()) "NORMAL" else if (!isDeviceSecure) "POTENTIALLY_HARMFUL" else "REVIEW_RECOMMENDED",
                durationMillis = duration,
                summaryText = summaryText
            )
            historyRepo.insertScan(historyEntity)

            // 5. Update Preferences Baseline
            prefsRepo.recordCheckCompletion(
                timestamp = System.currentTimeMillis(),
                score = score,
                knownApps = currentPackageNames,
                newApps = newAppPackages
            )

            // 6. Security Notification (if actionable findings exist and enabled)
            if (prefs.notificationsEnabled && actionableFindings.isNotEmpty()) {
                SecurityNotificationHelper.showSecurityAlertNotification(
                    context = context,
                    actionableCount = actionableFindings.size,
                    primaryTitle = primaryTitle
                )
            }

            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val PERIODIC_WORK_TAG = "cyber_security_monitor_work"

        fun enableMonitoring(context: Context) {
            scheduleMonitoring(context, "DAILY")
        }

        fun scheduleMonitoring(context: Context, frequency: String) {
            try {
                val workManager = WorkManager.getInstance(context)

                if (frequency.equals("OFF", ignoreCase = true)) {
                    workManager.cancelUniqueWork(PERIODIC_WORK_TAG)
                    return
                }

                val repeatIntervalHours = if (frequency.equals("WEEKLY", ignoreCase = true)) {
                    7 * 24L // 168 hours
                } else {
                    24L // Daily (24 hours)
                }

                val constraints = Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                    .setRequiresBatteryNotLow(true)
                    .build()

                val workRequest = PeriodicWorkRequestBuilder<SecurityMonitorWorker>(
                    repeatIntervalHours,
                    TimeUnit.HOURS
                )
                    .setConstraints(constraints)
                    .build()

                workManager.enqueueUniquePeriodicWork(
                    PERIODIC_WORK_TAG,
                    ExistingPeriodicWorkPolicy.UPDATE,
                    workRequest
                )
            } catch (_: Exception) {
                // WorkManager might not be initialized in test or background-restricted environment
            }
        }

        fun disableMonitoring(context: Context) {
            try {
                WorkManager.getInstance(context).cancelUniqueWork(PERIODIC_WORK_TAG)
            } catch (_: Exception) {
                // WorkManager might not be initialized in test or background-restricted environment
            }
        }
    }
}
