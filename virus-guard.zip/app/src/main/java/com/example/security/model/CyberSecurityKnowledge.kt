package com.example.security.model

import android.provider.Settings

object CyberSecurityKnowledge {

    val phishingScenarios: List<PhishingScenario> = listOf(
        PhishingScenario(
            id = "phish_sms_package",
            type = PhishingType.SMS,
            title = "Unclaimed Package SMS (Smishing)",
            senderOrSource = "+1 (555) 019-2831",
            content = "URGENT: Your courier parcel #US-88291 cannot be delivered due to an unpaid $1.50 customs fee. Click http://usps-tracking-update.xyz/pay within 24h to prevent parcel return.",
            isSuspicious = true,
            redFlags = listOf(
                "Artificial urgency ('within 24h' or 'cannot be delivered')",
                "Deceptive unofficial domain (usps-tracking-update.xyz instead of usps.com)",
                "Unsolicited request to submit credit card details for small fee",
                "Sent from an arbitrary mobile number instead of an official shortcode"
            ),
            whySuspicious = "Attackers register cheap domains like .xyz to impersonate postal services. The small fee ($1.50) is designed to get you to enter full credit card and CVV information.",
            safeAction = "Never click links in delivery SMS messages. Navigate directly to the official carrier app or website and type your actual tracking code."
        ),
        PhishingScenario(
            id = "phish_email_bank",
            type = PhishingType.EMAIL,
            title = "Suspended Banking Account Email",
            senderOrSource = "security@chase-account-alert.net",
            content = "Dear Customer,\nWe detected unauthorized login attempts from a foreign IP. Your access is temporarily restricted. Verify your identity now by visiting the Chase Resolution Center: https://chase.online-id-verify.com/login",
            isSuspicious = true,
            redFlags = listOf(
                "Sender address (chase-account-alert.net) is not the official bank domain (chase.com)",
                "Generic greeting ('Dear Customer') rather than your verified name",
                "Threat of account restriction to induce panic",
                "Link points to a deceptive subdomain designed to harvest login credentials"
            ),
            whySuspicious = "Banks never send urgent emails demanding you click a link to input your password and SSN. Attackers set up identical replica login portals to steal credentials.",
            safeAction = "Close the email. Open your banking app directly or dial the customer service number printed on the back of your debit card."
        ),
        PhishingScenario(
            id = "phish_support_tech",
            type = PhishingType.FAKE_SUPPORT,
            title = "Fake Technical Support Popup",
            senderOrSource = "Browser Alert / System Message",
            content = "WARNING: Critical security breach detected! 3 Trojan viruses have infected your Android system. Call Google Certified Support immediately at 1-800-555-0199 for instant removal.",
            isSuspicious = true,
            redFlags = listOf(
                "Browser popups cannot scan your internal Android system files",
                "High pressure scare tactics ('3 Trojan viruses')",
                "Toll-free phone number requesting direct contact with unknown operators",
                "Requests you to install remote assistance apps (like AnyDesk/TeamViewer)"
            ),
            whySuspicious = "Websites cannot see what files or viruses are on your phone. These fake tech support scams trick users into paying hundreds of dollars or granting remote device control.",
            safeAction = "Close the browser tab or clear browser data. Never call phone numbers displayed on scary website popups."
        ),
        PhishingScenario(
            id = "phish_prize_scam",
            type = PhishingType.PRIZE_SCAM,
            title = "Celebration Gift Card Winner",
            senderOrSource = "promotions@lucky-draw-winner.club",
            content = "Congratulations! You have been chosen as today's $1,000 Amazon Gift Card Winner! Complete this 3-question survey and confirm your mailing address and shipping fee.",
            isSuspicious = true,
            redFlags = listOf(
                "Winning a contest or lottery you never entered",
                "Requirement to pay a 'shipping fee' to claim a prize",
                "Vague domain (.club) with no affiliation to the named merchant"
            ),
            whySuspicious = "Legitimate merchants do not award large gift cards through random popups requiring shipping fees. It is a scheme to harvest credit cards and phone numbers for recurring subscriptions.",
            safeAction = "Ignore and delete the message. Remember: if you didn't enter a contest, you didn't win."
        ),
        PhishingScenario(
            id = "phish_login_page",
            type = PhishingType.LOGIN_PAGE,
            title = "Shared Document Notification",
            senderOrSource = "notifications@docs-cloud-share.top",
            content = "Your manager has shared 'Q3_Payroll_Adjustment.pdf' with you on Google Drive. Sign in with your Google account to view document: https://drive-google.view-document.top",
            isSuspicious = true,
            redFlags = listOf(
                "Apex domain is view-document.top, NOT google.com",
                "Drive notifications come directly from drive-shares-noreply@google.com",
                "Enticing file title designed to trigger emotional curiosity"
            ),
            whySuspicious = "The login screen shown on view-document.top will look exactly like Google's sign-in screen, but keystrokes are recorded and saved on the attacker's server.",
            safeAction = "Inspect the browser address bar. If the address does not end in .google.com, never type your username and password."
        )
    )

    val accountSecurityItems: List<AccountSecurityItem> = listOf(
        AccountSecurityItem(
            id = "acc_pwd_unique",
            title = "Use Unique Passwords for Every Account",
            description = "Never reuse the same password across multiple websites. If one service suffers a data breach, credential stuffing bots attempt the same combination on email, banking, and social apps.",
            recommendation = "Generate unique 14+ character passphrases for each online service."
        ),
        AccountSecurityItem(
            id = "acc_pwd_manager",
            title = "Adopt a Reputable Password Manager",
            description = "Password managers store encrypted credentials locally or securely synchronized. They automatically autofill only on legitimate domain addresses, preventing phishing fake-site entry.",
            recommendation = "Use Android Autofill with trusted tools like Bitwarden, 1Password, or Google Password Manager."
        ),
        AccountSecurityItem(
            id = "acc_2fa",
            title = "Enable Two-Factor Authentication (2FA / MFA)",
            description = "Two-factor authentication requires a second piece of evidence (authenticator app OTP code, biometric prompt, or physical security key) before granting access.",
            recommendation = "Prefer App-based TOTP (Google Authenticator, Aegis) over SMS where available."
        ),
        AccountSecurityItem(
            id = "acc_no_otp_sharing",
            title = "Never Share Verification Codes (OTPs)",
            description = "No legitimate bank or company representative will ever ask you to read back a 6-digit one-time verification code over the phone or text.",
            recommendation = "Treat OTP codes with the same confidentiality as your ATM PIN."
        ),
        AccountSecurityItem(
            id = "acc_recovery_audit",
            title = "Review Account Recovery Methods",
            description = "Ensure secondary email addresses and phone numbers linked to your primary Google/Apple accounts are up-to-date and protected.",
            recommendation = "Periodically check Google Account Security > Ways we can verify it's you."
        )
    )

    val guideTopics: List<SecurityGuideTopic> = listOf(
        SecurityGuideTopic(
            id = "guide_malware",
            title = "What is Malware?",
            category = "Threat Fundamentals",
            summary = "Malware is malicious software designed to harm, exploit, or perform unauthorized actions on a device.",
            detailedExplanation = "Malware (short for 'malicious software') is an umbrella term encompassing Trojans, spyware, ransomware, and adware. On Android, malware typically arrives disguised as legitimate apps (like calculators, fake streaming apps, or system cleaners) downloaded outside official app stores, or through malicious APK links.",
            bestPractices = listOf(
                "Only install apps from Google Play Store or verified vendor stores",
                "Keep Google Play Protect enabled",
                "Review permissions requested by new apps before approving them",
                "Keep your Android OS updated with the latest monthly security patch"
            ),
            whatToAvoid = listOf(
                "Downloading 'modded' or cracked APK files from online forums",
                "Granting Accessibility or Notification Listener permissions to unverified utilities",
                "Clicking unexpected popup download links"
            )
        ),
        SecurityGuideTopic(
            id = "guide_phishing",
            title = "What is Phishing & Social Engineering?",
            category = "Deception & Scams",
            summary = "Phishing is the fraudulent attempt to obtain sensitive information by disguising as a trustworthy entity.",
            detailedExplanation = "Phishing relies on psychological manipulation rather than technical system bugs. Attackers impersonate trusted brands—such as your bank, courier service, or Google—via email, SMS (smishing), or instant messaging. They create urgency ('Account will be closed in 2 hours') so you act before thinking.",
            bestPractices = listOf(
                "Always check the exact domain address in the browser bar",
                "Use bookmark shortcuts or the official mobile app to access financial accounts",
                "Enable multi-factor authentication (MFA) on all critical accounts"
            ),
            whatToAvoid = listOf(
                "Clicking links sent in unexpected SMS messages about unpaid delivery fees",
                "Typing login credentials into pages reached via promotional emails",
                "Sharing one-time verification passwords (OTPs) with anyone"
            )
        ),
        SecurityGuideTopic(
            id = "guide_ransomware",
            title = "What is Ransomware?",
            category = "Threat Fundamentals",
            summary = "Ransomware encrypts files or locks access to devices, demanding a ransom payment to restore access.",
            detailedExplanation = "While traditional ransomware encrypts desktop hard drives, mobile ransomware often locks the device screen by abusing full-screen overlay or device administrator permissions, or threatening users with bogus accusations. Paying the ransom is never recommended because it finances criminal operations with no guarantee of recovery.",
            bestPractices = listOf(
                "Maintain automatic backups of your photos, documents, and contacts in Google Drive or local storage",
                "Ensure your screen lock and Android encryption are enabled",
                "Boot into Safe Mode if an unauthorized app locks your screen to uninstall it safely"
            ),
            whatToAvoid = listOf(
                "Granting Device Administrator or Accessibility privileges to unknown tools",
                "Paying ransoms or contacting attackers directly"
            )
        ),
        SecurityGuideTopic(
            id = "guide_spyware",
            title = "What is Spyware & Stalkerware?",
            category = "Privacy & Surveillance",
            summary = "Software that secretly records user activity, location, messages, or audio without clear consent.",
            detailedExplanation = "Spyware monitors your behavior in the background. It may record keystrokes, track your GPS coordinates, capture audio from the microphone, or read your SMS messages. On Android, spyware often disguises itself under innocuous package names (like 'System Service' or 'Battery Booster') and requests sensitive runtime permissions.",
            bestPractices = listOf(
                "Use Virus Guard's App Security Audit to find apps with camera, mic, or location access",
                "Protect your phone with a PIN that nobody else knows",
                "Review Google Play Protect's harmful app scan logs regularly"
            ),
            whatToAvoid = listOf(
                "Leaving your unlocked phone unattended around untrusted individuals",
                "Installing parental control or tracking tools from unverified websites"
            )
        ),
        SecurityGuideTopic(
            id = "guide_data_breach",
            title = "What is a Data Breach?",
            category = "Account Security",
            summary = "A security incident in which sensitive or protected data is copied, transmitted, or viewed by unauthorized parties.",
            detailedExplanation = "When a company's database is hacked, customer passwords, emails, addresses, and sometimes credit card data can be leaked online. If you use the same password across multiple websites, hackers use automated bots ('credential stuffing') to test that leaked password on other services.",
            bestPractices = listOf(
                "Use a distinct password for every online account",
                "Check free breach alert services (like haveibeenpwned.com) if you suspect a leak",
                "Change passwords immediately if a service you use announces a compromise"
            ),
            whatToAvoid = listOf(
                "Reusing your primary email password on any other website or app",
                "Ignoring breach notification emails from reputable providers"
            )
        ),
        SecurityGuideTopic(
            id = "guide_2fa",
            title = "What is Two-Factor Authentication (2FA)?",
            category = "Account Security",
            summary = "An essential security layer requiring two separate forms of identification to access an account.",
            detailedExplanation = "Two-factor authentication relies on something you know (your password) and something you have (your smartphone with an authenticator app or hardware security key). Even if an attacker steals your password in a phishing attack, they cannot log into your account without your physical second factor.",
            bestPractices = listOf(
                "Enable 2FA on your Google account, Apple ID, primary email, and financial institutions",
                "Prefer authenticator apps (Google Authenticator, Aegis, Bitwarden) over SMS where possible",
                "Store backup recovery codes in a safe, offline location"
            ),
            whatToAvoid = listOf(
                "Disabling 2FA for convenience",
                "Storing unencrypted backup codes in plaintext notes apps"
            )
        ),
        SecurityGuideTopic(
            id = "guide_vpn",
            title = "What is a VPN (Virtual Private Network)?",
            category = "Network Safety",
            summary = "An encrypted tunnel between your device and the internet that shields your transit data.",
            detailedExplanation = "When you connect to an open or public Wi-Fi network (like in a cafe or airport), other devices on that network could potentially observe unencrypted traffic or DNS requests. A VPN wraps your data in strong encryption before sending it over the network.",
            bestPractices = listOf(
                "Use a reputable, audited VPN provider that does not log your browsing traffic",
                "Enable VPN when connecting to unknown or unprotected public Wi-Fi hotspots",
                "Verify that Android's key icon or VPN indicator is visible in your status bar"
            ),
            whatToAvoid = listOf(
                "Using sketchy 'free unlimited VPN' apps that harvest and sell your browsing data",
                "Assuming a VPN protects you from typing passwords into phishing websites"
            )
        ),
        SecurityGuideTopic(
            id = "guide_https",
            title = "What is HTTPS & TLS Encryption?",
            category = "Network Safety",
            summary = "Hypertext Transfer Protocol Secure encrypts communication between your browser and the website server.",
            detailedExplanation = "HTTPS ensures that data transmitted between your device and the web server cannot be read or altered in transit by third parties (like internet service providers or malicious Wi-Fi routers). Modern browsers flag unencrypted HTTP sites as 'Not Secure'.",
            bestPractices = listOf(
                "Check that links start with 'https://' before entering private details",
                "Keep your web browser updated to recognize modern TLS certificate standards"
            ),
            whatToAvoid = listOf(
                "Submitting personal info or payment card numbers on plain 'http://' pages",
                "Bypassing invalid SSL/TLS certificate warnings on unexpected websites"
            )
        ),
        SecurityGuideTopic(
            id = "guide_scam_recognition",
            title = "How to Recognize a Scam",
            category = "Deception & Scams",
            summary = "Practical rules of thumb to detect online fraud before financial or identity loss occurs.",
            detailedExplanation = "Most digital scams share recognizable hallmarks: unexpected contact, extreme urgency, promises of easy money, or requests for unusual payment methods (like gift cards, cryptocurrency, or wire transfers).",
            bestPractices = listOf(
                "Pause before reacting to urgent requests",
                "Independently verify requests using official telephone numbers",
                "Discuss suspicious inquiries with a trusted family member or friend"
            ),
            whatToAvoid = listOf(
                "Sending money or buying gift cards to claim a supposed prize or tax settlement",
                "Rushing into transactions because someone on the phone claims an emergency"
            )
        ),
        SecurityGuideTopic(
            id = "guide_protect_phone",
            title = "How to Protect Your Android Phone",
            category = "Device Security",
            summary = "Essential daily habits to keep your mobile hardware and personal data safe.",
            detailedExplanation = "Your phone holds your personal memories, private conversations, and financial access. Implementing standard built-in Android protection creates a powerful multi-layered defense.",
            bestPractices = listOf(
                "Always keep a secure 6+ digit PIN or biometric fingerprint lock active",
                "Install monthly system updates as soon as they become available",
                "Review app permissions every few months and revoke unused permissions",
                "Enable Find My Device in Android Settings"
            ),
            whatToAvoid = listOf(
                "Leaving developer options and USB debugging permanently enabled",
                "Disabling Google Play Protect",
                "Leaving your phone unattended in public spaces"
            )
        ),
        SecurityGuideTopic(
            id = "guide_protect_accounts",
            title = "How to Protect Online Accounts",
            category = "Account Security",
            summary = "Practical steps to safeguard your digital identity across web services.",
            detailedExplanation = "Your primary email address is the master key to your digital identity because it can reset passwords on all other accounts. Safeguarding your primary email with 2FA and a strong passphrase protects everything connected to it.",
            bestPractices = listOf(
                "Treat your primary email account as your most critical digital asset",
                "Review active sessions and logged-in devices under Google Account > Security",
                "Enable login alerts for new sign-ins from unrecognized browsers"
            ),
            whatToAvoid = listOf(
                "Using easily guessed security questions with answers found on your social media",
                "Logging into sensitive accounts on shared or public computers"
            )
        )
    )

    val emergencyChecklist: List<EmergencyChecklistItem> = listOf(
        EmergencyChecklistItem(
            stepNumber = 1,
            title = "Disconnect from Untrusted Networks",
            description = "If you suspect an active network attack or data leak, turn off Wi-Fi and Bluetooth immediately. Switch to your private cellular data connection or Airplane Mode.",
            isUrgent = true,
            actionLabel = "Open Network Settings",
            intentAction = Settings.ACTION_WIRELESS_SETTINGS
        ),
        EmergencyChecklistItem(
            stepNumber = 2,
            title = "Review Suspicious Applications",
            description = "Open Virus Guard's App Security Audit. Inspect recently installed apps or apps with high-risk permission combinations. Uninstall any apps you did not intentionally install.",
            isUrgent = true,
            actionLabel = "Review Apps"
        ),
        EmergencyChecklistItem(
            stepNumber = 3,
            title = "Audit Sensitive Permissions",
            description = "Revoke Camera, Microphone, SMS, and Overlay permissions for any apps that should not require them in Android Settings > Privacy > Permission Manager.",
            isUrgent = false,
            actionLabel = "Privacy Settings",
            intentAction = Settings.ACTION_PRIVACY_SETTINGS
        ),
        EmergencyChecklistItem(
            stepNumber = 4,
            title = "Update Android & Installed Apps",
            description = "Ensure your operating system and all installed applications are updated to the latest versions to patch known security vulnerabilities.",
            isUrgent = false,
            actionLabel = "System Updates",
            intentAction = Settings.ACTION_SYSTEM_UPDATE_SETTINGS
        ),
        EmergencyChecklistItem(
            stepNumber = 5,
            title = "Change Important Passwords from a Trusted Device",
            description = "If you suspect your credentials have been compromised, change passwords for your primary email, banking, and Google account from a separate clean computer or trusted device.",
            isUrgent = true
        ),
        EmergencyChecklistItem(
            stepNumber = 6,
            title = "Enable Two-Factor Authentication (2FA)",
            description = "Add an authenticator app or hardware security key to your accounts. This ensures that even if credentials leaked, attackers cannot sign in.",
            isUrgent = false
        ),
        EmergencyChecklistItem(
            stepNumber = 7,
            title = "Contact Service Providers if Account is Compromised",
            description = "If you observe unauthorized transactions, call your bank's fraud department immediately to freeze cards. Notify service providers if primary accounts are hijacked.",
            isUrgent = true
        ),
        EmergencyChecklistItem(
            stepNumber = 8,
            title = "Use Built-In Android Security Features",
            description = "Confirm Google Play Protect is enabled and running daily scans. Verify that Android Device Protection and Find My Device are active.",
            isUrgent = false,
            actionLabel = "Security Settings",
            intentAction = Settings.ACTION_SECURITY_SETTINGS
        )
    )
}
