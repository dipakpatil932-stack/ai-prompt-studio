package com.example.security.analyzer

import com.example.security.model.RiskLevel

data class SecurityRuleEvaluation(
    val ruleId: String,
    val reason: String,
    val severity: RiskLevel,
    val evidence: String,
    val recommendation: String,
    val penaltyPoints: Int
)

object RiskScoreEngine {

    val RULES = listOf(
        "RULE_UNSCANNED" to "Device has never been scanned by Virus Guard.",
        "RULE_HARMFUL_APP" to "Application requesting dangerous high-risk permission combination.",
        "RULE_SIDELOADED_APP" to "App installed outside official trusted app store.",
        "RULE_DEBUGGABLE_FLAG" to "App compiled with active developer debug flags.",
        "RULE_DEVICE_UNLOCKED" to "No screen lock or biometric lock enabled on device.",
        "RULE_USB_DEBUGGING" to "USB debugging (ADB) bridge enabled on device.",
        "RULE_SENSITIVE_PERM" to "App requests access to sensitive private data."
    )

    fun evaluateRule(
        ruleId: String,
        isTriggered: Boolean,
        evidence: String
    ): SecurityRuleEvaluation? {
        if (!isTriggered) return null

        return when (ruleId) {
            "RULE_UNSCANNED" -> SecurityRuleEvaluation(
                ruleId = ruleId,
                reason = "Initial device scan has not yet been executed.",
                severity = RiskLevel.REVIEW_RECOMMENDED,
                evidence = evidence,
                recommendation = "Run a Quick Scan or Deep Scan to verify all installed packages.",
                penaltyPoints = 20
            )
            "RULE_HARMFUL_APP" -> SecurityRuleEvaluation(
                ruleId = ruleId,
                reason = "Potentially harmful permission combination detected.",
                severity = RiskLevel.POTENTIALLY_HARMFUL,
                evidence = evidence,
                recommendation = "Inspect and consider removing unverified apps with high-risk privileges.",
                penaltyPoints = 25
            )
            "RULE_SIDELOADED_APP" -> SecurityRuleEvaluation(
                ruleId = ruleId,
                reason = "Third-party application installed from external/unknown source.",
                severity = RiskLevel.REVIEW_RECOMMENDED,
                evidence = evidence,
                recommendation = "Confirm that you trust the publisher and origin of sideloaded apps.",
                penaltyPoints = 10
            )
            "RULE_DEBUGGABLE_FLAG" -> SecurityRuleEvaluation(
                ruleId = ruleId,
                reason = "Application is compiled in debuggable mode (FLAG_DEBUGGABLE).",
                severity = RiskLevel.REVIEW_RECOMMENDED,
                evidence = evidence,
                recommendation = "Review if this is a test or experimental app installed manually.",
                penaltyPoints = 5
            )
            "RULE_DEVICE_UNLOCKED" -> SecurityRuleEvaluation(
                ruleId = ruleId,
                reason = "Device has no secure screen lock enabled.",
                severity = RiskLevel.POTENTIALLY_HARMFUL,
                evidence = evidence,
                recommendation = "Enable a PIN, password, or fingerprint lock in Android Settings.",
                penaltyPoints = 15
            )
            "RULE_USB_DEBUGGING" -> SecurityRuleEvaluation(
                ruleId = ruleId,
                reason = "USB debugging bridge (ADB) is enabled.",
                severity = RiskLevel.REVIEW_RECOMMENDED,
                evidence = evidence,
                recommendation = "Disable USB debugging in Developer Options when not in use.",
                penaltyPoints = 5
            )
            else -> null
        }
    }
}
