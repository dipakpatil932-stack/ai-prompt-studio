package com.example.security.model

enum class CheckState {
    GOOD,
    REVIEW,
    NOT_AVAILABLE
}

enum class AppAuditRiskLevel {
    LOW,
    REVIEW,
    HIGH
}

enum class AlertSeverity {
    HIGH,
    MEDIUM,
    INFO
}

data class DeviceSecurityCheck(
    val id: String,
    val title: String,
    val category: String,
    val state: CheckState,
    val stateLabel: String,
    val explanation: String,
    val evidence: String,
    val recommendation: String,
    val intentAction: String? = null
)

data class AppSecurityAuditItem(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val requestedPermissions: List<String>,
    val sensitivePermissions: List<String>,
    val installerPackageName: String?,
    val installerDisplayName: String,
    val riskLevel: AppAuditRiskLevel,
    val riskIndicators: List<String>,
    val recommendation: String
)

data class PrivacyPermissionGroup(
    val groupKey: String,
    val displayName: String,
    val iconName: String,
    val plainLanguageExplanation: String,
    val permissions: List<String>,
    val associatedApps: List<String>
)

data class CyberSecurityAlertItem(
    val id: String,
    val title: String,
    val reason: String,
    val evidence: String,
    val recommendedAction: String,
    val severity: AlertSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val isAcknowledged: Boolean = false
)

data class CyberScoreFactor(
    val title: String,
    val category: String,
    val pointsAwarded: Int,
    val maxPoints: Int,
    val statusText: String,
    val detail: String
)

data class CyberSecurityScore(
    val totalScore: Int,
    val deviceSecurityScore: Int,
    val appSecurityScore: Int,
    val privacyScore: Int,
    val networkScore: Int,
    val accountSecurityScore: Int,
    val ratingLabel: String,
    val factors: List<CyberScoreFactor>
)

data class CyberSecurityReport(
    val scanTimestamp: Long,
    val formattedDate: String,
    val overallScore: Int,
    val deviceChecksSummary: String,
    val deviceChecksPassed: Int,
    val deviceChecksReview: Int,
    val deviceChecksNotAvailable: Int,
    val appAuditSummary: String,
    val totalAppsAudited: Int,
    val lowRiskApps: Int,
    val reviewApps: Int,
    val highRiskApps: Int,
    val privacyFindingsSummary: String,
    val sensitivePermissionCount: Int,
    val networkSummary: String,
    val linkCheckSummary: String,
    val topRecommendations: List<String>,
    val plainTextReport: String
)

enum class PhishingType {
    EMAIL,
    SMS,
    WEBSITE,
    LOGIN_PAGE,
    FAKE_SUPPORT,
    PRIZE_SCAM
}

data class PhishingScenario(
    val id: String,
    val type: PhishingType,
    val title: String,
    val senderOrSource: String,
    val content: String,
    val isSuspicious: Boolean,
    val redFlags: List<String>,
    val whySuspicious: String,
    val safeAction: String
)

data class AccountSecurityItem(
    val id: String,
    val title: String,
    val description: String,
    val recommendation: String,
    val isActionable: Boolean = true,
    val status: CheckState = CheckState.GOOD
)

data class SecurityGuideTopic(
    val id: String,
    val title: String,
    val category: String,
    val summary: String,
    val detailedExplanation: String,
    val bestPractices: List<String>,
    val whatToAvoid: List<String>
)

data class EmergencyChecklistItem(
    val stepNumber: Int,
    val title: String,
    val description: String,
    val isUrgent: Boolean = false,
    val actionLabel: String? = null,
    val intentAction: String? = null
)
