package com.example.security.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.security.analyzer.AppAnalyzer
import com.example.security.analyzer.FileAnalyzer
import com.example.security.model.AppSecurityInfo
import com.example.security.model.RiskLevel
import com.example.security.model.ScanResult
import com.example.security.model.ScanType
import com.example.security.model.ThreatRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

data class ScanProgress(
    val progress: Float, // 0.0 to 1.0
    val currentItemName: String,
    val itemsProcessed: Int,
    val totalItems: Int,
    val threatsFound: Int,
    val permissionsAnalyzed: Int,
    val filesAnalyzed: Int = 0
)

class ThreatDetectionEngine(private val context: Context) {

    val appAnalyzer = AppAnalyzer(context)
    val fileAnalyzer = FileAnalyzer(context)

    suspend fun getInstalledPackages(includeSystemApps: Boolean = false): List<PackageInfo> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val flags = PackageManager.GET_PERMISSIONS

            val packages = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstalledPackages(flags)
                }
            } catch (_: Exception) {
                emptyList()
            }

            if (includeSystemApps) {
                packages
            } else {
                packages.filter { pkg ->
                    val appInfo = pkg.applicationInfo
                    if (appInfo == null) true
                    else (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                }.ifEmpty { packages } // Fallback to all if user filter is empty
            }
        }

    suspend fun runScan(
        scanType: ScanType,
        includeSystemApps: Boolean,
        onProgress: suspend (ScanProgress) -> Unit
    ): ScanResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val packages = getInstalledPackages(includeSystemApps = includeSystemApps || scanType == ScanType.DEEP)
        val totalItems = packages.size.coerceAtLeast(1)

        val analyzedApps = mutableListOf<AppSecurityInfo>()
        val allThreats = mutableListOf<ThreatRecord>()
        var totalPermissions = 0
        var filesAnalyzedCount = 0
        var canceled = false

        for (index in packages.indices) {
            if (!currentCoroutineContext().isActive) {
                canceled = true
                break
            }

            val pkg = packages[index]
            val analyzed = appAnalyzer.analyzePackage(pkg)
            analyzedApps.add(analyzed)
            allThreats.addAll(analyzed.threatRecords)
            totalPermissions += analyzed.requestedPermissions.size

            val progressPercent = (index + 1).toFloat() / totalItems.toFloat() * (if (scanType == ScanType.DEEP) 0.85f else 1.0f)
            onProgress(
                ScanProgress(
                    progress = progressPercent,
                    currentItemName = analyzed.appName,
                    itemsProcessed = index + 1,
                    totalItems = totalItems,
                    threatsFound = allThreats.size,
                    permissionsAnalyzed = totalPermissions,
                    filesAnalyzed = filesAnalyzedCount
                )
            )

            // Micro-delay in UI to keep scanning visually smooth without freezing the thread
            if (scanType == ScanType.DEEP) {
                delay(20)
            } else {
                delay(12)
            }
        }

        // For Deep Scan, perform inspection of accessible application storage directories
        if (!canceled && scanType == ScanType.DEEP) {
            val storageDirs = listOfNotNull(
                context.cacheDir,
                context.filesDir,
                context.externalCacheDir,
                context.getExternalFilesDir(null)
            )

            for (dir in storageDirs) {
                if (!currentCoroutineContext().isActive) {
                    canceled = true
                    break
                }
                val dirFiles = dir.listFiles() ?: emptyArray()
                for (file in dirFiles) {
                    if (!currentCoroutineContext().isActive) {
                        canceled = true
                        break
                    }
                    if (file.isFile) {
                        filesAnalyzedCount++
                        val ext = file.extension.lowercase()
                        if (SignatureDatabase.SUSPICIOUS_EXTENSIONS.contains(ext) && ext != "apk") {
                            allThreats.add(
                                ThreatRecord(
                                    id = "file_${file.name}",
                                    title = "Suspicious Storage File: ${file.name}",
                                    description = "Potentially executable file extension .$ext detected in app storage",
                                    reason = "File has executable script or library extension in local directory.",
                                    severity = RiskLevel.REVIEW_RECOMMENDED,
                                    targetName = file.name,
                                    targetIdentifier = file.absolutePath,
                                    targetType = com.example.security.model.TargetType.FILE,
                                    recommendation = "Review if this file was created by an untrusted source.",
                                    isSystemProtected = false
                                )
                            )
                        }
                    }
                }
                onProgress(
                    ScanProgress(
                        progress = 0.95f,
                        currentItemName = "Storage: ${dir.name}",
                        itemsProcessed = totalItems,
                        totalItems = totalItems,
                        threatsFound = allThreats.size,
                        permissionsAnalyzed = totalPermissions,
                        filesAnalyzed = filesAnalyzedCount
                    )
                )
            }
        }

        val duration = System.currentTimeMillis() - startTime
        val normalCount = analyzedApps.count { it.riskLevel == RiskLevel.NORMAL }
        val reviewCount = analyzedApps.count { it.riskLevel == RiskLevel.REVIEW_RECOMMENDED }
        val harmfulCount = analyzedApps.count { it.riskLevel == RiskLevel.POTENTIALLY_HARMFUL }

        val overallRisk = when {
            harmfulCount > 0 -> RiskLevel.POTENTIALLY_HARMFUL
            reviewCount > 0 -> RiskLevel.REVIEW_RECOMMENDED
            else -> RiskLevel.NORMAL
        }

        ScanResult(
            scanType = scanType,
            timestamp = System.currentTimeMillis(),
            totalAppsChecked = analyzedApps.size,
            totalFilesChecked = filesAnalyzedCount,
            totalPermissionsChecked = totalPermissions,
            normalCount = normalCount,
            reviewCount = reviewCount,
            harmfulCount = harmfulCount,
            overallRisk = overallRisk,
            threats = allThreats,
            durationMillis = duration,
            isCanceled = canceled
        )
    }
}
