package com.example.security.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity

object SecurityNotificationHelper {
    const val CHANNEL_ID = "virus_guard_security_monitor"
    const val NOTIFICATION_ID = 2026
    const val EXTRA_OPEN_TAB = "extra_open_tab"
    const val TAB_SECURITY_MONITOR = "SECURITY_MONITOR"
    const val TAB_FIX_CENTER = "FIX_CENTER"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Security Alerts"
            val descriptionText = "Notifications for genuine security findings and review recommendations"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableLights(true)
                enableVibration(true)
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showSecurityAlertNotification(
        context: Context,
        actionableCount: Int,
        primaryTitle: String? = null
    ) {
        if (actionableCount <= 0) return

        try {
            createNotificationChannel(context)

            if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                return
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_OPEN_TAB, TAB_FIX_CENTER)
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                101,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val title = "🛡️ Virus Guard"
            val message = if (actionableCount == 1) {
                if (!primaryTitle.isNullOrBlank()) {
                    "1 security item needs your attention: $primaryTitle"
                } else {
                    "1 security item needs your attention."
                }
            } else {
                "$actionableCount security items need your attention."
            }

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText("$message Tap to review evidence and apply standard Android fixes.")
                )
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build()

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Respect permission denial without crashing
        } catch (_: Exception) {
            // Fail gracefully
        }
    }
}
