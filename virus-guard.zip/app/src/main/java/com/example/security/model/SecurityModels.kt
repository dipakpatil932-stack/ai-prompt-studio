package com.example.security.model

enum class RiskLevel {
    NORMAL,
    REVIEW_RECOMMENDED,
    POTENTIALLY_HARMFUL
}

enum class ScanType {
    QUICK,
    DEEP,
    FILE
}

enum class TargetType {
    APP,
    FILE,
    APK,
    URL,
    PERMISSION,
    DEVICE
}

enum class CheckStatus {
    PASSED,
    REVIEW,
    ACTION_NEEDED
}

data class ThreatRecord(
    val id: String,
    val title: String,
    val description: String,
    val reason: String,
    val severity: RiskLevel,
    val targetName: String,
    val targetIdentifier: String,
    val targetType: TargetType,
    val recommendation: String,
    val isSystemProtected: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class AppSecurityInfo(
    val packageName: String,
    val appName: String,
    val versionName: String = "",
    val versionCode: Long = 0L,
    val isSystemApp: Boolean = false,
    val isDebuggable: Boolean = false,
    val installerPackageName: String? = null,
    val targetSdkVersion: Int = 0,
    val requestedPermissions: List<String> = emptyList(),
    val sensitivePermissions: List<String> = emptyList(),
    val riskLevel: RiskLevel = RiskLevel.NORMAL,
    val threatRecords: List<ThreatRecord> = emptyList(),
    val reasons: List<String> = emptyList(),
    val riskReasons: List<String> = reasons
)

data class ScanResult(
    val scanType: ScanType,
    val timestamp: Long = System.currentTimeMillis(),
    val totalAppsChecked: Int,
    val totalFilesChecked: Int = 0,
    val totalPermissionsChecked: Int = 0,
    val normalCount: Int = 0,
    val reviewCount: Int = 0,
    val harmfulCount: Int = 0,
    val overallRisk: RiskLevel = RiskLevel.NORMAL,
    val threats: List<ThreatRecord> = emptyList(),
    val durationMillis: Long = 0L,
    val isCanceled: Boolean = false
)

data class CheckupItem(
    val id: String,
    val title: String,
    val category: String,
    val status: CheckStatus,
    val explanation: String,
    val recommendation: String,
    val intentAction: String? = null
)

data class CheckupResult(
    val timestamp: Long,
    val score: Int,
    val passedCount: Int,
    val reviewCount: Int,
    val actionNeededCount: Int,
    val items: List<CheckupItem>
)

data class FileSecurityInfo(
    val fileName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val extension: String,
    val sha256Hash: String,
    val riskLevel: RiskLevel,
    val reasons: List<String>,
    val isApk: Boolean
)

data class ApkSecurityInfo(
    val apkName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val targetSdk: Int,
    val requestedPermissions: List<String>,
    val sensitivePermissions: List<String>,
    val sizeBytes: Long,
    val sha256Hash: String,
    val signatureCount: Int,
    val isDebuggable: Boolean,
    val suspiciousIndicators: List<String>,
    val riskLevel: RiskLevel
)

data class LinkSecurityInfo(
    val url: String,
    val host: String,
    val isHttps: Boolean,
    val hasIpHost: Boolean,
    val hasPunycode: Boolean,
    val hasEmbeddedCredentials: Boolean,
    val hasNonStandardPort: Boolean,
    val riskLevel: RiskLevel,
    val reasons: List<String>
)

data class NetworkSecurityInfo(
    val isConnected: Boolean,
    val connectionType: String,
    val isVpnActive: Boolean,
    val isMetered: Boolean,
    val dnsOrGateways: String = "",
    val securitySummary: String,
    val riskLevel: RiskLevel,
    val notes: String = securitySummary
)

data class ThreatIntelResult(
    val isKnownMalicious: Boolean,
    val isOffline: Boolean,
    val message: String
)

data class SecurityAlert(
    val id: String,
    val title: String,
    val description: String,
    val severity: RiskLevel,
    val targetName: String,
    val targetIdentifier: String,
    val targetType: TargetType,
    val timestamp: Long = System.currentTimeMillis(),
    val whatWasFound: String = description,
    val whyItMatters: String = "This configuration or permission exposure permits elevated privileges on this device.",
    val whatToDo: String = "Review this item or adjust its setting in Android Settings.",
    val intentAction: String? = null
)

data class SecurityRecommendation(
    val id: String,
    val title: String,
    val description: String,
    val priority: RiskLevel,
    val actionLabel: String? = null,
    val intentAction: String? = null
)

enum class FindingSeverity {
    INFO,
    REVIEW,
    ACTION_RECOMMENDED
}

data class CheckPhoneFinding(
    val id: String,
    val title: String,
    val smartSeverity: FindingSeverity = FindingSeverity.REVIEW,
    val severity: RiskLevel = when (smartSeverity) {
        FindingSeverity.INFO -> RiskLevel.NORMAL
        FindingSeverity.REVIEW -> RiskLevel.REVIEW_RECOMMENDED
        FindingSeverity.ACTION_RECOMMENDED -> RiskLevel.POTENTIALLY_HARMFUL
    },
    val whatWasFound: String = "",
    val evidence: String = "",
    val whyItMatters: String = "",
    val recommendedAction: String = "",
    val howToFix: String = recommendedAction,
    val category: String,
    val intentAction: String? = null,
    val packageName: String? = null,
    val detectionRule: String? = null,
    val sha256: String? = null,
    val permissions: List<String> = emptyList(),
    val technicalStatus: String? = null
)

data class CategoryScore(
    val categoryName: String,
    val score: Int,
    val maxScore: Int = 20,
    val status: String,
    val isClean: Boolean,
    val findings: List<CheckPhoneFinding> = emptyList()
)

data class CheckPhoneStats(
    val devicePassedCount: Int = 0,
    val appsCheckedCount: Int = 0,
    val permissionsEvaluatedCount: Int = 0,
    val privacyGroupsEvaluated: Int = 0,
    val networkStatus: String = "Normal",
    val filesSafe: Boolean = true,
    val securitySettingsPassedCount: Int = 0
)

data class CheckPhoneResult(
    val score: Int,
    val isAllGood: Boolean,
    val headline: String,
    val subHeadline: String,
    val findings: List<CheckPhoneFinding>,
    val stats: CheckPhoneStats,
    val categoryScores: List<CategoryScore> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)
