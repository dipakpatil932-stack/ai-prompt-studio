package com.example.security.analyzer

import android.content.Context
import android.content.pm.PackageInfo
import com.example.security.model.AppSecurityAuditItem
import com.example.security.model.PrivacyPermissionGroup

class PrivacyAnalyzer(private val context: Context) {

    fun auditPrivacy(apps: List<AppSecurityAuditItem>): List<PrivacyPermissionGroup> {
        val groups = mutableListOf<PrivacyPermissionGroup>()

        // 1. Camera Access
        val cameraApps = apps.filter { it.requestedPermissions.contains("android.permission.CAMERA") }
            .map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "camera",
                displayName = "Camera Access",
                iconName = "camera",
                plainLanguageExplanation = "Camera permission can allow an app to capture photos and video streams while active or permitted by Android runtime dialogs.",
                permissions = listOf("android.permission.CAMERA"),
                associatedApps = cameraApps
            )
        )

        // 2. Microphone Access
        val micApps = apps.filter { it.requestedPermissions.contains("android.permission.RECORD_AUDIO") }
            .map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "microphone",
                displayName = "Microphone Access",
                iconName = "mic",
                plainLanguageExplanation = "Microphone permission can allow an app to access microphone audio input and record sound while permitted by Android.",
                permissions = listOf("android.permission.RECORD_AUDIO"),
                associatedApps = micApps
            )
        )

        // 3. Location Access
        val locationApps = apps.filter {
            it.requestedPermissions.contains("android.permission.ACCESS_FINE_LOCATION") ||
                    it.requestedPermissions.contains("android.permission.ACCESS_COARSE_LOCATION") ||
                    it.requestedPermissions.contains("android.permission.ACCESS_BACKGROUND_LOCATION")
        }.map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "location",
                displayName = "Location Access",
                iconName = "location",
                plainLanguageExplanation = "Location permission allows apps to read precise GPS coordinates or cell tower estimates to approximate your physical whereabouts.",
                permissions = listOf(
                    "android.permission.ACCESS_FINE_LOCATION",
                    "android.permission.ACCESS_COARSE_LOCATION",
                    "android.permission.ACCESS_BACKGROUND_LOCATION"
                ),
                associatedApps = locationApps
            )
        )

        // 4. Contacts & Address Book Access
        val contactsApps = apps.filter {
            it.requestedPermissions.contains("android.permission.READ_CONTACTS") ||
                    it.requestedPermissions.contains("android.permission.WRITE_CONTACTS")
        }.map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "contacts",
                displayName = "Contacts Access",
                iconName = "contacts",
                plainLanguageExplanation = "Contacts permission allows an application to read people, phone numbers, and email addresses stored in your address book.",
                permissions = listOf("android.permission.READ_CONTACTS", "android.permission.WRITE_CONTACTS"),
                associatedApps = contactsApps
            )
        )

        // 5. SMS & Messages Access
        val smsApps = apps.filter {
            it.requestedPermissions.any { perm ->
                perm == "android.permission.READ_SMS" ||
                        perm == "android.permission.RECEIVE_SMS" ||
                        perm == "android.permission.SEND_SMS"
            }
        }.map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "sms",
                displayName = "SMS & Text Messages",
                iconName = "sms",
                plainLanguageExplanation = "SMS permissions allow reading, receiving, or sending text messages, including two-factor verification OTP codes.",
                permissions = listOf(
                    "android.permission.READ_SMS",
                    "android.permission.RECEIVE_SMS",
                    "android.permission.SEND_SMS"
                ),
                associatedApps = smsApps
            )
        )

        // 6. Notification Access
        val notifApps = apps.filter {
            it.requestedPermissions.contains("android.permission.POST_NOTIFICATIONS")
        }.map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "notifications",
                displayName = "Notification Access",
                iconName = "notifications",
                plainLanguageExplanation = "Notification permission allows apps to display alerts, popups, and badges in your system notification shade.",
                permissions = listOf("android.permission.POST_NOTIFICATIONS"),
                associatedApps = notifApps
            )
        )

        // 7. System Alert Window (Floating Overlay)
        val overlayApps = apps.filter {
            it.requestedPermissions.contains("android.permission.SYSTEM_ALERT_WINDOW")
        }.map { it.appName }
        groups.add(
            PrivacyPermissionGroup(
                groupKey = "overlay",
                displayName = "Display Over Other Apps",
                iconName = "overlay",
                plainLanguageExplanation = "Overlay permission allows an app to draw windows or floating bubbles on top of other running applications.",
                permissions = listOf("android.permission.SYSTEM_ALERT_WINDOW"),
                associatedApps = overlayApps
            )
        )

        return groups
    }
}
