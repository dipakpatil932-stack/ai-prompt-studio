package com.example.security.scanner

import com.example.security.model.RiskLevel

object SignatureDatabase {
    const val DATABASE_VERSION = "2026.09-local-v1"
    const val STATUS_DISCLOSURE = "No external threat intelligence database is connected. Local rule-based analyzer active."

    // Known risky or double extension patterns commonly used in phishing/payload delivery
    val SUSPICIOUS_EXTENSIONS = setOf(
        "apk", "dex", "so", "exe", "scr", "bat", "vbs", "cmd", "sh", "jar"
    )

    val SUSPICIOUS_DOUBLE_EXTENSIONS = listOf(
        ".pdf.apk", ".doc.apk", ".jpg.apk", ".png.apk", ".zip.apk", ".mp4.apk"
    )

    // Specific high-risk permission pairings
    val HIGH_RISK_PERMISSION_COMBINATIONS = listOf(
        Pair(
            setOf("android.permission.RECEIVE_SMS", "android.permission.SEND_SMS", "android.permission.READ_PHONE_STATE"),
            "Full SMS read/write combined with device state can allow intercepting one-time codes."
        ),
        Pair(
            setOf("android.permission.RECORD_AUDIO", "android.permission.CAMERA", "android.permission.ACCESS_FINE_LOCATION"),
            "Combined continuous audio recording, camera, and fine location access requires high trust."
        ),
        Pair(
            setOf("android.permission.BIND_ACCESSIBILITY_SERVICE", "android.permission.SYSTEM_ALERT_WINDOW"),
            "Accessibility service paired with screen overlays allows reading screen content and drawing over other apps."
        )
    )

    // Known legitimate system package prefixes that are core Android OS
    val TRUSTED_SYSTEM_PREFIXES = listOf(
        "com.android.",
        "com.google.android.",
        "android",
        "com.google.android.gms",
        "com.google.android.gsf"
    )

    // Well-known popular applications that legitimately require permissions (e.g. video calling, camera, messaging)
    // and must never be falsely flagged as viruses or suspicious.
    val WELL_KNOWN_LEGITIMATE_PACKAGES = setOf(
        "com.google.android.youtube",
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "com.google.android.apps.messaging",
        "com.google.android.dialer",
        "com.google.android.apps.maps",
        "com.google.android.gm",
        "com.google.android.googlequicksearchbox",
        "com.google.android.apps.photos",
        "com.google.android.apps.docs",
        "com.google.android.keep",
        "com.android.chrome",
        "org.mozilla.firefox",
        "com.microsoft.emmx",
        "com.opera.browser",
        "com.facebook.katana",
        "com.facebook.orca",
        "com.instagram.android",
        "com.twitter.android",
        "us.zoom.videomeetings",
        "com.microsoft.teams",
        "com.spotify.music",
        "com.netflix.mediaclient",
        "com.amazon.mShop.android.shopping"
    )

    fun isTrustedSystemPackage(packageName: String): Boolean {
        return TRUSTED_SYSTEM_PREFIXES.any { packageName.startsWith(it) }
    }

    fun isRecognizedLegitimateApp(packageName: String): Boolean {
        return WELL_KNOWN_LEGITIMATE_PACKAGES.contains(packageName) || isTrustedSystemPackage(packageName)
    }
}
