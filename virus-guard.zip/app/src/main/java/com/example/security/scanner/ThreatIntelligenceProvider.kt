package com.example.security.scanner

import com.example.security.model.ThreatIntelResult

interface ThreatIntelligenceProvider {
    val isConnected: Boolean
    val providerName: String
    suspend fun checkHash(sha256: String): ThreatIntelResult
    suspend fun checkUrl(url: String): ThreatIntelResult
}

class OfflineThreatIntelligenceProvider : ThreatIntelligenceProvider {
    override val isConnected: Boolean = false
    override val providerName: String = "Offline Analysis Engine"

    override suspend fun checkHash(sha256: String): ThreatIntelResult {
        return ThreatIntelResult(
            isKnownMalicious = false,
            isOffline = true,
            message = "Online threat intelligence is not connected. Evaluated via local heuristics only."
        )
    }

    override suspend fun checkUrl(url: String): ThreatIntelResult {
        return ThreatIntelResult(
            isKnownMalicious = false,
            isOffline = true,
            message = "Online threat intelligence is not connected. Evaluated via local pattern engine."
        )
    }
}
