package com.example.security.model

data class ScoreFactor(
    val title: String,
    val description: String,
    val pointDelta: Int
)

data class SecurityScoreBreakdown(
    val score: Int,
    val isEvaluated: Boolean,
    val factors: List<ScoreFactor>
)

object SecurityScoreCalculator {

    fun calculate(apps: List<AppSecurityInfo>, hasBeenScanned: Boolean): SecurityScoreBreakdown {
        if (!hasBeenScanned) {
            return SecurityScoreBreakdown(
                score = 80,
                isEvaluated = false,
                factors = listOf(
                    ScoreFactor(
                        title = "Device Scan Pending",
                        description = "Initial device security check has not been run. Start a Quick Scan or Deep Scan to verify all app permissions.",
                        pointDelta = -20
                    )
                )
            )
        }

        var score = 100
        val factors = mutableListOf<ScoreFactor>()

        val harmful = apps.filter { it.riskLevel == RiskLevel.POTENTIALLY_HARMFUL }
        if (harmful.isNotEmpty()) {
            val delta = -(harmful.size * 25).coerceAtMost(60)
            score += delta
            factors.add(
                ScoreFactor(
                    title = "Potentially Harmful Apps Detected",
                    description = "${harmful.size} application(s) have critical permission or packaging anomalies.",
                    pointDelta = delta
                )
            )
        }

        val review = apps.filter { it.riskLevel == RiskLevel.REVIEW_RECOMMENDED }
        if (review.isNotEmpty()) {
            val delta = -(review.size * 8).coerceAtMost(40)
            score += delta
            factors.add(
                ScoreFactor(
                    title = "Items Recommended for Review",
                    description = "${review.size} application(s) have sensitive permission combinations or unverified install origins.",
                    pointDelta = delta
                )
            )
        }

        val debuggableUserApps = apps.filter { it.isDebuggable && !it.isSystemApp }
        if (debuggableUserApps.isNotEmpty()) {
            val delta = -(debuggableUserApps.size * 5).coerceAtMost(15)
            score += delta
            factors.add(
                ScoreFactor(
                    title = "Debuggable Applications",
                    description = "${debuggableUserApps.size} user app(s) compiled with development debug flags enabled.",
                    pointDelta = delta
                )
            )
        }

        val sideloadedWithPerms = apps.filter {
            !it.isSystemApp &&
            it.installerPackageName == null &&
            it.riskLevel == RiskLevel.NORMAL &&
            it.sensitivePermissions.isNotEmpty()
        }
        if (sideloadedWithPerms.isNotEmpty()) {
            val delta = -(sideloadedWithPerms.size * 2).coerceAtMost(10)
            score += delta
            factors.add(
                ScoreFactor(
                    title = "Sideloaded Applications with Permissions",
                    description = "${sideloadedWithPerms.size} app(s) installed manually outside official app stores.",
                    pointDelta = delta
                )
            )
        }

        if (factors.isEmpty()) {
            factors.add(
                ScoreFactor(
                    title = "All Security Checks Passed",
                    description = "All ${apps.size} scanned applications have verified install origins and expected permission configurations.",
                    pointDelta = 0
                )
            )
        }

        return SecurityScoreBreakdown(
            score = score.coerceIn(15, 100),
            isEvaluated = true,
            factors = factors
        )
    }
}
