package com.example.security.analyzer

import android.content.Context
import android.content.pm.PackageManager
import com.example.data.database.SecurityAlertEntity
import com.example.data.database.SecurityCheckResultEntity
import com.example.data.database.SecurityRecommendationEntity
import com.example.security.model.AlertSeverity
import com.example.security.model.AppAuditRiskLevel
import com.example.security.model.AppSecurityAuditItem
import com.example.security.model.CheckState
import com.example.security.model.CyberScoreFactor
import com.example.security.model.CyberSecurityAlertItem
import com.example.security.model.CyberSecurityReport
import com.example.security.model.CyberSecurityScore
import com.example.security.model.DeviceSecurityCheck
import com.example.security.model.PrivacyPermissionGroup

data class FullCyberAuditResult(
    val score: CyberSecurityScore,
    val deviceChecks: List<DeviceSecurityCheck>,
    val appAudits: List<AppSecurityAuditItem>,
    val privacyGroups: List<PrivacyPermissionGroup>,
    val networkReport: NetworkSafetyReport,
    val alerts: List<CyberSecurityAlertItem>,
    val recommendations: List<SecurityRecommendationEntity>,
    val report: CyberSecurityReport
)

class CyberSecurityEngine(private val context: Context) {

    private val deviceAnalyzer = DeviceSecurityAnalyzer(context)
    private val appAnalyzer = AppSecurityAnalyzer(context)
    private val privacyAnalyzer = PrivacyAnalyzer(context)
    private val networkAnalyzer = NetworkSafetyAnalyzer(context)
    val linkAnalyzer = LinkSafetyAnalyzer()
    private val alertManager = SecurityAlertManager()
    private val recommendationEngine = SecurityRecommendationEngine(context)
    private val reportGenerator = SecurityReportGenerator(context)

    fun runFullAudit(lastLinkResult: LinkSafetyAnalysisResult? = null): FullCyberAuditResult {
        // 1. Audit Device Security
        val deviceChecks = deviceAnalyzer.auditDeviceSecurity()

        // 2. Audit Applications
        val packageManager = context.packageManager
        val installedPackages = try {
            packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        } catch (_: Exception) {
            emptyList()
        }
        val appAudits = installedPackages.map { pkg ->
            appAnalyzer.auditApp(pkg)
        }

        // 3. Audit Privacy Permissions
        val privacyGroups = privacyAnalyzer.auditPrivacy(appAudits)

        // 4. Audit Network Safety
        val networkReport = networkAnalyzer.evaluateNetworkSafety()

        // 5. Calculate Transparent Cyber Security Score
        val score = calculateTransparentScore(deviceChecks, appAudits, privacyGroups, networkReport)

        // 6. Generate Alerts
        val alerts = alertManager.generateAlerts(deviceChecks, appAudits)

        // 7. Generate Actionable Recommendations
        val isScreenLocked = deviceChecks.find { it.id == "device_screen_lock" }?.state == CheckState.GOOD
        val recommendations = recommendationEngine.generateRecommendations(
            deviceChecks = deviceChecks,
            appAudits = appAudits,
            isVpnActive = networkReport.isVpnActive,
            isScreenLocked = isScreenLocked
        )

        // 8. Generate Report
        val report = reportGenerator.generateReport(
            score = score,
            deviceChecks = deviceChecks,
            appAudits = appAudits,
            privacyGroups = privacyGroups,
            networkReport = networkReport,
            lastLinkResult = lastLinkResult,
            recommendations = recommendations.map { it.description }
        )

        return FullCyberAuditResult(
            score = score,
            deviceChecks = deviceChecks,
            appAudits = appAudits,
            privacyGroups = privacyGroups,
            networkReport = networkReport,
            alerts = alerts,
            recommendations = recommendations,
            report = report
        )
    }

    private fun calculateTransparentScore(
        deviceChecks: List<DeviceSecurityCheck>,
        appAudits: List<AppSecurityAuditItem>,
        privacyGroups: List<PrivacyPermissionGroup>,
        networkReport: NetworkSafetyReport
    ): CyberSecurityScore {
        val factors = mutableListOf<CyberScoreFactor>()

        // Category 1: Device Security (Max 25 pts)
        var devicePts = 25
        val screenLockCheck = deviceChecks.find { it.id == "device_screen_lock" }
        if (screenLockCheck?.state == CheckState.REVIEW) {
            devicePts -= 12
            factors.add(CyberScoreFactor("Screen Lock", "Device Security", 0, 12, "Review Needed", "Device lacks hardware-backed PIN/pattern lock"))
        } else {
            factors.add(CyberScoreFactor("Screen Lock", "Device Security", 12, 12, "Protected", "Secure lock screen is active"))
        }

        val adbCheck = deviceChecks.find { it.id == "device_adb" }
        val devCheck = deviceChecks.find { it.id == "device_dev_options" }
        if (adbCheck?.state == CheckState.REVIEW) {
            devicePts -= 7
            factors.add(CyberScoreFactor("USB Debugging", "Device Security", 0, 7, "Review Needed", "ADB debugging bridge is enabled"))
        } else if (devCheck?.state == CheckState.REVIEW) {
            devicePts -= 3
            factors.add(CyberScoreFactor("Developer Mode", "Device Security", 4, 7, "Active", "Developer options enabled"))
        } else {
            factors.add(CyberScoreFactor("Developer Protection", "Device Security", 7, 7, "Optimal", "Developer bridge is disabled"))
        }

        val patchCheck = deviceChecks.find { it.id == "device_sec_patch" }
        if (patchCheck?.state == CheckState.REVIEW) {
            devicePts -= 4
            factors.add(CyberScoreFactor("Security Patch", "Device Security", 2, 6, "Review Needed", "Security patch is older than recommended"))
        } else {
            factors.add(CyberScoreFactor("Security Patch", "Device Security", 6, 6, "Good", "Security patch verified"))
        }
        val finalDeviceScore = devicePts.coerceIn(0, 25)

        // Category 2: App Security (Max 25 pts)
        var appPts = 25
        val highRiskApps = appAudits.count { it.riskLevel == AppAuditRiskLevel.HIGH }
        val reviewApps = appAudits.count { it.riskLevel == AppAuditRiskLevel.REVIEW }
        if (highRiskApps > 0) {
            val deduction = (highRiskApps * 8).coerceAtMost(15)
            appPts -= deduction
            factors.add(CyberScoreFactor("High-Risk Apps", "App Security", (15 - deduction).coerceAtLeast(0), 15, "Action Recommended", "$highRiskApps app(s) have sensitive permission combos"))
        } else {
            factors.add(CyberScoreFactor("High-Risk Apps", "App Security", 15, 15, "Clean", "No high-risk combinations detected"))
        }
        if (reviewApps > 0) {
            val deduction = (reviewApps * 2).coerceAtMost(10)
            appPts -= deduction
            factors.add(CyberScoreFactor("App Review Profile", "App Security", (10 - deduction).coerceAtLeast(0), 10, "Reviewed", "$reviewApps app(s) have sensitive permissions"))
        } else {
            factors.add(CyberScoreFactor("App Review Profile", "App Security", 10, 10, "Standard", "All apps exhibit standard profiles"))
        }
        val finalAppScore = appPts.coerceIn(0, 25)

        // Category 3: Privacy Hygiene (Max 20 pts)
        var privacyPts = 20
        val overlayCount = privacyGroups.find { it.groupKey == "overlay" }?.associatedApps?.size ?: 0
        val smsCount = privacyGroups.find { it.groupKey == "sms" }?.associatedApps?.size ?: 0
        if (overlayCount > 3) {
            privacyPts -= 5
            factors.add(CyberScoreFactor("Overlay Access", "Privacy", 5, 10, "Review", "$overlayCount apps have display-over-other-apps permission"))
        } else {
            factors.add(CyberScoreFactor("Overlay Access", "Privacy", 10, 10, "Controlled", "Overlay permissions are well-contained"))
        }
        if (smsCount > 2) {
            privacyPts -= 5
            factors.add(CyberScoreFactor("SMS Access", "Privacy", 5, 10, "Elevated", "$smsCount apps can read or send SMS text"))
        } else {
            factors.add(CyberScoreFactor("SMS Access", "Privacy", 10, 10, "Restricted", "SMS permissions restricted to designated apps"))
        }
        val finalPrivacyScore = privacyPts.coerceIn(0, 20)

        // Category 4: Network Safety (Max 15 pts)
        var networkPts = 15
        if (networkReport.isVpnActive) {
            factors.add(CyberScoreFactor("VPN Encryption", "Network Safety", 15, 15, "Encrypted", "VPN tunnel is actively protecting traffic"))
        } else if (networkReport.connectionType.contains("Cellular", ignoreCase = true)) {
            factors.add(CyberScoreFactor("Network Transit", "Network Safety", 13, 15, "Cellular", "Direct carrier network connection"))
        } else if (networkReport.connectionType.contains("Wi-Fi", ignoreCase = true)) {
            factors.add(CyberScoreFactor("Network Transit", "Network Safety", 12, 15, "Wi-Fi", "Connected to local Wi-Fi"))
        } else {
            factors.add(CyberScoreFactor("Network Transit", "Network Safety", 10, 15, "Offline", "Device is offline"))
        }
        val finalNetworkScore = networkPts.coerceIn(0, 15)

        // Category 5: Account & Authentication Hygiene (Max 15 pts)
        // Standard baseline evaluation (13/15 if user has lock screen, 10/15 otherwise)
        val finalAccountScore = if (screenLockCheck?.state == CheckState.GOOD) 13 else 9
        factors.add(CyberScoreFactor("Authentication Boundary", "Account Security", finalAccountScore, 15, "Evaluated", "Based on device credentials and authentication recommendations"))

        val total = finalDeviceScore + finalAppScore + finalPrivacyScore + finalNetworkScore + finalAccountScore
        val clampedTotal = total.coerceIn(0, 100)

        val rating = when {
            clampedTotal >= 85 -> "Strong Protection"
            clampedTotal >= 70 -> "Good - Minor Reviews"
            clampedTotal >= 50 -> "Moderate - Action Needed"
            else -> "Vulnerable - Urgent Action"
        }

        return CyberSecurityScore(
            totalScore = clampedTotal,
            deviceSecurityScore = finalDeviceScore,
            appSecurityScore = finalAppScore,
            privacyScore = finalPrivacyScore,
            networkScore = finalNetworkScore,
            accountSecurityScore = finalAccountScore,
            ratingLabel = rating,
            factors = factors
        )
    }

    fun shareReport(report: CyberSecurityReport) {
        reportGenerator.shareReport(report)
    }
}
