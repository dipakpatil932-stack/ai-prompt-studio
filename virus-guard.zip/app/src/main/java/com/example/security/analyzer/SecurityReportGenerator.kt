package com.example.security.analyzer

import android.content.Context
import android.content.Intent
import com.example.security.model.AppAuditRiskLevel
import com.example.security.model.AppSecurityAuditItem
import com.example.security.model.CheckState
import com.example.security.model.CyberSecurityReport
import com.example.security.model.CyberSecurityScore
import com.example.security.model.DeviceSecurityCheck
import com.example.security.model.PrivacyPermissionGroup
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SecurityReportGenerator(private val context: Context) {

    fun generateReport(
        score: CyberSecurityScore,
        deviceChecks: List<DeviceSecurityCheck>,
        appAudits: List<AppSecurityAuditItem>,
        privacyGroups: List<PrivacyPermissionGroup>,
        networkReport: NetworkSafetyReport,
        lastLinkResult: LinkSafetyAnalysisResult?,
        recommendations: List<String>
    ): CyberSecurityReport {
        val now = System.currentTimeMillis()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val formattedDate = dateFormat.format(Date(now))

        val passedChecks = deviceChecks.count { it.state == CheckState.GOOD }
        val reviewChecks = deviceChecks.count { it.state == CheckState.REVIEW }
        val naChecks = deviceChecks.count { it.state == CheckState.NOT_AVAILABLE }

        val totalApps = appAudits.size
        val lowApps = appAudits.count { it.riskLevel == AppAuditRiskLevel.LOW }
        val reviewApps = appAudits.count { it.riskLevel == AppAuditRiskLevel.REVIEW }
        val highApps = appAudits.count { it.riskLevel == AppAuditRiskLevel.HIGH }

        val totalSensitivePermissions = privacyGroups.sumOf { it.associatedApps.size }

        val plainText = buildString {
            appendLine("============================================")
            appendLine("🛡️ VIRUS GUARD - CYBER SECURITY REPORT")
            appendLine("Generated: $formattedDate")
            appendLine("Overall Cyber Security Score: ${score.totalScore}/100 (${score.ratingLabel})")
            appendLine("============================================")
            appendLine()

            appendLine("1. DEVICE SECURITY AUDIT")
            appendLine("   - Passed Checks: $passedChecks")
            appendLine("   - Items Needing Review: $reviewChecks")
            appendLine("   - Not Available via Public APIs: $naChecks")
            deviceChecks.forEach { check ->
                val marker = when (check.state) {
                    CheckState.GOOD -> "[GOOD]"
                    CheckState.REVIEW -> "[REVIEW]"
                    CheckState.NOT_AVAILABLE -> "[N/A]"
                }
                appendLine("   $marker ${check.title}: ${check.explanation}")
            }
            appendLine()

            appendLine("2. APPLICATION SECURITY AUDIT")
            appendLine("   - Total Apps Inspected: $totalApps")
            appendLine("   - Low Risk Apps: $lowApps")
            appendLine("   - Review Recommended: $reviewApps")
            appendLine("   - High Risk Combinations: $highApps")
            if (highApps > 0) {
                appendLine("   High risk applications:")
                appAudits.filter { it.riskLevel == AppAuditRiskLevel.HIGH }.forEach {
                    appendLine("     * ${it.appName} (${it.packageName}): ${it.riskIndicators.joinToString("; ")}")
                }
            }
            appendLine()

            appendLine("3. PRIVACY PERMISSIONS AUDIT")
            privacyGroups.forEach { group ->
                appendLine("   - ${group.displayName}: ${group.associatedApps.size} app(s)")
            }
            appendLine()

            appendLine("4. NETWORK SAFETY")
            appendLine("   - Connection Type: ${networkReport.connectionType}")
            appendLine("   - VPN Status: ${if (networkReport.isVpnActive) "Active (Encrypted)" else "Inactive"}")
            appendLine("   - Metered: ${if (networkReport.isMetered) "Yes" else "No"}")
            appendLine("   - Status: ${networkReport.summary}")
            appendLine()

            appendLine("5. LINK SAFETY CHECKER")
            if (lastLinkResult != null) {
                appendLine("   - Last Checked URL: ${lastLinkResult.host}")
                appendLine("   - Assessment: ${lastLinkResult.statusLabel}")
                appendLine("   - Details: ${lastLinkResult.reasons.joinToString("; ").ifEmpty { "No warnings found" }}")
            } else {
                appendLine("   - No recent URLs submitted for analysis.")
            }
            appendLine()

            appendLine("6. KEY RECOMMENDATIONS")
            if (recommendations.isNotEmpty()) {
                recommendations.forEachIndexed { idx, rec ->
                    appendLine("   ${idx + 1}. $rec")
                }
            } else {
                appendLine("   - All inspected controls meet security recommendations.")
            }
            appendLine()
            appendLine("Defensive notice: This report contains legitimate local device audit metrics. No private personal data is collected or sent to remote servers.")
        }

        return CyberSecurityReport(
            scanTimestamp = now,
            formattedDate = formattedDate,
            overallScore = score.totalScore,
            deviceChecksSummary = "$passedChecks passed, $reviewChecks review, $naChecks not available",
            deviceChecksPassed = passedChecks,
            deviceChecksReview = reviewChecks,
            deviceChecksNotAvailable = naChecks,
            appAuditSummary = "$totalApps audited ($lowApps low, $reviewApps review, $highApps high)",
            totalAppsAudited = totalApps,
            lowRiskApps = lowApps,
            reviewApps = reviewApps,
            highRiskApps = highApps,
            privacyFindingsSummary = "$totalSensitivePermissions instances of sensitive permissions across installed apps",
            sensitivePermissionCount = totalSensitivePermissions,
            networkSummary = networkReport.summary,
            linkCheckSummary = lastLinkResult?.statusLabel ?: "Ready for URL verification",
            topRecommendations = recommendations,
            plainTextReport = plainText
        )
    }

    fun shareReport(report: CyberSecurityReport) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, report.plainTextReport)
            putExtra(Intent.EXTRA_SUBJECT, "Virus Guard Cyber Security Report - ${report.formattedDate}")
            type = "text/plain"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share Cyber Security Report").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(shareIntent)
        } catch (_: Exception) {
            // Fallback gracefully
        }
    }
}
