package com.example.security.analyzer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import com.example.security.model.NetworkSecurityInfo
import com.example.security.model.RiskLevel

class NetworkAnalyzer(private val context: Context) {

    fun analyzeNetwork(): NetworkSecurityInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return NetworkSecurityInfo(
                isConnected = false,
                connectionType = "Unknown",
                isVpnActive = false,
                isMetered = false,
                dnsOrGateways = "",
                securitySummary = "Network connectivity service unavailable.",
                riskLevel = RiskLevel.NORMAL
            )

        val activeNetwork = cm.activeNetwork
        if (activeNetwork == null) {
            return NetworkSecurityInfo(
                isConnected = false,
                connectionType = "Offline",
                isVpnActive = false,
                isMetered = false,
                dnsOrGateways = "",
                securitySummary = "Device is currently offline. No active network connections.",
                riskLevel = RiskLevel.NORMAL
            )
        }

        val capabilities = cm.getNetworkCapabilities(activeNetwork)
        val isVpnActive = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val isMetered = cm.isActiveNetworkMetered

        val connectionType = when {
            capabilities == null -> "Unknown"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Active Network"
        }

        val isInternetValidated = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

        val summary = buildString {
            append("Connected to $connectionType.")
            if (isVpnActive) append(" Virtual Private Network (VPN) encryption active.")
            if (isMetered) append(" Connection is metered.")
            if (isInternetValidated) append(" Internet access validated.")
        }

        return NetworkSecurityInfo(
            isConnected = true,
            connectionType = connectionType,
            isVpnActive = isVpnActive,
            isMetered = isMetered,
            dnsOrGateways = if (isVpnActive) "VPN Encrypted Tunnel" else "Standard DNS Routing",
            securitySummary = summary,
            riskLevel = RiskLevel.NORMAL
        )
    }
}
