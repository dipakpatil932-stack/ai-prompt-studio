package com.example.security.model

enum class CompromiseStatus {
    NO_OBVIOUS_ISSUE,    // 🟢 No obvious issue
    REVIEW_RECOMMENDED,  // 🟠 Review recommended
    ACTION_RECOMMENDED   // 🔴 Action recommended
}

data class CompromiseIndicator(
    val id: String,
    val title: String,
    val hindiTitle: String,
    val category: String,
    val status: CompromiseStatus,
    val whatWasFound: String,
    val hindiWhatWasFound: String,
    val whyItMatters: String,
    val hindiWhyItMatters: String,
    val whatUserCanDo: String,
    val hindiWhatUserCanDo: String,
    val intentAction: String? = null,
    val isAndroidLimitation: Boolean = false,
    val limitationNote: String? = null
)

data class SuspiciousAppDetail(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val isSystemApp: Boolean,
    val installTimeMillis: Long,
    val formattedInstallDate: String,
    val isRecentlyInstalled: Boolean, // e.g. within 30 days
    val installerName: String,
    val isSideloaded: Boolean,
    val hasAccessibilityAccess: Boolean,
    val hasNotificationAccess: Boolean,
    val hasDeviceAdminAccess: Boolean,
    val hasOverlayAccess: Boolean,
    val hasInstallPackagesAccess: Boolean,
    val sensitivePermissions: List<String>,
    val riskFactors: List<String>,
    val hindiRiskFactors: List<String>,
    val riskLevel: CompromiseStatus,
    val whatWasFound: String,
    val hindiWhatWasFound: String,
    val whyItMatters: String,
    val hindiWhyItMatters: String,
    val whatUserCanDo: String,
    val hindiWhatUserCanDo: String
)

data class HackingPrivacyGroup(
    val id: String,
    val name: String,
    val hindiName: String,
    val iconName: String,
    val description: String,
    val hindiDescription: String,
    val permittedAppsCount: Int,
    val permittedApps: List<String>
)

data class RecoveryStep(
    val stepNumber: Int,
    val title: String,
    val hindiTitle: String,
    val summary: String,
    val hindiSummary: String,
    val detailedInstructions: List<String>,
    val hindiInstructions: List<String>,
    val isWarning: Boolean = false,
    val warningText: String? = null,
    val hindiWarningText: String? = null,
    val actionLabel: String? = null,
    val intentAction: String? = null
)

data class AccountSecurityCheckItem(
    val id: String,
    val title: String,
    val hindiTitle: String,
    val description: String,
    val hindiDescription: String,
    val actionAdvice: String,
    val hindiActionAdvice: String
)

data class EmergencyActionItem(
    val stepNumber: Int,
    val actionText: String,
    val hindiActionText: String,
    val explanation: String,
    val hindiExplanation: String,
    val intentAction: String? = null
)

data class MobileHackingAuditResult(
    val timestamp: Long,
    val formattedDate: String,
    val overallStatus: CompromiseStatus,
    val headline: String,
    val hindiHeadline: String,
    val summaryExplanation: String,
    val hindiSummaryExplanation: String,
    val indicators: List<CompromiseIndicator>,
    val suspiciousApps: List<SuspiciousAppItemWrapper>,
    val recentlyInstalledApps: List<SuspiciousAppItemWrapper>,
    val privacyAuditGroups: List<HackingPrivacyGroup>,
    val connectionType: String,
    val isVpnActive: Boolean,
    val vpnDetails: String,
    val networkSecuritySummary: String,
    val androidLimitationsDisclosures: List<String>,
    val plainTextReport: String
)

data class SuspiciousAppItemWrapper(
    val detail: SuspiciousAppDetail
)
