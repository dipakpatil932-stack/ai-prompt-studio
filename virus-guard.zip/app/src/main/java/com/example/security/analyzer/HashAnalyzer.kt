package com.example.security.analyzer

import android.content.Context
import android.net.Uri
import com.example.security.model.ThreatIntelResult
import com.example.security.scanner.OfflineThreatIntelligenceProvider
import com.example.security.scanner.ThreatIntelligenceProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.security.MessageDigest

class HashAnalyzer(
    private val context: Context,
    private val threatIntelProvider: ThreatIntelligenceProvider = OfflineThreatIntelligenceProvider()
) {

    suspend fun computeSha256(uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)
            context.contentResolver.openInputStream(uri)?.use { stream: InputStream ->
                var bytesRead: Int
                while (stream.read(buffer).also { bytesRead = it } != -1) {
                    digest.update(buffer, 0, bytesRead)
                }
            } ?: return@withContext "Unavailable"
            val hashBytes = digest.digest()
            hashBytes.joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            "Error calculating hash"
        }
    }

    suspend fun checkHashThreatIntel(sha256: String): ThreatIntelResult {
        return threatIntelProvider.checkHash(sha256)
    }
}
