package com.example.security.analyzer

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import com.example.security.model.ApkSecurityInfo
import com.example.security.model.RiskLevel
import com.example.security.scanner.SignatureDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest

class ApkAnalyzer(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    suspend fun analyzeApkUri(uri: Uri): ApkSecurityInfo = withContext(Dispatchers.IO) {
        val tempApkFile = File(context.cacheDir, "temp_analyze_${System.currentTimeMillis()}.apk")
        var sha256 = "Unavailable"
        var sizeBytes = 0L

        try {
            // Safely stream content into temp cache file while computing SHA-256
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(8192)

            context.contentResolver.openInputStream(uri)?.use { input: InputStream ->
                FileOutputStream(tempApkFile).use { output ->
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        digest.update(buffer, 0, bytesRead)
                        sizeBytes += bytesRead
                    }
                }
            }
            sha256 = digest.digest().joinToString("") { "%02x".format(it) }

            // Inspect archive using Android PackageManager
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES
            } else {
                @Suppress("DEPRECATION")
                PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNATURES
            }

            val packageInfo: PackageInfo? = packageManager.getPackageArchiveInfo(tempApkFile.absolutePath, flags)

            if (packageInfo == null) {
                return@withContext ApkSecurityInfo(
                    apkName = "Corrupted or Invalid APK",
                    packageName = "Unknown",
                    versionName = "N/A",
                    versionCode = 0L,
                    targetSdk = 0,
                    requestedPermissions = emptyList(),
                    sensitivePermissions = emptyList(),
                    sizeBytes = sizeBytes,
                    sha256Hash = sha256,
                    signatureCount = 0,
                    isDebuggable = false,
                    suspiciousIndicators = listOf("Package manager could not parse AndroidManifest.xml (corrupted, encrypted, or invalid APK structure)."),
                    riskLevel = RiskLevel.REVIEW_RECOMMENDED
                )
            }

            // Fix sourceDir for label extraction
            packageInfo.applicationInfo?.sourceDir = tempApkFile.absolutePath
            packageInfo.applicationInfo?.publicSourceDir = tempApkFile.absolutePath

            val appName = try {
                packageInfo.applicationInfo?.loadLabel(packageManager)?.toString() ?: packageInfo.packageName
            } catch (_: Exception) {
                packageInfo.packageName
            }

            val packageName = packageInfo.packageName
            val versionName = packageInfo.versionName ?: "1.0"
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }

            val targetSdk = packageInfo.applicationInfo?.targetSdkVersion ?: 0
            val isDebuggable = ((packageInfo.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_DEBUGGABLE) != 0

            val requestedPermissions = packageInfo.requestedPermissions?.toList() ?: emptyList()
            val sensitiveFound = mutableListOf<String>()
            val suspiciousIndicators = mutableListOf<String>()

            for (perm in requestedPermissions) {
                val simpleName = perm.substringAfterLast('.')
                if (perm.startsWith("android.permission.")) {
                    if (perm in SENSITIVE_PERMISSIONS_SET) {
                        sensitiveFound.add(simpleName)
                    }
                }
            }

            // Check signature count
            val signatureCount = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.signingInfo?.apkContentsSigners?.size ?: 0
            } else {
                @Suppress("DEPRECATION")
                packageInfo.signatures?.size ?: 0
            }

            // Heuristic indicators
            if (signatureCount == 0) {
                suspiciousIndicators.add("No cryptographic signing certificate found. Unsigned APKs cannot be safely verified.")
            }

            if (targetSdk in 1..28) {
                suspiciousIndicators.add("Targets older Android version (targetSdk $targetSdk). Modern apps target SDK 31+ to enforce runtime permission sandboxing.")
            }

            if (isDebuggable) {
                suspiciousIndicators.add("Debuggable flag enabled (FLAG_DEBUGGABLE). This APK was built for development and exposes runtime memory.")
            }

            // High-risk combinations
            val permSet = requestedPermissions.toSet()
            if (permSet.contains("android.permission.SYSTEM_ALERT_WINDOW") &&
                permSet.contains("android.permission.BIND_ACCESSIBILITY_SERVICE")
            ) {
                suspiciousIndicators.add("Combined Overlay + Accessibility permissions: Can interact with screen and draw over other apps.")
            }

            if (permSet.contains("android.permission.RECEIVE_BOOT_COMPLETED") &&
                (permSet.contains("android.permission.SEND_SMS") || permSet.contains("android.permission.RECEIVE_SMS"))
            ) {
                suspiciousIndicators.add("Background startup with SMS monitoring/sending capabilities.")
            }

            if (permSet.contains("android.permission.REQUEST_INSTALL_PACKAGES")) {
                suspiciousIndicators.add("Can prompt installation of additional APKs from external storage.")
            }

            val isRecognized = SignatureDatabase.isRecognizedLegitimateApp(packageName)
            val riskLevel = when {
                suspiciousIndicators.any { it.contains("Combined Overlay") || it.contains("SMS monitoring") } -> RiskLevel.POTENTIALLY_HARMFUL
                suspiciousIndicators.isNotEmpty() && !isRecognized -> RiskLevel.REVIEW_RECOMMENDED
                sensitiveFound.size > 5 && !isRecognized -> RiskLevel.REVIEW_RECOMMENDED
                else -> RiskLevel.NORMAL
            }

            ApkSecurityInfo(
                apkName = appName,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode,
                targetSdk = targetSdk,
                requestedPermissions = requestedPermissions,
                sensitivePermissions = sensitiveFound,
                sizeBytes = sizeBytes,
                sha256Hash = sha256,
                signatureCount = signatureCount,
                isDebuggable = isDebuggable,
                suspiciousIndicators = suspiciousIndicators,
                riskLevel = riskLevel
            )
        } catch (e: Exception) {
            ApkSecurityInfo(
                apkName = "Error Analyzing APK",
                packageName = "Error",
                versionName = "N/A",
                versionCode = 0L,
                targetSdk = 0,
                requestedPermissions = emptyList(),
                sensitivePermissions = emptyList(),
                sizeBytes = sizeBytes,
                sha256Hash = sha256,
                signatureCount = 0,
                isDebuggable = false,
                suspiciousIndicators = listOf("Analysis encountered an error: ${e.message ?: "Unable to read APK file structure"}"),
                riskLevel = RiskLevel.REVIEW_RECOMMENDED
            )
        } finally {
            try {
                if (tempApkFile.exists()) tempApkFile.delete()
            } catch (_: Exception) {}
        }
    }

    companion object {
        private val SENSITIVE_PERMISSIONS_SET = setOf(
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.READ_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.SEND_SMS",
            "android.permission.READ_CALL_LOG",
            "android.permission.CALL_PHONE",
            "android.permission.SYSTEM_ALERT_WINDOW",
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
            "android.permission.REQUEST_INSTALL_PACKAGES",
            "android.permission.MANAGE_EXTERNAL_STORAGE"
        )
    }
}
