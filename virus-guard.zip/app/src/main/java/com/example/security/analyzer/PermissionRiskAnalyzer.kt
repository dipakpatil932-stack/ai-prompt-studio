package com.example.security.analyzer

import com.example.security.model.RiskLevel
import com.example.security.model.TargetType
import com.example.security.model.ThreatRecord
import com.example.security.scanner.SignatureDatabase

data class PermissionAnalysisResult(
    val sensitivePermissions: List<String>,
    val highRiskCombinations: List<String>,
    val riskLevel: RiskLevel,
    val reasons: List<String>,
    val threatRecords: List<ThreatRecord>
)

object PermissionRiskAnalyzer {

    // Map of sensitive permission to clear, calm explanation of why it requires user review
    private val SENSITIVE_PERMISSION_DESCRIPTIONS = mapOf(
        "android.permission.CAMERA" to "Requests access to your device camera to capture photos or video. Check whether this is necessary for the app's features.",
        "android.permission.RECORD_AUDIO" to "Requests access to your microphone. Check whether this permission is necessary for the app's features.",
        "android.permission.ACCESS_FINE_LOCATION" to "Requests precise GPS location access, which can reveal your exact physical location.",
        "android.permission.ACCESS_COARSE_LOCATION" to "Requests approximate cell/Wi-Fi location access.",
        "android.permission.ACCESS_BACKGROUND_LOCATION" to "Requests continuous location access even when the app is closed or running in the background.",
        "android.permission.READ_CONTACTS" to "Requests access to your personal contact address book.",
        "android.permission.WRITE_CONTACTS" to "Requests ability to modify or add entries to your contact list.",
        "android.permission.READ_SMS" to "Requests access to read incoming and stored SMS text messages.",
        "android.permission.RECEIVE_SMS" to "Requests permission to monitor and receive incoming SMS messages, including verification codes.",
        "android.permission.SEND_SMS" to "Requests permission to send SMS text messages, which could incur carrier charges.",
        "android.permission.READ_CALL_LOG" to "Requests access to your incoming and outgoing phone call logs.",
        "android.permission.CALL_PHONE" to "Requests ability to initiate outgoing telephone calls directly without going through the dialer.",
        "android.permission.READ_PHONE_STATE" to "Requests device identifier and cellular network status information.",
        "android.permission.READ_EXTERNAL_STORAGE" to "Requests broad access to read files and media on shared device storage.",
        "android.permission.WRITE_EXTERNAL_STORAGE" to "Requests broad access to modify files on shared device storage.",
        "android.permission.MANAGE_EXTERNAL_STORAGE" to "Requests full management access to all files on shared storage (All Files Access).",
        "android.permission.SYSTEM_ALERT_WINDOW" to "Allows this application to draw floating windows on top of other running applications.",
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to "Can inspect screen content and simulate touch inputs on behalf of the user.",
        "android.permission.REQUEST_INSTALL_PACKAGES" to "Allows this application to prompt the installation of new APK packages from outside app stores.",
        "android.permission.POST_NOTIFICATIONS" to "Allows sending push notifications to your lock screen and notification shade."
    )

    fun analyze(
        packageName: String,
        appName: String,
        requestedPermissions: List<String>,
        isSystemApp: Boolean,
        isRecognizedLegitimateApp: Boolean = SignatureDatabase.isRecognizedLegitimateApp(packageName)
    ): PermissionAnalysisResult {
        val sensitiveFound = mutableListOf<String>()
        val reasons = mutableListOf<String>()
        val threats = mutableListOf<ThreatRecord>()
        val highRiskCombos = mutableListOf<String>()

        val permSet = requestedPermissions.toSet()

        for (perm in requestedPermissions) {
            val explanation = SENSITIVE_PERMISSION_DESCRIPTIONS[perm]
            if (explanation != null) {
                val simpleName = perm.substringAfterLast('.')
                sensitiveFound.add(simpleName)

                // Only evaluate single high-risk permission threats for non-system, non-recognized apps
                if (!isSystemApp && !isRecognizedLegitimateApp && isHighRiskSinglePermission(perm)) {
                    val severity = when {
                        perm == "android.permission.BIND_ACCESSIBILITY_SERVICE" ||
                        perm == "android.permission.REQUEST_INSTALL_PACKAGES" ||
                        perm == "android.permission.MANAGE_EXTERNAL_STORAGE" -> RiskLevel.REVIEW_RECOMMENDED
                        else -> RiskLevel.NORMAL
                    }
                    if (severity != RiskLevel.NORMAL) {
                        reasons.add(explanation)
                        threats.add(
                            ThreatRecord(
                                id = "${packageName}_${simpleName}",
                                title = "Sensitive Permission: $simpleName",
                                description = "Requested by $appName",
                                reason = explanation,
                                severity = severity,
                                targetName = appName,
                                targetIdentifier = packageName,
                                targetType = TargetType.PERMISSION,
                                recommendation = "Review in Android Settings if this app does not need this feature.",
                                isSystemProtected = isSystemApp
                            )
                        )
                    }
                }
            }
        }

        // Check combinations from SignatureDatabase only for unverified/unknown apps
        if (!isSystemApp && !isRecognizedLegitimateApp) {
            for ((combo, explanation) in SignatureDatabase.HIGH_RISK_PERMISSION_COMBINATIONS) {
                if (permSet.containsAll(combo)) {
                    val names = combo.map { it.substringAfterLast('.') }.joinToString(" + ")
                    highRiskCombos.add(names)
                    val severity = RiskLevel.REVIEW_RECOMMENDED
                    reasons.add("Combined permissions ($names): $explanation")
                    threats.add(
                        ThreatRecord(
                            id = "${packageName}_combo_${combo.hashCode()}",
                            title = "Permission Combination: $names",
                            description = "Sensitive multi-permission pattern detected in $appName",
                            reason = explanation,
                            severity = severity,
                            targetName = appName,
                            targetIdentifier = packageName,
                            targetType = TargetType.PERMISSION,
                            recommendation = "Verify that this application's developer is known and legitimate.",
                            isSystemProtected = false
                        )
                    )
                }
            }
        }

        val finalRisk = when {
            threats.any { it.severity == RiskLevel.POTENTIALLY_HARMFUL } -> RiskLevel.POTENTIALLY_HARMFUL
            threats.any { it.severity == RiskLevel.REVIEW_RECOMMENDED } -> RiskLevel.REVIEW_RECOMMENDED
            else -> RiskLevel.NORMAL
        }

        return PermissionAnalysisResult(
            sensitivePermissions = sensitiveFound,
            highRiskCombinations = highRiskCombos,
            riskLevel = finalRisk,
            reasons = reasons,
            threatRecords = threats
        )
    }

    private fun isHighRiskSinglePermission(permission: String): Boolean {
        return when (permission) {
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
            "android.permission.REQUEST_INSTALL_PACKAGES",
            "android.permission.MANAGE_EXTERNAL_STORAGE",
            "android.permission.SYSTEM_ALERT_WINDOW",
            "android.permission.RECEIVE_SMS",
            "android.permission.SEND_SMS",
            "android.permission.READ_CALL_LOG" -> true
            else -> false
        }
    }
}
