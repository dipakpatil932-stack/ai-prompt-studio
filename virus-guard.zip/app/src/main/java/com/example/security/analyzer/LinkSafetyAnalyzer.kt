package com.example.security.analyzer

import android.net.Uri
import com.example.security.scanner.OfflineThreatIntelligenceProvider
import com.example.security.scanner.ThreatIntelligenceProvider
import java.util.regex.Pattern

enum class LinkSafetyStatus {
    NO_OBVIOUS_WARNING, // 🟢 No obvious warning
    REVIEW_RECOMMENDED  // 🟠 Review Recommended
}

data class LinkSafetyAnalysisResult(
    val originalUrl: String,
    val formattedUrl: String,
    val host: String,
    val scheme: String,
    val isHttps: Boolean,
    val hasIpHost: Boolean,
    val hasPunycode: Boolean,
    val hasMisleadingSubdomain: Boolean,
    val hasUnusualEncodedChars: Boolean,
    val hasEmbeddedCredentials: Boolean,
    val status: LinkSafetyStatus,
    val statusLabel: String,
    val reasons: List<String>,
    val recommendation: String,
    val threatIntelStatus: String = "Local analysis only — online threat intelligence is not connected."
)

class LinkSafetyAnalyzer(
    private val threatIntelProvider: ThreatIntelligenceProvider = OfflineThreatIntelligenceProvider()
) {

    private val ipv4Pattern = Pattern.compile("^([0-9]{1,3}\\.){3}[0-9]{1,3}$")

    private val suspiciousKeywords = listOf(
        "login", "signin", "verify", "secure", "update", "account",
        "banking", "paypal", "appleid", "google-support", "wallet", "recovery", "password", "auth"
    )

    private val highRiskTlds = setOf(
        "xyz", "top", "work", "loan", "club", "stream", "gq", "cf", "tk", "ml", "ga", "buzz"
    )

    fun analyzeLink(rawUrl: String): LinkSafetyAnalysisResult {
        val trimmed = rawUrl.trim()
        val formattedUrl = if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            "https://$trimmed"
        } else {
            trimmed
        }

        val uri = try {
            Uri.parse(formattedUrl)
        } catch (_: Exception) {
            null
        }

        val host = uri?.host ?: ""
        val scheme = uri?.scheme?.lowercase() ?: ""
        val isHttps = scheme == "https"
        val reasons = mutableListOf<String>()

        if (uri == null || host.isBlank()) {
            return LinkSafetyAnalysisResult(
                originalUrl = rawUrl,
                formattedUrl = formattedUrl,
                host = "Invalid Link",
                scheme = scheme,
                isHttps = false,
                hasIpHost = false,
                hasPunycode = false,
                hasMisleadingSubdomain = false,
                hasUnusualEncodedChars = false,
                hasEmbeddedCredentials = false,
                status = LinkSafetyStatus.REVIEW_RECOMMENDED,
                statusLabel = "Review Recommended",
                reasons = listOf("Invalid or malformed URL syntax. Check the link address."),
                recommendation = "Do not open links with unreadable or corrupted format."
            )
        }

        // 1. HTTPS Usage
        if (!isHttps) {
            reasons.add("Uses unencrypted HTTP protocol. Passwords and credentials transmitted over this link can be viewed by network observers.")
        }

        // 2. IP Host
        val hasIpHost = ipv4Pattern.matcher(host).matches()
        if (hasIpHost) {
            reasons.add("Host is a numerical IP address ($host) rather than a registered domain name. Legitimate services typically use branded domain names.")
        }

        // 3. Punycode (IDN homograph attack prevention)
        val hasPunycode = host.contains("xn--", ignoreCase = true)
        if (hasPunycode) {
            reasons.add("Uses internationalized Punycode encoding (xn--). Often used in homoglyph spoofing to resemble known brands.")
        }

        // 4. Unusual encoded characters (e.g. %00, %0d, %0a, repeated encoding)
        val hasUnusualEncodedChars = rawUrl.contains("%00") || rawUrl.contains("%0d") ||
                rawUrl.contains("%0a") || rawUrl.contains("%25") || rawUrl.contains("@")
        if (hasUnusualEncodedChars) {
            reasons.add("Contains unusual URL encoding or special characters (@, %00) often used to disguise actual landing targets.")
        }

        // 5. Embedded credentials
        val hasEmbeddedCredentials = uri.encodedUserInfo?.isNotEmpty() == true
        if (hasEmbeddedCredentials) {
            reasons.add("Contains embedded authentication credentials (user:pass@domain).")
        }

        // 6. Misleading subdomain patterns
        val hostParts = host.split('.')
        var hasMisleadingSubdomain = false
        if (hostParts.size > 2) {
            val apexDomain = hostParts.takeLast(2).joinToString(".")
            val subdomains = hostParts.dropLast(2)
            for (sub in subdomains) {
                for (kw in suspiciousKeywords) {
                    if (sub.contains(kw, ignoreCase = true)) {
                        hasMisleadingSubdomain = true
                        reasons.add("Subdomain contains security keyword '$kw' while destination apex domain is '$apexDomain'. Check if this domain officially belongs to that entity.")
                        break
                    }
                }
            }
        }

        // 7. High-risk TLD with multiple subdomain nesting
        val tld = hostParts.lastOrNull()?.lowercase() ?: ""
        if (tld in highRiskTlds && hostParts.size > 2) {
            reasons.add("Uses top-level domain (.$tld) with multi-level nested subdomains.")
        }

        val status = if (reasons.isEmpty()) {
            LinkSafetyStatus.NO_OBVIOUS_WARNING
        } else {
            LinkSafetyStatus.REVIEW_RECOMMENDED
        }

        val statusLabel = if (status == LinkSafetyStatus.NO_OBVIOUS_WARNING) {
            "No Obvious Warning"
        } else {
            "Review Recommended"
        }

        val recommendation = if (status == LinkSafetyStatus.NO_OBVIOUS_WARNING) {
            "Standard URL structure with valid HTTPS encryption. Always verify destination content before entering personal login credentials."
        } else {
            "Exercise caution: Do not submit sensitive passwords, PINs, or financial information on this page without independently verifying the address."
        }

        return LinkSafetyAnalysisResult(
            originalUrl = rawUrl,
            formattedUrl = formattedUrl,
            host = host,
            scheme = scheme,
            isHttps = isHttps,
            hasIpHost = hasIpHost,
            hasPunycode = hasPunycode,
            hasMisleadingSubdomain = hasMisleadingSubdomain,
            hasUnusualEncodedChars = hasUnusualEncodedChars,
            hasEmbeddedCredentials = hasEmbeddedCredentials,
            status = status,
            statusLabel = statusLabel,
            reasons = reasons,
            recommendation = recommendation
        )
    }
}
