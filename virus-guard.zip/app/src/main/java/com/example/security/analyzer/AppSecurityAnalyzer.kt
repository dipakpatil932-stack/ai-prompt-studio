package com.example.security.analyzer

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.security.model.AppAuditRiskLevel
import com.example.security.model.AppSecurityAuditItem
import com.example.security.scanner.SignatureDatabase

class AppSecurityAnalyzer(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    fun auditApp(pkgInfo: PackageInfo): AppSecurityAuditItem {
        val appInfo = pkgInfo.applicationInfo
        val appName = try {
            appInfo?.loadLabel(packageManager)?.toString() ?: pkgInfo.packageName
        } catch (_: Exception) {
            pkgInfo.packageName
        }

        val isSystem = if (appInfo != null) {
            (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        } else false

        val isDebuggable = if (appInfo != null) {
            (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        } else false

        val requestedPermissions = pkgInfo.requestedPermissions?.toList() ?: emptyList()
        val sensitivePerms = filterSensitivePermissions(requestedPermissions)

        val installerPackage = getInstallerPackage(pkgInfo.packageName)
        val installerDisplayName = formatInstallerName(installerPackage, isSystem)

        val riskIndicators = mutableListOf<String>()
        val isRecognizedLegit = SignatureDatabase.isRecognizedLegitimateApp(pkgInfo.packageName)

        // Evaluate indicators without automatically calling an app malware
        if (!isSystem && !isRecognizedLegit) {
            val hasSms = requestedPermissions.any { it.contains("SMS", ignoreCase = true) }
            val hasOverlay = requestedPermissions.contains("android.permission.SYSTEM_ALERT_WINDOW")
            val hasAccessibility = requestedPermissions.contains("android.permission.BIND_ACCESSIBILITY_SERVICE")
            val hasAudio = requestedPermissions.contains("android.permission.RECORD_AUDIO")
            val hasCamera = requestedPermissions.contains("android.permission.CAMERA")
            val hasContacts = requestedPermissions.contains("android.permission.READ_CONTACTS")
            val hasLocation = requestedPermissions.contains("android.permission.ACCESS_FINE_LOCATION")
            val hasBoot = requestedPermissions.contains("android.permission.RECEIVE_BOOT_COMPLETED")

            if (hasSms && hasOverlay) {
                riskIndicators.add("Combines SMS access with System Alert Window (overlay capability)")
            }
            if (hasAccessibility) {
                riskIndicators.add("Requests Accessibility Service binding (deep screen inspection)")
            }
            if (hasAudio && hasBoot && !isRecognizedLegit) {
                riskIndicators.add("Requests Microphone access alongside start-on-boot privilege")
            }
            if (hasCamera && hasOverlay) {
                riskIndicators.add("Requests Camera access and floating overlay permission")
            }
            if (isDebuggable) {
                riskIndicators.add("Application is flagged as debuggable in its manifest")
            }
            if (installerPackage != "com.android.vending" && installerPackage != "com.google.android.feedback") {
                riskIndicators.add("Installed from outside Google Play Store ($installerDisplayName)")
            }
        }

        val riskLevel = when {
            isSystem -> AppAuditRiskLevel.LOW
            isRecognizedLegit -> AppAuditRiskLevel.LOW
            riskIndicators.any { it.contains("Accessibility", ignoreCase = true) || it.contains("overlay", ignoreCase = true) } -> AppAuditRiskLevel.HIGH
            riskIndicators.isNotEmpty() || sensitivePerms.size >= 4 -> AppAuditRiskLevel.REVIEW
            else -> AppAuditRiskLevel.LOW
        }

        val recommendation = when (riskLevel) {
            AppAuditRiskLevel.HIGH -> "Review permissions in system settings. If you do not recognize or rely on this app, consider uninstalling it."
            AppAuditRiskLevel.REVIEW -> "Verify that the app's declared permissions match its functional features."
            AppAuditRiskLevel.LOW -> if (isSystem) "Core system package protected by Android system partition." else "Standard permission profile with legitimate usage parameters."
        }

        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.versionCode.toLong()
        }

        return AppSecurityAuditItem(
            appName = appName,
            packageName = pkgInfo.packageName,
            versionName = pkgInfo.versionName ?: "1.0",
            versionCode = versionCode,
            isSystemApp = isSystem,
            requestedPermissions = requestedPermissions,
            sensitivePermissions = sensitivePerms,
            installerPackageName = installerPackage,
            installerDisplayName = installerDisplayName,
            riskLevel = riskLevel,
            riskIndicators = riskIndicators,
            recommendation = recommendation
        )
    }

    private fun filterSensitivePermissions(permissions: List<String>): List<String> {
        val sensitivePrefixes = setOf(
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.READ_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.SEND_SMS",
            "android.permission.READ_PHONE_STATE",
            "android.permission.SYSTEM_ALERT_WINDOW",
            "android.permission.REQUEST_INSTALL_PACKAGES",
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
            "android.permission.POST_NOTIFICATIONS"
        )
        return permissions.filter { it in sensitivePrefixes }
    }

    private fun getInstallerPackage(packageName: String): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                packageManager.getInstallSourceInfo(packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                packageManager.getInstallerPackageName(packageName)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun formatInstallerName(installer: String?, isSystem: Boolean): String {
        return when {
            isSystem -> "System Partition (Pre-installed)"
            installer == null -> "Unknown / Direct Sideload"
            installer == "com.android.vending" -> "Google Play Store"
            installer == "com.google.android.feedback" -> "Google Play Services"
            installer == "com.amazon.venezia" -> "Amazon Appstore"
            installer == "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
            installer == "com.android.packageinstaller" -> "Package Installer (Manual APK)"
            installer == "com.google.android.packageinstaller" -> "Android Package Installer"
            else -> installer
        }
    }
}
