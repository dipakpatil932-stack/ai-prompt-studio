package com.example.security.analyzer

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import com.example.security.model.AppSecurityInfo
import com.example.security.model.RiskLevel
import com.example.security.model.SecurityRecommendation

class RecommendationEngine(private val context: Context) {

    fun generateRecommendations(
        apps: List<AppSecurityInfo>,
        hasScanned: Boolean
    ): List<SecurityRecommendation> {
        val list = mutableListOf<SecurityRecommendation>()

        if (!hasScanned) {
            list.add(
                SecurityRecommendation(
                    id = "rec_run_scan",
                    title = "Run Initial Device Security Scan",
                    description = "Perform a Quick Scan or Deep Scan to verify all installed packages, signatures, and dangerous permissions.",
                    priority = RiskLevel.REVIEW_RECOMMENDED,
                    actionLabel = "Start Scan"
                )
            )
        }

        // Screen Lock check
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isDeviceSecure = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            keyguardManager?.isDeviceSecure == true
        } else {
            @Suppress("DEPRECATION")
            keyguardManager?.isKeyguardSecure == true
        }

        if (!isDeviceSecure) {
            list.add(
                SecurityRecommendation(
                    id = "rec_screen_lock",
                    title = "Enable Screen Lock Protection",
                    description = "Set a secure PIN, pattern, password, or biometric lock to safeguard device storage against unauthorized physical access.",
                    priority = RiskLevel.POTENTIALLY_HARMFUL,
                    actionLabel = "Security Settings",
                    intentAction = Settings.ACTION_SECURITY_SETTINGS
                )
            )
        }

        // Developer Options / USB Debugging
        val devOptions = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }
        val adbEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        if (devOptions && adbEnabled) {
            list.add(
                SecurityRecommendation(
                    id = "rec_disable_adb",
                    title = "Turn Off USB Debugging (ADB)",
                    description = "USB debugging allows attached computers to execute commands and access app data. Turn it off when not developing.",
                    priority = RiskLevel.REVIEW_RECOMMENDED,
                    actionLabel = "Developer Options",
                    intentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                )
            )
        }

        // High Risk Apps
        val harmfulApps = apps.filter { it.riskLevel == RiskLevel.POTENTIALLY_HARMFUL }
        if (harmfulApps.isNotEmpty()) {
            list.add(
                SecurityRecommendation(
                    id = "rec_harmful_apps",
                    title = "Inspect ${harmfulApps.size} High Risk Application(s)",
                    description = "Apps with elevated privilege combinations or suspicious packaging detected on device.",
                    priority = RiskLevel.POTENTIALLY_HARMFUL,
                    actionLabel = "Review Apps"
                )
            )
        }

        // Sideloaded Apps
        val sideloadedWithPerms = apps.filter {
            !it.isSystemApp && it.installerPackageName == null && it.sensitivePermissions.isNotEmpty()
        }
        if (sideloadedWithPerms.isNotEmpty()) {
            list.add(
                SecurityRecommendation(
                    id = "rec_sideloaded",
                    title = "Review ${sideloadedWithPerms.size} Sideloaded App(s)",
                    description = "Applications installed from outside official stores hold sensitive device permissions.",
                    priority = RiskLevel.REVIEW_RECOMMENDED,
                    actionLabel = "Check Origins"
                )
            )
        }

        if (list.isEmpty()) {
            list.add(
                SecurityRecommendation(
                    id = "rec_all_good",
                    title = "Optimal Security Posture",
                    description = "Device settings, screen protection, and application permissions meet recommended safety baselines.",
                    priority = RiskLevel.NORMAL,
                    actionLabel = "Everything Safe"
                )
            )
        }

        return list
    }
}
