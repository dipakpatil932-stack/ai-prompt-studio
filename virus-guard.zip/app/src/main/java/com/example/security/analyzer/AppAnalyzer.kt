package com.example.security.analyzer

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.security.model.AppSecurityInfo
import com.example.security.model.RiskLevel
import com.example.security.model.TargetType
import com.example.security.model.ThreatRecord
import com.example.security.scanner.SignatureDatabase

class AppAnalyzer(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    private val SENSITIVE_PERMISSIONS = setOf(
        "android.permission.RECORD_AUDIO",
        "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.READ_CONTACTS",
        "android.permission.WRITE_CONTACTS",
        "android.permission.READ_SMS",
        "android.permission.SEND_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.READ_CALL_LOG",
        "android.permission.WRITE_CALL_LOG",
        "android.permission.READ_PHONE_STATE",
        "android.permission.PROCESS_OUTGOING_CALLS",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.BIND_ACCESSIBILITY_SERVICE",
        "android.permission.PACKAGE_USAGE_STATS",
        "android.permission.MANAGE_EXTERNAL_STORAGE",
        "android.permission.REQUEST_INSTALL_PACKAGES"
    )

    fun analyzePackage(pkg: PackageInfo): AppSecurityInfo {
        val appInfo = pkg.applicationInfo
        val packageName = pkg.packageName ?: "unknown"
        val appName = appInfo?.let {
            try {
                packageManager.getApplicationLabel(it).toString()
            } catch (_: Exception) {
                packageName
            }
        } ?: packageName

        val versionName = pkg.versionName ?: "1.0"
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkg.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkg.versionCode.toLong()
        }

        val isSystemApp = appInfo?.let { (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 } ?: false
        val isDebuggable = appInfo?.let { (it.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0 } ?: false
        val targetSdkVersion = appInfo?.targetSdkVersion ?: 0

        val installerPackageName = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                packageManager.getInstallSourceInfo(packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                packageManager.getInstallerPackageName(packageName)
            }
        } catch (_: Exception) {
            null
        }

        val requestedPermissions = pkg.requestedPermissions?.toList() ?: emptyList()
        val sensitivePermissions = requestedPermissions.filter { SENSITIVE_PERMISSIONS.contains(it) }

        val reasons = mutableListOf<String>()
        val threatRecords = mutableListOf<ThreatRecord>()

        // Check if package is a known trusted system app or recognized popular application
        val isRecognized = SignatureDatabase.isRecognizedLegitimateApp(packageName)

        // Rule: Sideloaded app check
        val isSideloaded = !isSystemApp && installerPackageName == null

        // Rule: Check high risk permission combinations
        val permissionSet = requestedPermissions.toSet()
        for ((comb, explanation) in SignatureDatabase.HIGH_RISK_PERMISSION_COMBINATIONS) {
            if (permissionSet.containsAll(comb) && !isRecognized) {
                reasons.add(explanation)
                threatRecords.add(
                    ThreatRecord(
                        id = "threat_${packageName}_perm_comb",
                        title = "Elevated Privilege Combination: $appName",
                        description = explanation,
                        reason = "Requests multiple sensitive permissions that together provide deep system access.",
                        severity = if (isSideloaded) RiskLevel.POTENTIALLY_HARMFUL else RiskLevel.REVIEW_RECOMMENDED,
                        targetName = appName,
                        targetIdentifier = packageName,
                        targetType = TargetType.APP,
                        recommendation = "Verify you explicitly trust this publisher before keeping privileged access.",
                        isSystemProtected = isSystemApp
                    )
                )
            }
        }

        // Rule: Debuggable app on production device
        if (isDebuggable && !isSystemApp) {
            reasons.add("App compiled with active developer debug flags (FLAG_DEBUGGABLE).")
            threatRecords.add(
                ThreatRecord(
                    id = "threat_${packageName}_debuggable",
                    title = "Debug Flag Enabled: $appName",
                    description = "Application is compiled in debug mode, which allows external memory inspection and logging.",
                    reason = "Debug flag should not be active in released applications.",
                    severity = RiskLevel.REVIEW_RECOMMENDED,
                    targetName = appName,
                    targetIdentifier = packageName,
                    targetType = TargetType.APP,
                    recommendation = "Ensure this build was installed intentionally for testing purposes.",
                    isSystemProtected = false
                )
            )
        }

        // Rule: Sideloaded app requesting high sensitive privileges
        if (isSideloaded && sensitivePermissions.size >= 4 && !isRecognized) {
            reasons.add("Sideloaded package requesting ${sensitivePermissions.size} sensitive permissions.")
            threatRecords.add(
                ThreatRecord(
                    id = "threat_${packageName}_sideloaded_perms",
                    title = "Sideloaded Privileged App: $appName",
                    description = "Application was installed outside official app stores and holds multiple private permissions.",
                    reason = "Unverified installation source with extensive device privileges.",
                    severity = RiskLevel.REVIEW_RECOMMENDED,
                    targetName = appName,
                    targetIdentifier = packageName,
                    targetType = TargetType.APP,
                    recommendation = "Review app origin and revoke unused permissions in Android App Settings.",
                    isSystemProtected = false
                )
            )
        }

        val riskLevel = when {
            threatRecords.any { it.severity == RiskLevel.POTENTIALLY_HARMFUL } -> RiskLevel.POTENTIALLY_HARMFUL
            threatRecords.any { it.severity == RiskLevel.REVIEW_RECOMMENDED } -> RiskLevel.REVIEW_RECOMMENDED
            else -> RiskLevel.NORMAL
        }

        return AppSecurityInfo(
            packageName = packageName,
            appName = appName,
            versionName = versionName,
            versionCode = versionCode,
            isSystemApp = isSystemApp,
            isDebuggable = isDebuggable,
            installerPackageName = installerPackageName,
            targetSdkVersion = targetSdkVersion,
            requestedPermissions = requestedPermissions,
            sensitivePermissions = sensitivePermissions,
            riskLevel = riskLevel,
            threatRecords = threatRecords,
            reasons = reasons,
            riskReasons = reasons
        )
    }
}
