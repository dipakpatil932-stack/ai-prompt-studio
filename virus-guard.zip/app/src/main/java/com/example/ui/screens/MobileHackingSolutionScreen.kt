package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.analyzer.MobileHackingEngine
import com.example.security.model.AccountSecurityCheckItem
import com.example.security.model.CompromiseIndicator
import com.example.security.model.CompromiseStatus
import com.example.security.model.EmergencyActionItem
import com.example.security.model.HackingPrivacyGroup
import com.example.security.model.MobileHackingAuditResult
import com.example.security.model.RecoveryStep
import com.example.security.model.SuspiciousAppDetail
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.HackingSolutionTab
import com.example.ui.viewmodel.SecurityViewModel

@Composable
fun MobileHackingSolutionScreen(
    viewModel: SecurityViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val auditResult by viewModel.hackingAuditResult.collectAsStateWithLifecycle()
    val isAuditing by viewModel.isHackingAuditing.collectAsStateWithLifecycle()
    val currentTab by viewModel.activeHackingTab.collectAsStateWithLifecycle()

    BackHandler {
        if (currentTab != HackingSolutionTab.DASHBOARD) {
            viewModel.selectHackingTab(HackingSolutionTab.DASHBOARD)
        } else {
            onBack()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("mobile_hacking_solution_screen")
    ) {
        // Top Navigation Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (currentTab != HackingSolutionTab.DASHBOARD) {
                                viewModel.selectHackingTab(HackingSolutionTab.DASHBOARD)
                            } else {
                                onBack()
                            }
                        },
                        modifier = Modifier.testTag("hacking_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🚨 Mobile Hacking Solution",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "मोबाइल हैकिंग और सुरक्षा समाधान",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isAuditing) {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .size(24.dp)
                                .padding(end = 8.dp),
                            strokeWidth = 2.dp,
                            color = BluePrimary
                        )
                    } else {
                        IconButton(
                            onClick = { viewModel.runHackingAudit() },
                            modifier = Modifier.testTag("hacking_refresh_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Audit",
                                tint = BluePrimary
                            )
                        }
                    }
                }

                // Sub Navigation Tabs
                ScrollableTabSelector(
                    selectedTab = currentTab,
                    onTabSelected = { viewModel.selectHackingTab(it) }
                )
            }
        }

        // Body Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            val result = auditResult
            if (result == null && isAuditing) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = BluePrimary)
                        Text(
                            text = "Performing legitimate defensive security checks...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "वैध सुरक्षा जांच की जा रही है...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else if (result != null) {
                when (currentTab) {
                    HackingSolutionTab.DASHBOARD -> {
                        HackingDashboardContent(
                            result = result,
                            isAuditing = isAuditing,
                            onCheckMyPhone = { viewModel.runHackingAudit() },
                            onNavigateToTab = { viewModel.selectHackingTab(it) },
                            onShareReport = { viewModel.shareHackingReport(context) }
                        )
                    }
                    HackingSolutionTab.CHECK_PHONE -> {
                        CompromiseIndicatorsView(
                            result = result,
                            onCheckMyPhone = { viewModel.runHackingAudit() }
                        )
                    }
                    HackingSolutionTab.SUSPICIOUS_APPS -> {
                        SuspiciousAppsView(
                            apps = result.suspiciousApps.map { it.detail },
                            recentlyInstalled = result.recentlyInstalledApps.map { it.detail }
                        )
                    }
                    HackingSolutionTab.ACCOUNT_SECURITY -> {
                        AccountSecurityView()
                    }
                    HackingSolutionTab.PRIVACY_CHECK -> {
                        PrivacyCheckView(groups = result.privacyAuditGroups)
                    }
                    HackingSolutionTab.RECOVERY_ASSISTANT -> {
                        RecoveryAssistantView()
                    }
                    HackingSolutionTab.SECURITY_REPORT -> {
                        SecurityReportView(
                            result = result,
                            onShare = { viewModel.shareHackingReport(context) }
                        )
                    }
                    HackingSolutionTab.EMERGENCY_CHECKLIST -> {
                        EmergencyChecklistView()
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrollableTabSelector(
    selectedTab: HackingSolutionTab,
    onTabSelected: (HackingSolutionTab) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        val tabs = listOf(
            HackingSolutionTab.DASHBOARD to "🚨 Overview / अवलोकन",
            HackingSolutionTab.CHECK_PHONE to "🔍 Check Phone / जांच",
            HackingSolutionTab.SUSPICIOUS_APPS to "📱 Suspicious Apps / ऐप्स",
            HackingSolutionTab.ACCOUNT_SECURITY to "🔐 Accounts / खाते",
            HackingSolutionTab.PRIVACY_CHECK to "🕵️ Privacy / प्राइवेसी",
            HackingSolutionTab.RECOVERY_ASSISTANT to "🛠️ Recovery / रिकवरी",
            HackingSolutionTab.SECURITY_REPORT to "📄 Report / रिपोर्ट",
            HackingSolutionTab.EMERGENCY_CHECKLIST to "⚡ Emergency / आपातकालीन"
        )

        items(tabs) { (tab, label) ->
            val isSelected = selectedTab == tab
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (isSelected) BluePrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onTabSelected(tab) }
                    .testTag("tab_${tab.name.lowercase()}")
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 12.sp
                    ),
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
    }
}

// ==========================================
// 1. DASHBOARD OVERVIEW
// ==========================================
@Composable
private fun HackingDashboardContent(
    result: MobileHackingAuditResult,
    isAuditing: Boolean,
    onCheckMyPhone: () -> Unit,
    onNavigateToTab: (HackingSolutionTab) -> Unit,
    onShareReport: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Main Compromise Posture Banner
        item {
            PostureStatusCard(result = result)
        }

        // Section 1: Large Button: 🚨 "Check My Phone"
        item {
            Button(
                onClick = onCheckMyPhone,
                enabled = !isAuditing,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (result.overallStatus) {
                        CompromiseStatus.ACTION_RECOMMENDED -> ThreatRed
                        CompromiseStatus.REVIEW_RECOMMENDED -> WarningAmber
                        CompromiseStatus.NO_OBVIOUS_ISSUE -> BluePrimary
                    },
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("btn_check_my_phone")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = if (isAuditing) "AUDITING SYSTEM..." else "🚨 CHECK MY PHONE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        )
                        Text(
                            text = "मेरा फ़ोन चेक करें (पूर्ण सुरक्षा परीक्षण)",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        // Important Accuracy & Defense Rule Notice
        item {
            AccuracyNoticeCard()
        }

        // Emergency Quick Action Grid (Large Buttons)
        item {
            Text(
                text = "Defense Modules / सुरक्षा मॉड्यूल",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LargeActionTile(
                        icon = Icons.Default.Lock,
                        iconTint = BluePrimary,
                        title = "SECURE MY ACCOUNTS",
                        hindiTitle = "अपने खाते सुरक्षित करें",
                        subtitle = "7-point account safety",
                        modifier = Modifier.weight(1f),
                        testTag = "tile_secure_accounts",
                        onClick = { onNavigateToTab(HackingSolutionTab.ACCOUNT_SECURITY) }
                    )
                    LargeActionTile(
                        icon = Icons.Default.Smartphone,
                        iconTint = WarningAmber,
                        title = "SUSPICIOUS APPS",
                        hindiTitle = "संदिग्ध ऐप्स",
                        subtitle = "${result.suspiciousApps.size} apps to review",
                        modifier = Modifier.weight(1f),
                        testTag = "tile_suspicious_apps",
                        onClick = { onNavigateToTab(HackingSolutionTab.SUSPICIOUS_APPS) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LargeActionTile(
                        icon = Icons.Default.Shield,
                        iconTint = SafeGreen,
                        title = "PRIVACY CHECK",
                        hindiTitle = "प्राइवेसी चेक",
                        subtitle = "Camera, Mic, SMS, Location",
                        modifier = Modifier.weight(1f),
                        testTag = "tile_privacy_check",
                        onClick = { onNavigateToTab(HackingSolutionTab.PRIVACY_CHECK) }
                    )
                    LargeActionTile(
                        icon = Icons.Default.Build,
                        iconTint = BlueDark,
                        title = "RECOVERY ASSISTANT",
                        hindiTitle = "रिकवरी सहायक",
                        subtitle = "6-step recovery guide",
                        modifier = Modifier.weight(1f),
                        testTag = "tile_recovery_assistant",
                        onClick = { onNavigateToTab(HackingSolutionTab.RECOVERY_ASSISTANT) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LargeActionTile(
                        icon = Icons.Default.Share,
                        iconTint = BluePrimary,
                        title = "SECURITY REPORT",
                        hindiTitle = "सुरक्षा रिपोर्ट",
                        subtitle = "Share on-device audit",
                        modifier = Modifier.weight(1f),
                        testTag = "tile_security_report",
                        onClick = { onNavigateToTab(HackingSolutionTab.SECURITY_REPORT) }
                    )
                    LargeActionTile(
                        icon = Icons.Default.Warning,
                        iconTint = ThreatRed,
                        title = "EMERGENCY LIST",
                        hindiTitle = "आपातकालीन चेकलिस्ट",
                        subtitle = "Immediate triage action",
                        modifier = Modifier.weight(1f),
                        testTag = "tile_emergency_checklist",
                        onClick = { onNavigateToTab(HackingSolutionTab.EMERGENCY_CHECKLIST) }
                    )
                }
            }
        }

        // Section 2: Security Findings & Indicators preview
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = if (result.overallStatus == CompromiseStatus.ACTION_RECOMMENDED) "Possible Security Issues" else "Security Findings & Status",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (result.overallStatus == CompromiseStatus.ACTION_RECOMMENDED) "कार्रवाई योग्य सुरक्षा निष्कर्ष" else "सुरक्षा समीक्षा निष्कर्ष एवं स्थितियां",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(
                    onClick = { onNavigateToTab(HackingSolutionTab.CHECK_PHONE) },
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("View All", fontSize = 12.sp)
                }
            }
        }

        // Show top 3 compromise indicators
        val previewIndicators = result.indicators.take(4)
        items(previewIndicators) { indicator ->
            IndicatorCard(indicator = indicator)
        }

        // Section 7: Network Safety Quick Posture
        item {
            NetworkSafetyCard(result = result)
        }

        // Section 11: Android Limitations Box
        item {
            AndroidLimitationsCard(disclosures = result.androidLimitationsDisclosures)
        }
    }
}

@Composable
private fun PostureStatusCard(result: MobileHackingAuditResult) {
    val (bgColor, accentColor, iconVector, badgeText, hindiBadgeText) = when (result.overallStatus) {
        CompromiseStatus.ACTION_RECOMMENDED -> {
            CardColorsConfig(
                bg = ThreatRed.copy(alpha = 0.12f),
                accent = ThreatRed,
                icon = Icons.Default.Warning,
                badge = "🔴 Action recommended",
                hindiBadge = "लाल: तत्काल कार्रवाई की सिफारिश"
            )
        }
        CompromiseStatus.REVIEW_RECOMMENDED -> {
            CardColorsConfig(
                bg = WarningAmber.copy(alpha = 0.12f),
                accent = WarningAmber,
                icon = Icons.Default.Info,
                badge = "🟠 Review recommended",
                hindiBadge = "नारंगी: समीक्षा की सिफारिश की जाती है"
            )
        }
        CompromiseStatus.NO_OBVIOUS_ISSUE -> {
            CardColorsConfig(
                bg = SafeGreen.copy(alpha = 0.12f),
                accent = SafeGreen,
                icon = Icons.Default.CheckCircle,
                badge = "🟢 No obvious issue",
                hindiBadge = "हरा: कोई स्पष्ट समस्या नहीं"
            )
        }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .testTag("posture_status_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(bgColor)
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = accentColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                Text(
                    text = result.formattedDate,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.Top) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = result.headline,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = result.hindiHeadline,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        ),
                        color = accentColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = result.summaryExplanation,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = result.hindiSummaryExplanation,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
            )
        }
    }
}

private data class CardColorsConfig(
    val bg: Color,
    val accent: Color,
    val icon: ImageVector,
    val badge: String,
    val hindiBadge: String
)

@Composable
private fun LargeActionTile(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    hindiTitle: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )

            Text(
                text = hindiTitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = iconTint,
                maxLines = 1
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun AccuracyNoticeCard() {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = BluePrimary,
                modifier = Modifier
                    .size(18.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Strict Accuracy Guarantee (सटीकता गारंटी):",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Virus Guard performs only legitimate Android security checks. We never claim 'Your phone is definitely hacked' without conclusive evidence, and we never fabricate threats.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "हम बिना पुख्ता सबूत के कभी यह दावा नहीं करते कि फोन हैक हो चुका है। सभी परीक्षण निष्पक्ष और पारदर्शी हैं।",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                )
            }
        }
    }
}

// ==========================================
// 2. COMPROMISE INDICATORS ("Possible Security Issues")
// ==========================================
@Composable
private fun CompromiseIndicatorsView(
    result: MobileHackingAuditResult,
    onCheckMyPhone: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = if (result.overallStatus == CompromiseStatus.ACTION_RECOMMENDED) "Possible Security Issues" else "Security Check Findings",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (result.overallStatus == CompromiseStatus.ACTION_RECOMMENDED) "संभावित सुरक्षा समस्याएं एवं जांच परिणाम" else "सुरक्षा जांच परिणाम एवं विश्लेषण",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = onCheckMyPhone,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Re-Check", fontSize = 12.sp)
                }
            }
        }

        items(result.indicators) { indicator ->
            IndicatorCard(indicator = indicator)
        }
    }
}

@Composable
private fun IndicatorCard(indicator: CompromiseIndicator) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    val (badgeText, badgeColor, statusBg) = when (indicator.status) {
        CompromiseStatus.ACTION_RECOMMENDED -> Triple("🔴 Action recommended", ThreatRed, ThreatRed.copy(alpha = 0.08f))
        CompromiseStatus.REVIEW_RECOMMENDED -> Triple("🟠 Review recommended", WarningAmber, WarningAmber.copy(alpha = 0.08f))
        CompromiseStatus.NO_OBVIOUS_ISSUE -> Triple("🟢 No obvious issue", SafeGreen, SafeGreen.copy(alpha = 0.08f))
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { isExpanded = !isExpanded }
            .testTag("indicator_${indicator.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(statusBg)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = badgeColor
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = indicator.category,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = indicator.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = indicator.hindiTitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = badgeColor
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // WHAT WAS FOUND
            SectionFindingBlock(
                headerEn = "WHAT WAS FOUND",
                headerHi = "क्या पाया गया",
                bodyEn = indicator.whatWasFound,
                bodyHi = indicator.hindiWhatWasFound,
                accent = badgeColor
            )

            // Expanded view shows WHY IT MATTERS & WHAT USER CAN DO
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier.padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // WHY IT MATTERS
                    SectionFindingBlock(
                        headerEn = "WHY IT MATTERS",
                        headerHi = "यह क्यों मायने रखता है",
                        bodyEn = indicator.whyItMatters,
                        bodyHi = indicator.hindiWhyItMatters,
                        accent = BluePrimary
                    )

                    // WHAT USER CAN DO
                    SectionFindingBlock(
                        headerEn = "WHAT USER CAN DO",
                        headerHi = "उपयोगकर्ता क्या कर सकता है",
                        bodyEn = indicator.whatUserCanDo,
                        bodyHi = indicator.hindiWhatUserCanDo,
                        accent = SafeGreen
                    )

                    if (indicator.intentAction != null) {
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(indicator.intentAction)
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    try {
                                        val fallback = Intent(Settings.ACTION_SETTINGS)
                                        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        context.startActivity(fallback)
                                    } catch (_: Exception) {}
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = badgeColor),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        ) {
                            Text("Open Android Settings / सेटिंग्स खोलें", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isExpanded) "Show Less ▲" else "Tap for Details ▼",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }
    }
}

@Composable
private fun SectionFindingBlock(
    headerEn: String,
    headerHi: String,
    bodyEn: String,
    bodyHi: String,
    accent: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "$headerEn / $headerHi",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = accent
                    )
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = bodyEn,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = bodyHi,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ==========================================
// 3. SUSPICIOUS APP DETECTION & ACTIONS
// ==========================================
@Composable
private fun SuspiciousAppsView(
    apps: List<SuspiciousAppDetail>,
    recentlyInstalled: List<SuspiciousAppDetail>
) {
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filteredList = remember(apps, recentlyInstalled, selectedFilter) {
        when (selectedFilter) {
            "RECENT" -> recentlyInstalled
            "SIDELOAD" -> apps.filter { it.isSideloaded }
            "HIGH_RISK" -> apps.filter { it.hasAccessibilityAccess || it.hasDeviceAdminAccess || it.hasOverlayAccess }
            else -> apps
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Suspicious Application Review",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "समीक्षा योग्य एवं संदिग्ध ऐप्स (सुरक्षित अनइंस्टॉल नियंत्रण)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Safety Guarantee Banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SafeGreen.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = SafeGreen,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Safe Defensive Actions Only (सुरक्षा नीति):",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = SafeGreen
                        )
                        Text(
                            text = "Virus Guard NEVER silently uninstalls applications or disables Android protections. You always review and confirm actions in Android system dialogs.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Filter chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf(
                    "ALL" to "All Flagged (${apps.size})",
                    "RECENT" to "Recent (${recentlyInstalled.size})",
                    "SIDELOAD" to "Sideloaded",
                    "HIGH_RISK" to "Elevated"
                )

                for ((key, label) in filters) {
                    val isSelected = selectedFilter == key
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) BluePrimary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { selectedFilter = key }
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        if (filteredList.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SafeGreen,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No Suspicious Applications Found",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "कोई संदिग्ध या खतरनाक ऐप नहीं मिला। आपके ऐप्स मानक अनुमति सीमाओं के भीतर काम कर रहे हैं।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredList) { app ->
                SuspiciousAppCard(app = app)
            }
        }
    }
}

@Composable
private fun SuspiciousAppCard(app: SuspiciousAppDetail) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    val accentColor = when (app.riskLevel) {
        CompromiseStatus.ACTION_RECOMMENDED -> ThreatRed
        CompromiseStatus.REVIEW_RECOMMENDED -> WarningAmber
        CompromiseStatus.NO_OBVIOUS_ISSUE -> SafeGreen
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("suspicious_app_${app.packageName}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accentColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (app.riskLevel == CompromiseStatus.ACTION_RECOMMENDED) "HIGH" else "REVIEW",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata Chips: Installer & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "Source: ${app.installerName}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (app.isRecentlyInstalled) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = WarningAmber.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "Installed: ${app.formattedInstallDate}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = WarningAmber,
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Flagged factors
            if (app.riskFactors.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (factor in app.riskFactors) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = factor,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Expandable details (What was found, Why it matters, What user can do)
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier.padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SectionFindingBlock(
                        headerEn = "WHAT WAS FOUND",
                        headerHi = "क्या पाया गया",
                        bodyEn = app.whatWasFound,
                        bodyHi = app.hindiWhatWasFound,
                        accent = accentColor
                    )
                    SectionFindingBlock(
                        headerEn = "WHY IT MATTERS",
                        headerHi = "यह क्यों मायने रखता है",
                        bodyEn = app.whyItMatters,
                        bodyHi = app.hindiWhyItMatters,
                        accent = BluePrimary
                    )
                    SectionFindingBlock(
                        headerEn = "WHAT USER CAN DO",
                        headerHi = "उपयोगकर्ता क्या कर सकता है",
                        bodyEn = app.whatUserCanDo,
                        bodyHi = app.hindiWhatUserCanDo,
                        accent = SafeGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4 Safe Actions as required by user prompt:
            // 1. Open App Info
            // 2. Review Permissions
            // 3. Open Android Settings
            // 4. Uninstall (never silent)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:${app.packageName}")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("App Info", fontSize = 11.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:${app.packageName}")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Text("Permissions", fontSize = 11.sp, maxLines = 1)
                }

                if (!app.isSystemApp) {
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_DELETE).apply {
                                    data = Uri.parse("package:${app.packageName}")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ThreatRed),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Uninstall", fontSize = 11.sp, maxLines = 1)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (isExpanded) "Hide Details ▲" else "Show Details ▼",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
    }
}

// ==========================================
// 4. ACCOUNT SECURITY (7 Educational Items)
// ==========================================
@Composable
private fun AccountSecurityView() {
    val items = remember { MobileHackingEngine.getAccountSecurityChecklist() }
    val completedMap = remember { mutableStateMapOf<String, Boolean>() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "🔐 Secure My Accounts",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "अपने ऑनलाइन खातों को सुरक्षित करने की 7-सूत्रीय गाइड",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Strict No-Credential Collection Guarantee
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BluePrimary.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Zero Credential Storage (गोपनीयता नीति):",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = BluePrimary
                        )
                        Text(
                            text = "Virus Guard NEVER collects, stores, or transmits passwords, OTPs, or authentication tokens. All steps are educational guidance for your direct implementation.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Progress status
        item {
            val completedCount = completedMap.count { it.value }
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Safety Steps Completed: $completedCount of ${items.size}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = if (completedCount == items.size) "All Done! 🛡️" else "In Progress",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (completedCount == items.size) SafeGreen else BluePrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        items(items) { item ->
            val isChecked = completedMap[item.id] ?: false
            AccountSecurityItemCard(
                item = item,
                isChecked = isChecked,
                onToggleCheck = { completedMap[item.id] = !isChecked }
            )
        }
    }
}

@Composable
private fun AccountSecurityItemCard(
    item: AccountSecurityCheckItem,
    isChecked: Boolean,
    onToggleCheck: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isChecked) SafeGreen.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onToggleCheck() }
            .testTag("account_item_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isChecked) SafeGreen else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (isChecked) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = item.hindiTitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = BluePrimary,
                        fontSize = 12.sp
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = item.hindiDescription,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "HOW TO DO IT (कैसे करें):",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.actionAdvice,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = item.hindiActionAdvice,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. PHONE RECOVERY GUIDE (6 Steps)
// ==========================================
@Composable
private fun RecoveryAssistantView() {
    val steps = remember { MobileHackingEngine.getRecoverySteps() }
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "🛠️ Recovery Assistant",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "सुरक्षित मोबाइल रिकवरी सहायक (कदम-दर-कदम मार्गदर्शन)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(steps) { step ->
            RecoveryStepCard(step = step)
        }
    }
}

@Composable
private fun RecoveryStepCard(step: RecoveryStep) {
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (step.isWarning) ThreatRed.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recovery_step_${step.stepNumber}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = if (step.isWarning) ThreatRed else BluePrimary
                ) {
                    Text(
                        text = "${step.stepNumber}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = step.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = step.hindiTitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = if (step.isWarning) ThreatRed else BluePrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = step.summary,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = step.hindiSummary,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (step.isWarning && step.warningText != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ThreatRed.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = step.warningText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = ThreatRed,
                                fontSize = 11.sp
                            )
                        )
                        if (step.hindiWarningText != null) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = step.hindiWarningText,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = ThreatRed,
                                    fontSize = 10.5.sp
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (inst in step.detailedInstructions) {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = "• ",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = if (step.isWarning) ThreatRed else BluePrimary
                        )
                        Text(
                            text = inst,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            if (step.actionLabel != null && step.intentAction != null) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(step.intentAction)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(step.actionLabel, fontSize = 12.sp)
                }
            }
        }
    }
}

// ==========================================
// 6. PRIVACY CHECK (9 Groups required by Prompt)
// ==========================================
@Composable
private fun PrivacyCheckView(groups: List<HackingPrivacyGroup>) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "🕵️ Privacy & Permission Audit",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "संवेदनशील अनुमतियों की जांच (कैमरा, माइक, एसएमएस, लोकेशन आदि)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_SETTINGS)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Settings", fontSize = 11.sp)
                }
            }
        }

        items(groups) { group ->
            PrivacyGroupCard(group = group)
        }
    }
}

@Composable
private fun PrivacyGroupCard(group: HackingPrivacyGroup) {
    var isExpanded by remember { mutableStateOf(false) }

    val iconVector = when (group.iconName) {
        "camera" -> Icons.Default.Videocam
        "mic" -> Icons.Default.Mic
        "location" -> Icons.Default.Place
        "contacts" -> Icons.Default.Phone
        "sms" -> Icons.Default.Sms
        "phone" -> Icons.Default.PhoneAndroid
        "folder" -> Icons.Default.Folder
        "notifications" -> Icons.Default.Notifications
        "accessibility" -> Icons.Default.Accessibility
        else -> Icons.Default.Shield
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { isExpanded = !isExpanded }
            .testTag("privacy_group_${group.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(BluePrimary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = group.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = group.hindiName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = BluePrimary,
                            fontSize = 11.sp
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (group.permittedAppsCount > 0) MaterialTheme.colorScheme.surfaceVariant else SafeGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${group.permittedAppsCount} Apps",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (group.permittedAppsCount > 0) MaterialTheme.colorScheme.onSurfaceVariant else SafeGreen,
                            fontSize = 11.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = group.description,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = group.hindiDescription,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                    Text(
                        text = "Applications with Access / अनुमत ऐप्स:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    if (group.permittedApps.isEmpty()) {
                        Text(
                            text = "No non-system applications hold this permission.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                            color = SafeGreen
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            for (app in group.permittedApps) {
                                Text(
                                    text = "• $app",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = if (isExpanded) "Hide Apps ▲" else "View Apps (${group.permittedAppsCount}) ▼",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
    }
}

// ==========================================
// 7. NETWORK SAFETY COMPONENT
// ==========================================
@Composable
private fun NetworkSafetyCard(result: MobileHackingAuditResult) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Wifi,
                    contentDescription = null,
                    tint = BluePrimary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Network Safety Status / नेटवर्क सुरक्षा",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Active interface and VPN tunnel audit",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Connection Type:",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = result.connectionType,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "VPN Status:",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = if (result.isVpnActive) "Active VPN Tunnel 🔒" else "Direct Network (No VPN)",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (result.isVpnActive) BluePrimary else SafeGreen,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Strict Network Rule: Virus Guard operates defensively only. We never intercept passwords, bypass HTTPS encryption, or scan other devices.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

// ==========================================
// 8. EMERGENCY SECURITY CHECKLIST (7 Actions)
// ==========================================
@Composable
private fun EmergencyChecklistView() {
    val items = remember { MobileHackingEngine.getEmergencyChecklist() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "🚨 Emergency Security Checklist",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "आपातकालीन सुरक्षा कदम (तत्काल कार्रवाई चेकलिस्ट)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = ThreatRed.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = ThreatRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Follow these 7 immediate triage actions if you suspect active tampering or unauthorized access.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = ThreatRed,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }

        items(items) { item ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Surface(
                        shape = CircleShape,
                        color = ThreatRed
                    ) {
                        Text(
                            text = "${item.stepNumber}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            ),
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = item.actionText,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = item.hindiActionText,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Medium,
                                color = ThreatRed,
                                fontSize = 11.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.explanation,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 9. SECURITY REPORT VIEW & SHARING
// ==========================================
@Composable
private fun SecurityReportView(
    result: MobileHackingAuditResult,
    onShare: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "📄 Mobile Security Audit Report",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "डिवाइस सुरक्षा रिपोर्ट (मानक एंड्रॉइड शेयरिंग उपलब्ध)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Button(
                onClick = onShare,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_share_report")
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "SHARE SECURITY REPORT (रिपोर्ट साझा करें)",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        }

        // Privacy Guarantee
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "🔒 Privacy Notice: Report contains only defensive security indicators and package names. Passwords, OTPs, private chats, or personal files are NEVER included.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        // Report Preview
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = result.plainTextReport,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}

// ==========================================
// 11. ANDROID LIMITATIONS CARD
// ==========================================
@Composable
private fun AndroidLimitationsCard(disclosures: List<String>) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = BluePrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Android Sandbox & Limitations Disclosure",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    )
                    Text(
                        text = "एंड्रॉइड सुरक्षा सीमाएं और पारदर्शिता प्रकटीकरण",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = BluePrimary.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Android does not provide this information to normal apps.",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary,
                        fontSize = 12.sp
                    ),
                    modifier = Modifier.padding(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (disc in disclosures) {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = "• ",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = BluePrimary
                        )
                        Text(
                            text = disc,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
