package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1565C0)
val BlueLight = Color(0xFF42A5F5)
val BlueDark = Color(0xFF0D47A1)
val TealSecondary = Color(0xFF00897B)
val IndigoTertiary = Color(0xFF3949AB)

val SafeGreen = Color(0xFF2E7D32)
val SafeGreenContainer = Color(0xFFE8F5E9)

val ThreatRed = Color(0xFFD32F2F)
val ThreatRedContainer = Color(0xFFFFEBEE)

val WarningAmber = Color(0xFFED6C02)
val WarningAmberContainer = Color(0xFFFFF3E0)

val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F3F4)

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceVariantDark = Color(0xFF2C2C2C)
