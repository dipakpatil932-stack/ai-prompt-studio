package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.security.model.RiskLevel
import com.example.security.model.ScanType
import com.example.security.model.ThreatRecord
import com.example.ui.components.RiskBadge
import com.example.ui.components.ScanRadarView
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.SecurityViewModel

@Composable
fun ScanScreen(
    viewModel: SecurityViewModel,
    onSelectAppPackage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scanState by viewModel.scanState.collectAsStateWithLifecycle()
    var selectedScanTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("scan_screen")
    ) {
        // Mode Selector: Quick Scan vs Deep Scan
        if (!scanState.isScanning) {
            TabRow(
                selectedTabIndex = selectedScanTab,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedScanTab == 0,
                    onClick = { selectedScanTab = 0 },
                    text = { Text(stringResource(R.string.quick_scan)) },
                    modifier = Modifier.testTag("tab_quick_scan")
                )
                Tab(
                    selected = selectedScanTab == 1,
                    onClick = { selectedScanTab = 1 },
                    text = { Text(stringResource(R.string.deep_scan)) },
                    modifier = Modifier.testTag("tab_deep_scan")
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                // Animated Radar
                ScanRadarView(
                    isScanning = scanState.isScanning
                )
            }

            // Scanning Status / Header
            item {
                if (scanState.isScanning) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = stringResource(R.string.scanning),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = scanState.currentItemName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Real Progress Bar
                        LinearProgressIndicator(
                            progress = { scanState.progress },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .height(8.dp)
                                .clip(CircleShape),
                            color = BluePrimary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (scanState.scanType == ScanType.DEEP && scanState.filesAnalyzed > 0) {
                                "${(scanState.progress * 100).toInt()}% • ${scanState.itemsProcessed}/${scanState.totalItems} apps • ${scanState.filesAnalyzed} files"
                            } else {
                                "${(scanState.progress * 100).toInt()}% • ${scanState.itemsProcessed}/${scanState.totalItems} apps"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedButton(
                            onClick = { viewModel.cancelScan() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ThreatRed),
                            modifier = Modifier.testTag("cancel_scan_button")
                        ) {
                            Icon(imageVector = Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.cancel_scan))
                        }
                    }
                } else if (scanState.wasCanceled) {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("scan_canceled_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(imageVector = Icons.Filled.Cancel, contentDescription = null, tint = ThreatRed, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Scan Canceled", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("The security scan was stopped before completion. You can restart it anytime.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    if (selectedScanTab == 0) viewModel.startQuickScan() else viewModel.startDeepScan()
                                },
                                modifier = Modifier.testTag("restart_scan_button")
                            ) {
                                Text("Restart Scan")
                            }
                        }
                    }
                } else if (scanState.lastResult != null) {
                    // Result Summary Card
                    val result = scanState.lastResult!!
                    val (statusColor, statusTextRes) = when (result.overallRisk) {
                        RiskLevel.NORMAL -> Pair(SafeGreen, R.string.status_safe)
                        RiskLevel.REVIEW_RECOMMENDED -> Pair(WarningAmber, R.string.status_warning)
                        RiskLevel.POTENTIALLY_HARMFUL -> Pair(ThreatRed, R.string.status_danger)
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("scan_result_card"),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(statusColor.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (result.overallRisk == RiskLevel.NORMAL) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                                        contentDescription = null,
                                        tint = statusColor
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = stringResource(R.string.scan_complete),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = stringResource(statusTextRes),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = statusColor
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                ScanStatItem(label = "Apps Checked", value = result.totalAppsChecked.toString())
                                ScanStatItem(label = "Permissions", value = result.totalPermissionsChecked.toString())
                                if (result.totalFilesChecked > 0) {
                                    ScanStatItem(label = "Files", value = result.totalFilesChecked.toString())
                                }
                                ScanStatItem(label = "Warnings", value = result.reviewCount.toString())
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Scan Duration: ${result.durationMillis / 1000f}s",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (selectedScanTab == 0) viewModel.startQuickScan() else viewModel.startDeepScan()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("scan_again_button")
                    ) {
                        Icon(imageVector = Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Scan Again")
                    }
                } else {
                    // Ready to Scan state
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (selectedScanTab == 0) stringResource(R.string.quick_scan) else stringResource(R.string.deep_scan),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (selectedScanTab == 0) stringResource(R.string.quick_scan_desc) else stringResource(R.string.deep_scan_desc),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                if (selectedScanTab == 0) viewModel.startQuickScan() else viewModel.startDeepScan()
                            },
                            modifier = Modifier
                                .fillMaxWidth(0.7f)
                                .height(52.dp)
                                .testTag("start_scan_button")
                        ) {
                            Icon(imageVector = Icons.Filled.Security, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Start Scan",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // If threats found, display detailed list
            if (scanState.lastResult != null && scanState.lastResult!!.threats.isNotEmpty()) {
                item {
                    Text(
                        text = "Review Items (${scanState.lastResult!!.threats.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                items(scanState.lastResult!!.threats) { threat ->
                    ThreatRecordCard(
                        threat = threat,
                        onInspect = { onSelectAppPackage(threat.targetIdentifier) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ScanStatItem(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ThreatRecordCard(
    threat: ThreatRecord,
    onInspect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onInspect),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = threat.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                RiskBadge(riskLevel = threat.severity)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Target: ${threat.targetName} (${threat.targetIdentifier})",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = threat.reason,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Recommendation: ${threat.recommendation}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
