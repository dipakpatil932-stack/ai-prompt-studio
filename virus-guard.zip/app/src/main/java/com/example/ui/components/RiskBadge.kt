package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.security.model.RiskLevel
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.SafeGreenContainer
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.ThreatRedContainer
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberContainer

@Composable
fun RiskBadge(
    riskLevel: RiskLevel,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, textRes) = when (riskLevel) {
        RiskLevel.NORMAL -> Triple(
            SafeGreenContainer.copy(alpha = 0.25f),
            SafeGreen,
            R.string.status_normal
        )
        RiskLevel.REVIEW_RECOMMENDED -> Triple(
            WarningAmberContainer.copy(alpha = 0.25f),
            WarningAmber,
            R.string.status_review_recommended
        )
        RiskLevel.POTENTIALLY_HARMFUL -> Triple(
            ThreatRedContainer.copy(alpha = 0.25f),
            ThreatRed,
            R.string.status_harmful
        )
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = stringResource(textRes),
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
