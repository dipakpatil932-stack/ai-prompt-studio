package com.example.ui.screens

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.security.model.CheckPhoneFinding
import com.example.security.model.RiskLevel
import com.example.ui.components.AttentionItemsDialog
import com.example.ui.components.CheckPhoneFlowDialog
import com.example.ui.components.MySecurityReportDialog
import com.example.ui.components.SecurityScoreDialog
import com.example.ui.components.StatusCard
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.TealSecondary
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CyberCenterSection
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.SecurityViewModel

@Composable
fun HomeScreen(
    viewModel: SecurityViewModel,
    onNavigateTab: (NavigationTab) -> Unit,
    onStartQuickScan: () -> Unit,
    onStartDeepScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()
    val isSimpleMode = preferences.isSimpleMode

    val apps by viewModel.installedApps.collectAsStateWithLifecycle()
    val latestScan by viewModel.latestHistory.collectAsStateWithLifecycle()
    val scoreBreakdown by viewModel.securityScoreBreakdown.collectAsStateWithLifecycle()
    val networkInfo by viewModel.networkSecurityInfo.collectAsStateWithLifecycle()
    val alerts by viewModel.alerts.collectAsStateWithLifecycle()
    val cyberAudit by viewModel.cyberAuditResult.collectAsStateWithLifecycle()

    // One-Tap Check My Phone flow states
    val isCheckingPhone by viewModel.isCheckingPhone.collectAsStateWithLifecycle()
    val checkPhoneStep by viewModel.checkPhoneStep.collectAsStateWithLifecycle()
    val checkPhoneProgress by viewModel.checkPhoneProgress.collectAsStateWithLifecycle()
    val checkPhoneResult by viewModel.checkPhoneResult.collectAsStateWithLifecycle()

    // Dialog presentation states
    var showScoreDialog by remember { mutableStateOf(false) }
    var showAttentionDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }

    // Real device screen lock check
    val keyguardManager = remember(context) { context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager }
    val isDeviceSecure = remember(keyguardManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            keyguardManager?.isDeviceSecure == true
        } else {
            @Suppress("DEPRECATION")
            keyguardManager?.isKeyguardSecure == true
        }
    }

    // Developer options check
    val devOptions = remember(context) {
        try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
    }

    val harmfulCount = apps.count { it.riskLevel == RiskLevel.POTENTIALLY_HARMFUL }
    val reviewCount = apps.count { it.riskLevel == RiskLevel.REVIEW_RECOMMENDED }
    val appsChecked = apps.size
    val warningsCount = harmfulCount + reviewCount
    val sensitiveAppsCount = apps.count { it.sensitivePermissions.isNotEmpty() }
    val sideloadedAppsCount = apps.count {
        !it.isSystemApp && it.installerPackageName != "com.android.vending" &&
                it.installerPackageName != "com.google.android.feedback" &&
                it.installerPackageName != "com.amazon.venezia"
    }

    val deviceStatus = when {
        harmfulCount > 0 -> RiskLevel.POTENTIALLY_HARMFUL
        reviewCount > 0 -> RiskLevel.REVIEW_RECOMMENDED
        else -> RiskLevel.NORMAL
    }

    // Modal Dialogs
    if (showScoreDialog) {
        SecurityScoreDialog(
            breakdown = scoreBreakdown,
            onDismiss = { showScoreDialog = false }
        )
    }

    if (showAttentionDialog) {
        AttentionItemsDialog(
            alerts = alerts,
            onDismiss = { showAttentionDialog = false }
        )
    }

    if (showReportDialog) {
        // Collect findings for the report
        val reportFindings = checkPhoneResult?.findings ?: alerts.map { alert ->
            CheckPhoneFinding(
                id = alert.id,
                title = alert.title,
                whyItMatters = alert.whyItMatters,
                howToFix = alert.whatToDo,
                category = alert.targetType.name,
                severity = alert.severity,
                intentAction = alert.intentAction,
                packageName = if (alert.targetIdentifier.contains(".")) alert.targetIdentifier else null
            )
        }
        MySecurityReportDialog(
            score = scoreBreakdown.score,
            latestScan = latestScan,
            apps = apps,
            findings = reportFindings,
            onDismiss = { showReportDialog = false }
        )
    }

    // Check Phone Flow Overlay
    if (isCheckingPhone || checkPhoneResult != null) {
        CheckPhoneFlowDialog(
            isChecking = isCheckingPhone,
            currentStep = checkPhoneStep,
            progress = checkPhoneProgress,
            result = checkPhoneResult,
            isSimpleMode = isSimpleMode,
            onDismiss = { viewModel.clearCheckPhoneResult() },
            onCancel = { viewModel.cancelCheckMyPhone() },
            onOpenReport = {
                viewModel.clearCheckPhoneResult()
                showReportDialog = true
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top App Bar & Mode Selector (Simple Mode vs Advanced Details)
        item {
            Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(BluePrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "🛡️ VIRUS GUARD",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = if (isSimpleMode) "Simple & Safe Protection" else "Advanced Security Suite",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Mode Switcher Pill
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { viewModel.setSimpleMode(true) }
                                .testTag("btn_mode_simple"),
                            color = if (isSimpleMode) MaterialTheme.colorScheme.primary else Color.Transparent
                        ) {
                            Text(
                                text = "👶 Simple",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isSimpleMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { viewModel.setSimpleMode(false) }
                                .testTag("btn_mode_advanced"),
                            color = if (!isSimpleMode) MaterialTheme.colorScheme.primary else Color.Transparent
                        ) {
                            Text(
                                text = "🔧 Advanced",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (!isSimpleMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 1. Security Status Card (80/100) — Tappable for breakdown
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showScoreDialog = true }
                    .testTag("home_security_status_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (scoreBreakdown.score >= 80) MaterialTheme.colorScheme.primaryContainer else WarningAmber.copy(alpha = 0.15f)
                )
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Security Status",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (scoreBreakdown.score >= 80) "Protected • Standard Android Baselines" else "Review Recommended",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            if (isSimpleMode) {
                                Text(
                                    text = "विवरण देखने के लिए टैप करें",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                            }
                        }

                        // Large Score Pill
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${scoreBreakdown.score}",
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (scoreBreakdown.score >= 80) SafeGreen else WarningAmber
                                )
                                Text(
                                    text = "/100",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Attention Alert Banner (if items need attention)
        if (alerts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAttentionDialog = true }
                        .testTag("home_attention_banner"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.12f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(WarningAmber.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Warning,
                                    contentDescription = null,
                                    tint = WarningAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "${alerts.size} items need your attention",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Tap to see details / विवरण देखें",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Details",
                            tint = WarningAmber
                        )
                    }
                }
            }
        }

        // 3. Prominent [ 🛡️ CHECK MY PHONE ] Button
        item {
            Button(
                onClick = { viewModel.runCheckMyPhone() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .testTag("btn_check_my_phone_prominent"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = "🛡️ CHECK MY PHONE",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "One-Tap Safety Checkup / सुरक्षा जांच",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        // The 5 Core Categories: Apps, Privacy, Network, Files, Device
        item {
            Text(
                text = "Security Categories",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // 1. Apps
        item {
            CategoryActionCard(
                title = "Apps",
                hindiTitle = "ऐप सुरक्षा",
                subtitle = if (harmfulCount > 0) "$harmfulCount app(s) need review" else "All $appsChecked installed apps checked",
                isClean = harmfulCount == 0,
                icon = Icons.Filled.PhoneAndroid,
                iconTint = BluePrimary,
                onClick = { onNavigateTab(NavigationTab.APPS) },
                testTag = "category_card_apps"
            )
        }

        // 2. Privacy
        item {
            CategoryActionCard(
                title = "Privacy",
                hindiTitle = "गोपनीयता नियंत्रण",
                subtitle = if (sensitiveAppsCount > 0) "$sensitiveAppsCount apps have sensitive permissions" else "Permissions optimal • No leakage",
                isClean = true,
                icon = Icons.Filled.Lock,
                iconTint = SafeGreen,
                onClick = { onNavigateTab(NavigationTab.CHECKUP) },
                testTag = "category_card_privacy"
            )
        }

        // 3. Network
        item {
            CategoryActionCard(
                title = "Network",
                hindiTitle = "नेटवर्क सुरक्षा",
                subtitle = if (networkInfo.isVpnActive) "VPN Active • Encrypted Tunnel" else "${networkInfo.connectionType} • Connection Safe",
                isClean = true,
                icon = if (networkInfo.isVpnActive) Icons.Filled.VpnKey else Icons.Filled.Wifi,
                iconTint = if (networkInfo.isVpnActive) SafeGreen else BluePrimary,
                onClick = { onNavigateTab(NavigationTab.TOOLS) },
                testTag = "category_card_network"
            )
        }

        // 4. Files
        item {
            CategoryActionCard(
                title = "Files",
                hindiTitle = "फ़ाइल जांच",
                subtitle = "Storage safe • Hash analyzer ready",
                isClean = true,
                icon = Icons.Filled.Folder,
                iconTint = TealSecondary,
                onClick = { onNavigateTab(NavigationTab.TOOLS) },
                testTag = "category_card_files"
            )
        }

        // 5. Device
        item {
            CategoryActionCard(
                title = "Device",
                hindiTitle = "डिवाइस सुरक्षा",
                subtitle = if (isDeviceSecure) "Screen Lock Active (PIN/Fingerprint)" else "Screen Lock Missing • Setup Recommended",
                isClean = isDeviceSecure,
                icon = Icons.Filled.Security,
                iconTint = if (isDeviceSecure) SafeGreen else WarningAmber,
                onClick = {
                    try {
                        context.startActivity(android.content.Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
                            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                        })
                    } catch (_: Exception) {}
                },
                testTag = "category_card_device"
            )
        }

        // 9. My Security Report Button
        item {
            OutlinedButton(
                onClick = { showReportDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_my_security_report"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Assessment,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "📊 My Security Report",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // If user toggled to Advanced Details, render the in-depth modules
        if (!isSimpleMode) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "🔧 Advanced Details & Deep Tools",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Quick & Deep Scan triggers
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onStartQuickScan,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_quick_scan_adv"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Quick Scan", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onStartDeepScan,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_deep_scan_adv"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Deep Scan", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Cyber Security Center Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.selectCyberSection(CyberCenterSection.OVERVIEW)
                            onNavigateTab(NavigationTab.CYBER_CENTER)
                        }
                        .testTag("card_cyber_security_center_adv"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Cyber Security Center",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Audit scores, Wi-Fi analyzer, and URL checker",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }
            }

            // Mobile Hacking Solution Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateTab(NavigationTab.HACKING_SOLUTION) }
                        .testTag("card_mobile_hacking_adv"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = null,
                                tint = ThreatRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Mobile Hacking Solution",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Compromise detection & incident recovery",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryActionCard(
    title: String,
    hindiTitle: String,
    subtitle: String,
    isClean: Boolean,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "($hindiTitle)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
