package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.model.RiskLevel
import com.example.ui.components.RiskBadge
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.SecurityViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ToolsScreen(
    viewModel: SecurityViewModel,
    modifier: Modifier = Modifier
) {
    var selectedToolIndex by remember { mutableIntStateOf(0) }

    val toolTabs = listOf(
        "Hacking Solution 🚨",
        "APK Analyzer",
        "File Scan",
        "Link Checker",
        "Hash Checker",
        "Privacy Center",
        "Scan History"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("tools_screen")
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedToolIndex,
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            toolTabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedToolIndex == index,
                    onClick = { selectedToolIndex = index },
                    text = { Text(title, fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("tool_tab_$index")
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedToolIndex) {
                0 -> MobileHackingSolutionScreen(
                    viewModel = viewModel,
                    onBack = { selectedToolIndex = 1 }
                )
                1 -> ApkAnalyzerView(viewModel)
                2 -> FileScanScreen(viewModel)
                3 -> LinkCheckerView(viewModel)
                4 -> HashCheckerView(viewModel)
                5 -> PrivacyCenterView(viewModel)
                6 -> HistoryScreen(viewModel)
            }
        }
    }
}

@Composable
private fun ApkAnalyzerView(viewModel: SecurityViewModel) {
    val apkInfo by viewModel.apkSecurityInfo.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzingApk.collectAsStateWithLifecycle()

    val apkPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.analyzeApk(it) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(BluePrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Android, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(30.dp))
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Standalone APK Analyzer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Safely inspect standalone APK files before installing. Audits package manifest, certificates, SDK targets, and requested permissions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { apkPicker.launch("application/vnd.android.package-archive") },
                        enabled = !isAnalyzing,
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(48.dp)
                            .testTag("pick_apk_button")
                    ) {
                        if (isAnalyzing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Analyzing APK...")
                        } else {
                            Icon(Icons.Filled.Android, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select APK File")
                        }
                    }
                }
            }
        }

        apkInfo?.let { info ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(info.apkName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(info.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            RiskBadge(riskLevel = info.riskLevel)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        DetailPill("Version", "${info.versionName} (Build ${info.versionCode})")
                        DetailPill("Target Android SDK", "API ${info.targetSdk}")
                        DetailPill("Package Size", "${info.sizeBytes / 1024} KB")
                        DetailPill("SHA-256 Hash", info.sha256Hash)

                        if (info.suspiciousIndicators.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Findings:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            info.suspiciousIndicators.forEach { ind ->
                                Text("• $ind", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedButton(onClick = { viewModel.clearApkResult() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Clear APK Analysis")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LinkCheckerView(viewModel: SecurityViewModel) {
    var urlInput by remember { mutableStateOf("") }
    val linkInfo by viewModel.linkSecurityInfo.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzingLink.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Safe Link Checker", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Detect deceptive domains, punycode spoofing, and insecure protocols.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("Enter website link or URL") },
                        placeholder = { Text("e.g. https://example.com/verify") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("link_input_field")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (urlInput.isNotBlank()) {
                                viewModel.analyzeUrl(urlInput)
                            }
                        },
                        enabled = urlInput.isNotBlank() && !isAnalyzing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("analyze_link_button")
                    ) {
                        if (isAnalyzing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Analyzing Link...")
                        } else {
                            Text("Check Link Safety")
                        }
                    }
                }
            }
        }

        linkInfo?.let { info ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(info.host, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            RiskBadge(riskLevel = info.riskLevel)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        DetailPill("Protocol", if (info.isHttps) "HTTPS (Encrypted)" else "HTTP (Insecure)", isWarning = !info.isHttps)
                        DetailPill("IP Host", if (info.hasIpHost) "Raw IP address host detected" else "Standard domain name", isWarning = info.hasIpHost)
                        DetailPill("Punycode / Homograph", if (info.hasPunycode) "Punycode (xn--) detected" else "None", isWarning = info.hasPunycode)

                        if (info.reasons.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Findings:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            info.reasons.forEach { reason ->
                                Text("• $reason", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedButton(onClick = { viewModel.clearUrlResult() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Clear Result")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HashCheckerView(viewModel: SecurityViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var hashResult by remember { mutableStateOf<String?>(null) }
    var fileName by remember { mutableStateOf<String?>(null) }
    var isComputing by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            isComputing = true
            scope.launch {
                val hash = viewModel.hashAnalyzer.computeSha256(it)
                hashResult = hash
                fileName = "Selected File"
                isComputing = false
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Cryptographic Hash Calculator", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Compute SHA-256 fingerprint of any file to verify cryptographic integrity and cross-reference with offline threat databases.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { filePicker.launch("*/*") },
                        enabled = !isComputing,
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(48.dp)
                            .testTag("compute_hash_button")
                    ) {
                        if (isComputing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Computing SHA-256...")
                        } else {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select File to Hash")
                        }
                    }
                }
            }
        }

        hashResult?.let { hash ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(fileName ?: "File", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("SHA-256 Checksum:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(hash, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)

                        Spacer(modifier = Modifier.height(14.dp))
                        OutlinedButton(onClick = { hashResult = null }, modifier = Modifier.fillMaxWidth()) {
                            Text("Clear Hash")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyCenterView(viewModel: SecurityViewModel) {
    val apps by viewModel.installedApps.collectAsStateWithLifecycle()
    val sensitiveApps = apps.filter { it.sensitivePermissions.isNotEmpty() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(SafeGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(26.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Privacy Center", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Zero external telemetry • 100% on-device analysis", style = MaterialTheme.typography.bodySmall, color = SafeGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Virus Guard operates completely on-device without sending personal data, installed app lists, or files to external cloud servers. Android's OS security sandbox restricts apps from modifying each other.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            Text(
                text = "Apps with Sensitive Permissions (${sensitiveApps.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(sensitiveApps) { app ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectApp(app) },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(app.appName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("${app.sensitivePermissions.size} sensitive permissions", style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                    }
                    RiskBadge(riskLevel = app.riskLevel)
                }
            }
        }
    }
}

@Composable
private fun DetailPill(label: String, value: String, isWarning: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = if (isWarning) ThreatRed else MaterialTheme.colorScheme.onSurface)
    }
}
