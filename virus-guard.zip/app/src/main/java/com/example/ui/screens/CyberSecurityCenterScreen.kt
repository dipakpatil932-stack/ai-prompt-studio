package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.analyzer.LinkSafetyStatus
import com.example.security.model.AlertSeverity
import com.example.security.model.AppAuditRiskLevel
import com.example.security.model.AppSecurityAuditItem
import com.example.security.model.CheckState
import com.example.security.model.CyberSecurityAlertItem
import com.example.security.model.CyberSecurityKnowledge
import com.example.security.model.DeviceSecurityCheck
import com.example.security.model.EmergencyChecklistItem
import com.example.security.model.PhishingScenario
import com.example.security.model.PrivacyPermissionGroup
import com.example.security.model.SecurityGuideTopic
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CyberCenterSection
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.SecurityViewModel

@Composable
fun CyberSecurityCenterScreen(
    viewModel: SecurityViewModel,
    modifier: Modifier = Modifier
) {
    val auditResult by viewModel.cyberAuditResult.collectAsStateWithLifecycle()
    val isAuditing by viewModel.isCyberAuditing.collectAsStateWithLifecycle()
    val selectedSection by viewModel.selectedCyberSection.collectAsStateWithLifecycle()
    val isMonitoring by viewModel.isMonitoringEnabled.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("cyber_security_center_screen")
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectedSection != null && selectedSection != CyberCenterSection.OVERVIEW) {
                    IconButton(
                        onClick = { viewModel.selectCyberSection(null) },
                        modifier = Modifier.testTag("cyber_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Cyber Security Center"
                        )
                    }
                } else {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Cyber Security",
                        tint = BluePrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Column {
                    Text(
                        text = if (selectedSection == null || selectedSection == CyberCenterSection.OVERVIEW)
                            "Cyber Security Center"
                        else getSectionTitle(selectedSection!!),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Defensive Android Integrity & Protection",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(
                onClick = { viewModel.runCyberAudit() },
                enabled = !isAuditing,
                modifier = Modifier.testTag("cyber_refresh_button")
            ) {
                if (isAuditing) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Cyber Audit",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

        // Content Area
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedSection) {
                null, CyberCenterSection.OVERVIEW -> {
                    CyberCenterOverviewView(
                        viewModel = viewModel,
                        audit = auditResult,
                        isAuditing = isAuditing,
                        isMonitoring = isMonitoring,
                        onSectionClick = { viewModel.selectCyberSection(it) }
                    )
                }
                CyberCenterSection.DEVICE_SECURITY -> {
                    DeviceSecurityDetailView(
                        checks = auditResult?.deviceChecks ?: emptyList(),
                        onRunCheck = { viewModel.runCyberAudit() }
                    )
                }
                CyberCenterSection.APP_SECURITY -> {
                    AppSecurityDetailView(
                        apps = auditResult?.appAudits ?: emptyList(),
                        onOpenSettings = { pkg -> viewModel.openAppSettings(context, pkg) },
                        onUninstall = { pkg -> viewModel.uninstallApp(context, pkg) }
                    )
                }
                CyberCenterSection.NETWORK_SAFETY -> {
                    NetworkSafetyDetailView(
                        report = auditResult?.networkReport,
                        onRefresh = { viewModel.runCyberAudit() }
                    )
                }
                CyberCenterSection.LINK_SAFETY -> {
                    LinkSafetyDetailView(viewModel = viewModel)
                }
                CyberCenterSection.PHISHING_AWARENESS -> {
                    PhishingAwarenessDetailView()
                }
                CyberCenterSection.ACCOUNT_SECURITY -> {
                    AccountSecurityDetailView()
                }
                CyberCenterSection.PRIVACY_CHECK -> {
                    PrivacyCheckDetailView(
                        groups = auditResult?.privacyGroups ?: emptyList()
                    )
                }
                CyberCenterSection.SECURITY_ALERTS -> {
                    SecurityAlertsDetailView(
                        alerts = auditResult?.alerts ?: emptyList(),
                        onAcknowledge = { viewModel.acknowledgeCyberAlert(it) }
                    )
                }
                CyberCenterSection.SECURITY_SCORE_DETAIL -> {
                    SecurityScoreBreakdownDetailView(
                        score = auditResult?.score
                    )
                }
                CyberCenterSection.SECURITY_REPORT -> {
                    SecurityReportDetailView(
                        report = auditResult?.report,
                        onShare = { viewModel.shareSecurityReport() }
                    )
                }
                CyberCenterSection.SECURITY_MONITOR -> {
                    SecurityMonitorDetailView(
                        isMonitoring = isMonitoring,
                        onToggle = { viewModel.setSecurityMonitoring(it) }
                    )
                }
                CyberCenterSection.SECURITY_GUIDE -> {
                    SecurityGuideDetailView()
                }
                CyberCenterSection.EMERGENCY_CHECKLIST -> {
                    EmergencyChecklistDetailView()
                }
            }
        }
    }
}

private fun getSectionTitle(section: CyberCenterSection): String {
    return when (section) {
        CyberCenterSection.OVERVIEW -> "Cyber Security Center"
        CyberCenterSection.DEVICE_SECURITY -> "Device Security Check"
        CyberCenterSection.APP_SECURITY -> "App Security Audit"
        CyberCenterSection.NETWORK_SAFETY -> "Network Safety"
        CyberCenterSection.LINK_SAFETY -> "Link Safety Checker"
        CyberCenterSection.PHISHING_AWARENESS -> "Phishing Awareness"
        CyberCenterSection.ACCOUNT_SECURITY -> "Account Security"
        CyberCenterSection.PRIVACY_CHECK -> "Privacy Permissions Check"
        CyberCenterSection.SECURITY_ALERTS -> "Security Alert Center"
        CyberCenterSection.SECURITY_SCORE_DETAIL -> "Cyber Security Score"
        CyberCenterSection.SECURITY_REPORT -> "Security Report"
        CyberCenterSection.SECURITY_MONITOR -> "Security Monitor"
        CyberCenterSection.SECURITY_GUIDE -> "Cyber Security Guide"
        CyberCenterSection.EMERGENCY_CHECKLIST -> "Emergency Checklist"
    }
}

@Composable
fun CyberCenterOverviewView(
    viewModel: SecurityViewModel,
    audit: com.example.security.analyzer.FullCyberAuditResult?,
    isAuditing: Boolean,
    isMonitoring: Boolean,
    onSectionClick: (CyberCenterSection) -> Unit
) {
    val score = audit?.score?.totalScore ?: 85
    val rating = audit?.score?.ratingLabel ?: "Calculated from Real Checks"
    val alertsCount = audit?.alerts?.size ?: 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Overall Cyber Security Score Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSectionClick(CyberCenterSection.SECURITY_SCORE_DETAIL) }
                    .testTag("cyber_score_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Cyber Security Score",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Calculated from real Android checks",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Score Badge
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        score >= 80 -> SafeGreen.copy(alpha = 0.2f)
                                        score >= 60 -> WarningAmber.copy(alpha = 0.2f)
                                        else -> ThreatRed.copy(alpha = 0.2f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$score",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = when {
                                    score >= 80 -> SafeGreen
                                    score >= 60 -> WarningAmber
                                    else -> ThreatRed
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Status: $rating",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "View Breakdown →",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Quick Utility Actions: Report, Monitor, Emergency
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onSectionClick(CyberCenterSection.SECURITY_REPORT) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_cyber_report"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Text(
                        text = "📊 Report",
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { onSectionClick(CyberCenterSection.SECURITY_MONITOR) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_cyber_monitor"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isMonitoring) SafeGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(
                        text = if (isMonitoring) "🛡️ Monitor ON" else "🛡️ Monitor",
                        color = if (isMonitoring) SafeGreen else MaterialTheme.colorScheme.onSecondaryContainer,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { onSectionClick(CyberCenterSection.EMERGENCY_CHECKLIST) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_cyber_emergency"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ThreatRed.copy(alpha = 0.15f))
                ) {
                    Text(
                        text = "🚨 Checklist",
                        color = ThreatRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Section Title
        item {
            Text(
                text = "Security Inspection Modules",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // The 8 Core Cards requested in User Specification Section 1
        item {
            CyberDashboardCard(
                icon = Icons.Default.Lock,
                title = "🔐 Device Security",
                subtitle = "Screen lock, encryption, update patch, dev options",
                statusLabel = audit?.deviceChecks?.count { it.state == CheckState.GOOD }?.let { "$it/7 Good" } ?: "Audited",
                onClick = { onSectionClick(CyberCenterSection.DEVICE_SECURITY) },
                testTag = "card_device_security"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.PhoneAndroid,
                title = "📱 App Security",
                subtitle = "Permissions, installation sources, risk indicators",
                statusLabel = audit?.appAudits?.size?.let { "$it Apps Checked" } ?: "Audit Apps",
                onClick = { onSectionClick(CyberCenterSection.APP_SECURITY) },
                testTag = "card_app_security"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Wifi,
                title = "🌐 Network Safety",
                subtitle = "Connection transport, VPN status, metered data",
                statusLabel = if (audit?.networkReport?.isVpnActive == true) "VPN Active" else audit?.networkReport?.connectionType ?: "Inspected",
                onClick = { onSectionClick(CyberCenterSection.NETWORK_SAFETY) },
                testTag = "card_network_safety"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Link,
                title = "🔗 Link Safety",
                subtitle = "Verify URLs, HTTPS encryption, domain spoofing",
                statusLabel = "Safe Link Checker",
                onClick = { onSectionClick(CyberCenterSection.LINK_SAFETY) },
                testTag = "card_link_safety"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Security,
                title = "🔑 Account Security",
                subtitle = "2FA, password managers, recovery methods hygiene",
                statusLabel = "Best Practices",
                onClick = { onSectionClick(CyberCenterSection.ACCOUNT_SECURITY) },
                testTag = "card_account_security"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Info,
                title = "🕵️ Privacy Check",
                subtitle = "Camera, microphone, location, SMS & contacts access",
                statusLabel = audit?.privacyGroups?.sumOf { it.associatedApps.size }?.let { "$it Grants" } ?: "Audit Permissions",
                onClick = { onSectionClick(CyberCenterSection.PRIVACY_CHECK) },
                testTag = "card_privacy_check"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Notifications,
                title = "🚨 Security Alerts",
                subtitle = "Actual security findings and recommended actions",
                statusLabel = if (alertsCount > 0) "$alertsCount Active Alerts" else "No Critical Alerts",
                statusColor = if (alertsCount > 0) ThreatRed else SafeGreen,
                onClick = { onSectionClick(CyberCenterSection.SECURITY_ALERTS) },
                testTag = "card_security_alerts"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Shield,
                title = "📚 Security Guide",
                subtitle = "Learn about malware, phishing, ransomware & scams",
                statusLabel = "11 Topics",
                onClick = { onSectionClick(CyberCenterSection.SECURITY_GUIDE) },
                testTag = "card_security_guide"
            )
        }

        item {
            CyberDashboardCard(
                icon = Icons.Default.Warning,
                title = "🎣 Phishing Awareness",
                subtitle = "Interactive scenarios to recognize email & SMS scams",
                statusLabel = "5 Scenarios",
                onClick = { onSectionClick(CyberCenterSection.PHISHING_AWARENESS) },
                testTag = "card_phishing_awareness"
            )
        }
    }
}

@Composable
fun CyberDashboardCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    statusLabel: String,
    statusColor: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = statusLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🔐 Device Security Check
// -------------------------------------------------------------
@Composable
fun DeviceSecurityDetailView(
    checks: List<DeviceSecurityCheck>,
    onRunCheck: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("device_security_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Standard Android API Checks",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Results reflect standard, unprivileged Android platform APIs. Results are never invented.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(checks) { check ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("check_item_${check.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = check.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        // State Badge
                        when (check.state) {
                            CheckState.GOOD -> {
                                Text(
                                    text = "✅ Good",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SafeGreen
                                )
                            }
                            CheckState.REVIEW -> {
                                Text(
                                    text = "⚠️ Review",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = WarningAmber
                                )
                            }
                            CheckState.NOT_AVAILABLE -> {
                                Text(
                                    text = "ℹ️ Not Available",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = check.explanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "API Evidence: ${check.evidence}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Recommendation: ${check.recommendation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (check.intentAction != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = Intent(check.intentAction).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    // Fallback
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Open System Settings")
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 📱 App Security Audit
// -------------------------------------------------------------
@Composable
fun AppSecurityDetailView(
    apps: List<AppSecurityAuditItem>,
    onOpenSettings: (String) -> Unit,
    onUninstall: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedRiskFilter by remember { mutableStateOf<AppAuditRiskLevel?>(null) }

    val filteredApps = remember(apps, searchQuery, selectedRiskFilter) {
        apps.filter { app ->
            (searchQuery.isBlank() || app.appName.contains(searchQuery, ignoreCase = true) || app.packageName.contains(searchQuery, ignoreCase = true)) &&
                    (selectedRiskFilter == null || app.riskLevel == selectedRiskFilter)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("app_security_detail_view")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("app_search_field"),
            placeholder = { Text("Search installed applications...") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                    }
                }
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedRiskFilter == null,
                onClick = { selectedRiskFilter = null },
                label = { Text("All (${apps.size})") }
            )
            FilterChip(
                selected = selectedRiskFilter == AppAuditRiskLevel.HIGH,
                onClick = { selectedRiskFilter = if (selectedRiskFilter == AppAuditRiskLevel.HIGH) null else AppAuditRiskLevel.HIGH },
                label = { Text("High (${apps.count { it.riskLevel == AppAuditRiskLevel.HIGH }})") }
            )
            FilterChip(
                selected = selectedRiskFilter == AppAuditRiskLevel.REVIEW,
                onClick = { selectedRiskFilter = if (selectedRiskFilter == AppAuditRiskLevel.REVIEW) null else AppAuditRiskLevel.REVIEW },
                label = { Text("Review (${apps.count { it.riskLevel == AppAuditRiskLevel.REVIEW }})") }
            )
            FilterChip(
                selected = selectedRiskFilter == AppAuditRiskLevel.LOW,
                onClick = { selectedRiskFilter = if (selectedRiskFilter == AppAuditRiskLevel.LOW) null else AppAuditRiskLevel.LOW },
                label = { Text("Low (${apps.count { it.riskLevel == AppAuditRiskLevel.LOW }})") }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredApps) { app ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_audit_card_${app.packageName}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Risk Badge
                            val (badgeText, badgeColor) = when (app.riskLevel) {
                                AppAuditRiskLevel.HIGH -> "HIGH RISK" to ThreatRed
                                AppAuditRiskLevel.REVIEW -> "REVIEW" to WarningAmber
                                AppAuditRiskLevel.LOW -> "LOW RISK" to SafeGreen
                            }

                            Text(
                                text = badgeText,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = badgeColor,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(badgeColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Source: ${app.installerDisplayName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (app.riskIndicators.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Risk Indicators:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = ThreatRed
                            )
                            app.riskIndicators.forEach { ind ->
                                Text(
                                    text = "• $ind",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Sensitive Permissions (${app.sensitivePermissions.size}): " +
                                    if (app.sensitivePermissions.isEmpty()) "None" else app.sensitivePermissions.joinToString { it.substringAfterLast('.') },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Recommendation: ${app.recommendation}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onOpenSettings(app.packageName) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("App Info")
                            }

                            if (!app.isSystemApp) {
                                Button(
                                    onClick = { onUninstall(app.packageName) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = ThreatRed.copy(alpha = 0.15f)),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Text("Uninstall", color = ThreatRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🌐 Network Safety
// -------------------------------------------------------------
@Composable
fun NetworkSafetyDetailView(
    report: com.example.security.analyzer.NetworkSafetyReport?,
    onRefresh: () -> Unit
) {
    val rep = report ?: return

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("network_safety_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Active Network: ${rep.connectionType}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = rep.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Network Indicators",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("VPN Tunnel Status")
                        Text(
                            text = if (rep.isVpnActive) "✅ Active (Encrypted)" else "Inactive",
                            fontWeight = FontWeight.Bold,
                            color = if (rep.isVpnActive) SafeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Connection Metering")
                        Text(
                            text = if (rep.isMetered) "Metered Connection" else "Unmetered",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Internet Validated")
                        Text(
                            text = if (rep.isInternetValidated) "✅ Validated" else "Unconfirmed",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Security Recommendations",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    rep.recommendations.forEach { rec ->
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text("🛡️ ", fontSize = 14.sp)
                            Text(text = rec, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Defensive Architecture Notice",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = rep.defensiveNotice,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🔗 Link Safety Checker
// -------------------------------------------------------------
@Composable
fun LinkSafetyDetailView(viewModel: SecurityViewModel) {
    var inputUrl by remember { mutableStateOf("") }
    val linkResult by viewModel.cyberLinkResult.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzingCyberLink.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("link_safety_detail_view")
    ) {
        Text(
            text = "Analyze Website Links",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Paste a URL below to inspect HTTPS encryption, domain spoofing, and structure.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = inputUrl,
            onValueChange = { inputUrl = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("url_input_field"),
            placeholder = { Text("https://example.com/login") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            trailingIcon = {
                if (inputUrl.isNotEmpty()) {
                    IconButton(onClick = { inputUrl = "" }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                    }
                }
            }
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { viewModel.analyzeCyberLink(inputUrl) },
                enabled = inputUrl.isNotBlank() && !isAnalyzing,
                modifier = Modifier
                    .weight(1f)
                    .testTag("btn_analyze_link"),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isAnalyzing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text("Check Link Safety")
                }
            }

            if (linkResult != null) {
                OutlinedButton(
                    onClick = { viewModel.clearCyberLinkResult() },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Clear")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (linkResult != null) {
            val res = linkResult!!
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("link_result_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (res.status == LinkSafetyStatus.NO_OBVIOUS_WARNING)
                        SafeGreen.copy(alpha = 0.1f)
                    else WarningAmber.copy(alpha = 0.1f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (res.status == LinkSafetyStatus.NO_OBVIOUS_WARNING) "🟢 No Obvious Warning" else "🟠 Review Recommended",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (res.status == LinkSafetyStatus.NO_OBVIOUS_WARNING) SafeGreen else WarningAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Host: ${res.host}", fontWeight = FontWeight.SemiBold)
                    Text(text = "HTTPS Encryption: ${if (res.isHttps) "Yes (Secure Protocol)" else "No (Unencrypted HTTP)"}")

                    if (res.reasons.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Detected Indicators:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        res.reasons.forEach { reason ->
                            Text(text = "• $reason", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Recommendation: ${res.recommendation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = res.threatIntelStatus,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🎣 Phishing Awareness
// -------------------------------------------------------------
@Composable
fun PhishingAwarenessDetailView() {
    val scenarios = remember { CyberSecurityKnowledge.phishingScenarios }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("phishing_awareness_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Educational Scam & Phishing Scenarios",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Learn to spot red flags in suspicious messages before clicking.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(scenarios) { scenario ->
            var expanded by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("phish_scenario_${scenario.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = scenario.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "From: ${scenario.senderOrSource}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = scenario.content,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { expanded = !expanded },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (expanded) "Hide Analysis" else "Why is this suspicious? 🔍")
                    }

                    AnimatedVisibility(visible = expanded) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            Text(
                                text = "Red Flags:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = ThreatRed
                            )
                            scenario.redFlags.forEach { flag ->
                                Text(text = "• $flag", style = MaterialTheme.typography.bodySmall)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Explanation:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = scenario.whySuspicious, style = MaterialTheme.typography.bodySmall)

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Safe Action:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SafeGreen
                            )
                            Text(text = scenario.safeAction, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🔑 Account Security
// -------------------------------------------------------------
@Composable
fun AccountSecurityDetailView() {
    val items = remember { CyberSecurityKnowledge.accountSecurityItems }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("account_security_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Account Security & Authentication Hygiene",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Educational guidelines to safeguard your digital identity across online services.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(items) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("acc_item_${item.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Recommendation: ${item.recommendation}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🕵️ Privacy Permissions Check
// -------------------------------------------------------------
@Composable
fun PrivacyCheckDetailView(groups: List<PrivacyPermissionGroup>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("privacy_check_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Sensitive Permissions Audit",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Review which installed applications have access to sensitive hardware or data.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(groups) { group ->
            var expanded by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .testTag("privacy_group_${group.groupKey}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = group.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "${group.associatedApps.size} App(s)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = group.plainLanguageExplanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    AnimatedVisibility(visible = expanded) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Applications with this permission:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                            if (group.associatedApps.isEmpty()) {
                                Text(
                                    text = "No applications currently hold this permission.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                group.associatedApps.forEach { appName ->
                                    Text(
                                        text = "• $appName",
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🚨 Security Alerts Detail
// -------------------------------------------------------------
@Composable
fun SecurityAlertsDetailView(
    alerts: List<CyberSecurityAlertItem>,
    onAcknowledge: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("security_alerts_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Cyber Security Alerts",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Actual findings produced by legitimate device and application audits.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (alerts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SafeGreen.copy(alpha = 0.1f))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SafeGreen,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Active Alerts",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "All audited controls meet recommended baseline standards.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(alerts) { alert ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("alert_item_${alert.id}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = alert.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )

                            val (label, color) = when (alert.severity) {
                                AlertSeverity.HIGH -> "HIGH" to ThreatRed
                                AlertSeverity.MEDIUM -> "MEDIUM" to WarningAmber
                                AlertSeverity.INFO -> "INFO" to BluePrimary
                            }

                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = color,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(color.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Reason: ${alert.reason}",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Evidence: ${alert.evidence}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Action: ${alert.recommendedAction}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = { onAcknowledge(alert.id) },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Acknowledge Alert")
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 📊 Cyber Security Score Breakdown
// -------------------------------------------------------------
@Composable
fun SecurityScoreBreakdownDetailView(
    score: com.example.security.model.CyberSecurityScore?
) {
    val sc = score ?: return

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("security_score_breakdown_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Overall Score: ${sc.totalScore}/100",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Status: ${sc.ratingLabel}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Point-by-point calculation based on real Android platform checks. Never uses simulated 100/100 scores.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Text(
                text = "Category Sub-Scores",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    ScoreCategoryRow("Device Security", sc.deviceSecurityScore, 25)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    ScoreCategoryRow("App Security", sc.appSecurityScore, 25)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    ScoreCategoryRow("Privacy Hygiene", sc.privacyScore, 20)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    ScoreCategoryRow("Network Safety", sc.networkScore, 15)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    ScoreCategoryRow("Account Security", sc.accountSecurityScore, 15)
                }
            }
        }

        item {
            Text(
                text = "Factor Breakdown",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(sc.factors) { factor ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = factor.title, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${factor.category} • ${factor.detail}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "${factor.pointsAwarded}/${factor.maxPoints} pts",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun ScoreCategoryRow(name: String, points: Int, max: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = name, fontWeight = FontWeight.SemiBold)
        Text(
            text = "$points / $max pts",
            fontWeight = FontWeight.Bold,
            color = if (points >= max * 0.8) SafeGreen else WarningAmber
        )
    }
}

// -------------------------------------------------------------
// Sub-View: 📊 Security Report Detail
// -------------------------------------------------------------
@Composable
fun SecurityReportDetailView(
    report: com.example.security.model.CyberSecurityReport?,
    onShare: () -> Unit
) {
    val rep = report ?: return

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("security_report_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Button(
                onClick = onShare,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_share_report"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Share Report via Android")
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Report Summary",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Generated on ${rep.formattedDate}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Overall Score: ${rep.overallScore}/100")
                    Text(text = "Device Checks: ${rep.deviceChecksSummary}")
                    Text(text = "App Audit: ${rep.appAuditSummary}")
                    Text(text = "Privacy Findings: ${rep.privacyFindingsSummary}")
                    Text(text = "Network Status: ${rep.networkSummary}")
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Full Plaintext Preview",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = rep.plainTextReport,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🛡️ Security Monitor
// -------------------------------------------------------------
@Composable
fun SecurityMonitorDetailView(
    isMonitoring: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("security_monitor_detail_view")
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isMonitoring) SafeGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isMonitoring) "Monitoring Active" else "Monitoring Disabled",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isMonitoring) SafeGreen else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isMonitoring)
                            "Periodic background security checks run every 12 hours using WorkManager."
                        else "Enable periodic background audits to receive alerts for new threats.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Switch(
                    checked = isMonitoring,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("switch_security_monitor")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Background Safety Controls",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Uses legitimate Android WorkManager periodic jobs.\n" +
                            "• Only executes when the battery is not low.\n" +
                            "• Zero continuous battery drain or hidden processes.\n" +
                            "• You can enable or disable monitoring at any time.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 📚 Security Guide
// -------------------------------------------------------------
@Composable
fun SecurityGuideDetailView() {
    val topics = remember { CyberSecurityKnowledge.guideTopics }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("security_guide_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Cyber Security Learning Center",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Essential educational topics explained simply for everyday mobile users.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(topics) { topic ->
            var expanded by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .testTag("guide_topic_${topic.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = topic.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = topic.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = topic.summary,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    AnimatedVisibility(visible = expanded) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = topic.detailedExplanation,
                                style = MaterialTheme.typography.bodyMedium
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Best Practices:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SafeGreen
                            )
                            topic.bestPractices.forEach { bp ->
                                Text(text = "✓ $bp", style = MaterialTheme.typography.bodySmall)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "What to Avoid:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = ThreatRed
                            )
                            topic.whatToAvoid.forEach { wta ->
                                Text(text = "✗ $wta", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Sub-View: 🚨 Emergency Checklist
// -------------------------------------------------------------
@Composable
fun EmergencyChecklistDetailView() {
    val items = remember { CyberSecurityKnowledge.emergencyChecklist }
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("emergency_checklist_detail_view"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ThreatRed.copy(alpha = 0.12f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Suspect Your Device Is Compromised?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ThreatRed
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Follow these safe, recommended steps in sequence. Do not bypass Android security controls.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        items(items) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checklist_step_${item.stepNumber}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Step ${item.stepNumber}: ${item.title}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )

                        if (item.isUrgent) {
                            Text(
                                text = "URGENT",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = ThreatRed,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(ThreatRed.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    if (item.actionLabel != null && item.intentAction != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = Intent(item.intentAction).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    // Fallback
                                }
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(item.actionLabel)
                        }
                    }
                }
            }
        }
    }
}
