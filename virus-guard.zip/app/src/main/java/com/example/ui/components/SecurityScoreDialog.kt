package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.security.model.ScoreFactor
import com.example.security.model.SecurityScoreBreakdown
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SafeGreen
import com.example.ui.theme.ThreatRed
import com.example.ui.theme.WarningAmber

@Composable
fun SecurityScoreDialog(
    breakdown: SecurityScoreBreakdown,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val attentionFactors = breakdown.factors.filter { it.pointDelta < 0 }
    val normalFactors = breakdown.factors.filter { it.pointDelta >= 0 }

    var expandedCategory by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("security_score_dialog")
            ) {
                // Top Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BluePrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Security Score Breakdown",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "100% Explainable & Evidence-Based",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("dismiss_score_dialog_button")) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Overall Score Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Current Device Score",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${breakdown.score} / 100",
                                        style = MaterialTheme.typography.headlineLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (breakdown.score >= 80) SafeGreen else WarningAmber
                                    )
                                    Text(
                                        text = if (attentionFactors.isEmpty()) "Optimal baseline protection" else "${attentionFactors.size} deduction(s) explained below",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(if (breakdown.score >= 80) SafeGreen.copy(alpha = 0.2f) else WarningAmber.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${breakdown.score}",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (breakdown.score >= 80) SafeGreen else WarningAmber
                                    )
                                }
                            }
                        }
                    }

                    // 5 Categories Section (Device Security, App Security, Privacy, Network Safety, File Safety)
                    item {
                        Text(
                            text = "5 Security Categories (Tap to open details)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Category 1: Device Security
                    item {
                        val deviceIssues = attentionFactors.filter { it.title.contains("Lock", ignoreCase = true) || it.title.contains("Debug", ignoreCase = true) || it.title.contains("ADB", ignoreCase = true) }
                        InteractiveCategoryCard(
                            name = "Device Security",
                            score = if (deviceIssues.isEmpty()) 20 else maxOf(0, 20 + deviceIssues.sumOf { it.pointDelta }),
                            maxScore = 20,
                            status = if (deviceIssues.isEmpty()) "Protected (20/20)" else "${deviceIssues.size} issue(s) detected",
                            isClean = deviceIssues.isEmpty(),
                            isExpanded = expandedCategory == "Device Security",
                            onToggle = { expandedCategory = if (expandedCategory == "Device Security") null else "Device Security" },
                            issues = deviceIssues,
                            onFix = { factor -> launchFactorSettings(context, factor) }
                        )
                    }

                    // Category 2: App Security
                    item {
                        val appIssues = attentionFactors.filter { it.title.contains("App", ignoreCase = true) || it.title.contains("Harmful", ignoreCase = true) || it.title.contains("Source", ignoreCase = true) }
                        InteractiveCategoryCard(
                            name = "App Security",
                            score = if (appIssues.isEmpty()) 20 else maxOf(0, 20 + appIssues.sumOf { it.pointDelta }),
                            maxScore = 20,
                            status = if (appIssues.isEmpty()) "Protected (20/20)" else "${appIssues.size} app(s) need review",
                            isClean = appIssues.isEmpty(),
                            isExpanded = expandedCategory == "App Security",
                            onToggle = { expandedCategory = if (expandedCategory == "App Security") null else "App Security" },
                            issues = appIssues,
                            onFix = { factor -> launchFactorSettings(context, factor) }
                        )
                    }

                    // Category 3: Privacy
                    item {
                        val privacyIssues = attentionFactors.filter { it.title.contains("Permission", ignoreCase = true) || it.title.contains("Sensitive", ignoreCase = true) || it.title.contains("Overlay", ignoreCase = true) }
                        InteractiveCategoryCard(
                            name = "Privacy",
                            score = if (privacyIssues.isEmpty()) 20 else maxOf(0, 20 + privacyIssues.sumOf { it.pointDelta }),
                            maxScore = 20,
                            status = if (privacyIssues.isEmpty()) "Controlled (20/20)" else "${privacyIssues.size} permission review(s)",
                            isClean = privacyIssues.isEmpty(),
                            isExpanded = expandedCategory == "Privacy",
                            onToggle = { expandedCategory = if (expandedCategory == "Privacy") null else "Privacy" },
                            issues = privacyIssues,
                            onFix = { factor -> launchFactorSettings(context, factor) }
                        )
                    }

                    // Category 4: Network Safety
                    item {
                        InteractiveCategoryCard(
                            name = "Network Safety",
                            score = 20,
                            maxScore = 20,
                            status = "Standard Encryption (20/20)",
                            isClean = true,
                            isExpanded = expandedCategory == "Network Safety",
                            onToggle = { expandedCategory = if (expandedCategory == "Network Safety") null else "Network Safety" },
                            issues = emptyList(),
                            onFix = { }
                        )
                    }

                    // Category 5: File Safety
                    item {
                        InteractiveCategoryCard(
                            name = "File Safety",
                            score = 20,
                            maxScore = 20,
                            status = "Sandbox Secure (20/20)",
                            isClean = true,
                            isExpanded = expandedCategory == "File Safety",
                            onToggle = { expandedCategory = if (expandedCategory == "File Safety") null else "File Safety" },
                            issues = emptyList(),
                            onFix = { }
                        )
                    }

                    // What Needs Attention Section
                    if (attentionFactors.isNotEmpty()) {
                        item {
                            Text(
                                text = "All Items Requiring Attention (${attentionFactors.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        items(attentionFactors) { factor ->
                            ScoreIssueCard(
                                factor = factor,
                                onFix = { launchFactorSettings(context, factor) }
                            )
                        }
                    }

                    // Baseline Passed Checks
                    item {
                        Text(
                            text = "Passed Baseline Controls (${normalFactors.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(normalFactors) { factor ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = SafeGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = factor.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(text = factor.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                // Close Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("dismiss_score_dialog_action"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Done / Close", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun InteractiveCategoryCard(
    name: String,
    score: Int,
    maxScore: Int,
    status: String,
    isClean: Boolean,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    issues: List<ScoreFactor>,
    onFix: (ScoreFactor) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .testTag("category_card_${name.replace(" ", "_")}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isClean) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (isClean) SafeGreen else WarningAmber,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$status • $score/$maxScore pts",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isClean) SafeGreen else WarningAmber,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    if (issues.isEmpty()) {
                        Text(
                            text = "✅ Optimal protection. No deductions applied to this category.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SafeGreen
                        )
                    } else {
                        Text(
                            text = "Specific deductions for $name:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ThreatRed
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        issues.forEach { issue ->
                            ScoreIssueCard(factor = issue, onFix = { onFix(issue) })
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScoreIssueCard(
    factor: ScoreFactor,
    onFix: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("score_issue_${factor.title}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚠️ ${factor.title}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "${factor.pointDelta} pts",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = ThreatRed
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // What was found
            Text(
                text = "WHAT WAS FOUND",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = factor.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Evidence
            Text(
                text = "EVIDENCE",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = when {
                    factor.title.contains("Lock", ignoreCase = true) ->
                        "KeyguardManager.isDeviceSecure query returned false on this Android device."
                    factor.title.contains("Debug", ignoreCase = true) || factor.title.contains("ADB", ignoreCase = true) ->
                        "Settings.Global.ADB_ENABLED query returned 1."
                    factor.title.contains("Harmful", ignoreCase = true) || factor.title.contains("App", ignoreCase = true) ->
                        "PackageManager audit flagged package with high risk privilege combinations."
                    else ->
                        "System configuration check recorded security deduction."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Why it matters
            Text(
                text = "WHY IT MATTERS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = when {
                    factor.title.contains("Lock", ignoreCase = true) ->
                        "Without a lock screen, unauthorized physical access allows full extraction of messages, banking credentials, and private files."
                    factor.title.contains("Debug", ignoreCase = true) || factor.title.contains("ADB", ignoreCase = true) ->
                        "USB debugging permits external machines to run developer commands on device storage."
                    factor.title.contains("Harmful", ignoreCase = true) || factor.title.contains("App", ignoreCase = true) ->
                        "Applications holding elevated privilege combinations could abuse background access."
                    else ->
                        "This configuration reduces isolation boundaries on the device."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Recommended Action
            Text(
                text = "RECOMMENDED ACTION",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = when {
                    factor.title.contains("Lock", ignoreCase = true) ->
                        "Open Security settings to configure a PIN, password, pattern, or fingerprint lock."
                    factor.title.contains("Debug", ignoreCase = true) || factor.title.contains("ADB", ignoreCase = true) ->
                        "Disable USB Debugging in Developer Options when not actively testing software."
                    else ->
                        "Review permissions in Android App Settings."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onFix,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("fix_now_${factor.title}"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("FIX NOW", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

private fun launchFactorSettings(context: Context, factor: ScoreFactor) {
    try {
        val action = when {
            factor.title.contains("Lock", ignoreCase = true) -> Settings.ACTION_SECURITY_SETTINGS
            factor.title.contains("Debug", ignoreCase = true) || factor.title.contains("ADB", ignoreCase = true) ->
                Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            factor.title.contains("Install", ignoreCase = true) || factor.title.contains("Source", ignoreCase = true) ->
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
            else -> Settings.ACTION_APPLICATION_SETTINGS
        }
        val intent = Intent(action).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        try {
            val fallback = Intent(Settings.ACTION_SECURITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(fallback)
        } catch (_: Exception) { }
    }
}
