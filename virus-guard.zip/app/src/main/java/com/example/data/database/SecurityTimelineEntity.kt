package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_timeline")
data class SecurityTimelineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String, // QUICK_SCAN, DEEP_SCAN, CHECKUP, APK_ANALYSIS, FILE_SCAN, LINK_CHECK, ALERT_REVIEWED
    val title: String,
    val description: String,
    val severity: String // NORMAL, REVIEW_RECOMMENDED, POTENTIALLY_HARMFUL
)
