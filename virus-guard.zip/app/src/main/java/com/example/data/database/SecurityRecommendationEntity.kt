package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_recommendations")
data class SecurityRecommendationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val recommendationId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val description: String,
    val category: String,
    val priority: String, // HIGH, REVIEW, NORMAL
    val actionLabel: String? = null,
    val isDismissed: Boolean = false
)
