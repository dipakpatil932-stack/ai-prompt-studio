package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CyberSecurityDao {

    // Security Check Results
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckResults(results: List<SecurityCheckResultEntity>)

    @Query("SELECT * FROM security_check_results ORDER BY id DESC")
    fun getAllCheckResults(): Flow<List<SecurityCheckResultEntity>>

    @Query("DELETE FROM security_check_results")
    suspend fun clearCheckResults()

    // Security Alerts
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: SecurityAlertEntity): Long

    @Query("SELECT * FROM security_alerts WHERE isAcknowledged = 0 ORDER BY timestamp DESC")
    fun getActiveAlerts(): Flow<List<SecurityAlertEntity>>

    @Query("SELECT * FROM security_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<SecurityAlertEntity>>

    @Query("UPDATE security_alerts SET isAcknowledged = 1 WHERE alertId = :alertId")
    suspend fun acknowledgeAlert(alertId: String)

    @Query("DELETE FROM security_alerts")
    suspend fun clearAlerts()

    // Recommendations
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecommendations(recommendations: List<SecurityRecommendationEntity>)

    @Query("SELECT * FROM security_recommendations WHERE isDismissed = 0 ORDER BY id ASC")
    fun getActiveRecommendations(): Flow<List<SecurityRecommendationEntity>>

    @Query("DELETE FROM security_recommendations")
    suspend fun clearRecommendations()

    // Security Events
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: SecurityEventEntity): Long

    @Query("SELECT * FROM security_events ORDER BY timestamp DESC LIMIT 100")
    fun getRecentEvents(): Flow<List<SecurityEventEntity>>

    @Query("DELETE FROM security_events")
    suspend fun clearEvents()
}
