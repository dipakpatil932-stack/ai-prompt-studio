package com.example.data.repository

import com.example.data.database.CyberSecurityDao
import com.example.data.database.SecurityAlertEntity
import com.example.data.database.SecurityCheckResultEntity
import com.example.data.database.SecurityEventEntity
import com.example.data.database.SecurityRecommendationEntity
import kotlinx.coroutines.flow.Flow

class CyberSecurityRepository(private val dao: CyberSecurityDao) {

    val activeAlerts: Flow<List<SecurityAlertEntity>> = dao.getActiveAlerts()
    val allAlerts: Flow<List<SecurityAlertEntity>> = dao.getAllAlerts()
    val recentEvents: Flow<List<SecurityEventEntity>> = dao.getRecentEvents()
    val checkResults: Flow<List<SecurityCheckResultEntity>> = dao.getAllCheckResults()
    val activeRecommendations: Flow<List<SecurityRecommendationEntity>> = dao.getActiveRecommendations()

    suspend fun saveCheckResults(results: List<SecurityCheckResultEntity>) {
        dao.clearCheckResults()
        dao.insertCheckResults(results)
    }

    suspend fun addAlert(alert: SecurityAlertEntity): Long {
        return dao.insertAlert(alert)
    }

    suspend fun acknowledgeAlert(alertId: String) {
        dao.acknowledgeAlert(alertId)
    }

    suspend fun clearAlerts() {
        dao.clearAlerts()
    }

    suspend fun saveRecommendations(recommendations: List<SecurityRecommendationEntity>) {
        dao.clearRecommendations()
        dao.insertRecommendations(recommendations)
    }

    suspend fun logEvent(
        eventType: String,
        title: String,
        description: String,
        severity: String,
        source: String = "CyberSecurityCenter"
    ) {
        dao.insertEvent(
            SecurityEventEntity(
                eventType = eventType,
                title = title,
                description = description,
                severity = severity,
                source = source
            )
        )
    }

    suspend fun clearEvents() {
        dao.clearEvents()
    }
}
