package com.example.data.repository

import com.example.data.database.SecurityTimelineDao
import com.example.data.database.SecurityTimelineEntity
import kotlinx.coroutines.flow.Flow

class SecurityTimelineRepository(private val dao: SecurityTimelineDao) {

    val allEvents: Flow<List<SecurityTimelineEntity>> = dao.getAllEvents()

    suspend fun recordEvent(
        eventType: String,
        title: String,
        description: String,
        severity: String
    ): Long {
        return dao.insertEvent(
            SecurityTimelineEntity(
                timestamp = System.currentTimeMillis(),
                eventType = eventType,
                title = title,
                description = description,
                severity = severity
            )
        )
    }

    suspend fun clearAll() {
        dao.clearAllEvents()
    }
}
