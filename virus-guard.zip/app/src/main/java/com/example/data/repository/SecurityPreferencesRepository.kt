package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SecurityPreferences(
    val languageCode: String = "en",
    val includeSystemApps: Boolean = false,
    val scanRemindersEnabled: Boolean = true,
    val isSimpleMode: Boolean = true,
    val smartMonitorEnabled: Boolean = true,
    val autoCheckFrequency: String = "DAILY", // "DAILY", "WEEKLY", "OFF"
    val notificationsEnabled: Boolean = true,
    val lastCheckTimestamp: Long = 0L,
    val lastCheckScore: Int = 100,
    val knownPackages: Set<String> = emptySet(),
    val newlyDetectedApps: Set<String> = emptySet()
)

class SecurityPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("virus_guard_prefs", Context.MODE_PRIVATE)

    private val _preferences = MutableStateFlow(loadPreferences())
    val preferences: StateFlow<SecurityPreferences> = _preferences.asStateFlow()

    private fun loadPreferences(): SecurityPreferences {
        return SecurityPreferences(
            languageCode = prefs.getString(KEY_LANGUAGE, "en") ?: "en",
            includeSystemApps = prefs.getBoolean(KEY_INCLUDE_SYSTEM, false),
            scanRemindersEnabled = prefs.getBoolean(KEY_NOTIFICATIONS, true),
            isSimpleMode = prefs.getBoolean(KEY_SIMPLE_MODE, true),
            smartMonitorEnabled = prefs.getBoolean(KEY_SMART_MONITOR, true),
            autoCheckFrequency = prefs.getString(KEY_AUTO_CHECK_FREQ, "DAILY") ?: "DAILY",
            notificationsEnabled = prefs.getBoolean(KEY_SECURITY_NOTIFS, true),
            lastCheckTimestamp = prefs.getLong(KEY_LAST_CHECK_TS, 0L),
            lastCheckScore = prefs.getInt(KEY_LAST_CHECK_SCORE, 100),
            knownPackages = prefs.getStringSet(KEY_KNOWN_PACKAGES, emptySet()) ?: emptySet(),
            newlyDetectedApps = prefs.getStringSet(KEY_NEW_APPS, emptySet()) ?: emptySet()
        )
    }

    fun setLanguage(code: String) {
        prefs.edit().putString(KEY_LANGUAGE, code).apply()
        _preferences.value = _preferences.value.copy(languageCode = code)
    }

    fun setIncludeSystemApps(include: Boolean) {
        prefs.edit().putBoolean(KEY_INCLUDE_SYSTEM, include).apply()
        _preferences.value = _preferences.value.copy(includeSystemApps = include)
    }

    fun setScanRemindersEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS, enabled).apply()
        _preferences.value = _preferences.value.copy(scanRemindersEnabled = enabled)
    }

    fun setSimpleMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SIMPLE_MODE, enabled).apply()
        _preferences.value = _preferences.value.copy(isSimpleMode = enabled)
    }

    fun setSmartMonitorEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SMART_MONITOR, enabled).apply()
        _preferences.value = _preferences.value.copy(smartMonitorEnabled = enabled)
    }

    fun setAutoCheckFrequency(freq: String) {
        prefs.edit().putString(KEY_AUTO_CHECK_FREQ, freq).apply()
        _preferences.value = _preferences.value.copy(autoCheckFrequency = freq)
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SECURITY_NOTIFS, enabled).apply()
        _preferences.value = _preferences.value.copy(notificationsEnabled = enabled)
    }

    fun recordCheckCompletion(timestamp: Long, score: Int, knownApps: Set<String>, newApps: Set<String>) {
        prefs.edit()
            .putLong(KEY_LAST_CHECK_TS, timestamp)
            .putInt(KEY_LAST_CHECK_SCORE, score)
            .putStringSet(KEY_KNOWN_PACKAGES, knownApps)
            .putStringSet(KEY_NEW_APPS, newApps)
            .apply()
        _preferences.value = _preferences.value.copy(
            lastCheckTimestamp = timestamp,
            lastCheckScore = score,
            knownPackages = knownApps,
            newlyDetectedApps = newApps
        )
    }

    fun clearNewlyDetectedApps() {
        prefs.edit().putStringSet(KEY_NEW_APPS, emptySet()).apply()
        _preferences.value = _preferences.value.copy(newlyDetectedApps = emptySet())
    }

    companion object {
        private const val KEY_LANGUAGE = "language_code"
        private const val KEY_INCLUDE_SYSTEM = "include_system_apps"
        private const val KEY_NOTIFICATIONS = "scan_reminders"
        private const val KEY_SIMPLE_MODE = "is_simple_mode"
        private const val KEY_SMART_MONITOR = "smart_monitor_enabled"
        private const val KEY_AUTO_CHECK_FREQ = "auto_check_frequency"
        private const val KEY_SECURITY_NOTIFS = "security_notifications_enabled"
        private const val KEY_LAST_CHECK_TS = "last_check_timestamp"
        private const val KEY_LAST_CHECK_SCORE = "last_check_score"
        private const val KEY_KNOWN_PACKAGES = "known_packages_baseline"
        private const val KEY_NEW_APPS = "newly_detected_apps"
    }
}
