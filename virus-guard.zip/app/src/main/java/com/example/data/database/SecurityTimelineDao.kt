package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SecurityTimelineDao {
    @Query("SELECT * FROM security_timeline ORDER BY timestamp DESC")
    fun getAllEvents(): Flow<List<SecurityTimelineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: SecurityTimelineEntity): Long

    @Query("DELETE FROM security_timeline")
    suspend fun clearAllEvents()
}
