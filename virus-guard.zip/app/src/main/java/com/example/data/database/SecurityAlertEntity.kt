package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_alerts")
data class SecurityAlertEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val alertId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val reason: String,
    val evidence: String,
    val severity: String, // HIGH, MEDIUM, INFO
    val recommendedAction: String,
    val isAcknowledged: Boolean = false
)
