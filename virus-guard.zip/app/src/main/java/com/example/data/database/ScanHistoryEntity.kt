package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val scanType: String, // QUICK, DEEP, FILE
    val itemsChecked: Int,
    val warningsCount: Int,
    val threatsFound: Int,
    val permissionsAnalyzed: Int,
    val overallRisk: String,
    val durationMillis: Long,
    val summaryText: String
)
