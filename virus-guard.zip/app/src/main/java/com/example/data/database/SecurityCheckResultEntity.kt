package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_check_results")
data class SecurityCheckResultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val checkId: String,
    val title: String,
    val category: String,
    val state: String, // GOOD, REVIEW, NOT_AVAILABLE
    val evidence: String,
    val explanation: String,
    val recommendation: String
)
