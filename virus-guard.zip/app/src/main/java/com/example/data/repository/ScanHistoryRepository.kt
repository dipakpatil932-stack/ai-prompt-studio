package com.example.data.repository

import com.example.data.database.ScanHistoryDao
import com.example.data.database.ScanHistoryEntity
import kotlinx.coroutines.flow.Flow

class ScanHistoryRepository(private val dao: ScanHistoryDao) {

    val allHistory: Flow<List<ScanHistoryEntity>> = dao.getAllHistory()

    val latestScan: Flow<ScanHistoryEntity?> = dao.getLatestScan()

    suspend fun insertScan(scan: ScanHistoryEntity): Long {
        return dao.insertScan(scan)
    }

    suspend fun clearHistory() {
        dao.clearHistory()
    }
}
