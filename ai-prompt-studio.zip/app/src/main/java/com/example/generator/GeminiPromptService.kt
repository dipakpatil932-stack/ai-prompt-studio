package com.example.generator

import com.example.BuildConfig
import com.example.data.model.GeneratedPrompt
import com.example.data.model.PromptInputState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiPromptService {

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    fun isConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    suspend fun enhanceWithAi(input: PromptInputState, basePrompt: GeneratedPrompt): GeneratedPrompt = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext basePrompt
        }

        try {
            val userPromptInstruction = buildString {
                append("You are an expert AI prompt engineer for Midjourney, Stable Diffusion, Sora, Veo, Runway, and Kling.\n")
                append("Refine and elevate this AI Prompt specification into an Oscar-level professional prompt.\n")
                append("Category: ${input.category.title}\n")
                append("Topic: ${input.topic.ifBlank { input.category.sampleTopic }}\n")
                append("Character: ${input.character.ifBlank { input.category.sampleCharacter }}\n")
                append("Location: ${input.location.ifBlank { input.category.sampleLocation }}\n")
                append("Visual Style: ${input.visualStyle}\n")
                append("Language: ${input.language.displayName}\n")
                append("Aspect Ratio: ${input.aspectRatio.ratio}\n")
                append("Output format: Provide a concise refined master prompt and negative prompt.")
            }

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().apply { put("text", userPromptInstruction) })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val bodyString = response.body?.string() ?: return@withContext basePrompt
                val responseJson = JSONObject(bodyString)
                val candidates = responseJson.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val text = parts?.optJSONObject(0)?.optString("text")

                if (!text.isNullOrBlank()) {
                    return@withContext basePrompt.copy(
                        fullPromptText = text.trim(),
                        cinematicDetails = basePrompt.cinematicDetails + " [AI Enhanced via Gemini 3.5 Flash]"
                    )
                }
            }
        } catch (_: Exception) {
            // Graceful fallback to offline engine
        }
        return@withContext basePrompt
    }
}
