package com.example.generator

import com.example.data.model.AppLanguage
import com.example.data.model.AspectRatioOption
import com.example.data.model.CharacterSpec
import com.example.data.model.GeneratedPrompt
import com.example.data.model.PromptCategory
import com.example.data.model.PromptInputState
import com.example.data.model.ScenePromptItem
import com.example.data.model.StoryDurationOption
import kotlin.random.Random

object PromptSynthesisEngine {

    val VISUAL_STYLES = listOf(
        "Cinematic 8K Hyperrealistic",
        "Photorealistic Unreal Engine 5",
        "IMAX 70mm Film Grain",
        "3D Pixar / Disney Animated Style",
        "Cyberpunk Neon Noir",
        "Vedic Mythological Epic Oil Painting",
        "Vintage 90s Bollywood Grain",
        "Dark Fantasy Chiaroscuro",
        "Japanese Studio Ghibli Anime",
        "Documentary National Geographic Style"
    )

    val CAMERA_ANGLES = listOf(
        "Low-angle hero shot emphasizing majesty and scale",
        "Cinematic eye-level medium close-up",
        "Dynamic high-angle aerial crane perspective",
        "Dutch tilt 45-degree tension shot",
        "Extreme macro close-up highlighting intricate ocular and facial micro-expressions",
        "Wide-angle establishing master shot with deep focal depth"
    )

    val CAMERA_MOVEMENTS = listOf(
        "Smooth orbital 360-degree pan around subject at 24fps",
        "Forward dolly push-in tracking subject forward motion",
        "Slow-motion vertigo Hitchcock dolly zoom",
        "Handheld subtle documentary sway with organic micro-shakes",
        "Sweeping high-velocity drone flyover dropping into eye level",
        "Static locked tripod shot with deep depth of field and anamorphic bokeh"
    )

    val LIGHTING_OPTIONS = listOf(
        "Volumetric golden hour sunset with god rays cutting through atmospheric haze",
        "Dramatic chiaroscuro high-contrast rim lighting and deep velvet shadows",
        "Bioluminescent cyan and magenta neon ambient fill with specular highlights",
        "Soft diffused overcast daylight with delicate skin subsurface scattering",
        "Celestial glowing golden aura with radiant divine lens flares",
        "Atmospheric foggy midnight moonlight reflecting off glossy wet surfaces"
    )

    fun generate(input: PromptInputState): GeneratedPrompt {
        val seed = Random.nextInt(1000, 9999)
        val topic = input.topic.ifBlank { input.category.sampleTopic }
        val charInput = input.character.ifBlank { input.category.sampleCharacter }
        val location = input.location.ifBlank { input.category.sampleLocation }
        val storyIdea = input.storyIdea.ifBlank { "Unfolding dramatic event revealing courage and destiny" }
        val style = input.visualStyle.ifBlank { "Cinematic 8K Hyperrealistic" }
        val lang = input.language
        val aspect = input.aspectRatio

        return when (input.category) {
            PromptCategory.IMAGE -> generateImagePrompt(seed, topic, charInput, location, style, lang, aspect)
            PromptCategory.VIDEO -> generateVideoPrompt(seed, topic, charInput, location, style, lang, aspect, input.duration)
            PromptCategory.CHARACTER -> generateCharacterPrompt(seed, topic, charInput, location, style, lang, aspect, input.keepCharacterConsistent)
            PromptCategory.STORY -> generateStoryPrompt(seed, topic, charInput, location, storyIdea, style, lang, aspect, input.storyDuration)
            PromptCategory.SCENE -> generateScenePrompt(seed, topic, charInput, location, style, lang, aspect)
            PromptCategory.SHORTS -> generateShortsPrompt(seed, topic, charInput, location, style, lang, aspect)
            PromptCategory.KIDS -> generateKidsPrompt(seed, topic, charInput, location, style, lang, aspect)
            PromptCategory.MYTHOLOGY -> generateMythologyPrompt(seed, topic, charInput, location, style, lang, aspect)
        }
    }

    private fun generateImagePrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption
    ): GeneratedPrompt {
        val cameraAngle = CAMERA_ANGLES[seed % CAMERA_ANGLES.size]
        val lighting = LIGHTING_OPTIONS[(seed + 1) % LIGHTING_OPTIONS.size]
        val clothing = getClothingDesc(character, style)
        val expression = getFacialExpression(seed)
        val cinematicDetails = "8k resolution, photorealistic masterwork, shot on ARRI Alexa 65, Cooke anamorphic prime lens, octanerender, subsurface scattering, realistic skin pore textures, volumetric fog, color graded cinematic palette"
        val negativePrompt = "blurry, low quality, oversaturated cartoonish skin, bad anatomy, deformed limbs, extra fingers, missing fingers, floating limbs, duplicate face, watermark, signature, jpeg compression artifacts"

        val dialogue = when (lang) {
            AppLanguage.HINDI -> "दृश्य कथा: \"सत्य की विजय अंधकार में भी चमकती है।\""
            AppLanguage.HINGLISH -> "Voiceover Subtitle: \"Jab hausla buland ho, toh raaste khud bante hain.\""
            AppLanguage.ENGLISH -> "Visual Theme: \"A moment of serene determination forged against the tides of time.\""
        }

        val promptText = buildString {
            append("Ultra-detailed $style of $topic. ")
            append("Subject: $character. ")
            append("Environment: $location. ")
            append("Lighting: $lighting. ")
            append("Camera: $cameraAngle. ")
            append("Costume & Details: $clothing, $expression. ")
            append("Details: $cinematicDetails. ")
            append("--ar ${aspect.ratio} --v 6.1 --style raw --q 2")
        }

        return GeneratedPrompt(
            title = topic.take(45),
            category = PromptCategory.IMAGE,
            fullPromptText = promptText,
            subject = character,
            environment = location,
            cameraAngle = cameraAngle,
            cameraMovement = "Static composition with cinematic framing",
            lighting = lighting,
            background = "$location with atmospheric depth and natural lens falloff",
            clothing = clothing,
            facialExpression = expression,
            visualStyle = style,
            cinematicDetails = cinematicDetails,
            audioDialogue = dialogue,
            negativePrompt = negativePrompt,
            aspectRatio = aspect,
            language = lang
        )
    }

    private fun generateVideoPrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption,
        duration: String
    ): GeneratedPrompt {
        val cameraAngle = "Eye-level medium shot transitioning smoothly into dynamic tracking"
        val cameraMovement = "Slow tracking forward push-in with subtle handheld stabilization and depth shift"
        val lighting = "Atmospheric edge lighting with deep ambient fill and soft volumetric haze"
        val clothing = getClothingDesc(character, style)
        val expression = "Intense, observant gaze shifting to resolute conviction"
        val cinematicDetails = "Sora / Veo / Runway Gen-3 optimized prompt, 60fps high motion fidelity, temporal coherence, raytraced reflections, no morphing artifacts"
        val negativePrompt = "temporal flickering, jitter, face warping, morphing limbs, jittery motion, low bitrate, pixelation, stuttering frame rate"

        val scenes = listOf(
            ScenePromptItem(
                sceneNumber = 1,
                duration = "3s",
                visualDescription = "Establishing shot of $location as the atmosphere shifts dramatically. $character stands poised, observing the surroundings.",
                characterAction = "$character slowly turns head toward camera, eyes narrowing with focused intensity.",
                cameraMovement = "Slow cinematic aerial dolly push descending to eye level",
                lighting = "Early dawn diffused golden haze with rim light on shoulders",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"वक़्त आ गया है, अब पीछे नहीं हटेंगे!\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Waqt aa gaya hai boss, now there is no turning back!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"The time has come. Stand your ground!\""
                },
                sfx = "Low bass drone rumble, wind rushing through fabric, distant metallic echoes",
                bgm = "Rising tension cinematic synth strings with slow heartbeat percussion",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 2,
                duration = "4s",
                visualDescription = "Dynamic mid-shot. $character takes deliberate action amidst intensifying ambient particles.",
                characterAction = "$character steps forward decisively, engaging with the focal element of $topic.",
                cameraMovement = "Smooth low-angle orbital pan around character at 45 degrees",
                lighting = "High-contrast dynamic key light casting sharp defined shadows",
                environment = "Center stage within $location with swirling mist and sparks",
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"जो सच के साथ है, वो कभी पराजित नहीं होता।\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Sach ke saath chalne wale kabhi haar nahi maante!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"Truth conquers all doubts.\""
                },
                sfx = "Crisp footsteps crunching on terrain, energetic whoosh of air, spark crackle",
                bgm = "Deep cinematic percussion swell with Indian dhol accents and brass horns",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 3,
                duration = "3s",
                visualDescription = "Climactic resolution shot. $character looks ahead toward the horizon as the climax of $topic occurs.",
                characterAction = "$character holds a victorious and steady posture, bathed in triumphant light.",
                cameraMovement = "Pull-back crane wide shot revealing the expansive scope of the environment",
                lighting = "Brilliant warm rim glow with celestial sunburst flare",
                environment = "$location under dramatic clearing skies",
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"विजय हमारी है!\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Jeet hamari hi hogi!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"Victory is finally ours!\""
                },
                sfx = "Resonant chime, wind calming down, birds or natural ambiance returning",
                bgm = "Triumphant orchestral climax resolving into a warm ambient acoustic outro",
                negativePrompt = negativePrompt
            )
        )

        val fullText = buildString {
            append("Cinematic AI Video Prompt for $topic.\n")
            append("Style: $style. Aspect Ratio: ${aspect.ratio}.\n")
            append("Master Description: $character moving purposefully through $location. $cameraMovement. $lighting. $cinematicDetails.\n\n")
            scenes.forEach { s ->
                append("[Scene ${s.sceneNumber} (${s.duration})]: ${s.visualDescription} | Action: ${s.characterAction} | Camera: ${s.cameraMovement} | SFX: ${s.sfx} | Audio: ${s.dialogue}\n\n")
            }
        }

        return GeneratedPrompt(
            title = topic.take(45),
            category = PromptCategory.VIDEO,
            fullPromptText = fullText,
            subject = character,
            environment = location,
            cameraAngle = cameraAngle,
            cameraMovement = cameraMovement,
            lighting = lighting,
            background = location,
            clothing = clothing,
            facialExpression = expression,
            visualStyle = style,
            cinematicDetails = cinematicDetails,
            audioDialogue = scenes.joinToString(" | ") { it.dialogue },
            negativePrompt = negativePrompt,
            scenes = scenes,
            aspectRatio = aspect,
            duration = duration.ifBlank { "10s" },
            language = lang
        )
    }

    private fun generateCharacterPrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption,
        keepConsistent: Boolean
    ): GeneratedPrompt {
        val age = "28–34 years old"
        val gender = if (character.contains("female", true) || character.contains("woman", true) || character.contains("girl", true)) "Female" else "Male"
        val appearance = "Striking athletic build, high cheekbones, well-defined jawline, piercing expressive dark amber eyes, distinctive calm aura"
        val hair = "Textured dark espresso wavy hair swept back with realistic natural highlights and subtle temple fading"
        val face = "Symmetrical countenance, defined brow ridge, faint subtle aesthetic scar above left eyebrow, natural skin pores, no plastic smoothing"
        val clothes = getClothingDesc(character, style)
        val bodyDesc = "Balanced upright posture conveying quiet dignity, steady breathing, grounded stance"
        val expression = "Measured confidence, observant depth, compassionate yet unyielding gaze"
        val personality = "Strategic thinker, loyal protector, calm under immense pressure, philosophical wisdom"

        val seedGuidance = if (keepConsistent) {
            "CONSISTENCY MASTER SEED: --seed 78421 --cref [URL_TO_SHEET] --cw 100. Always keep facial proportions locked: high cheekbones, left brow scar, dark amber iris, and exact clothing palette. When rendering across multiple scenes, append '--no hair_style_change, face_swap, outfit_inconsistency'."
        } else {
            "Standard generation without seed lock."
        }

        val turnaround = "Character turnaround sheet, multiple angles: full body front view, 3/4 profile portrait, side profile close-up, and dynamic action pose against clean neutral studio backdrop. Consistent lighting, identical facial geometry and wardrobe across all 4 poses."

        val masterPrompt = buildString {
            append("CHARACTER MASTER SPEC: $character, $age, $gender.\n")
            append("Appearance: $appearance. Hair: $hair. Face: $face.\n")
            append("Wardrobe: $clothes. Body: $bodyDesc.\n")
            append("Expression: $expression. Personality: $personality.\n")
            append("Visual Style: $style, shot on 85mm portrait prime lens, f/1.4 shallow depth of field, natural studio key light.\n")
            if (keepConsistent) {
                append("\n[Character Consistency Rule]: $seedGuidance\n")
                append("\n[Turnaround Sheet Prompt]: $turnaround")
            }
        }

        val spec = CharacterSpec(
            age = age,
            gender = gender,
            appearance = appearance,
            hair = hair,
            face = face,
            clothes = clothes,
            bodyDescription = bodyDesc,
            expression = expression,
            personality = personality,
            cinematicStyle = style,
            keepConsistent = keepConsistent,
            seedLockGuidance = seedGuidance,
            turnaroundPrompt = turnaround
        )

        return GeneratedPrompt(
            title = "$character (${if (keepConsistent) "Consistent Seed" else "Solo"})",
            category = PromptCategory.CHARACTER,
            fullPromptText = masterPrompt,
            subject = character,
            environment = location,
            cameraAngle = "Three-point lighting studio portrait and full-length turnaround",
            cameraMovement = "Static portrait lock with subtle 3D parallax",
            lighting = "Three-point studio lighting with soft diffused fill and subtle rim hair light",
            background = "Neutral studio slate with soft radial vignette and bokeh",
            clothing = clothes,
            facialExpression = expression,
            visualStyle = style,
            cinematicDetails = "Consistent character model, anatomical precision, Photorealistic skin textures, 8K render, zero face morphing",
            audioDialogue = when (lang) {
                AppLanguage.HINDI -> "चरित्र संवाद: \"मेरा संकल्प ही मेरी पहचान है।\""
                AppLanguage.HINGLISH -> "Character Voice: \"Mera sankalp hi meri asli taqat hai, compromise never.\""
                AppLanguage.ENGLISH -> "Character Voice: \"Integrity is not negotiable. I stand by my code.\""
            },
            negativePrompt = "deformed face, asymmetrical eyes, inconsistent facial structure, multiple people, morphing outfits, cartoonish smoothing, airbrushed plastic skin",
            characterSpec = spec,
            aspectRatio = aspect,
            language = lang
        )
    }

    private fun generateStoryPrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        storyIdea: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption,
        duration: StoryDurationOption
    ): GeneratedPrompt {
        val count = duration.sceneCount
        val sceneDurationSeconds = duration.seconds / count
        val scenes = mutableListOf<ScenePromptItem>()

        val acts = listOf(
            "Inciting Incident: The ordinary world of $character is interrupted when unexpected challenge arises.",
            "Rising Action: $character journeys through $location, discovering critical clues and overcoming obstacle 1.",
            "The Turning Point: A sudden conflict strikes, testing $character's endurance and loyalty.",
            "Darkest Hour: When all hope seems lost, an inner breakthrough ignites renewed willpower.",
            "Climax: $character confronts the ultimate test of $topic in a dramatic showdown.",
            "Resolution: Peace is restored, leaving an inspiring moral footprint for the future."
        )

        for (i in 1..count) {
            val actText = acts[(i - 1) % acts.size]
            val sceneDialogue = when (lang) {
                AppLanguage.HINDI -> when (i) {
                    1 -> "संवाद: \"यहाँ कुछ तो छुपा है... मुझे देखना होगा।\""
                    2 -> "संवाद: \"रास्ता कठिन है, पर इरादे चट्टान जैसे हैं!\""
                    3 -> "संवाद: \"हिम्मत मत हारो, रोशनी ज़रूर दिखेगी!\""
                    else -> "संवाद: \"यही वह क्षण है जिसके लिए हम सबने प्रतीक्षा की थी!\""
                }
                AppLanguage.HINGLISH -> when (i) {
                    1 -> "Dialogue: \"Kismat humein yahan le aayi hai, let's explore!\""
                    2 -> "Dialogue: \"Rukna mana hai, hum apni manzil tak pahunch kar rahenge.\""
                    3 -> "Dialogue: \"Mushkil waqt hi asli hero banata hai!\""
                    else -> "Dialogue: \"And finally, humne kar dikhaya! Sabka sapna sach hua.\""
                }
                AppLanguage.ENGLISH -> when (i) {
                    1 -> "Dialogue: \"There is something extraordinary waiting to be found here.\""
                    2 -> "Dialogue: \"The path is treacherous, but we must push forward!\""
                    3 -> "Dialogue: \"Hold the line! Everything depends on this moment.\""
                    else -> "Dialogue: \"We stood together, and that made all the difference.\""
                }
            }

            scenes.add(
                ScenePromptItem(
                    sceneNumber = i,
                    duration = "${sceneDurationSeconds}s",
                    visualDescription = "Scene $i: $actText Visualized in $location with $character.",
                    characterAction = "$character executes purposeful movement in response to the unfolding plot.",
                    cameraMovement = if (i % 2 == 0) "Fast-paced tracking handheld camera" else "Sweeping cinematic steadycam dolly",
                    lighting = if (i == count) "Brilliant celebratory sunrise rays" else "Deep atmospheric shadows with directional light beams",
                    environment = "$location (Progression Phase $i)",
                    dialogue = sceneDialogue,
                    sfx = "Scene $i environmental foley: footsteps, weather ambiance, tense musical cue",
                    bgm = "Cinematic orchestral score evolving dynamically from tension to triumph",
                    negativePrompt = "blurry, continuity errors, costume shift, deformed anatomy, flicker"
                )
            )
        }

        val fullStoryPrompt = buildString {
            append("FULL STORY SCRIPT & AI PROMPT SEQUENCE (${duration.durationText})\n")
            append("Logline: $storyIdea\n")
            append("Protagonist: $character | World: $location | Style: $style | Aspect: ${aspect.ratio}\n\n")
            scenes.forEach { s ->
                append("=== SCENE ${s.sceneNumber} (${s.duration}) ===\n")
                append("Visual: ${s.visualDescription}\n")
                append("Action: ${s.characterAction}\n")
                append("Camera & Lens: ${s.cameraMovement}, 35mm master\n")
                append("Audio/Dialogue: ${s.dialogue}\n")
                append("SFX/BGM: ${s.sfx} | ${s.bgm}\n\n")
            }
        }

        return GeneratedPrompt(
            title = "$topic (${duration.durationText})",
            category = PromptCategory.STORY,
            fullPromptText = fullStoryPrompt,
            subject = character,
            environment = location,
            cameraAngle = "Multi-camera sequence with cinematic shot grammar",
            cameraMovement = "Narrative arc choreography across $count scenes",
            lighting = "Dynamic time-of-day progression matching story mood",
            background = location,
            clothing = getClothingDesc(character, style),
            facialExpression = "Emotional arc from curiosity to tension to triumph",
            visualStyle = style,
            cinematicDetails = "Continuous story prompts, narrative continuity, character likeness lock",
            audioDialogue = scenes.first().dialogue,
            negativePrompt = "continuity errors, facial identity drift, sudden outfit changes, jitter, poor framerate",
            scenes = scenes,
            aspectRatio = aspect,
            duration = duration.durationText,
            language = lang
        )
    }

    private fun generateScenePrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption
    ): GeneratedPrompt {
        val cameraAngle = "Low-angle dynamic hero framing"
        val cameraMovement = "High-speed tracking shot with rotational orbit ending in Dutch tilt"
        val lighting = "Atmospheric backlighting with tungsten key light and volumetric smoke"
        val clothing = getClothingDesc(character, style)
        val expression = "Adrenaline-fueled laser focus"
        val cinematicDetails = "Shot on Panavision Millennium DXL2, anamorphic 40mm lens, 120fps ultra slow motion, cinematic teal and orange color grade"

        val dialogue = when (lang) {
            AppLanguage.HINDI -> "संवाद: \"नज़र मत हटाना, यह आखिरी मौका है!\""
            AppLanguage.HINGLISH -> "Dialogue: \"Eye on the target, koi galti ki gunjaish nahi hai!\""
            AppLanguage.ENGLISH -> "Dialogue: \"Eyes on the objective. We only get one shot at this!\""
        }

        val promptText = buildString {
            append("Cinematic Scene Prompt: $topic. ")
            append("Subject: $character in $location. ")
            append("Action Choreography: High-intensity movement with dramatic weight and momentum. ")
            append("Camera: $cameraAngle, $cameraMovement. ")
            append("Lighting: $lighting. ")
            append("Wardrobe: $clothing. ")
            append("Audio Direction: $dialogue. ")
            append("Render: $cinematicDetails. Aspect: ${aspect.ratio}")
        }

        val scenes = listOf(
            ScenePromptItem(
                sceneNumber = 1,
                duration = "5s",
                visualDescription = "High-octane opening of $topic. $character accelerates into action.",
                characterAction = "$character bursts into motion with explosive velocity.",
                cameraMovement = cameraMovement,
                lighting = lighting,
                environment = location,
                dialogue = dialogue,
                sfx = "Engine roar, sonic boom whoosh, shattered glass debris clatter",
                bgm = "High-energy hybrid orchestral techno pulse",
                negativePrompt = "motion blur smear, duplicate artifacts, out of focus"
            )
        )

        return GeneratedPrompt(
            title = topic.take(45),
            category = PromptCategory.SCENE,
            fullPromptText = promptText,
            subject = character,
            environment = location,
            cameraAngle = cameraAngle,
            cameraMovement = cameraMovement,
            lighting = lighting,
            background = location,
            clothing = clothing,
            facialExpression = expression,
            visualStyle = style,
            cinematicDetails = cinematicDetails,
            audioDialogue = dialogue,
            negativePrompt = "blurry, jitter, anatomical distortion, low bitrate",
            scenes = scenes,
            aspectRatio = aspect,
            language = lang
        )
    }

    private fun generateShortsPrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption
    ): GeneratedPrompt {
        val negativePrompt = "static boring frame, low energy, small unreadable text, dull colors, horizontal black bars"
        val scenes = listOf(
            ScenePromptItem(
                sceneNumber = 1,
                duration = "3s (THE HOOK)",
                visualDescription = "Fast-paced 9:16 vertical hook! Immediate visual shock displaying $topic. Bold yellow text on screen: 'YOU WON'T BELIEVE THIS!'",
                characterAction = "$character looks directly into lens, pointing dramatically with wide expressive eyes.",
                cameraMovement = "Aggressive snap-zoom into character face from 10 feet to 2 feet in 0.4 seconds",
                lighting = "Vibrant high-saturation ring light and RGB cyber background glows",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "हुक संवाद: \"रुकिए! क्या आपको पता है कि इसके पीछे का असली रहस्य क्या है?\""
                    AppLanguage.HINGLISH -> "Hook Dialogue: \"Wait! Ye secret dekhkar aapke hosh udd jayenge!\""
                    AppLanguage.ENGLISH -> "Hook Dialogue: \"Stop scrolling! You need to see this insane mystery right now!\""
                },
                sfx = "Record scratch sound effect, dramatic boom hit, laser swoosh",
                bgm = "Trending viral Phonk / high-BPM synth baseline",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 2,
                duration = "10s (THE REVEAL)",
                visualDescription = "Rapid cuts displaying three mind-blowing visual angles of $topic. High-energy dynamic animations and kinetic particle effects.",
                characterAction = "$character gestures smoothly as visual overlays and 3D floating graphics appear.",
                cameraMovement = "Dynamic vertical tilt-down with quick whip pans between elements",
                lighting = "High-contrast dynamic volumetric spotlights",
                environment = "$location with floating neon annotations",
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"वैज्ञानिक भी हैरान रह गए जब उन्होंने यह अद्भुत खोज देखी...\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Scientists bhi shock ho gaye jab unhone ye sach dekha!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"Even top researchers couldn't explain what was discovered here...\""
                },
                sfx = "Whoosh transitions, cash register ding, mystery bell toll",
                bgm = "Fast rhythmic viral bass beat continuing",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 3,
                duration = "5s (CALL TO ACTION)",
                visualDescription = "Climactic question screen with pulsating subscribe button graphic and eye-catching ending loop.",
                characterAction = "$character smiles and points down to comments with engaging charisma.",
                cameraMovement = "Slow subtle dolly back with smooth loop transition back to Scene 1",
                lighting = "Warm flattering studio beauty lighting",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "सीटीए: \"कमेंट में बताइए, क्या आप इस पर विश्वास करते हैं? सब्सक्राइब करना न भूलें!\""
                    AppLanguage.HINGLISH -> "CTA: \"Aapko kya lagta hai? Comment karke batao aur follow karo for more!\""
                    AppLanguage.ENGLISH -> "CTA: \"Do you think this is real? Drop your thoughts in the comments and subscribe!\""
                },
                sfx = "Notification bell sound, upbeat chime, pop sound",
                bgm = "High energy music outro with satisfying beat drop",
                negativePrompt = negativePrompt
            )
        )

        val fullText = buildString {
            append("YOUTUBE SHORTS VIRAL PROMPT (9:16 Vertical Master)\n")
            append("Concept: $topic\n")
            append("Pacing: Ultra-fast 3-second hook rule, bold typography, loop-ready outro.\n\n")
            scenes.forEach { s ->
                append("[Shorts Scene ${s.sceneNumber} - ${s.duration}]\n")
                append("Visual Hook: ${s.visualDescription}\n")
                append("Action & Camera: ${s.characterAction} | ${s.cameraMovement}\n")
                append("Narration / Audio: ${s.dialogue}\n")
                append("SFX/Music: ${s.sfx} | ${s.bgm}\n\n")
            }
        }

        return GeneratedPrompt(
            title = "Shorts: ${topic.take(38)}",
            category = PromptCategory.SHORTS,
            fullPromptText = fullText,
            subject = character,
            environment = location,
            cameraAngle = "Vertical 9:16 mobile-optimized portrait framing",
            cameraMovement = "Fast snap zooms and energetic whip pans",
            lighting = "Vibrant saturated high-key studio and RGB accents",
            background = location,
            clothing = "Modern stylish urban creator attire with sharp contrast",
            facialExpression = "Intensely expressive, engaging, dynamic reactions",
            visualStyle = "Hyper-saturated Viral TikTok/Shorts 4K Aesthetic",
            cinematicDetails = "Vertical 9:16 format, high retention visuals, bold subtitles, seamless loop",
            audioDialogue = scenes.first().dialogue,
            negativePrompt = negativePrompt,
            scenes = scenes,
            aspectRatio = AspectRatioOption.PORTRAIT,
            duration = "30s",
            language = lang
        )
    }

    private fun generateKidsPrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption
    ): GeneratedPrompt {
        val clothing = "Adorable oversized colorful bow-tie, tiny cartoon sneakers, and bright yellow overalls"
        val expression = "Hilarious goofy expression with wide sparkly cartoon eyes and cheeky grin"
        val negativePrompt = "scary, dark, violent, realistic human anatomy, muted desaturated colors, sharp terrifying monsters"

        val scenes = listOf(
            ScenePromptItem(
                sceneNumber = 1,
                duration = "4s",
                visualDescription = "Colorful 3D Pixar animated world! $character tips-toes clumsily towards a giant shiny fruit in $location.",
                characterAction = "$character wobbles on one foot, making funny cartoon faces while balancing.",
                cameraMovement = "Bouncy handheld tracking shot following the comical wobbling",
                lighting = "Bright sunshine with candy-colored rainbow hues and fluffy clouds",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "मजेदार संवाद: \"अरे बाप रे! इतना बड़ा तरबूज? आज तो दावत होगी, ही ही ही!\""
                    AppLanguage.HINGLISH -> "Funny Dialogue: \"Arrey baap re! Itna bada watermelon? Aaj toh full party hogi, haha!\""
                    AppLanguage.ENGLISH -> "Funny Dialogue: \"Whoa! Look at that humongous treat! Sneaky time begins, hihi!\""
                },
                sfx = "Cartoon tip-toe xylophone plinks, comical boing spring sound, rubber squeak",
                bgm = "Playful bouncy marimba and cheerful pizzicato strings",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 2,
                duration = "4s",
                visualDescription = "Comedic slapstick moment! A hilarious mishap occurs as $character slips on a peel and goes spinning like a top.",
                characterAction = "$character spins around with dizzy swirly eyes and cartoon stars circling overhead.",
                cameraMovement = "Fast dynamic zoom-in on the spinning face with funny cartoon motion blur",
                lighting = "Warm sunny daylight with sparkles and pop bubbles",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"अरे रुको रुको... मेरी दुनिया घूम रही है! बचाओ!\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Arrey ruko ruko... Mummy meri chakkar aa rahe hain, oof!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"Whoaaaa-whoaaa-whoaaa! Everything is spinning around, help!\""
                },
                sfx = "Comical slide whistle, slip sound, bowling pins falling, cheerful baby giggle",
                bgm = "Fast slapstick cartoon orchestra with trombone wah-wah",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 3,
                duration = "4s",
                visualDescription = "Happy funny ending! All the friendly jungle animals burst into laughter and share the treat together.",
                characterAction = "$character happily does a goofy victory dance, waving directly at the audience.",
                cameraMovement = "Cheerful pull-out wide shot with floating celebratory confetti and balloons",
                lighting = "Golden warm afternoon glow with magical sparkling butterflies",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"हाहाहा! मिलकर खाने का मज़ा ही कुछ और है! बाय बाय दोस्तों!\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Hahaha! Saath milkar khane ka maza hi alag hai! Bye bye dosto!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"Hahaha! Sharing with friends is the best fun ever! See you next time!\""
                },
                sfx = "Group cheer, joyful laughter, party horn toot, confetti pop",
                bgm = "Uplifting celebratory kids fanfare with happy whistle tune",
                negativePrompt = negativePrompt
            )
        )

        val fullText = buildString {
            append("KIDS FUNNY 3D ANIMATION PROMPT (Pixar / Disney 3D Animated Style)\n")
            append("Topic: $topic\n")
            append("Protagonist: $character | World: $location | Style: Vibrant 3D Stylized Cartoon\n\n")
            scenes.forEach { s ->
                append("Scene ${s.sceneNumber} (${s.duration}): ${s.visualDescription}\n")
                append("Slapstick Action: ${s.characterAction}\n")
                append("Audio & Dialogue: ${s.dialogue}\n")
                append("SFX: ${s.sfx} | Music: ${s.bgm}\n\n")
            }
        }

        return GeneratedPrompt(
            title = "Kids: ${topic.take(38)}",
            category = PromptCategory.KIDS,
            fullPromptText = fullText,
            subject = character,
            environment = location,
            cameraAngle = "Low playful child-height camera angles with vibrant depth",
            cameraMovement = "Bouncy animated camera tracking",
            lighting = "Bright, high-key candy sunshine with soft colorful ambient bounce",
            background = "$location with oversized stylized flora and cartoon shapes",
            clothing = clothing,
            facialExpression = expression,
            visualStyle = "3D Pixar Animation / RenderMan / Stylized CGI 4K",
            cinematicDetails = "Vibrant subsurface scattering on cute stylized characters, exaggerated slapstick squash and stretch, zero scary elements",
            audioDialogue = scenes.first().dialogue,
            negativePrompt = negativePrompt,
            scenes = scenes,
            aspectRatio = aspect,
            duration = "30s",
            language = lang
        )
    }

    private fun generateMythologyPrompt(
        seed: Int,
        topic: String,
        character: String,
        location: String,
        style: String,
        lang: AppLanguage,
        aspect: AspectRatioOption
    ): GeneratedPrompt {
        val cameraAngle = "Monumental low-angle divine reverence shot looking up towards the heavens"
        val cameraMovement = "Slow majestic ascending crane shot rising through swirling celestial clouds"
        val lighting = "Blinding divine radiance emanated from cosmic astras, golden ethereal halos, and celestial lightning"
        val clothing = "Sacred pitambar silk dhoti with intricate zari borders, rudraksha and gold armlets, glowing divine ornaments"
        val expression = "Transcendental serenity combined with supreme cosmic authority and cosmic compassion"
        val cinematicDetails = "8K IMAX Epic Vedic Cinematic Masterpiece, sacred geometry aura, volumetric divine mist, photorealistic divine weapons with particle physics"
        val negativePrompt = "disrespectful depiction, westernized generic fantasy, weak lighting, low budget CGI, distorted hands, blurry divine symbols"

        val scenes = listOf(
            ScenePromptItem(
                sceneNumber = 1,
                duration = "5s",
                visualDescription = "Epic opening of the cosmic realm at $location. The skies churn with swirling nebulas and thunderous clouds. $character manifests in divine grandeur.",
                characterAction = "$character opens radiant eyes as the cosmos reverberates with sacred vibrations.",
                cameraMovement = "Slow majestic push-in through celestial temple pillars",
                lighting = "Ethereal blue and golden radiant aura illuminating the cosmos",
                environment = location,
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "वैदिक श्लोक / संवाद: \"यदा यदा हि धर्मस्य ग्लानिर्भवति भारत। अभ्युत्थानमधर्मस्य तदात्मानं सृजाम्यहम्॥\""
                    AppLanguage.HINGLISH -> "Vedic Shloka: \"Dharmo Rakshati Rakshitah! Jab adharm badhta hai, tabhi divya shakti ka aagman hota hai.\""
                    AppLanguage.ENGLISH -> "Divine Proclamation: \"Whenever righteousness falters and dark forces arise, the Supreme descends to restore universal cosmic order.\""
                },
                sfx = "Deep resonant Shankh (Conch shell) blast, celestial bell chime, cosmic thunder roll",
                bgm = "Thunderous Vedic Sanskrit chanting with deep damru beats and divine sitar swells",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 2,
                duration = "5s",
                visualDescription = "Awe-inspiring divine manifestation! Cosmic weapons (Trishul / Sudarshana Chakra) ignite with blinding golden energy particles.",
                characterAction = "$character raises the divine astra, sending waves of golden luminescence across the three worlds.",
                cameraMovement = "Dynamic 360-degree rotational orbit around the radiant deity at 120fps slow motion",
                lighting = "Blinding celestial solar flares and sacred rainbow halos",
                environment = "Heart of $location engulfed in divine illumination",
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "संवाद: \"सत्य सनातन है, अनंत है, और सर्वशक्तिमान है! ॐ नमः शिवाय!\""
                    AppLanguage.HINGLISH -> "Dialogue: \"Satya Sanatan hai, aur adharm ka vinash nishchit hai! Har Har Mahadev!\""
                    AppLanguage.ENGLISH -> "Dialogue: \"Truth is eternal, infinite, and invincible throughout the cosmos!\""
                },
                sfx = "Energetic crackle of celestial lightning, deep resonant Om vibration, damru rhythm",
                bgm = "Climactic orchestral Indian epic score with intense dholak, nagada, and brass horns",
                negativePrompt = negativePrompt
            ),
            ScenePromptItem(
                sceneNumber = 3,
                duration = "5s",
                visualDescription = "Sublime transcendent peace. The cosmic storm subsides as divine blessings descend in a shower of glowing golden parijata flowers.",
                characterAction = "$character bestows the Abhaya Mudra (blessing of fearlessness), smiling with boundless eternal grace.",
                cameraMovement = "Slow ascending crane shot floating up towards the glowing celestial canopy",
                lighting = "Peaceful twilight golden hour bathed in divine nectar rays",
                environment = "$location restored to supreme divine peace",
                dialogue = when (lang) {
                    AppLanguage.HINDI -> "आशीर्वाद: \"ॐ शान्तिः शान्तिः शान्तिः। समस्त लोकों का कल्याण हो।\""
                    AppLanguage.HINGLISH -> "Blessing: \"Sarve bhavantu sukhinah! Har man me shanti aur prem basey.\""
                    AppLanguage.ENGLISH -> "Blessing: \"Om Shanti Shanti Shanti. May peace, courage, and harmony reign across all realms.\""
                },
                sfx = "Gentle rain of divine flowers, soft bansuri flute melody, temple bells",
                bgm = "Soul-stirring meditative Indian classical bansuri and tanpura melody",
                negativePrompt = negativePrompt
            )
        )

        val fullText = buildString {
            append("EPIC VEDIC MYTHOLOGY CINEMATIC PROMPT\n")
            append("Deity/Subject: $character\n")
            append("Cosmic Realm: $location | Topic: $topic\n")
            append("Visual Artistry: $style, Divine Realism, Sacred Iconography, 8K IMAX\n\n")
            scenes.forEach { s ->
                append("=== SCENE ${s.sceneNumber} (${s.duration}) ===\n")
                append("Visual: ${s.visualDescription}\n")
                append("Divine Action: ${s.characterAction}\n")
                append("Camera Choreography: ${s.cameraMovement}\n")
                append("Divine Mantra / Dialogue: ${s.dialogue}\n")
                append("Sacred Audio: SFX: ${s.sfx} | BGM: ${s.bgm}\n\n")
            }
        }

        return GeneratedPrompt(
            title = "Mythology: ${topic.take(38)}",
            category = PromptCategory.MYTHOLOGY,
            fullPromptText = fullText,
            subject = character,
            environment = location,
            cameraAngle = cameraAngle,
            cameraMovement = cameraMovement,
            lighting = lighting,
            background = location,
            clothing = clothing,
            facialExpression = expression,
            visualStyle = style,
            cinematicDetails = cinematicDetails,
            audioDialogue = scenes.first().dialogue,
            negativePrompt = negativePrompt,
            scenes = scenes,
            aspectRatio = aspect,
            duration = "1 Minute",
            language = lang
        )
    }

    private fun getClothingDesc(character: String, style: String): String {
        return when {
            character.contains("astronaut", true) -> "High-tech pressurized carbon-composite spacesuit with glowing cyan HUD visor and tactile life-support pack"
            character.contains("cyber", true) -> "Matte black tactical exoskeleton jacket with embedded neon fiber optics and holographic lapel"
            character.contains("shiva", true) || character.contains("krishna", true) || character.contains("vedic", true) -> "Regal golden silk Pitambar drapery, intricately chased rudraksha armlets, glowing celestial garlands"
            character.contains("rajput", true) || character.contains("warrior", true) -> "Handcrafted saffron angrakha tunic adorned with royal brocade, polished Damascus steel chestplate, royal turban with jeweled feather"
            character.contains("monkey", true) || character.contains("cartoon", true) -> "Vibrant yellow overall shorts, tiny red cape, and comical oversized buttons"
            else -> "Tailored cinematic wardrobe styled with authentic natural fabrics, realistic micro-creases, and detailed textile weave"
        }
    }

    private fun getFacialExpression(seed: Int): String {
        val expressions = listOf(
            "Focused intense concentration with a subtle flicker of fierce determination",
            "Serene tranquil composure with profound emotional depth in eyes",
            "Subtle enigmatic half-smile reflecting hidden wisdom and confidence",
            "Awe-struck wonder with wide eyes reflecting the glowing environment",
            "Steadfast courageous posture radiating quiet commanding authority"
        )
        return expressions[seed % expressions.size]
    }
}
