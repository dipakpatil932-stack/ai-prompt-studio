package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_prompts")
data class SavedPromptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val category: String,
    val fullPromptText: String,
    val negativePrompt: String,
    val audioDialogue: String,
    val aspectRatio: String,
    val duration: String,
    val language: String,
    val scenesJson: String = "",
    val characterSpecJson: String = "",
    val breakdownJson: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
