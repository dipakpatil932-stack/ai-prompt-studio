package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PromptDao {
    @Query("SELECT * FROM saved_prompts ORDER BY timestamp DESC")
    fun getAllSavedPrompts(): Flow<List<SavedPromptEntity>>

    @Query("SELECT * FROM saved_prompts WHERE category = :category ORDER BY timestamp DESC")
    fun getPromptsByCategory(category: String): Flow<List<SavedPromptEntity>>

    @Query("SELECT * FROM saved_prompts WHERE id = :id LIMIT 1")
    suspend fun getPromptById(id: Long): SavedPromptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrompt(prompt: SavedPromptEntity): Long

    @Query("DELETE FROM saved_prompts WHERE id = :id")
    suspend fun deletePromptById(id: Long)

    @Query("DELETE FROM saved_prompts")
    suspend fun deleteAll()

    @Query("UPDATE saved_prompts SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)
}
