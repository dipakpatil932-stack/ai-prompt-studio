package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.NaturePeople
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppLanguage(val code: String, val displayName: String, val badge: String) {
    ENGLISH("en", "English", "EN"),
    HINDI("hi", "हिन्दी", "HI"),
    HINGLISH("hinglish", "Hinglish", "HG")
}

enum class AspectRatioOption(val ratio: String, val label: String, val iconDesc: String) {
    PORTRAIT("9:16", "9:16 (Shorts/Reels)", "Vertical"),
    LANDSCAPE("16:9", "16:9 (Cinematic/YT)", "Landscape"),
    SQUARE("1:1", "1:1 (Square/Feed)", "Square")
}

enum class StoryDurationOption(val durationText: String, val sceneCount: Int, val seconds: Int) {
    SEC_30("30 Seconds", 3, 30),
    MIN_1("1 Minute", 5, 60),
    MIN_3("3 Minutes", 8, 180),
    MIN_5("5 Minutes", 12, 300)
}

enum class PromptCategory(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val defaultAspect: AspectRatioOption,
    val defaultDuration: String,
    val sampleTopic: String,
    val sampleCharacter: String,
    val sampleLocation: String
) {
    IMAGE(
        id = "image",
        title = "AI Image Prompt",
        subtitle = "Photorealistic, 8K & Artistic",
        description = "Hyperdetailed prompts engineered for Midjourney, FLUX.1, DALL-E 3, and Stable Diffusion SDXL.",
        defaultAspect = AspectRatioOption.LANDSCAPE,
        defaultDuration = "",
        sampleTopic = "Cyberpunk rain-soaked street food vendor at night",
        sampleCharacter = "Elderly weathered chef with glowing cybernetic eye",
        sampleLocation = "Futuristic Old Delhi alley with neon lanterns and steam"
    ),
    VIDEO(
        id = "video",
        title = "AI Video Prompt",
        subtitle = "Runway, Sora, Veo & Kling",
        description = "Scene-by-scene prompts with camera velocity, lighting evolution, negative prompts and sound directions.",
        defaultAspect = AspectRatioOption.LANDSCAPE,
        defaultDuration = "10s",
        sampleTopic = "Astronaut discovering glowing crystalline lifeform inside an ice cavern",
        sampleCharacter = "Determined female astrobiologist in high-tech illuminated pressurized spacesuit",
        sampleLocation = "Sub-zero alien glacial cavern on Europa with bioluminescent ice veins"
    ),
    CHARACTER(
        id = "character",
        title = "Character Generator",
        subtitle = "Consistent Master Seeds",
        description = "Generate locked character sheets, facial landmarks, posture, costume guides, and seed retention tags.",
        defaultAspect = AspectRatioOption.SQUARE,
        defaultDuration = "",
        sampleTopic = "Royal Rajput warrior diplomat in 16th century fortress",
        sampleCharacter = "Rana Veer, 32 years old, sharp Rajput features, trimmed royal beard, saffron turban, regal posture",
        sampleLocation = "Amber Palace marble courtyard overlooking twilight desert"
    ),
    STORY(
        id = "story",
        title = "Story Prompt",
        subtitle = "Multi-Scene Narrative (30s–5m)",
        description = "Auto-divided narrative arcs into structured scene cards with timecodes, dialogue, and cinematic visuals.",
        defaultAspect = AspectRatioOption.LANDSCAPE,
        defaultDuration = "1 Minute",
        sampleTopic = "A poor village boy invents a solar water pump from scrap metal",
        sampleCharacter = "Aarav, 12 years old, curious eyes, messy curly hair, patched cotton kurta",
        sampleLocation = "Sun-drenched drought-hit Rajasthani farmland and village workshop"
    ),
    SCENE(
        id = "scene",
        title = "Scene-by-Scene",
        subtitle = "Cinematic Shot Sequences",
        description = "Choreographed camera movement, lighting, transitions, and audio cues for film directors.",
        defaultAspect = AspectRatioOption.LANDSCAPE,
        defaultDuration = "15s",
        sampleTopic = "High-speed electric superbike chase through midnight mountain tunnels",
        sampleCharacter = "Rogue undercover agent in matte-black carbon fiber armor",
        sampleLocation = "Himalayan highway tunnels illuminated by amber sodium vapor lights"
    ),
    SHORTS(
        id = "shorts",
        title = "YouTube Shorts",
        subtitle = "High Hook 9:16 Viral Prompts",
        description = "Fast-paced vertical videos engineered with 3-second visual hooks, bold subtitles, and dynamic pacing.",
        defaultAspect = AspectRatioOption.PORTRAIT,
        defaultDuration = "30s",
        sampleTopic = "Top 3 deepest mysteries buried under the Great Indian Pyramids and Temples",
        sampleCharacter = "Charismatic young archaeologist speaking directly to lens",
        sampleLocation = "Dark underground subterranean vault with golden hieroglyphs"
    ),
    KIDS(
        id = "kids",
        title = "Kids Funny Videos",
        subtitle = "3D Animated Slapstick & Fun",
        description = "Pixar/Dreamworks style 3D cartoon prompts with goofy characters, comedic timing, and hilarious SFX.",
        defaultAspect = AspectRatioOption.LANDSCAPE,
        defaultDuration = "30s",
        sampleTopic = "A mischievous baby monkey trying to steal a giant watermelon from a grumpy elephant",
        sampleCharacter = "Chintu the baby monkey with oversized ears and playful grin",
        sampleLocation = "Colorful sunny jungle glade filled with giant ripe fruits and cartoon flowers"
    ),
    MYTHOLOGY(
        id = "mythology",
        title = "Mythological Videos",
        subtitle = "Vedic Epics & Divine Auras",
        description = "Awe-inspiring cinematic prompts depicting Lord Shiva, Lord Krishna, celestial astras, and cosmic battles.",
        defaultAspect = AspectRatioOption.LANDSCAPE,
        defaultDuration = "1 Minute",
        sampleTopic = "Lord Shiva performing the cosmic Tandava dance on Mount Kailash amidst cosmic storm",
        sampleCharacter = "Bhagwan Shiva with ash-smeared blue body, glowing third eye, crescent moon, and flowing Ganga locks",
        sampleLocation = "Sacred Mount Kailash summit surrounded by swirling nebula galaxies and lightning"
    );

    val icon: ImageVector
        get() = when (this) {
            IMAGE -> Icons.Default.PhotoCamera
            VIDEO -> Icons.Default.Movie
            CHARACTER -> Icons.Default.Face
            STORY -> Icons.Default.ViewCarousel
            SCENE -> Icons.Default.AutoAwesome
            SHORTS -> Icons.Default.Smartphone
            KIDS -> Icons.Default.ChildCare
            MYTHOLOGY -> Icons.Default.NaturePeople
        }
}
