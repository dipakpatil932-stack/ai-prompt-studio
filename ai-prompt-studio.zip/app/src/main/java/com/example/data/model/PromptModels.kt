package com.example.data.model

data class ScenePromptItem(
    val sceneNumber: Int,
    val duration: String,
    val visualDescription: String,
    val characterAction: String,
    val cameraMovement: String,
    val lighting: String,
    val environment: String,
    val dialogue: String,
    val sfx: String,
    val bgm: String,
    val negativePrompt: String
)

data class CharacterSpec(
    val age: String,
    val gender: String,
    val appearance: String,
    val hair: String,
    val face: String,
    val clothes: String,
    val bodyDescription: String,
    val expression: String,
    val personality: String,
    val cinematicStyle: String,
    val keepConsistent: Boolean = true,
    val seedLockGuidance: String = "",
    val turnaroundPrompt: String = ""
)

data class GeneratedPrompt(
    val id: Long = 0,
    val title: String,
    val category: PromptCategory,
    val fullPromptText: String,
    val subject: String,
    val environment: String,
    val cameraAngle: String,
    val cameraMovement: String,
    val lighting: String,
    val background: String,
    val clothing: String,
    val facialExpression: String,
    val visualStyle: String,
    val cinematicDetails: String,
    val audioDialogue: String,
    val negativePrompt: String,
    val scenes: List<ScenePromptItem> = emptyList(),
    val characterSpec: CharacterSpec? = null,
    val aspectRatio: AspectRatioOption = AspectRatioOption.LANDSCAPE,
    val duration: String = "",
    val language: AppLanguage = AppLanguage.ENGLISH,
    val timestamp: Long = System.currentTimeMillis()
)

data class PromptInputState(
    val category: PromptCategory = PromptCategory.IMAGE,
    val topic: String = "",
    val character: String = "",
    val location: String = "",
    val storyIdea: String = "",
    val visualStyle: String = "Cinematic 8K Hyperrealistic",
    val language: AppLanguage = AppLanguage.ENGLISH,
    val duration: String = "10s",
    val storyDuration: StoryDurationOption = StoryDurationOption.MIN_1,
    val aspectRatio: AspectRatioOption = AspectRatioOption.LANDSCAPE,
    val keepCharacterConsistent: Boolean = true,
    val isGenerating: Boolean = false,
    val errorMessage: String? = null
)
