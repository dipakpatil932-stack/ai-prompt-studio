package com.example.data.repository

import com.example.data.local.PromptDao
import com.example.data.local.SavedPromptEntity
import com.example.data.model.AppLanguage
import com.example.data.model.AspectRatioOption
import com.example.data.model.CharacterSpec
import com.example.data.model.GeneratedPrompt
import com.example.data.model.PromptCategory
import com.example.data.model.ScenePromptItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

class PromptRepository(private val promptDao: PromptDao) {

    val allPrompts: Flow<List<GeneratedPrompt>> = promptDao.getAllSavedPrompts().map { entities ->
        entities.map { it.toGeneratedPrompt() }
    }

    fun getPromptsByCategory(category: PromptCategory): Flow<List<GeneratedPrompt>> {
        return promptDao.getPromptsByCategory(category.id).map { entities ->
            entities.map { it.toGeneratedPrompt() }
        }
    }

    suspend fun savePrompt(prompt: GeneratedPrompt): Long {
        return promptDao.insertPrompt(prompt.toEntity())
    }

    suspend fun deletePrompt(id: Long) {
        promptDao.deletePromptById(id)
    }

    suspend fun clearAll() {
        promptDao.deleteAll()
    }

    suspend fun toggleFavorite(id: Long, isFavorite: Boolean) {
        promptDao.updateFavorite(id, isFavorite)
    }

    // Converters
    private fun GeneratedPrompt.toEntity(): SavedPromptEntity {
        val scenesArray = JSONArray()
        scenes.forEach { scene ->
            val obj = JSONObject().apply {
                put("sceneNumber", scene.sceneNumber)
                put("duration", scene.duration)
                put("visualDescription", scene.visualDescription)
                put("characterAction", scene.characterAction)
                put("cameraMovement", scene.cameraMovement)
                put("lighting", scene.lighting)
                put("environment", scene.environment)
                put("dialogue", scene.dialogue)
                put("sfx", scene.sfx)
                put("bgm", scene.bgm)
                put("negativePrompt", scene.negativePrompt)
            }
            scenesArray.put(obj)
        }

        val charObj = characterSpec?.let { spec ->
            JSONObject().apply {
                put("age", spec.age)
                put("gender", spec.gender)
                put("appearance", spec.appearance)
                put("hair", spec.hair)
                put("face", spec.face)
                put("clothes", spec.clothes)
                put("bodyDescription", spec.bodyDescription)
                put("expression", spec.expression)
                put("personality", spec.personality)
                put("cinematicStyle", spec.cinematicStyle)
                put("keepConsistent", spec.keepConsistent)
                put("seedLockGuidance", spec.seedLockGuidance)
                put("turnaroundPrompt", spec.turnaroundPrompt)
            }
        }

        val breakdownObj = JSONObject().apply {
            put("subject", subject)
            put("environment", environment)
            put("cameraAngle", cameraAngle)
            put("cameraMovement", cameraMovement)
            put("lighting", lighting)
            put("background", background)
            put("clothing", clothing)
            put("facialExpression", facialExpression)
            put("visualStyle", visualStyle)
            put("cinematicDetails", cinematicDetails)
        }

        return SavedPromptEntity(
            id = id,
            title = title,
            category = category.id,
            fullPromptText = fullPromptText,
            negativePrompt = negativePrompt,
            audioDialogue = audioDialogue,
            aspectRatio = aspectRatio.ratio,
            duration = duration,
            language = language.code,
            scenesJson = scenesArray.toString(),
            characterSpecJson = charObj?.toString() ?: "",
            breakdownJson = breakdownObj.toString(),
            timestamp = timestamp
        )
    }

    private fun SavedPromptEntity.toGeneratedPrompt(): GeneratedPrompt {
        val resolvedCategory = PromptCategory.values().firstOrNull { it.id == category } ?: PromptCategory.IMAGE
        val resolvedAspect = AspectRatioOption.values().firstOrNull { it.ratio == aspectRatio } ?: AspectRatioOption.LANDSCAPE
        val resolvedLang = AppLanguage.values().firstOrNull { it.code == language } ?: AppLanguage.ENGLISH

        val scenesList = mutableListOf<ScenePromptItem>()
        if (scenesJson.isNotEmpty()) {
            try {
                val array = JSONArray(scenesJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    scenesList.add(
                        ScenePromptItem(
                            sceneNumber = obj.optInt("sceneNumber", i + 1),
                            duration = obj.optString("duration", ""),
                            visualDescription = obj.optString("visualDescription", ""),
                            characterAction = obj.optString("characterAction", ""),
                            cameraMovement = obj.optString("cameraMovement", ""),
                            lighting = obj.optString("lighting", ""),
                            environment = obj.optString("environment", ""),
                            dialogue = obj.optString("dialogue", ""),
                            sfx = obj.optString("sfx", ""),
                            bgm = obj.optString("bgm", ""),
                            negativePrompt = obj.optString("negativePrompt", "")
                        )
                    )
                }
            } catch (_: Exception) { }
        }

        var charSpec: CharacterSpec? = null
        if (characterSpecJson.isNotEmpty()) {
            try {
                val obj = JSONObject(characterSpecJson)
                charSpec = CharacterSpec(
                    age = obj.optString("age", ""),
                    gender = obj.optString("gender", ""),
                    appearance = obj.optString("appearance", ""),
                    hair = obj.optString("hair", ""),
                    face = obj.optString("face", ""),
                    clothes = obj.optString("clothes", ""),
                    bodyDescription = obj.optString("bodyDescription", ""),
                    expression = obj.optString("expression", ""),
                    personality = obj.optString("personality", ""),
                    cinematicStyle = obj.optString("cinematicStyle", ""),
                    keepConsistent = obj.optBoolean("keepConsistent", true),
                    seedLockGuidance = obj.optString("seedLockGuidance", ""),
                    turnaroundPrompt = obj.optString("turnaroundPrompt", "")
                )
            } catch (_: Exception) { }
        }

        var subject = ""
        var environment = ""
        var cameraAngle = ""
        var cameraMovement = ""
        var lighting = ""
        var background = ""
        var clothing = ""
        var facialExpression = ""
        var visualStyle = ""
        var cinematicDetails = ""

        if (breakdownJson.isNotEmpty()) {
            try {
                val obj = JSONObject(breakdownJson)
                subject = obj.optString("subject", "")
                environment = obj.optString("environment", "")
                cameraAngle = obj.optString("cameraAngle", "")
                cameraMovement = obj.optString("cameraMovement", "")
                lighting = obj.optString("lighting", "")
                background = obj.optString("background", "")
                clothing = obj.optString("clothing", "")
                facialExpression = obj.optString("facialExpression", "")
                visualStyle = obj.optString("visualStyle", "")
                cinematicDetails = obj.optString("cinematicDetails", "")
            } catch (_: Exception) { }
        }

        return GeneratedPrompt(
            id = id,
            title = title,
            category = resolvedCategory,
            fullPromptText = fullPromptText,
            subject = subject,
            environment = environment,
            cameraAngle = cameraAngle,
            cameraMovement = cameraMovement,
            lighting = lighting,
            background = background,
            clothing = clothing,
            facialExpression = facialExpression,
            visualStyle = visualStyle,
            cinematicDetails = cinematicDetails,
            audioDialogue = audioDialogue,
            negativePrompt = negativePrompt,
            scenes = scenesList,
            characterSpec = charSpec,
            aspectRatio = resolvedAspect,
            duration = duration,
            language = resolvedLang,
            timestamp = timestamp
        )
    }
}
