package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding Palette
val ElectricIndigo = Color(0xFF6366F1)
val ElectricIndigoLight = Color(0xFF818CF8)
val ElectricIndigoDark = Color(0xFF4338CA)

val CyberCyan = Color(0xFF06B6D4)
val CyberCyanLight = Color(0xFF38BDF8)

val RadiantAmber = Color(0xFFF59E0B)
val RadiantAmberLight = Color(0xFFFBBF24)

val NeonPurple = Color(0xFFA855F7)
val NeonPurpleLight = Color(0xFFC084FC)

val CoralRose = Color(0xFFF43F5E)
val EmeraldMint = Color(0xFF10B981)

// Dark Theme Surfaces
val DarkCanvas = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF121726)
val DarkSurfaceVariant = Color(0xFF1B2236)
val DarkBorder = Color(0xFF28314B)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Light Theme Surfaces
val LightCanvas = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)
