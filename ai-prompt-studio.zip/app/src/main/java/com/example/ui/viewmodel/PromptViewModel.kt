package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppLanguage
import com.example.data.model.AspectRatioOption
import com.example.data.model.GeneratedPrompt
import com.example.data.model.PromptCategory
import com.example.data.model.PromptInputState
import com.example.data.model.StoryDurationOption
import com.example.data.repository.PromptRepository
import com.example.generator.GeminiPromptService
import com.example.generator.PromptSynthesisEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ThemeMode {
    SYSTEM, DARK, LIGHT
}

class PromptViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PromptRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = PromptRepository(db.promptDao())
    }

    private val _inputState = MutableStateFlow(PromptInputState())
    val inputState: StateFlow<PromptInputState> = _inputState.asStateFlow()

    private val _currentPrompt = MutableStateFlow<GeneratedPrompt?>(null)
    val currentPrompt: StateFlow<GeneratedPrompt?> = _currentPrompt.asStateFlow()

    private val _isCurrentPromptSaved = MutableStateFlow(false)
    val isCurrentPromptSaved: StateFlow<Boolean> = _isCurrentPromptSaved.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyCategoryFilter = MutableStateFlow<PromptCategory?>(null)
    val historyCategoryFilter: StateFlow<PromptCategory?> = _historyCategoryFilter.asStateFlow()

    // History stream combined with search & category filter
    val historyPrompts: StateFlow<List<GeneratedPrompt>> = combine(
        repository.allPrompts,
        _historySearchQuery,
        _historyCategoryFilter
    ) { all, query, filter ->
        all.filter { item ->
            val matchesCategory = filter == null || item.category == filter
            val matchesQuery = query.isBlank() ||
                item.title.contains(query, ignoreCase = true) ||
                item.fullPromptText.contains(query, ignoreCase = true) ||
                item.category.title.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setCategory(category: PromptCategory) {
        _inputState.update {
            it.copy(
                category = category,
                aspectRatio = category.defaultAspect,
                duration = if (category.defaultDuration.isNotEmpty()) category.defaultDuration else it.duration
            )
        }
    }

    fun updateTopic(topic: String) {
        _inputState.update { it.copy(topic = topic) }
    }

    fun updateCharacter(character: String) {
        _inputState.update { it.copy(character = character) }
    }

    fun updateLocation(location: String) {
        _inputState.update { it.copy(location = location) }
    }

    fun updateStoryIdea(idea: String) {
        _inputState.update { it.copy(storyIdea = idea) }
    }

    fun updateVisualStyle(style: String) {
        _inputState.update { it.copy(visualStyle = style) }
    }

    fun updateLanguage(language: AppLanguage) {
        _inputState.update { it.copy(language = language) }
    }

    fun updateDuration(duration: String) {
        _inputState.update { it.copy(duration = duration) }
    }

    fun updateStoryDuration(duration: StoryDurationOption) {
        _inputState.update { it.copy(storyDuration = duration) }
    }

    fun updateAspectRatio(aspectRatio: AspectRatioOption) {
        _inputState.update { it.copy(aspectRatio = aspectRatio) }
    }

    fun toggleKeepCharacterConsistent(consistent: Boolean) {
        _inputState.update { it.copy(keepCharacterConsistent = consistent) }
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun setHistoryCategoryFilter(category: PromptCategory?) {
        _historyCategoryFilter.value = category
    }

    fun generatePrompt() {
        viewModelScope.launch {
            _inputState.update { it.copy(isGenerating = true, errorMessage = null) }
            try {
                val state = _inputState.value
                val base = PromptSynthesisEngine.generate(state)
                val finalPrompt = if (GeminiPromptService.isConfigured()) {
                    GeminiPromptService.enhanceWithAi(state, base)
                } else {
                    base
                }
                _currentPrompt.value = finalPrompt
                _isCurrentPromptSaved.value = false
            } catch (e: Exception) {
                _inputState.update { it.copy(errorMessage = e.localizedMessage ?: "Generation failed") }
            } finally {
                _inputState.update { it.copy(isGenerating = false) }
            }
        }
    }

    fun regenerate() {
        generatePrompt()
    }

    fun toggleSaveCurrentPrompt() {
        val prompt = _currentPrompt.value ?: return
        viewModelScope.launch {
            if (_isCurrentPromptSaved.value) {
                if (prompt.id > 0) {
                    repository.deletePrompt(prompt.id)
                }
                _isCurrentPromptSaved.value = false
            } else {
                val newId = repository.savePrompt(prompt)
                _currentPrompt.value = prompt.copy(id = newId)
                _isCurrentPromptSaved.value = true
            }
        }
    }

    fun deletePrompt(id: Long) {
        viewModelScope.launch {
            repository.deletePrompt(id)
            if (_currentPrompt.value?.id == id) {
                _isCurrentPromptSaved.value = false
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
            _isCurrentPromptSaved.value = false
        }
    }

    fun selectPromptFromHistory(prompt: GeneratedPrompt) {
        _currentPrompt.value = prompt
        _isCurrentPromptSaved.value = true
        _inputState.update {
            it.copy(
                category = prompt.category,
                aspectRatio = prompt.aspectRatio,
                language = prompt.language
            )
        }
    }
}
