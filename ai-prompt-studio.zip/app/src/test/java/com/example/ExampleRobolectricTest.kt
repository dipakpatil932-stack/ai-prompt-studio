package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppLanguage
import com.example.data.model.AspectRatioOption
import com.example.data.model.PromptCategory
import com.example.data.model.PromptInputState
import com.example.generator.PromptSynthesisEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AI Prompt Studio", appName)
    }

    @Test
    fun `verify prompt synthesis for image category`() {
        val input = PromptInputState(
            category = PromptCategory.IMAGE,
            topic = "Futuristic Varanasi Ghats",
            language = AppLanguage.HINDI,
            aspectRatio = AspectRatioOption.LANDSCAPE
        )
        val prompt = PromptSynthesisEngine.generate(input)
        assertNotNull(prompt)
        assertEquals(PromptCategory.IMAGE, prompt.category)
        assertTrue(prompt.fullPromptText.contains("16:9"))
        assertTrue(prompt.fullPromptText.contains("Futuristic Varanasi Ghats"))
    }

    @Test
    fun `verify story generator creates multi-scene breakdown`() {
        val input = PromptInputState(
            category = PromptCategory.STORY,
            topic = "Epic Journey of Arjun",
            language = AppLanguage.HINGLISH
        )
        val prompt = PromptSynthesisEngine.generate(input)
        assertNotNull(prompt)
        assertTrue(prompt.scenes.isNotEmpty())
        assertEquals(5, prompt.scenes.size) // Default 1 Minute = 5 scenes
    }

    @Test
    fun `verify character consistency lock`() {
        val input = PromptInputState(
            category = PromptCategory.CHARACTER,
            character = "Detective Vikram Roy",
            keepCharacterConsistent = true
        )
        val prompt = PromptSynthesisEngine.generate(input)
        assertNotNull(prompt.characterSpec)
        assertTrue(prompt.characterSpec!!.keepConsistent)
        assertTrue(prompt.characterSpec!!.seedLockGuidance.contains("--seed"))
    }
}
