package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sentences")
data class SentenceEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val english: String,
    val hindi: String,
    val pronunciationHint: String,
    val category: String,
    val level: String,
    val isDailyBatch: Boolean = false,
    val isBookmarked: Boolean = false,
    val isMastered: Boolean = false,
    val isOnlineUpdate: Boolean = false,
    val practiceCount: Int = 0
)

@Entity(tableName = "vocabulary")
data class VocabularyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val word: String,
    val hindiMeaning: String,
    val pronunciation: String,
    val partOfSpeech: String,
    val exampleEnglish: String,
    val exampleHindi: String,
    val category: String,
    val level: String,
    val isMastered: Boolean = false,
    val isOnlineUpdate: Boolean = false
)

@Entity(tableName = "grammar_lessons")
data class GrammarLessonEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val titleHindi: String,
    val titleEnglish: String,
    val level: String,
    val summaryHindi: String,
    val formula: String,
    val explanationHindi: String,
    val examplesEncoded: String, // Format: "En1|Hi1;;En2|Hi2"
    val tipHindi: String,
    val isCompleted: Boolean = false,
    val isOnlineUpdate: Boolean = false
)

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val titleHindi: String,
    val titleEnglish: String,
    val situationHindi: String,
    val level: String,
    val turnsEncoded: String, // Format: "Speaker|English|Hindi;;..."
    val isCompleted: Boolean = false
)

@Entity(tableName = "quiz_questions")
data class QuizQuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val questionHindi: String,
    val promptEnglish: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctIndex: Int,
    val explanationHindi: String,
    val category: String,
    val level: String,
    val isOnlineUpdate: Boolean = false
)

@Entity(tableName = "practice_attempts")
data class PracticeAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val targetEnglish: String,
    val spokenText: String,
    val accuracyPercent: Int,
    val aiFeedbackHindi: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val id: Int = 1,
    val selectedLevel: String = LearningLevel.BEGINNER.code,
    val xpPoints: Int = 0,
    val streakDays: Int = 1,
    val dailyBatchDate: String = "",
    val lastActiveDate: String = "",
    val quizzesTaken: Int = 0,
    val totalQuizScore: Int = 0,
    val totalQuizQuestions: Int = 0,
    val speakingAttempts: Int = 0,
    val totalSpeakingScore: Int = 0,
    val ttsSpeed: Float = 0.95f
)
