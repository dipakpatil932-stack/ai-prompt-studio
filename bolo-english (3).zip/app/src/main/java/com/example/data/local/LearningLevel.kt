package com.example.data.local

enum class LearningLevel(
    val code: String,
    val titleHindi: String,
    val titleEnglish: String,
    val subtitleHindi: String
) {
    BEGINNER(
        code = "BEGINNER",
        titleHindi = "प्रारंभिक (Beginner)",
        titleEnglish = "Beginner",
        subtitleHindi = "बुनियादी शब्द और रोज़मर्रा के आसान वाक्य"
    ),
    INTERMEDIATE(
        code = "INTERMEDIATE",
        titleHindi = "मध्यम (Intermediate)",
        titleEnglish = "Intermediate",
        subtitleHindi = "बातचीत, दफ़्तर, यात्रा और व्याकरण का अभ्यास"
    ),
    ADVANCED(
        code = "ADVANCED",
        titleHindi = "उन्नत (Advanced)",
        titleEnglish = "Advanced",
        subtitleHindi = "धाराप्रवाह बोलचाल, मुहावरे और प्रभावी वाक्य"
    );

    companion object {
        fun fromCode(code: String): LearningLevel =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: BEGINNER
    }
}
