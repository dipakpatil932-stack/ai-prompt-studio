package com.example.data.seed

import com.example.data.local.GrammarLessonEntity

object GrammarSeed {
    fun getLessons(): List<GrammarLessonEntity> = listOf(
        GrammarLessonEntity(
            titleHindi = "1. Is, Am, Are का सही प्रयोग (वर्तमान स्थिति)",
            titleEnglish = "Use of Is, Am, Are",
            level = "BEGINNER",
            summaryHindi = "जब हम किसी की वर्तमान स्थिति, पहचान, पेशा या गुण बताते हैं (बिना किसी मुख्य क्रिया के), तब Is, Am, Are का उपयोग होता है।",
            formula = "Subject + is / am / are + Noun / Adjective",
            explanationHindi = "• I के साथ हमेशा 'am' लगता है।\n• He, She, It या किसी एक नाम (एकवचन) के साथ 'is' लगता है।\n• You, We, They या बहुवचन के साथ 'are' लगता है।\n• नकारात्मक (Negative) बनाने के लिए is/am/are के बाद 'not' लगाएँ।",
            examplesEncoded = "I am a student.|मैं एक विद्यार्थी हूँ।;;She is very polite.|वह बहुत विनम्र है।;;They are ready for the trip.|वे यात्रा के लिए तैयार हैं।;;He is not busy today.|वह आज व्यस्त नहीं है।",
            tipHindi = "याद रखें: 'I' के साथ कभी भी 'is' या 'are' न लगाएँ—हमेशा 'I am' बोलें।"
        ),
        GrammarLessonEntity(
            titleHindi = "2. Was और Were (भूतकाल की स्थिति)",
            titleEnglish = "Use of Was and Were",
            level = "BEGINNER",
            summaryHindi = "बीते हुए समय (था, थी, थे) में किसी व्यक्ति या चीज़ की स्थिति बताने के लिए Was और Were का उपयोग किया जाता है।",
            formula = "Subject + was / were + Noun / Adjective",
            explanationHindi = "• I, He, She, It और एकवचन के साथ 'was' का प्रयोग होता है।\n• You, We, They और बहुवचन के साथ 'were' का प्रयोग होता है।\n• प्रश्न पूछने के लिए Was/Were को वाक्य की शुरुआत में रखें।",
            examplesEncoded = "I was at home yesterday.|मैं कल घर पर था।;;We were very happy to see you.|हम आपको देखकर बहुत खुश थे।;;The shop was closed in the afternoon.|दोपहर में दुकान बंद थी।;;Were you tired after work?|क्या आप काम के बाद थके हुए थे?",
            tipHindi = "'You' हमेशा बहुवचन क्रिया लेता है, इसलिए 'You was' गलत है — हमेशा 'You were' बोलें।"
        ),
        GrammarLessonEntity(
            titleHindi = "3. Has, Have और Had (पास होना / अधिकार)",
            titleEnglish = "Possession: Has, Have, Had",
            level = "BEGINNER",
            summaryHindi = "जब बताना हो कि किसी के पास कोई वस्तु, रिश्ता या समय है (या भूतकाल में था), तो Has / Have / Had का प्रयोग करें।",
            formula = "Subject + has / have (Present) | had (Past) + Object",
            explanationHindi = "• वर्तमान में I, You, We, They के साथ 'have' लगता है।\n• वर्तमान में He, She, It और एकवचन नाम के साथ 'has' लगता है।\n• भूतकाल (पास था) में सभी कर्ताओं के साथ 'had' लगता है।",
            examplesEncoded = "I have an extra pen.|मेरे पास एक अतिरिक्त पेन है।;;She has a meeting at 4 PM.|शाम 4 बजे उसकी एक मीटिंग है।;;Do you have any questions?|क्या आपके पास कोई सवाल हैं?;;We had a great time yesterday.|कल हमारा समय बहुत अच्छा बीता।",
            tipHindi = "नकारात्मक वाक्यों में 'don't/doesn't' के साथ हमेशा 'have' आता है, 'has' नहीं (जैसे: He doesn't have a car)।"
        ),
        GrammarLessonEntity(
            titleHindi = "4. Present Simple Tense (आदत और दैनिक दिनचर्या)",
            titleEnglish = "Present Simple Tense",
            level = "BEGINNER",
            summaryHindi = "रोज़ाना के काम, आदतें और सामान्य सत्य (ता है, ती है, ते हैं) बताने के लिए Present Simple Tense इस्तेमाल होता है।",
            formula = "Subject + V1 (s/es for He/She/It) + Object",
            explanationHindi = "• I, You, We, They के साथ क्रिया का मूल रूप (V1) लगता है।\n• He, She, It के साथ क्रिया में -s या -es जुड़ता है।\n• सवाल या नकारात्मक वाक्य में 'Do' (I/You/We/They) और 'Does' (He/She/It) का प्रयोग होता है।",
            examplesEncoded = "I wake up at 6 AM daily.|मैं रोज़ सुबह 6 बजे उठता हूँ।;;She speaks English very clearly.|वह बहुत साफ अंग्रेज़ी बोलती है।;;Do you drink tea or coffee?|क्या आप चाय पीते हैं या कॉफी?;;He does not eat spicy food.|वह तीखा खाना नहीं खाता।",
            tipHindi = "जब 'does' का उपयोग हो (जैसे: Does she speak?), तो क्रिया से 's' हटा दें — 'Does she speaks' गलत है!"
        ),
        GrammarLessonEntity(
            titleHindi = "5. Present Continuous Tense (अभी चल रहा काम)",
            titleEnglish = "Present Continuous Tense",
            level = "BEGINNER",
            summaryHindi = "जो काम ठीक अभी बोलते समय हो रहा है (रहा है, रही है, रहे हैं), उसे बताने के लिए इसका उपयोग करते हैं।",
            formula = "Subject + is / am / are + Verb-ing + Object",
            explanationHindi = "• क्रिया के पहले रूप में '-ing' जोड़ें (work -> working, speak -> speaking)।\n• निकट भविष्य की पक्की योजना के लिए भी इसका उपयोग होता है (जैसे: I am leaving tomorrow)।",
            examplesEncoded = "I am practicing spoken English now.|मैं अभी अंग्रेज़ी बोलने का अभ्यास कर रहा हूँ।;;They are waiting outside the gate.|वे गेट के बाहर इंतज़ार कर रहे हैं।;;Is it raining outside?|क्या बाहर बारिश हो रही है?;;We are going to Delhi tonight.|हम आज रात दिल्ली जा रहे हैं।",
            tipHindi = "कुछ क्रियाएँ जैसे know, want, like, understand में आमतौर पर '-ing' नहीं लगता (I know, न कि I am knowing)।"
        ),
        GrammarLessonEntity(
            titleHindi = "6. Articles: A, An और The का सही नियम",
            titleEnglish = "Articles: A, An, The",
            level = "BEGINNER",
            summaryHindi = "संज्ञा (Noun) से पहले 'A', 'An' या 'The' कब लगाना है, यह हिंदी भाषियों के लिए सबसे ज़रूरी नियम है।",
            formula = "A (व्यंजन ध्वनि) | An (स्वर ध्वनि a,e,i,o,u) | The (विशेष/निश्चित)",
            explanationHindi = "• अक्षर नहीं, बल्कि **ध्वनि (Sound)** देखें: 'An hour' (आवर - अ की ध्वनि), 'A university' (यूनिवर्सिटी - य की ध्वनि)।\n• पहली बार किसी चीज़ का ज़िक्र करें तो A/An, और जब दोनों जानते हों कि किस खास चीज़ की बात हो रही है, तो 'The' लगाएँ।",
            examplesEncoded = "I bought a new umbrella.|मैंने एक नया छाता खरीदा।;;Wait for an hour, please.|कृपया एक घंटे इंतज़ार करें।;;Please close the front door.|कृपया सामने वाला दरवाज़ा बंद कर दें।;;He is an honest person.|वह एक ईमानदार व्यक्ति है।",
            tipHindi = "ध्वनि नियम याद रखें: अ, आ, इ, ई, उ, ऊ, ए, ऐ, ओ, औ की आवाज़ आए तो हमेशा 'An' लगाएँ!"
        ),
        GrammarLessonEntity(
            titleHindi = "7. Simple Past Tense (बीता हुआ कल)",
            titleEnglish = "Simple Past Tense",
            level = "INTERMEDIATE",
            summaryHindi = "जो काम भूतकाल में हो चुका है (किया, गया, देखा, बोला), उसे बताने के लिए Verb की 2nd Form (V2) लगती है।",
            formula = "Subject + V2 + Object | Negative: Subject + did not + V1",
            explanationHindi = "• सकारात्मक वाक्यों में हमेशा Verb का दूसरा रूप (went, saw, spoke, bought) आता है।\n• 'did' या 'did not' के बाद हमेशा Verb का पहला रूप (V1) ही आता है!",
            examplesEncoded = "I went to the market yesterday.|मैं कल बाज़ार गया था।;;She sent the email on time.|उसने समय पर ईमेल भेज दिया।;;Did you call me earlier?|क्या आपने मुझे पहले कॉल किया था?;;I did not forget your birthday.|मैं आपका जन्मदिन नहीं भूला।",
            tipHindi = "सबसे आम गलती: 'I didn't went' बोलना गलत है! सही वाक्य है: 'I didn't go'."
        ),
        GrammarLessonEntity(
            titleHindi = "8. Future Plans: Will और Going to",
            titleEnglish = "Future: Will vs Going to",
            level = "INTERMEDIATE",
            summaryHindi = "भविष्य की योजना, वादा या तुरंत लिए गए निर्णय को बताने के लिए 'Will' और 'Going to' का अंतर समझें।",
            formula = "Subject + will + V1 | Subject + is/am/are + going to + V1",
            explanationHindi = "• बातचीत के दौरान तुरंत लिया गया फैसला या वादा = 'will' (I will help you)।\n• पहले से तय की हुई योजना = 'going to' (I am going to start a course next week)।",
            examplesEncoded = "I will call you back in five minutes.|मैं पाँच मिनट में आपको वापस कॉल करूँगा।;;We are going to visit Jaipur next month.|हम अगले महीने जयपुर घूमने जाने वाले हैं।;;Will you attend the meeting today?|क्या आप आज मीटिंग में शामिल होंगे?;;It looks cloudy; it is going to rain.|बादल छाए हैं; बारिश होने वाली है।",
            tipHindi = "'Will' के साथ सभी कर्ताओं (I, He, She, They) के लिए नियम एक जैसा रहता है—कभी V1 में 's' न जोड़ें।"
        ),
        GrammarLessonEntity(
            titleHindi = "9. Modals: Can, Could, Should और Must",
            titleEnglish = "Essential Modal Verbs",
            level = "INTERMEDIATE",
            summaryHindi = "क्षमता, विनम्र अनुरोध, सलाह और अनिवार्यता व्यक्त करने के लिए Modal Verbs का प्रयोग किया जाता है।",
            formula = "Subject + Modal (can/could/should/must) + V1",
            explanationHindi = "• Can = सकता हूँ (क्षमता/अनुमति)\n• Could = विनम्र निवेदन ('क्या आप कृपया...') या भूतकाल की क्षमता\n• Should = चाहिए (सलाह)\n• Must = अवश्य चाहिए (ज़रूरी नियम या पक्का दायित्व)",
            examplesEncoded = "Can you speak English fluently?|क्या आप धाराप्रवाह अंग्रेज़ी बोल सकते हैं?;;Could you please speak slowly?|क्या आप कृपया धीरे बोल सकते हैं?;;You should practice for 15 minutes daily.|आपको रोज़ 15 मिनट अभ्यास करना चाहिए।;;We must wear a helmet while riding.|बाइक चलाते समय हमें हेलमेट अवश्य पहनना चाहिए।",
            tipHindi = "किसी से मदद माँगते समय 'Can you' से ज़्यादा विनम्र और प्रभावशाली 'Could you please' होता है।"
        ),
        GrammarLessonEntity(
            titleHindi = "10. Prepositions: In, On और At (समय व स्थान)",
            titleEnglish = "Prepositions: In, On, At",
            level = "INTERMEDIATE",
            summaryHindi = "समय और जगह बताते समय In, On और At का सही चुनाव वाक्य को बिल्कुल सटीक बनाता है।",
            formula = "At (सटीक समय/जगह) | On (दिन/तारीख/सतह) | In (महीना/साल/बड़ी जगह)",
            explanationHindi = "• समय: At 7 PM (सटीक समय), On Monday / On 15th August (दिन/तारीख), In January / In 2026 / In the morning (महीना/भाग)।\n• जगह: At the bus stop (बिंदु), On the table (सतह), In India / In the room (अंदर/बड़ा क्षेत्र)।",
            examplesEncoded = "The meeting starts at 10 AM.|मीटिंग सुबह 10 बजे शुरू होती है।;;We do not work on Sundays.|हम रविवार को काम नहीं करते।;;My keys are on the study table.|मेरी चाबियाँ स्टडी टेबल पर हैं।;;She lives in Pune with her family.|वह अपने परिवार के साथ पुणे में रहती है।",
            tipHindi = "'Night' के साथ 'at night' बोलते हैं, जबकि 'morning/evening' के साथ 'in the morning / in the evening' लगता है।"
        ),
        GrammarLessonEntity(
            titleHindi = "11. Present Perfect Tense (काम अभी पूरा हुआ है)",
            titleEnglish = "Present Perfect Tense",
            level = "INTERMEDIATE",
            summaryHindi = "जब कोई काम हाल ही में पूरा हुआ हो और उसका असर अभी भी हो (चुका है, कर लिया है), तब Have/Has + V3 लगाते हैं।",
            formula = "Subject + has / have + V3 (Past Participle)",
            explanationHindi = "• I, You, We, They + have + V3 (done, seen, finished, eaten)।\n• He, She, It + has + V3।\n• यदि निश्चित पुराना समय (जैसे yesterday, last year) बताना हो, तो Simple Past लगाएँ, Present Perfect नहीं!",
            examplesEncoded = "I have completed my daily lesson.|मैंने अपना दैनिक पाठ पूरा कर लिया है।;;Have you ever visited Mumbai?|क्या आप कभी मुंबई गए हैं?;;She has already sent the file.|वह पहले ही फ़ाइल भेज चुकी है।;;They have not arrived yet.|वे अभी तक नहीं पहुँचे हैं।",
            tipHindi = "गलत: 'I have seen him yesterday.' -> सही: 'I saw him yesterday.' (कल के लिए V2 लगाएँ)।"
        ),
        GrammarLessonEntity(
            titleHindi = "12. Active से Passive Voice (कर्मवाच्य)",
            titleEnglish = "Active & Passive Voice",
            level = "ADVANCED",
            summaryHindi = "जब काम करने वाले से ज़्यादा काम (Action) महत्वपूर्ण हो—जैसे समाचार, ऑफिस ईमेल और सूचनाएँ—तब Passive Voice का उपयोग होता है।",
            formula = "Object + is/am/are/was/were/will be + V3 (+ by Subject)",
            explanationHindi = "• Active: The manager approved the leave. (मैनेजर ने छुट्टी मंजूर की।)\n• Passive: The leave was approved. (छुट्टी मंजूर कर दी गई।)\n• औपचारिक (Formal) अंग्रेज़ी में Passive Voice बहुत काम आता है।",
            examplesEncoded = "English is spoken all over the world.|पूरी दुनिया में अंग्रेज़ी बोली जाती है।;;Your order has been shipped today.|आपका ऑर्डर आज भेज दिया गया है।;;The issue will be resolved soon.|समस्या का समाधान जल्द कर दिया जाएगा।;;This report was prepared by our team.|यह रिपोर्ट हमारी टीम द्वारा तैयार की गई थी।",
            tipHindi = "Passive Voice में हमेशा Verb की 3rd Form (V3) का ही उपयोग होता है।"
        ),
        GrammarLessonEntity(
            titleHindi = "13. Conditional Sentences (यदि / अगर वाले वाक्य)",
            titleEnglish = "Conditional Sentences (If-Clauses)",
            level = "ADVANCED",
            summaryHindi = "शर्त और परिणाम वाले वाक्य ('अगर ऐसा हुआ तो वैसा होगा') बोलने के तीन मुख्य प्रकार समझें।",
            formula = "Type 1: If + Present, will + V1 | Type 2: If + Past, would + V1",
            explanationHindi = "• Type 1 (संभव शर्त): If you practice daily, you will speak fluently.\n• Type 2 (काल्पनिक स्थिति): If I had more time, I would learn two languages.\n• Type 3 (बीता पछतावा): If you had called earlier, I would have waited.",
            examplesEncoded = "If it rains, we will take a cab.|अगर बारिश हुई, तो हम टैक्सी ले लेंगे।;;If I were you, I would accept the offer.|अगर मैं आपकी जगह होता, तो मैं यह प्रस्ताव स्वीकार कर लेता।;;Call me if you need any help.|अगर आपको कोई मदद चाहिए तो मुझे कॉल करें।;;If you had practiced, you would have passed.|अगर आपने अभ्यास किया होता, तो आप पास हो जाते।",
            tipHindi = "काल्पनिक वाक्यों में सभी कर्ताओं के साथ 'were' का उपयोग सुंदर माना जाता है (जैसे: If I were you)।"
        ),
        GrammarLessonEntity(
            titleHindi = "14. भारतीय हिंदी भाषियों की 5 आम अंग्रेज़ी गलतियाँ",
            titleEnglish = "Common Mistakes to Avoid",
            level = "ADVANCED",
            summaryHindi = "हम अक्सर हिंदी से शब्द-दर-शब्द अनुवाद करने पर कुछ आम गलतियाँ कर बैठते हैं—आइए उन्हें आज ही सुधारें!",
            formula = "सही मुहावरेदार अंग्रेज़ी बोलें, सीधा अनुवाद नहीं",
            explanationHindi = "1. गलत: 'Myself Rahul.' -> सही: 'I am Rahul.' या 'My name is Rahul.'\n2. गलत: 'Revert back' / 'Return back' -> सही: 'Revert' / 'Reply' / 'Return' (back दोबारा न लगाएँ)।\n3. गलत: 'I am having two brothers.' -> सही: 'I have two brothers.'\n4. गलत: 'Pass out from college' -> सही: 'Graduated from college' (pass out का अर्थ बेहोश होना होता है!)।\n5. गलत: 'Discuss about the plan' -> सही: 'Discuss the plan' (about नहीं लगता)।",
            examplesEncoded = "Please reply to my email soon.|कृपया मेरे ईमेल का जल्द जवाब दें।;;We will discuss the project today.|हम आज प्रोजेक्ट पर चर्चा करेंगे।;;I graduated from Pune University.|मैंने पुणे विश्वविद्यालय से स्नातक किया।;;Do not repeat that mistake again.|वह गलती दोबारा न दोहराएँ। (repeat के साथ again नहीं!)",
            tipHindi = "बोलते समय 'Discuss', 'Explain', 'Order' के तुरंत बाद बिना 'about/for' के वस्तु (Object) बोलें।"
        )
    )
}
