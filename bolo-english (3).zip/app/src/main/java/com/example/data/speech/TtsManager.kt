package com.example.data.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class TtsManager(context: Context) {
    private var tts: TextToSpeech? = null
    private var speechRate: Float = 0.95f

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _offlineVoiceAvailable = MutableStateFlow(false)
    val offlineVoiceAvailable: StateFlow<Boolean> = _offlineVoiceAvailable.asStateFlow()

    private val _currentText = MutableStateFlow<String?>(null)
    val currentText: StateFlow<String?> = _currentText.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val indianEnglish = Locale.Builder().setLanguage("en").setRegion("IN").build()
                val res = engine.setLanguage(indianEnglish)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale.US)
                }
                engine.setSpeechRate(speechRate)
                val voice = engine.voice
                _offlineVoiceAvailable.value = voice != null && !voice.isNetworkConnectionRequired
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        _currentText.value = null
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        _currentText.value = null
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        _currentText.value = null
                    }
                })
                _isReady.value = true
            } else {
                Log.e("TtsManager", "TextToSpeech init failed with status $status")
                _isReady.value = false
            }
        }
    }

    fun setRate(rate: Float) {
        speechRate = rate.coerceIn(0.6f, 1.4f)
        tts?.setSpeechRate(speechRate)
    }

    fun speak(text: String, rate: Float = speechRate) {
        val engine = tts ?: return
        if (!_isReady.value || text.isBlank()) return
        engine.setSpeechRate(rate.coerceIn(0.6f, 1.4f))
        _currentText.value = text
        val utteranceId = UUID.randomUUID().toString()
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _currentText.value = null
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        _isReady.value = false
        _isSpeaking.value = false
    }
}
