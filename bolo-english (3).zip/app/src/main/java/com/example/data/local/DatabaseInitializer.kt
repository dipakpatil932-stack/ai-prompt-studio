package com.example.data.local

import android.content.Context
import android.util.Log
import androidx.room.withTransaction
import com.example.data.seed.ConversationAndQuizSeed
import com.example.data.seed.GrammarSeed
import com.example.data.seed.VocabSeed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DatabaseInitializer(
    private val context: Context,
    private val database: BoloDatabase
) {
    suspend fun ensureInitialized() = withContext(Dispatchers.IO) {
        val sentenceDao = database.sentenceDao()
        val vocabDao = database.vocabularyDao()
        val grammarDao = database.grammarDao()
        val conversationDao = database.conversationDao()
        val quizDao = database.quizDao()
        val progressDao = database.progressDao()

        val needsSentences = sentenceDao.getCount() == 0
        val needsVocab = vocabDao.getCount() == 0
        val needsGrammar = grammarDao.getCount() == 0
        val needsConversations = conversationDao.getCount() == 0
        val needsQuizzes = quizDao.getCount() == 0
        val existingProgress = progressDao.getProgressOnce()

        if (needsSentences) {
            val loadedSentences = loadSentencesFromAsset()
            database.withTransaction {
                // Insert in chunks of 500 for smooth SQLite performance
                loadedSentences.chunked(500).forEach { chunk ->
                    sentenceDao.insertAll(chunk)
                }
            }
        }

        database.withTransaction {
            if (needsVocab) vocabDao.insertAll(VocabSeed.getVocabulary())
            if (needsGrammar) grammarDao.insertAll(GrammarSeed.getLessons())
            if (needsConversations) conversationDao.insertAll(ConversationAndQuizSeed.getConversations())
            if (needsQuizzes) quizDao.insertAll(ConversationAndQuizSeed.getQuizQuestions())
        }

        val today = currentDateKey()
        val progress = existingProgress ?: UserProgressEntity(
            id = 1,
            selectedLevel = LearningLevel.BEGINNER.code,
            xpPoints = 0,
            streakDays = 1,
            dailyBatchDate = "",
            lastActiveDate = today
        )

        if (progress.dailyBatchDate != today) {
            val level = progress.selectedLevel
            val picked = sentenceDao.getRandomSentencesForLevel(level, 10)
                .ifEmpty { sentenceDao.getRandomSentences(10) }

            database.withTransaction {
                sentenceDao.clearDailyBatch()
                if (picked.isNotEmpty()) {
                    sentenceDao.markDailyBatch(picked.map { it.id })
                }
                val newStreak = updateStreak(progress.lastActiveDate, today, progress.streakDays)
                progressDao.upsertProgress(
                    progress.copy(
                        dailyBatchDate = today,
                        lastActiveDate = today,
                        streakDays = newStreak
                    )
                )
            }
        } else if (existingProgress == null) {
            progressDao.upsertProgress(progress)
        }
    }

    suspend fun refreshDailyBatchForLevel(levelCode: String) = withContext(Dispatchers.IO) {
        val sentenceDao = database.sentenceDao()
        val progressDao = database.progressDao()
        val picked = sentenceDao.getRandomSentencesForLevel(levelCode, 10)
            .ifEmpty { sentenceDao.getRandomSentences(10) }

        database.withTransaction {
            sentenceDao.clearDailyBatch()
            if (picked.isNotEmpty()) {
                sentenceDao.markDailyBatch(picked.map { it.id })
            }
            val current = progressDao.getProgressOnce() ?: UserProgressEntity()
            progressDao.upsertProgress(
                current.copy(
                    selectedLevel = levelCode,
                    dailyBatchDate = currentDateKey()
                )
            )
        }
    }

    private fun loadSentencesFromAsset(): List<SentenceEntity> {
        val list = ArrayList<SentenceEntity>(5000)
        try {
            context.assets.open("sentences_5000.tsv").use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                    var line: String? = reader.readLine()
                    while (line != null) {
                        val parts = line.split('\t')
                        if (parts.size >= 5) {
                            list.add(
                                SentenceEntity(
                                    english = parts[0],
                                    hindi = parts[1],
                                    pronunciationHint = parts[2],
                                    category = parts[3],
                                    level = parts[4]
                                )
                            )
                        }
                        line = reader.readLine()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("DatabaseInitializer", "Failed reading sentences_5000.tsv", e)
        }
        return list
    }

    private fun currentDateKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun updateStreak(lastDate: String, today: String, currentStreak: Int): Int {
        if (lastDate.isBlank() || lastDate == today) return currentStreak.coerceAtLeast(1)
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val prev = fmt.parse(lastDate)?.time ?: return 1
            val now = fmt.parse(today)?.time ?: return 1
            val diffDays = ((now - prev) / (1000L * 60L * 60L * 24L)).toInt()
            when (diffDays) {
                1 -> currentStreak + 1
                0 -> currentStreak
                else -> 1
            }
        } catch (_: Exception) {
            1
        }
    }
}
