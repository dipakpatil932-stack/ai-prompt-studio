package com.example.data.seed

import com.example.data.local.VocabularyEntity

object VocabSeed {
    fun getVocabulary(): List<VocabularyEntity> = listOf(
        // BEGINNER - Daily Use
        VocabularyEntity(
            word = "Grateful",
            hindiMeaning = "आभारी / कृतज्ञ",
            pronunciation = "ग्रेट-फुल",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "I am very grateful for your support.",
            exampleHindi = "आपके सहयोग के लिए मैं बहुत आभारी हूँ।",
            category = "Emotions",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Schedule",
            hindiMeaning = "समय-सारणी / कार्यक्रम",
            pronunciation = "शेड्यूल / स्केड्यूल",
            partOfSpeech = "Noun / Verb",
            exampleEnglish = "Let us check tomorrow's train schedule.",
            exampleHindi = "चलिए कल की ट्रेन की समय-सारणी देखते हैं।",
            category = "Daily Use",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Purchase",
            hindiMeaning = "खरीदना",
            pronunciation = "पर-चेज़",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "I want to purchase a new notebook.",
            exampleHindi = "मैं एक नई कॉपी खरीदना चाहता हूँ।",
            category = "Shopping",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Polite",
            hindiMeaning = "विनम्र / सभ्य",
            pronunciation = "पो-लाइट",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Always be polite when speaking to elders.",
            exampleHindi = "बड़ों से बात करते समय हमेशा विनम्र रहें।",
            category = "Social",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Delicious",
            hindiMeaning = "स्वादिष्ट",
            pronunciation = "डि-लि-शस",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "My mother cooked a delicious dinner.",
            exampleHindi = "मेरी माँ ने बहुत स्वादिष्ट रात का खाना बनाया।",
            category = "Food",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Borrow",
            hindiMeaning = "उधार लेना",
            pronunciation = "बॉ-रो",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "May I borrow your pen for a minute?",
            exampleHindi = "क्या मैं एक मिनट के लिए आपका पेन उधार ले सकता हूँ?",
            category = "Daily Use",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Lend",
            hindiMeaning = "उधार देना",
            pronunciation = "लेंड",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Could you lend me some change for the bus?",
            exampleHindi = "क्या आप मुझे बस के लिए कुछ छुट्टे पैसे दे सकते हैं?",
            category = "Daily Use",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Arrive",
            hindiMeaning = "पहुँचना / आना",
            pronunciation = "अ-राइव",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "The train will arrive on platform two.",
            exampleHindi = "ट्रेन प्लेटफॉर्म नंबर दो पर आएगी।",
            category = "Travel",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Medicine",
            hindiMeaning = "दवा / औषधि",
            pronunciation = "मे-डि-सिन",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "Take this medicine twice a day after food.",
            exampleHindi = "यह दवा खाने के बाद दिन में दो बार लें।",
            category = "Health",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Comfortable",
            hindiMeaning = "आरामदायक",
            pronunciation = "कम्फर्ट-एबल",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "These shoes are very comfortable for walking.",
            exampleHindi = "ये जूते चलने के लिए बहुत आरामदायक हैं।",
            category = "Shopping",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Prepare",
            hindiMeaning = "तैयारी करना",
            pronunciation = "प्रि-पेयर",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "I am preparing for my English test.",
            exampleHindi = "मैं अपने अंग्रेज़ी टेस्ट की तैयारी कर रहा हूँ।",
            category = "Daily Use",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Remember",
            hindiMeaning = "याद रखना",
            pronunciation = "रि-मेम-बर",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Remember to lock the door before leaving.",
            exampleHindi = "जाने से पहले दरवाज़ा लॉक करना याद रखें।",
            category = "Daily Use",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Healthy",
            hindiMeaning = "स्वस्थ",
            pronunciation = "हेल्-दी",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Fresh fruits keep our body healthy.",
            exampleHindi = "ताज़े फल हमारे शरीर को स्वस्थ रखते हैं।",
            category = "Health",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Reply",
            hindiMeaning = "उत्तर देना / जवाब",
            pronunciation = "रि-प्लाई",
            partOfSpeech = "Verb / Noun",
            exampleEnglish = "Please reply to my message soon.",
            exampleHindi = "कृपया मेरे संदेश का जल्द जवाब दें।",
            category = "Daily Use",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Crowded",
            hindiMeaning = "भीड़-भाड़ वाला",
            pronunciation = "क्राउ-डेड",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "The market is very crowded on Sundays.",
            exampleHindi = "रविवार को बाज़ार में बहुत भीड़ रहती है।",
            category = "Travel",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Receipt",
            hindiMeaning = "रसीद",
            pronunciation = "रि-सीट",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "Always collect your receipt after payment.",
            exampleHindi = "भुगतान के बाद हमेशा अपनी रसीद ज़रूर लें।",
            category = "Shopping",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Urgent",
            hindiMeaning = "अत्यावश्यक / ज़रूरी",
            pronunciation = "अर-जेंट",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "I have an urgent meeting at 11 AM.",
            exampleHindi = "सुबह 11 बजे मेरी एक बेहद ज़रूरी मीटिंग है।",
            category = "Office",
            level = "BEGINNER"
        ),
        VocabularyEntity(
            word = "Explain",
            hindiMeaning = "समझाना / स्पष्ट करना",
            pronunciation = "एक्स-प्लेन",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Could you explain this rule in simple Hindi?",
            exampleHindi = "क्या आप यह नियम सरल हिंदी में समझा सकते हैं?",
            category = "Social",
            level = "BEGINNER"
        ),
        // INTERMEDIATE
        VocabularyEntity(
            word = "Confident",
            hindiMeaning = "आत्मविश्वासी",
            pronunciation = "कॉन-फि-डेंट",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Daily speaking practice makes you confident.",
            exampleHindi = "रोज़ बोलने का अभ्यास आपको आत्मविश्वासी बनाता है।",
            category = "Emotions",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Appreciate",
            hindiMeaning = "सराहना करना / महत्व समझना",
            pronunciation = "अ-प्री-शिएट",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "We really appreciate your quick response.",
            exampleHindi = "हम आपके त्वरित उत्तर की वास्तव में सराहना करते हैं।",
            category = "Office",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Opportunity",
            hindiMeaning = "अवसर / मौका",
            pronunciation = "ऑप-र-च्यू-नि-टी",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "Thank you for giving me this opportunity.",
            exampleHindi = "मुझे यह अवसर देने के लिए धन्यवाद।",
            category = "Office",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Convenient",
            hindiMeaning = "सुविधाजनक",
            pronunciation = "कन-वी-नि-यंट",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Is tomorrow morning convenient for a call?",
            exampleHindi = "क्या कल सुबह कॉल के लिए सुविधाजनक समय रहेगा?",
            category = "Office",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Hesitate",
            hindiMeaning = "हिचकिचाना / संकोच करना",
            pronunciation = "हे-ज़ि-टेट",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Do not hesitate to ask if you have doubts.",
            exampleHindi = "यदि आपको कोई संदेह हो तो पूछने में संकोच न करें।",
            category = "Social",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Affordable",
            hindiMeaning = "किफ़ायती / सस्ता",
            pronunciation = "अ-फोर्ड-एबल",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "This hotel offers clean and affordable rooms.",
            exampleHindi = "यह होटल साफ़ और किफ़ायती कमरे देता है।",
            category = "Shopping",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Symptom",
            hindiMeaning = "लक्षण (बीमारी का)",
            pronunciation = "सिम्प-टम",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "Fever and cough are common flu symptoms.",
            exampleHindi = "बुखार और खाँसी फ्लू के सामान्य लक्षण हैं।",
            category = "Health",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Deadline",
            hindiMeaning = "अंतिम समय-सीमा",
            pronunciation = "डेड-लाइन",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "We must submit the project before the deadline.",
            exampleHindi = "हमें समय-सीमा से पहले प्रोजेक्ट जमा करना होगा।",
            category = "Office",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Postpone",
            hindiMeaning = "टालना / स्थगित करना",
            pronunciation = "पोस्ट-पोन",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "They had to postpone the trip due to rain.",
            exampleHindi = "बारिश के कारण उन्हें यात्रा स्थगित करनी पड़ी।",
            category = "Travel",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Improve",
            hindiMeaning = "सुधार करना",
            pronunciation = "इम-प्रूव",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Reading aloud helps improve pronunciation.",
            exampleHindi = "ज़ोर से पढ़ने से उच्चारण सुधारने में मदद मिलती है।",
            category = "Daily Use",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Encouraging",
            hindiMeaning = "प्रोत्साहित करने वाला",
            pronunciation = "एन-क-रे-जिंग",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Her encouraging words boosted my morale.",
            exampleHindi = "उसके प्रोत्साहन भरे शब्दों ने मेरा मनोबल बढ़ाया।",
            category = "Emotions",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Destination",
            hindiMeaning = "मंज़िल / गंतव्य",
            pronunciation = "डेस-टि-ने-शन",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "We reached our destination safely.",
            exampleHindi = "हम सुरक्षित रूप से अपनी मंज़िल पर पहुँच गए।",
            category = "Travel",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Reliable",
            hindiMeaning = "भरोसेमंद / विश्वसनीय",
            pronunciation = "रि-लाय-एबल",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "This local bus service is very reliable.",
            exampleHindi = "यह स्थानीय बस सेवा बहुत भरोसेमंद है।",
            category = "Travel",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Negotiate",
            hindiMeaning = "मोलभाव करना / बातचीत करना",
            pronunciation = "ने-गो-शिएट",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "You can negotiate the price at local stalls.",
            exampleHindi = "आप स्थानीय दुकानों पर कीमत के लिए मोलभाव कर सकते हैं।",
            category = "Shopping",
            level = "INTERMEDIATE"
        ),
        VocabularyEntity(
            word = "Nutritious",
            hindiMeaning = "पौष्टिक",
            pronunciation = "न्यू-ट्रि-शस",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "A nutritious breakfast keeps you energetic.",
            exampleHindi = "पौष्टिक नाश्ता आपको ऊर्जावान रखता है।",
            category = "Food",
            level = "INTERMEDIATE"
        ),
        // ADVANCED
        VocabularyEntity(
            word = "Fluency",
            hindiMeaning = "धाराप्रवाह बोलने की क्षमता",
            pronunciation = "फ्लू-एन-सी",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "Fluency comes naturally with consistent practice.",
            exampleHindi = "निरंतर अभ्यास से धाराप्रवाह बोलने की क्षमता अपने आप आती है।",
            category = "Social",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Clarify",
            hindiMeaning = "स्पष्ट करना / भ्रम दूर करना",
            pronunciation = "क्लै-रि-फाई",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Let me clarify that point once again.",
            exampleHindi = "मुझे वह बिंदु एक बार फिर स्पष्ट करने दीजिए।",
            category = "Office",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Inconvenience",
            hindiMeaning = "असुविधा / परेशानी",
            pronunciation = "इन-कन-वी-नियंस",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "We apologize for the inconvenience caused.",
            exampleHindi = "हुई असुविधा के लिए हम क्षमा चाहते हैं।",
            category = "Office",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Prioritize",
            hindiMeaning = "प्राथमिकता देना",
            pronunciation = "प्राय-ऑ-रि-टाइज़",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Learn to prioritize important tasks first.",
            exampleHindi = "ज़रूरी कार्यों को पहले प्राथमिकता देना सीखें।",
            category = "Office",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Resilient",
            hindiMeaning = "मज़बूत / कठिन हालात से उबरने वाला",
            pronunciation = "रि-ज़ि-लि-यंट",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Stay resilient even when mistakes happen.",
            exampleHindi = "गलतियाँ होने पर भी हार न मानें और मज़बूत बने रहें।",
            category = "Emotions",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Articulate",
            hindiMeaning = "स्पष्ट व प्रभावशाली ढंग से बोलना",
            pronunciation = "आर-टि-क्यु-लेट",
            partOfSpeech = "Verb / Adjective",
            exampleEnglish = "She can articulate her thoughts very clearly.",
            exampleHindi = "वह अपने विचार बहुत स्पष्ट रूप से व्यक्त कर सकती हैं।",
            category = "Social",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Acknowledge",
            hindiMeaning = "स्वीकार करना / प्राप्ति की सूचना देना",
            pronunciation = "एक-नॉ-लेज",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Please acknowledge receipt of this email.",
            exampleHindi = "कृपया इस ईमेल की प्राप्ति की पुष्टि करें।",
            category = "Office",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Perspective",
            hindiMeaning = "दृष्टिकोण / नज़रिया",
            pronunciation = "पर-स्पेक-टिव",
            partOfSpeech = "Noun (संज्ञा)",
            exampleEnglish = "Reading widens your perspective on life.",
            exampleHindi = "पढ़ने से जीवन के प्रति आपका दृष्टिकोण व्यापक होता है।",
            category = "Social",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Collaborate",
            hindiMeaning = "मिलकर काम करना / सहयोग करना",
            pronunciation = "को-लै-ब-रेट",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Our teams will collaborate on the new launch.",
            exampleHindi = "हमारी टीमें नए लॉन्च पर मिलकर काम करेंगी।",
            category = "Office",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Accommodate",
            hindiMeaning = "समायोजित करना / जगह देना",
            pronunciation = "अ-कॉ-मो-डेट",
            partOfSpeech = "Verb (क्रिया)",
            exampleEnglish = "Can you accommodate a change in our meeting time?",
            exampleHindi = "क्या आप मीटिंग के समय में बदलाव समायोजित कर सकते हैं?",
            category = "Office",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Inevitable",
            hindiMeaning = "अनिवाय / जिसे टाला न जा सके",
            pronunciation = "इन-ए-वि-टेबल",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "Making small mistakes is inevitable when learning.",
            exampleHindi = "सीखते समय छोटी गलतियाँ होना स्वाभाविक और अनिवार्य है।",
            category = "Social",
            level = "ADVANCED"
        ),
        VocabularyEntity(
            word = "Comprehensive",
            hindiMeaning = "विस्तृत / संपूर्ण",
            pronunciation = "कॉम-प्रि-हेन-सिव",
            partOfSpeech = "Adjective (विशेषण)",
            exampleEnglish = "He prepared a comprehensive guide for beginners.",
            exampleHindi = "उन्होंने शुरुआती लोगों के लिए एक विस्तृत गाइड तैयार की।",
            category = "Daily Use",
            level = "ADVANCED"
        )
    )
}
