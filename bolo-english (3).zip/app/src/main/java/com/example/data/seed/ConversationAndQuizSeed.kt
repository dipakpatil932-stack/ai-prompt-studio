package com.example.data.seed

import com.example.data.local.ConversationEntity
import com.example.data.local.QuizQuestionEntity

object ConversationAndQuizSeed {
    fun getConversations(): List<ConversationEntity> = listOf(
        ConversationEntity(
            titleHindi = "सुबह की पहली मुलाकात और परिचय",
            titleEnglish = "Morning Greeting & Self Introduction",
            situationHindi = "किसी नए सहकर्मी या पड़ोसी से पहली बार विनम्रता से मिलना और अपना परिचय देना।",
            level = "BEGINNER",
            turnsEncoded = listOf(
                "Aarav|Good morning! My name is Aarav. May I know your name?|सुप्रभात! मेरा नाम आरव है। क्या मैं आपका नाम जान सकता हूँ?",
                "Priya|Good morning, Aarav! I am Priya. Nice to meet you.|सुप्रभात, आरव! मैं प्रिया हूँ। आपसे मिलकर अच्छा लगा।",
                "Aarav|Nice to meet you too, Priya. Where are you from?|आपसे मिलकर भी अच्छा लगा, प्रिया। आप कहाँ से हैं?",
                "Priya|I am from Jaipur, and I recently moved here for work.|मैं जयपुर से हूँ, और हाल ही में काम के सिलसिले में यहाँ आई हूँ।",
                "Aarav|Welcome to the city! Please let me know if you need any help.|शहर में आपका स्वागत है! अगर आपको कोई मदद चाहिए तो कृपया मुझे बताएं।",
                "Priya|Thank you so much, Aarav. That is very kind of you.|बहुत-बहुत धन्यवाद, आरव। आपकी यह सहृदयता बहुत अच्छी है।"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "रेस्टोरेंट में खाना ऑर्डर करना",
            titleEnglish = "Ordering Food at a Restaurant",
            situationHindi = "होटल या रेस्टोरेंट में टेबल माँगना, मेन्यू से पूछना और बिल मँगवाना।",
            level = "BEGINNER",
            turnsEncoded = listOf(
                "Waiter|Good evening, welcome! A table for two?|शुभ संध्या, स्वागत है! क्या दो लोगों के लिए टेबल चाहिए?",
                "Customer|Yes, please. Could we sit near the window?|जी हाँ, कृपया। क्या हम खिड़की के पास बैठ सकते हैं?",
                "Waiter|Certainly! Here is the menu. Would you like some water first?|बिल्कुल! यह रहा मेन्यू। क्या आप पहले पानी लेना पसंद करेंगे?",
                "Customer|Yes, two glasses of regular water, and please make our food less spicy.|हाँ, दो गिलास सादा पानी, और कृपया हमारा खाना कम तीखा बनाइएगा।",
                "Waiter|Sure, I will inform the chef. What would you like to order?|ज़रूर, मैं शेफ को बता दूँगा। आप क्या ऑर्डर करना चाहेंगे?",
                "Customer|One paneer butter masala with three rotis, and the bill afterwards please.|एक पनीर बटर मसाला तीन रोटियों के साथ, और कृपया बाद में बिल दे दीजिएगा।"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "दुकान पर खरीदारी और मोलभाव",
            titleEnglish = "Shopping & Asking for Discount",
            situationHindi = "कपड़ों या सामान की दुकान में साइज़ पूछना, कीमत जानना और UPI से भुगतान करना।",
            level = "BEGINNER",
            turnsEncoded = listOf(
                "Shopkeeper|Hello! How can I help you today?|नमस्ते! आज मैं आपकी क्या मदद कर सकता हूँ?",
                "Buyer|I am looking for a cotton shirt in medium size.|मैं मीडियम साइज़ में एक कॉटन शर्ट देख रहा हूँ।",
                "Shopkeeper|Here are three colors. How about this navy blue one?|ये तीन रंग हैं। यह नेवी ब्लू वाली कैसी रहेगी?",
                "Buyer|It looks nice! How much does it cost?|यह अच्छी लग रही है! इसकी कीमत कितनी है?",
                "Shopkeeper|It is 900 rupees, sir.|यह 900 रुपये की है, सर।",
                "Buyer|Could you give me a small discount? Do you accept UPI payment?|क्या आप मुझे थोड़ी छूट दे सकते हैं? क्या आप यूपीआई भुगतान लेते हैं?"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "डॉक्टर से स्वास्थ्य पर बातचीत",
            titleEnglish = "Visiting a Doctor",
            situationHindi = "क्लिनिक में अपने लक्षण बताना और दवा लेने का तरीका पूछना।",
            level = "INTERMEDIATE",
            turnsEncoded = listOf(
                "Doctor|Good morning! Please have a seat. What seems to be the problem?|सुप्रभात! कृपया बैठिए। क्या परेशानी हो रही है?",
                "Patient|Doctor, I have been having a mild fever and sore throat since yesterday.|डॉक्टर, मुझे कल से हल्का बुखार और गले में खराश है।",
                "Doctor|Are you also feeling weak or having body ache?|क्या आपको कमज़ोरी या बदन दर्द भी महसूस हो रहा है?",
                "Patient|Yes, a little bit of headache too, especially in the evening.|हाँ, थोड़ा सिरदर्द भी है, खासकर शाम के समय।",
                "Doctor|Nothing to worry about. Take these tablets after meals and drink warm water.|चिंता की कोई बात नहीं है। ये गोलियाँ खाने के बाद लें और गुनगुना पानी पिएं।",
                "Patient|Thank you, doctor. Should I come back for a checkup after three days?|धन्यवाद, डॉक्टर। क्या मुझे तीन दिन बाद फिर से जाँच के लिए आना चाहिए?"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "रेलवे स्टेशन / एयरपोर्ट पर पूछताछ",
            titleEnglish = "Travel & Ticket Inquiry",
            situationHindi = "स्टेशन पर ट्रेन की देरी, प्लेटफॉर्म नंबर और सीट की जानकारी लेना।",
            level = "INTERMEDIATE",
            turnsEncoded = listOf(
                "Traveler|Excuse me, could you tell me which platform the Shatabdi Express arrives on?|माफ़ कीजिए, क्या आप बता सकते हैं कि शताब्दी एक्सप्रेस किस प्लेटफॉर्म पर आती है?",
                "Staff|It usually arrives on platform number four.|यह आमतौर पर प्लेटफॉर्म नंबर चार पर आती है।",
                "Traveler|Is the train running on time today?|क्या आज ट्रेन समय पर चल रही है?",
                "Staff|It is delayed by about twenty minutes due to fog.|कोहरे के कारण यह लगभग बीस मिनट देरी से चल रही है।",
                "Traveler|Thank you for the update. Where is the waiting room?|जानकारी के लिए धन्यवाद। प्रतीक्षालय (वेटिंग रूम) कहाँ है?",
                "Staff|Walk straight ahead and turn left near the bookstall.|सीधे आगे चलें और बुकस्टॉल के पास बाएँ मुड़ें।"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "ऑफिस मीटिंग और डेडलाइन पर चर्चा",
            titleEnglish = "Office Meeting & Project Discussion",
            situationHindi = "मैनेजर या सहकर्मी के साथ काम की प्रगति और समय-सीमा पर पेशेवर बातचीत।",
            level = "INTERMEDIATE",
            turnsEncoded = listOf(
                "Manager|Hi Rohan, could you share an update on the client presentation?|हाय रोहन, क्या आप क्लाइंट प्रेजेंटेशन पर अपडेट साझा कर सकते हैं?",
                "Rohan|Yes, I have completed the data slides and am currently reviewing the summary.|हाँ, मैंने डेटा स्लाइड्स पूरी कर ली हैं और अभी सारांश की समीक्षा कर रहा हूँ।",
                "Manager|Great! Will it be ready before our 4 PM deadline?|बढ़िया! क्या यह शाम 4 बजे की समय-सीमा से पहले तैयार हो जाएगा?",
                "Rohan|Definitely. I will email you the final draft within an hour.|बिल्कुल। मैं एक घंटे के भीतर आपको अंतिम ड्राफ्ट ईमेल कर दूँगा।",
                "Manager|Appreciate your effort. Let us have a quick review call at three.|आपके प्रयास की सराहना करता हूँ। चलिए तीन बजे एक छोटी रिव्यू कॉल करते हैं।",
                "Rohan|Sounds good! I will keep everything ready by then.|ठीक है! मैं तब तक सब कुछ तैयार रखूँगा।"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "नौकरी का इंटरव्यू (Job Interview)",
            titleEnglish = "Job Interview Practice",
            situationHindi = "इंटरव्यू में अपने अनुभव, ताकत और इस नौकरी के प्रति उत्साह के बारे में आत्मविश्वास से बोलना।",
            level = "ADVANCED",
            turnsEncoded = listOf(
                "Interviewer|Welcome! Please tell me a little bit about yourself and your background.|स्वागत है! कृपया अपने और अपनी पृष्ठभूमि के बारे में थोड़ा बताएं।",
                "Candidate|Thank you for this opportunity. I have three years of experience in customer operations and problem solving.|इस अवसर के लिए धन्यवाद। मुझे कस्टमर ऑपरेशंस और समस्या समाधान में तीन साल का अनुभव है।",
                "Interviewer|What would you consider your biggest strength at work?|काम में आप अपनी सबसे बड़ी ताकत किसे मानते हैं?",
                "Candidate|I stay calm under pressure and communicate clearly with both teammates and clients.|मैं दबाव में भी शांत रहता हूँ और टीम तथा क्लाइंट दोनों से स्पष्ट संवाद करता हूँ।",
                "Interviewer|Why do you want to join our organization?|आप हमारी संस्था से क्यों जुड़ना चाहते हैं?",
                "Candidate|Your company values continuous learning, and I am eager to contribute my skills to grow with the team.|आपकी कंपनी निरंतर सीखने को महत्व देती है, और मैं टीम के साथ आगे बढ़ने के लिए अपने कौशल का योगदान देने को उत्सुक हूँ।"
            ).joinToString(";;")
        ),
        ConversationEntity(
            titleHindi = "बैंक में खाता व कार्ड की सहायता",
            titleEnglish = "Bank Visit & Account Help",
            situationHindi = "बैंक में केवाईसी अपडेट या नए डेबिट कार्ड के बारे में बात करना।",
            level = "INTERMEDIATE",
            turnsEncoded = listOf(
                "Customer|Excuse me, I need to update my mobile number linked to my savings account.|माफ़ कीजिए, मुझे अपने बचत खाते से जुड़ा मोबाइल नंबर अपडेट कराना है।",
                "Officer|Sure. Please fill out this KYC update form and attach a copy of your ID.|ज़रूर। कृपया यह केवाईसी अपडेट फॉर्म भरें और अपने पहचान पत्र की कॉपी संलग्न करें।",
                "Customer|How long will it take for the new number to become active?|नया नंबर सक्रिय होने में कितना समय लगेगा?",
                "Officer|It usually takes up to 24 working hours. You will receive an SMS confirmation.|इसमें आमतौर पर 24 कार्य घंटे लगते हैं। आपको एसएमएस से पुष्टि मिल जाएगी।",
                "Customer|Thank you for clarifying that so clearly.|इतनी स्पष्टता से समझाने के लिए धन्यवाद।"
            ).joinToString(";;")
        )
    )

    fun getQuizQuestions(): List<QuizQuestionEntity> = listOf(
        // BEGINNER
        QuizQuestionEntity(
            questionHindi = "'मैं एक विद्यार्थी हूँ' का सही अंग्रेज़ी अनुवाद चुनें:",
            promptEnglish = "Translate into English",
            optionA = "I is a student.",
            optionB = "I am a student.",
            optionC = "I are a student.",
            optionD = "I be a student.",
            correctIndex = 1,
            explanationHindi = "'I' के साथ हमेशा 'am' का प्रयोग होता है — इसलिए 'I am a student.' सही है।",
            category = "Grammar",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "'कृपया धीरे बोलिए' को अंग्रेज़ी में विनम्रता से कैसे कहेंगे?",
            promptEnglish = "Choose the polite English sentence",
            optionA = "Speak slow you.",
            optionB = "Please speak slowly.",
            optionC = "You slowly talking.",
            optionD = "Tell slowly now.",
            correctIndex = 1,
            explanationHindi = "'Please speak slowly.' स्वाभाविक और विनम्र अंग्रेज़ी वाक्य है।",
            category = "Daily Sentences",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "सही Article चुनें: 'Wait for ___ hour.'",
            promptEnglish = "Fill in the blank",
            optionA = "a",
            optionB = "an",
            optionC = "the",
            optionD = "no article",
            correctIndex = 1,
            explanationHindi = "'hour' का उच्चारण 'आवर' (स्वर ध्वनि) से शुरू होता है, 'h' साइलेंट है, इसलिए 'an hour' सही है।",
            category = "Grammar",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "'Grateful' शब्द का सही हिंदी अर्थ क्या है?",
            promptEnglish = "Meaning of 'Grateful'",
            optionA = "नाराज़",
            optionB = "आभारी / कृतज्ञ",
            optionC = "जल्दबाज़",
            optionD = "थका हुआ",
            correctIndex = 1,
            explanationHindi = "'Grateful' का अर्थ 'आभारी' होता है (जैसे: I am grateful to you)।",
            category = "Vocabulary",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "खाली स्थान भरें: 'She ___ English every morning.'",
            promptEnglish = "Present Simple Tense",
            optionA = "practice",
            optionB = "practices",
            optionC = "practicing",
            optionD = "are practice",
            correctIndex = 1,
            explanationHindi = "Present Simple में He/She/It के साथ Verb में -s/-es जुड़ता है ('She practices')।",
            category = "Grammar",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "'मुझे पानी चाहिए' के लिए सबसे विनम्र वाक्य कौन-सा है?",
            promptEnglish = "Polite request",
            optionA = "Give water fast.",
            optionB = "I want water you give.",
            optionC = "Could I have a glass of water, please?",
            optionD = "Bring water me.",
            correctIndex = 2,
            explanationHindi = "'Could I have ..., please?' किसी चीज़ को विनम्रता से माँगने का सबसे अच्छा तरीका है।",
            category = "Conversation",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "'Borrow' और 'Lend' में क्या अंतर है?",
            promptEnglish = "Vocabulary Check",
            optionA = "Borrow = उधार लेना, Lend = उधार देना",
            optionB = "Borrow = खरीदना, Lend = बेचना",
            optionC = "दोनों का अर्थ उधार देना है",
            optionD = "Borrow = खोना, Lend = पाना",
            correctIndex = 0,
            explanationHindi = "किसी से कुछ लेना 'Borrow' कहलाता है, और किसी को कुछ देना 'Lend' कहलाता है।",
            category = "Vocabulary",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "सही वाक्य पहचानें (Past Tense):",
            promptEnglish = "Choose the correct sentence",
            optionA = "You was late yesterday.",
            optionB = "You were late yesterday.",
            optionC = "You are late yesterday.",
            optionD = "You is late yesterday.",
            correctIndex = 1,
            explanationHindi = "'You' के साथ भूतकाल में हमेशा 'were' का प्रयोग होता है।",
            category = "Grammar",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "'Receipt' का सही उच्चारण और अर्थ क्या है?",
            promptEnglish = "Word Check: Receipt",
            optionA = "रि-सीप्ट — खाली कागज़",
            optionB = "रि-सीट — रसीद",
            optionC = "रे-सिप — खाना",
            optionD = "रि-पीट — दोहराना",
            correctIndex = 1,
            explanationHindi = "'Receipt' में 'p' साइलेंट रहता है; इसे 'रि-सीट' पढ़ते हैं और इसका अर्थ 'रसीद' होता है।",
            category = "Vocabulary",
            level = "BEGINNER"
        ),
        QuizQuestionEntity(
            questionHindi = "दुकान पर कीमत पूछने के लिए क्या बोलेंगे?",
            promptEnglish = "Shopping English",
            optionA = "How much does this cost?",
            optionB = "How many cost this?",
            optionC = "What money this?",
            optionD = "Tell price of it.",
            correctIndex = 0,
            explanationHindi = "किसी वस्तु की कीमत पूछने के लिए 'How much does this cost?' बिल्कुल सही और स्वाभाविक वाक्य है।",
            category = "Daily Sentences",
            level = "BEGINNER"
        ),

        // INTERMEDIATE
        QuizQuestionEntity(
            questionHindi = "निम्न में से व्याकरण की दृष्टि से सही वाक्य चुनें:",
            promptEnglish = "Spot the correct sentence",
            optionA = "I did not went to office yesterday.",
            optionB = "I did not go to office yesterday.",
            optionC = "I was not go to office yesterday.",
            optionD = "I have not went to office yesterday.",
            correctIndex = 1,
            explanationHindi = "'did not' के बाद हमेशा Verb का पहला रूप (V1 = go) आता है, 'went' नहीं।",
            category = "Grammar",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "सही Preposition भरें: 'The train arrives ___ 8:30 AM ___ Monday.'",
            promptEnglish = "Prepositions of Time",
            optionA = "in, at",
            optionB = "on, in",
            optionC = "at, on",
            optionD = "at, in",
            correctIndex = 2,
            explanationHindi = "सटीक समय (8:30 AM) से पहले 'at' और दिन (Monday) से पहले 'on' का उपयोग होता है।",
            category = "Grammar",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "'Do not hesitate to ask' का हिंदी अर्थ क्या है?",
            promptEnglish = "Understand the phrase",
            optionA = "पूछने में जल्दबाज़ी न करें",
            optionB = "पूछने में संकोच न करें",
            optionC = "सवाल मत पूछो",
            optionD = "जवाब मत दो",
            correctIndex = 1,
            explanationHindi = "'Hesitate' का अर्थ 'हिचकिचाना या संकोच करना' होता है।",
            category = "Vocabulary",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "'आपकी आवाज़ कट रही है' को फोन कॉल पर अंग्रेज़ी में कैसे बोलेंगे?",
            promptEnglish = "Phone Call English",
            optionA = "Your voice is cutting now.",
            optionB = "Your voice is breaking up a bit.",
            optionC = "Your sound is broken down.",
            optionD = "Voice is stopping again.",
            correctIndex = 1,
            explanationHindi = "अंग्रेज़ी में फोन पर आवाज़ कटने के लिए 'Your voice is breaking up' का उपयोग होता है।",
            category = "Conversation",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "सही विकल्प चुनें: 'He ___ have a car.'",
            promptEnglish = "Negative Possession",
            optionA = "don't",
            optionB = "doesn't",
            optionC = "isn't",
            optionD = "hasn't to",
            correctIndex = 1,
            explanationHindi = "एकवचन 'He' के साथ नकारात्मक वाक्य में 'doesn't have' का प्रयोग होता है।",
            category = "Grammar",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "'Postpone' का अर्थ क्या है?",
            promptEnglish = "Vocabulary Check",
            optionA = "जल्दी करना",
            optionB = "टालना / स्थगित करना",
            optionC = "रद्द करना हमेशा के लिए",
            optionD = "भेजना",
            correctIndex = 1,
            explanationHindi = "किसी कार्यक्रम को आगे की तारीख पर टालने को 'Postpone' कहते हैं (रद्द करने को 'Cancel' कहते हैं)।",
            category = "Vocabulary",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "'आपको रोज़ अभ्यास करना चाहिए' का सही अनुवाद है:",
            promptEnglish = "Using Modals",
            optionA = "You can practice daily.",
            optionB = "You should practice daily.",
            optionC = "You might practice daily.",
            optionD = "You would practice daily.",
            correctIndex = 1,
            explanationHindi = "सलाह देने के लिए ('चाहिए') Modal Verb 'should' का उपयोग होता है।",
            category = "Grammar",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "सही वाक्य चुनें (Present Perfect vs Past):",
            promptEnglish = "Tense Accuracy",
            optionA = "I have met him yesterday.",
            optionB = "I met him yesterday.",
            optionC = "I meet him yesterday.",
            optionD = "I am meeting him yesterday.",
            correctIndex = 1,
            explanationHindi = "'yesterday' जैसे निश्चित भूतकाल समय के साथ Simple Past ('met') लगता है, 'have met' नहीं।",
            category = "Grammar",
            level = "INTERMEDIATE"
        ),
        QuizQuestionEntity(
            questionHindi = "'Convenient' का सही हिंदी अर्थ क्या है?",
            promptEnglish = "Meaning of Convenient",
            optionA = "सुविधाजनक",
            optionB = "कठिन",
            optionC = "ज़रूरी",
            optionD = "आश्चर्यजनक",
            correctIndex = 0,
            explanationHindi = "'Convenient' का अर्थ 'सुविधाजनक / आरामदेह' होता है (जैसे: Is 5 PM convenient for you?)।",
            category = "Vocabulary",
            level = "INTERMEDIATE"
        ),

        // ADVANCED
        QuizQuestionEntity(
            questionHindi = "भारतीय हिंदी भाषियों द्वारा की जाने वाली आम गलती सुधारें — सही वाक्य कौन-सा है?",
            promptEnglish = "Fix the Common Mistake",
            optionA = "Let us discuss about the plan.",
            optionB = "Let us discuss the plan.",
            optionC = "Let us discussing the plan.",
            optionD = "Let us to discuss about plan.",
            correctIndex = 1,
            explanationHindi = "'Discuss' के बाद 'about' का प्रयोग नहीं होता। सही वाक्य 'Let us discuss the plan.' है।",
            category = "Common Mistakes",
            level = "ADVANCED"
        ),
        QuizQuestionEntity(
            questionHindi = "सही Conditional वाक्य चुनें (काल्पनिक स्थिति):",
            promptEnglish = "Second Conditional",
            optionA = "If I was you, I will accept it.",
            optionB = "If I were you, I would accept it.",
            optionC = "If I am you, I would accept it.",
            optionD = "If I were you, I will accept it.",
            correctIndex = 1,
            explanationHindi = "काल्पनिक सलाह ('अगर मैं आपकी जगह होता') के लिए 'If I were you, I would...' का प्रयोग होता है।",
            category = "Grammar",
            level = "ADVANCED"
        ),
        QuizQuestionEntity(
            questionHindi = "Passive Voice चुनें: 'हमारी टीम ने रिपोर्ट तैयार की।'",
            promptEnglish = "Choose correct Passive Voice",
            optionA = "The report was prepare by our team.",
            optionB = "The report was prepared by our team.",
            optionC = "The report is preparing by our team.",
            optionD = "The report prepared our team.",
            correctIndex = 1,
            explanationHindi = "Passive Voice में हमेशा 'was/were + Verb की 3rd form (prepared)' का उपयोग होता है।",
            category = "Grammar",
            level = "ADVANCED"
        ),
        QuizQuestionEntity(
            questionHindi = "'Articulate' का अर्थ क्या है?",
            promptEnglish = "Advanced Vocabulary",
            optionA = "अस्पष्ट बोलना",
            optionB = "विचारों को स्पष्ट व प्रभावशाली ढंग से व्यक्त करना",
            optionC = "चुपचाप सुनना",
            optionD = "बहस करना",
            correctIndex = 1,
            explanationHindi = "'Articulate' का अर्थ अपनी बात को साफ, तार्किक और प्रभावशाली शब्दों में रखना होता है।",
            category = "Vocabulary",
            level = "ADVANCED"
        ),
        QuizQuestionEntity(
            questionHindi = "सही वाक्य चुनें ('Revert back' बनाम सही अंग्रेज़ी):",
            promptEnglish = "Professional Email English",
            optionA = "Please revert back to me soon.",
            optionB = "Please reply to me soon.",
            optionC = "Kindly return back your answer.",
            optionD = "Please repeat again this mail.",
            correctIndex = 1,
            explanationHindi = "'Revert' या 'Return' में 'back' का भाव पहले से होता है, इसलिए 'revert back' अशुद्ध है। 'Please reply to me soon' या 'Please revert' सही है।",
            category = "Common Mistakes",
            level = "ADVANCED"
        ),
        QuizQuestionEntity(
            questionHindi = "'Stay resilient when mistakes happen' का क्या आशय है?",
            promptEnglish = "Understand the expression",
            optionA = "गलतियाँ होने पर काम छोड़ दें",
            optionB = "गलतियाँ होने पर भी हार न मानें और मज़बूत बने रहें",
            optionC = "दूसरों की गलतियाँ निकालें",
            optionD = "गलतियाँ छिपा लें",
            correctIndex = 1,
            explanationHindi = "'Resilient' का अर्थ कठिन परिस्थितियों या असफलता के बाद फिर से मज़बूती से संभल जाना होता है।",
            category = "Vocabulary",
            level = "ADVANCED"
        ),
        QuizQuestionEntity(
            questionHindi = "ऑफिस ईमेल में 'हुई असुविधा के लिए खेद है' को सबसे प्रोफेशनल तरीके से कैसे लिखेंगे?",
            promptEnglish = "Professional Apology",
            optionA = "Sorry for trouble you got.",
            optionB = "We apologize for the inconvenience caused.",
            optionC = "Excuse for the problem happened.",
            optionD = "I am bad for your issue.",
            correctIndex = 1,
            explanationHindi = "'We apologize for the inconvenience caused.' औपचारिक अंग्रेज़ी में सबसे मानक और सम्मानजनक वाक्य है।",
            category = "Conversation",
            level = "ADVANCED"
        )
    )
}
