package com.example.data.ai

import android.util.Log
import com.example.data.local.LearningLevel
import com.example.data.local.QuizQuestionEntity
import com.example.data.local.SentenceEntity
import com.example.data.local.VocabularyEntity
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class MistakeAnalysis(
    val isCorrect: Boolean,
    val correctedEnglish: String,
    val hindiExplanation: String,
    val grammarRuleHindi: String,
    val pronunciationTipHindi: String,
    val betterAlternative: String
)

data class OnlineContentBundle(
    val sentences: List<SentenceEntity>,
    val vocabulary: List<VocabularyEntity>,
    val quizQuestions: List<QuizQuestionEntity>
)

data class TeacherChatTurn(
    val role: String, // "user" or "model"
    val text: String
)

class AiTeacherRepository {
    companion object {
        private const val TAG = "AiTeacherRepository"
        private const val MODEL_NAME = "gemini-3.8-flash"
    }

    private val teacherModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            systemInstruction = content {
                text(
                    """
                    You are 'Priya Ma'am', a warm, encouraging Indian English Teacher in the 'Bolo English' app.
                    Your student speaks Hindi and wants to learn spoken English from basic to advanced.
                    Rules:
                    1. Respond clearly and gently. Keep your English reply natural and easy to understand for the student's level.
                    2. Always include a helpful Hindi translation or explanation in Devanagari so the student understands 100%.
                    3. If the student makes any grammar, spelling, or phrasing mistake in English, kindly point out the exact mistake, explain WHY it was wrong in Hindi, and give the corrected English sentence.
                    4. Keep replies concise (under 150 words) and structured with clear lines, encouraging the student to reply in English.
                    """.trimIndent()
                )
            }
        )
    }

    private val mistakeSchema = Schema.obj(
        properties = mapOf(
            "isCorrect" to Schema.boolean(description = "True if the user's English sentence is grammatically correct and natural"),
            "correctedEnglish" to Schema.string(description = "The corrected, natural English sentence"),
            "hindiExplanation" to Schema.string(description = "Clear explanation in Hindi (Devanagari) explaining any mistake and why the fix works"),
            "grammarRuleHindi" to Schema.string(description = "Short grammar rule summary in Hindi"),
            "pronunciationTipHindi" to Schema.string(description = "Helpful pronunciation tip in Hindi/Hinglish"),
            "betterAlternative" to Schema.string(description = "A polite or more natural daily-conversation alternative in English")
        )
    )

    private val mistakeModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = mistakeSchema
            }
        )
    }

    private val updateSchema = Schema.obj(
        properties = mapOf(
            "sentences" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "english" to Schema.string(),
                        "hindi" to Schema.string(),
                        "pronunciation" to Schema.string(),
                        "category" to Schema.string()
                    )
                ),
                description = "5 fresh daily conversation English sentences with Hindi meanings"
            ),
            "vocabulary" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "word" to Schema.string(),
                        "hindiMeaning" to Schema.string(),
                        "pronunciation" to Schema.string(),
                        "partOfSpeech" to Schema.string(),
                        "exampleEnglish" to Schema.string(),
                        "exampleHindi" to Schema.string(),
                        "category" to Schema.string()
                    )
                ),
                description = "5 useful English vocabulary words with Hindi meaning and example"
            ),
            "quizzes" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "questionHindi" to Schema.string(),
                        "promptEnglish" to Schema.string(),
                        "optionA" to Schema.string(),
                        "optionB" to Schema.string(),
                        "optionC" to Schema.string(),
                        "optionD" to Schema.string(),
                        "correctIndex" to Schema.integer(description = "0, 1, 2, or 3"),
                        "explanationHindi" to Schema.string(),
                        "category" to Schema.string()
                    )
                ),
                description = "3 multiple-choice quiz questions with Hindi explanations"
            )
        )
    )

    private val updateModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = updateSchema
            }
        )
    }

    fun streamTeacherReply(
        history: List<TeacherChatTurn>,
        userMessage: String,
        level: LearningLevel
    ): Flow<String> = flow {
        val chatHistory = history.takeLast(10).map { turn ->
            content(turn.role) { text(turn.text) }
        }
        val promptWithLevel = "[Student Level: ${level.titleEnglish}] $userMessage"
        val chat = teacherModel.startChat(history = chatHistory)
        val accumulated = StringBuilder()

        withTimeout(60_000L) {
            chat.sendMessageStream(promptWithLevel).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
        }
        if (accumulated.isBlank()) {
            throw IllegalStateException("AI Teacher returned an empty response.")
        }
    }

    suspend fun explainMistakeInHindi(
        userSentence: String,
        targetSentence: String?,
        level: LearningLevel
    ): Result<MistakeAnalysis> {
        return try {
            val prompt = buildString {
                appendLine("Analyze this English sentence written or spoken by a Hindi-speaking learner (Level: ${level.titleEnglish}).")
                appendLine("User's English: \"$userSentence\"")
                if (!targetSentence.isNullOrBlank()) {
                    appendLine("Target practice sentence (if comparing): \"$targetSentence\"")
                }
                appendLine("Explain all grammar, tense, preposition, article, or word-choice mistakes clearly in Hindi (Devanagari). If it is already correct, praise in Hindi and give a helpful tip.")
            }

            val response = withTimeout(60_000L) {
                mistakeModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Empty AI response.")
            val json = JSONObject(raw)

            Result.success(
                MistakeAnalysis(
                    isCorrect = json.optBoolean("isCorrect", false),
                    correctedEnglish = json.optString("correctedEnglish", userSentence),
                    hindiExplanation = json.optString("hindiExplanation", ""),
                    grammarRuleHindi = json.optString("grammarRuleHindi", ""),
                    pronunciationTipHindi = json.optString("pronunciationTipHindi", ""),
                    betterAlternative = json.optString("betterAlternative", "")
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Mistake analysis timed out", e)
            Result.failure(Exception("AI विश्लेषण में समय सीमा समाप्त हो गई। कृपया पुनः प्रयास करें।"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Mistake analysis failed", e)
            Result.failure(Exception("AI से संपर्क नहीं हो सका: ${e.localizedMessage ?: "नेटवर्क त्रुटि"}"))
        }
    }

    suspend fun fetchOnlineLessonUpdate(level: LearningLevel): Result<OnlineContentBundle> {
        return try {
            val prompt = """
                Generate fresh English learning content for a Hindi-speaking learner at ${level.titleEnglish} level.
                Provide:
                - 5 new practical daily conversation English sentences (different from basic textbooks), with natural Hindi Devanagari translation, Devanagari pronunciation guide, and category (one of: Greetings, Office, Travel, Shopping, Food, Health, Phone, Social).
                - 5 useful English vocabulary words with Hindi meaning, Devanagari pronunciation, part of speech, and a realistic English + Hindi example sentence.
                - 3 multiple-choice quiz questions testing grammar, translation, or common mistakes made by Hindi speakers, with 4 options, correctIndex (0..3), and a clear Hindi explanation.
            """.trimIndent()

            val response = withTimeout(60_000L) {
                updateModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Empty AI update response.")
            val json = JSONObject(raw)

            val sentencesArr = json.getJSONArray("sentences")
            val sentences = (0 until sentencesArr.length()).map { i ->
                val obj = sentencesArr.getJSONObject(i)
                SentenceEntity(
                    english = obj.getString("english"),
                    hindi = obj.getString("hindi"),
                    pronunciationHint = obj.getString("pronunciation"),
                    category = obj.optString("category", "Social"),
                    level = level.code,
                    isOnlineUpdate = true
                )
            }

            val vocabArr = json.getJSONArray("vocabulary")
            val vocab = (0 until vocabArr.length()).map { i ->
                val obj = vocabArr.getJSONObject(i)
                VocabularyEntity(
                    word = obj.getString("word"),
                    hindiMeaning = obj.getString("hindiMeaning"),
                    pronunciation = obj.getString("pronunciation"),
                    partOfSpeech = obj.optString("partOfSpeech", "Word"),
                    exampleEnglish = obj.getString("exampleEnglish"),
                    exampleHindi = obj.getString("exampleHindi"),
                    category = obj.optString("category", "Daily Use"),
                    level = level.code,
                    isOnlineUpdate = true
                )
            }

            val quizArr = json.getJSONArray("quizzes")
            val quizzes = (0 until quizArr.length()).map { i ->
                val obj = quizArr.getJSONObject(i)
                QuizQuestionEntity(
                    questionHindi = obj.getString("questionHindi"),
                    promptEnglish = obj.getString("promptEnglish"),
                    optionA = obj.getString("optionA"),
                    optionB = obj.getString("optionB"),
                    optionC = obj.getString("optionC"),
                    optionD = obj.getString("optionD"),
                    correctIndex = obj.optInt("correctIndex", 0).coerceIn(0, 3),
                    explanationHindi = obj.getString("explanationHindi"),
                    category = obj.optString("category", "Grammar"),
                    level = level.code,
                    isOnlineUpdate = true
                )
            }

            Result.success(OnlineContentBundle(sentences, vocab, quizzes))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Online update timed out", e)
            Result.failure(Exception("ऑनलाइन अपडेट डाउनलोड करने में समय अधिक लगा। कृपया पुनः प्रयास करें।"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Online update failed", e)
            Result.failure(Exception("ऑनलाइन अपडेट प्राप्त नहीं हो सका: ${e.localizedMessage ?: "नेटवर्क समस्या"}"))
        }
    }
}
