package com.example.data.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class WordMatchResult(
    val word: String,
    val matched: Boolean
)

data class PronunciationEvaluation(
    val accuracyPercent: Int,
    val wordResults: List<WordMatchResult>,
    val feedbackHindi: String
)

sealed interface SpeechUiState {
    data object Idle : SpeechUiState
    data object Listening : SpeechUiState
    data class Partial(val text: String) : SpeechUiState
    data class Result(val text: String) : SpeechUiState
    data class Error(val messageHindi: String) : SpeechUiState
}

class SpeechPracticeManager(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow<SpeechUiState>(SpeechUiState.Idle)
    val state: StateFlow<SpeechUiState> = _state.asStateFlow()

    val isRecognitionAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(preferOffline: Boolean) {
        if (!isRecognitionAvailable) {
            _state.value = SpeechUiState.Error(
                "इस डिवाइस पर स्पीच रिकॉग्निशन सेवा उपलब्ध नहीं है। आप नीचे वाक्य टाइप करके भी अभ्यास कर सकते हैं।"
            )
            return
        }

        try {
            recognizer?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(context.applicationContext)
            recognizer = sr

            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _state.value = SpeechUiState.Listening
                }

                override fun onBeginningOfSpeech() {
                    _state.value = SpeechUiState.Listening
                }

                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "माइक्रोफ़ोन से ऑडियो रिकॉर्ड नहीं हो सका।"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "कृपया माइक्रोफ़ोन की अनुमति (Permission) दें।"
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "ऑफलाइन स्पीच पैक उपलब्ध नहीं होने पर नेटवर्क की आवश्यकता हो सकती है। आप टेक्स्ट लिखकर भी अभ्यास कर सकते हैं।"
                        SpeechRecognizer.ERROR_NO_MATCH -> "आपकी आवाज़ स्पष्ट नहीं समझ आई, कृपया फिर से बोलें।"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "कोई आवाज़ सुनाई नहीं दी। माइक दबाकर स्पष्ट अंग्रेज़ी बोलें।"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "स्पीच सेवा व्यस्त है, कृपया एक सेकंड बाद प्रयास करें।"
                        else -> "स्पीच पहचानने में समस्या आई (कोड $error)। कृपया पुनः प्रयास करें।"
                    }
                    _state.value = SpeechUiState.Error(msg)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = matches?.firstOrNull().orEmpty().trim()
                    if (best.isNotEmpty()) {
                        _state.value = SpeechUiState.Result(best)
                    } else {
                        _state.value = SpeechUiState.Error("आवाज़ समझ नहीं आई, कृपया फिर से प्रयास करें।")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (partial.isNotBlank()) {
                        _state.value = SpeechUiState.Partial(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            }
            _state.value = SpeechUiState.Listening
            sr.startListening(intent)
        } catch (e: Exception) {
            _state.value = SpeechUiState.Error(
                "माइक्रोफ़ोन शुरू नहीं हो सका: ${e.localizedMessage ?: "अज्ञात त्रुटि"}"
            )
        }
    }

    fun stopListening() {
        try {
            recognizer?.stopListening()
        } catch (_: Exception) {
        }
    }

    fun resetState() {
        _state.value = SpeechUiState.Idle
    }

    fun destroy() {
        try {
            recognizer?.destroy()
        } catch (_: Exception) {
        }
        recognizer = null
    }

    companion object {
        fun evaluatePronunciation(target: String, spoken: String): PronunciationEvaluation {
            val cleanTargetWords = normalizeWords(target)
            val cleanSpokenWords = normalizeWords(spoken).toSet()

            if (cleanTargetWords.isEmpty()) {
                return PronunciationEvaluation(0, emptyList(), "कृपया अभ्यास के लिए एक वाक्य चुनें।")
            }
            if (cleanSpokenWords.isEmpty()) {
                return PronunciationEvaluation(
                    0,
                    cleanTargetWords.map { WordMatchResult(it, false) },
                    "कोई शब्द नहीं सुना गया। कृपया स्पष्ट आवाज़ में बोलें।"
                )
            }

            val wordResults = cleanTargetWords.map { word ->
                val isMatch = cleanSpokenWords.contains(word) ||
                    cleanSpokenWords.any { spokenWord -> levenshtein(word, spokenWord) <= 1 && word.length > 3 }
                WordMatchResult(word = word, matched = isMatch)
            }

            val matchedCount = wordResults.count { it.matched }
            val percent = ((matchedCount.toFloat() / cleanTargetWords.size.toFloat()) * 100f)
                .toInt()
                .coerceIn(0, 100)

            val feedback = when {
                percent >= 90 -> "शानदार! आपका उच्चारण बहुत ही सटीक और स्पष्ट है।"
                percent >= 70 -> "बहुत अच्छा! ज़्यादातर शब्द सही थे। लाल रंग के शब्दों का अभ्यास एक बार और करें।"
                percent >= 45 -> "अच्छा प्रयास! स्पीकर बटन से वाक्य सुनकर थोड़ा धीरे-धीरे बोलने की कोशिश करें।"
                else -> "कोई बात नहीं, अभ्यास से ही सुधार होता है। पहले 'सुनें' बटन दबाकर उच्चारण सुनें और फिर बोलें।"
            }

            return PronunciationEvaluation(
                accuracyPercent = percent,
                wordResults = wordResults,
                feedbackHindi = feedback
            )
        }

        private fun normalizeWords(input: String): List<String> =
            input.lowercase()
                .replace(Regex("[^a-z0-9'\\s]"), " ")
                .split(Regex("\\s+"))
                .filter { it.isNotBlank() }

        private fun levenshtein(a: String, b: String): Int {
            val dp = Array(a.length + 1) { IntArray(b.length + 1) }
            for (i in 0..a.length) dp[i][0] = i
            for (j in 0..b.length) dp[0][j] = j
            for (i in 1..a.length) {
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    dp[i][j] = minOf(
                        dp[i - 1][j] + 1,
                        dp[i][j - 1] + 1,
                        dp[i - 1][j - 1] + cost
                    )
                }
            }
            return dp[a.length][b.length]
        }
    }
}
