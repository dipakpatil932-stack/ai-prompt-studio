package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiTeacherRepository
import com.example.data.ai.MistakeAnalysis
import com.example.data.ai.TeacherChatTurn
import com.example.data.local.BoloDatabase
import com.example.data.local.ConversationEntity
import com.example.data.local.DatabaseInitializer
import com.example.data.local.GrammarLessonEntity
import com.example.data.local.LearningLevel
import com.example.data.local.PracticeAttemptEntity
import com.example.data.local.QuizQuestionEntity
import com.example.data.local.SentenceEntity
import com.example.data.local.UserProgressEntity
import com.example.data.local.VocabularyEntity
import com.example.data.network.ConnectivityObserver
import com.example.data.repository.BoloRepository
import com.example.data.speech.PronunciationEvaluation
import com.example.data.speech.SpeechPracticeManager
import com.example.data.speech.SpeechUiState
import com.example.data.speech.TtsManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SentenceFilter(
    val level: String = "ALL",
    val category: String = "ALL",
    val bookmarkedOnly: Boolean = false,
    val query: String = ""
)

data class VocabFilter(
    val level: String = "ALL",
    val category: String = "ALL",
    val query: String = ""
)

data class QuizUiState(
    val selectedLevel: String = "ALL",
    val questions: List<QuizQuestionEntity> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOption: Int? = null,
    val score: Int = 0,
    val isFinished: Boolean = false,
    val isLoading: Boolean = false
)

sealed interface MistakeCheckUiState {
    data object Idle : MistakeCheckUiState
    data object Loading : MistakeCheckUiState
    data class Success(val analysis: MistakeAnalysis) : MistakeCheckUiState
    data class Error(val message: String) : MistakeCheckUiState
}

sealed interface OnlineUpdateUiState {
    data object Idle : OnlineUpdateUiState
    data object Loading : OnlineUpdateUiState
    data class Success(val message: String) : OnlineUpdateUiState
    data class Error(val message: String) : OnlineUpdateUiState
}

data class ChatMessageUi(
    val id: String,
    val isFromTeacher: Boolean,
    val text: String,
    val isStreaming: Boolean = false
)

sealed interface AiChatUiState {
    data object Idle : AiChatUiState
    data object Streaming : AiChatUiState
    data class Error(val message: String) : AiChatUiState
}

class BoloViewModel(application: Application) : AndroidViewModel(application) {
    private val database = BoloDatabase.getInstance(application)
    private val initializer = DatabaseInitializer(application, database)
    private val connectivityObserver = ConnectivityObserver(application)
    private val aiRepository = AiTeacherRepository()
    private val repository = BoloRepository(database, initializer, connectivityObserver, aiRepository)

    val ttsManager = TtsManager(application)
    val speechManager = SpeechPracticeManager(application)

    private val _isInitializing = MutableStateFlow(true)
    val isInitializing: StateFlow<Boolean> = _isInitializing.asStateFlow()

    val isOnline: StateFlow<Boolean> = repository.isOnline

    val progress: StateFlow<UserProgressEntity> = repository.progress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProgressEntity())

    val dailySentences: StateFlow<List<SentenceEntity>> = repository.dailySentences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalSentenceCount: StateFlow<Int> = repository.totalSentenceCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val masteredSentenceCount: StateFlow<Int> = repository.masteredSentenceCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalVocabCount: StateFlow<Int> = repository.totalVocabCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val masteredVocabCount: StateFlow<Int> = repository.masteredVocabCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalGrammarCount: StateFlow<Int> = repository.totalGrammarCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val completedGrammarCount: StateFlow<Int> = repository.completedGrammarCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val sentenceCategories: StateFlow<List<String>> = repository.sentenceCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vocabCategories: StateFlow<List<String>> = repository.vocabCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentAttempts: StateFlow<List<PracticeAttemptEntity>> = repository.recentAttempts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filters
    private val _sentenceFilter = MutableStateFlow(SentenceFilter())
    val sentenceFilter: StateFlow<SentenceFilter> = _sentenceFilter.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val filteredSentences: StateFlow<List<SentenceEntity>> = _sentenceFilter
        .flatMapLatest { f ->
            repository.observeSentences(f.level, f.category, f.bookmarkedOnly, f.query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _vocabFilter = MutableStateFlow(VocabFilter())
    val vocabFilter: StateFlow<VocabFilter> = _vocabFilter.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val filteredVocabulary: StateFlow<List<VocabularyEntity>> = _vocabFilter
        .flatMapLatest { f ->
            repository.observeVocabulary(f.level, f.category, f.query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _grammarLevelFilter = MutableStateFlow("ALL")
    val grammarLevelFilter: StateFlow<String> = _grammarLevelFilter.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val grammarLessons: StateFlow<List<GrammarLessonEntity>> = _grammarLevelFilter
        .flatMapLatest { lvl -> repository.observeGrammarLessons(lvl) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _conversationLevelFilter = MutableStateFlow("ALL")
    val conversationLevelFilter: StateFlow<String> = _conversationLevelFilter.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val conversations: StateFlow<List<ConversationEntity>> = _conversationLevelFilter
        .flatMapLatest { lvl -> repository.observeConversations(lvl) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Speaking Practice State
    private val _practiceSentence = MutableStateFlow(
        SentenceEntity(
            english = "Could you please speak slowly?",
            hindi = "क्या आप कृपया धीरे बोल सकते हैं?",
            pronunciationHint = "कुड यू प्लीज़ स्पीक स्लोली?",
            category = "Greetings",
            level = "BEGINNER"
        )
    )
    val practiceSentence: StateFlow<SentenceEntity> = _practiceSentence.asStateFlow()

    private val _spokenInputText = MutableStateFlow("")
    val spokenInputText: StateFlow<String> = _spokenInputText.asStateFlow()

    private val _evaluation = MutableStateFlow<PronunciationEvaluation?>(null)
    val evaluation: StateFlow<PronunciationEvaluation?> = _evaluation.asStateFlow()

    private val _mistakeState = MutableStateFlow<MistakeCheckUiState>(MistakeCheckUiState.Idle)
    val mistakeState: StateFlow<MistakeCheckUiState> = _mistakeState.asStateFlow()

    // Quiz State
    private val _quizState = MutableStateFlow(QuizUiState())
    val quizState: StateFlow<QuizUiState> = _quizState.asStateFlow()

    // Online Content Update State
    private val _onlineUpdateState = MutableStateFlow<OnlineUpdateUiState>(OnlineUpdateUiState.Idle)
    val onlineUpdateState: StateFlow<OnlineUpdateUiState> = _onlineUpdateState.asStateFlow()

    // AI Teacher Chat State
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessageUi(
                id = "welcome",
                isFromTeacher = true,
                text = "नमस्ते! मैं प्रिया मैम हूँ, आपकी Bolo English AI टीचर। 😊\n" +
                    "आप मुझसे अंग्रेज़ी में कोई भी बात लिखकर या बोलकर पूछ सकते हैं। मैं आपकी अंग्रेज़ी की गलतियाँ प्यार से हिंदी में समझाऊँगी!\n\n" +
                    "Hello! How are you feeling today? Tell me about your day in English!"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessageUi>> = _chatMessages.asStateFlow()

    private val _aiChatState = MutableStateFlow<AiChatUiState>(AiChatUiState.Idle)
    val aiChatState: StateFlow<AiChatUiState> = _aiChatState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeOfflineData()
            _isInitializing.value = false
            startNewQuiz("ALL")
            loadNextPracticeSentence()
        }

        // Sync TTS rate from saved user progress
        viewModelScope.launch {
            progress.collect { p ->
                ttsManager.setRate(p.ttsSpeed)
            }
        }

        // Auto-evaluate whenever SpeechRecognizer yields a final result
        viewModelScope.launch {
            speechManager.state.collect { st ->
                if (st is SpeechUiState.Result) {
                    _spokenInputText.value = st.text
                    evaluateSpokenText(st.text)
                }
            }
        }
    }

    // TTS Actions
    fun speakEnglish(text: String, slow: Boolean = false) {
        val rate = if (slow) 0.72f else progress.value.ttsSpeed
        ttsManager.speak(text, rate)
    }

    fun stopSpeakingTts() {
        ttsManager.stop()
    }

    fun updateTtsSpeed(speed: Float) {
        ttsManager.setRate(speed)
        viewModelScope.launch { repository.updateTtsSpeed(speed) }
    }

    // Level & Daily 10
    fun selectLearningLevel(level: LearningLevel) {
        viewModelScope.launch {
            repository.updateSelectedLevel(level)
        }
    }

    fun refreshDailySentences() {
        viewModelScope.launch {
            val lvl = LearningLevel.fromCode(progress.value.selectedLevel)
            repository.refreshDaily10ForLevel(lvl)
        }
    }

    // Sentence Filters & Actions
    fun updateSentenceFilter(transform: (SentenceFilter) -> SentenceFilter) {
        _sentenceFilter.update(transform)
    }

    fun toggleSentenceBookmark(id: Int) {
        viewModelScope.launch { repository.toggleSentenceBookmark(id) }
    }

    fun setSentenceMastered(id: Int, mastered: Boolean) {
        viewModelScope.launch { repository.setSentenceMastered(id, mastered) }
    }

    // Vocabulary Actions
    fun updateVocabFilter(transform: (VocabFilter) -> VocabFilter) {
        _vocabFilter.update(transform)
    }

    fun toggleVocabMastered(item: VocabularyEntity) {
        viewModelScope.launch { repository.toggleVocabMastered(item.id, item.isMastered) }
    }

    // Grammar Actions
    fun setGrammarLevelFilter(level: String) {
        _grammarLevelFilter.value = level
    }

    fun toggleGrammarCompleted(lesson: GrammarLessonEntity) {
        viewModelScope.launch { repository.toggleGrammarCompleted(lesson.id, lesson.isCompleted) }
    }

    // Conversation Actions
    fun setConversationLevelFilter(level: String) {
        _conversationLevelFilter.value = level
    }

    fun markConversationCompleted(id: Int) {
        viewModelScope.launch { repository.markConversationCompleted(id) }
    }

    // Speaking Practice
    fun setPracticeSentence(sentence: SentenceEntity) {
        _practiceSentence.value = sentence
        _spokenInputText.value = ""
        _evaluation.value = null
        _mistakeState.value = MistakeCheckUiState.Idle
        speechManager.resetState()
    }

    fun loadNextPracticeSentence() {
        viewModelScope.launch {
            val lvl = progress.value.selectedLevel
            val pool = repository.getRandomPracticeSentences(lvl, 10)
            val next = pool.firstOrNull { it.id != _practiceSentence.value.id } ?: pool.firstOrNull()
            if (next != null) {
                setPracticeSentence(next)
            }
        }
    }

    fun startMicPractice() {
        _mistakeState.value = MistakeCheckUiState.Idle
        speechManager.startListening(preferOffline = !isOnline.value)
    }

    fun stopMicPractice() {
        speechManager.stopListening()
    }

    fun updateSpokenInputText(text: String) {
        _spokenInputText.value = text
    }

    fun evaluateSpokenText(spoken: String = _spokenInputText.value) {
        val target = _practiceSentence.value.english
        val eval = SpeechPracticeManager.evaluatePronunciation(target, spoken)
        _evaluation.value = eval
        if (spoken.isNotBlank()) {
            viewModelScope.launch {
                repository.recordSpeakingAttempt(
                    targetEnglish = target,
                    spokenText = spoken,
                    accuracyPercent = eval.accuracyPercent
                )
            }
        }
    }

    fun explainMistakeWithAi(customUserSentence: String? = null, compareWithTarget: Boolean = true) {
        val textToCheck = (customUserSentence ?: _spokenInputText.value).trim()
        if (textToCheck.isBlank()) {
            _mistakeState.value = MistakeCheckUiState.Error("कृपया पहले कोई अंग्रेज़ी वाक्य बोलें या लिखें।")
            return
        }
        viewModelScope.launch {
            _mistakeState.value = MistakeCheckUiState.Loading
            val lvl = LearningLevel.fromCode(progress.value.selectedLevel)
            val target = if (compareWithTarget) _practiceSentence.value.english else null
            val res = repository.explainMistakeInHindi(textToCheck, target, lvl)
            _mistakeState.value = res.fold(
                onSuccess = { MistakeCheckUiState.Success(it) },
                onFailure = { MistakeCheckUiState.Error(it.message ?: "विश्लेषण विफल रहा।") }
            )
        }
    }

    fun clearMistakeResult() {
        _mistakeState.value = MistakeCheckUiState.Idle
    }

    // Quiz Actions
    fun startNewQuiz(level: String = _quizState.value.selectedLevel) {
        viewModelScope.launch {
            _quizState.update { it.copy(selectedLevel = level, isLoading = true) }
            val questions = repository.getQuizRound(level, 8)
            _quizState.value = QuizUiState(
                selectedLevel = level,
                questions = questions,
                currentIndex = 0,
                selectedOption = null,
                score = 0,
                isFinished = false,
                isLoading = false
            )
        }
    }

    fun selectQuizAnswer(optionIndex: Int) {
        val current = _quizState.value
        if (current.selectedOption != null || current.isFinished) return
        val q = current.questions.getOrNull(current.currentIndex) ?: return
        val isCorrect = optionIndex == q.correctIndex
        _quizState.update {
            it.copy(
                selectedOption = optionIndex,
                score = if (isCorrect) it.score + 1 else it.score
            )
        }
    }

    fun nextQuizQuestion() {
        val current = _quizState.value
        val nextIdx = current.currentIndex + 1
        if (nextIdx >= current.questions.size) {
            _quizState.update { it.copy(isFinished = true) }
            viewModelScope.launch {
                repository.recordQuizCompletion(current.score, current.questions.size)
            }
        } else {
            _quizState.update {
                it.copy(currentIndex = nextIdx, selectedOption = null)
            }
        }
    }

    // AI Teacher Chat Actions
    fun sendTeacherMessage(message: String) {
        val trimmed = message.trim()
        if (trimmed.isBlank()) return
        if (!repository.checkOnlineNow()) {
            _aiChatState.value = AiChatUiState.Error(
                "इंटरनेट कनेक्शन उपलब्ध नहीं है। इंटरनेट वापस आने पर AI टीचर जवाब देगा—तब तक ऑफलाइन पाठ जारी रखें।"
            )
            return
        }

        val userMsg = ChatMessageUi(
            id = "u_${System.currentTimeMillis()}",
            isFromTeacher = false,
            text = trimmed
        )
        val modelId = "m_${System.currentTimeMillis() + 1}"
        val historyTurns = _chatMessages.value
            .drop(1) // Skip initial static greeting
            .map { TeacherChatTurn(role = if (it.isFromTeacher) "model" else "user", text = it.text) }

        _chatMessages.update {
            it + userMsg + ChatMessageUi(
                id = modelId,
                isFromTeacher = true,
                text = "",
                isStreaming = true
            )
        }
        _aiChatState.value = AiChatUiState.Streaming

        viewModelScope.launch {
            val lvl = LearningLevel.fromCode(progress.value.selectedLevel)
            try {
                repository.streamTeacherChat(historyTurns, trimmed, lvl).collect { partialText ->
                    _chatMessages.update { list ->
                        list.map { msg ->
                            if (msg.id == modelId) msg.copy(text = partialText, isStreaming = true) else msg
                        }
                    }
                }
                _chatMessages.update { list ->
                    list.map { msg ->
                        if (msg.id == modelId) msg.copy(isStreaming = false) else msg
                    }
                }
                _aiChatState.value = AiChatUiState.Idle
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("BoloViewModel", "AI Teacher chat failed", e)
                _chatMessages.update { list ->
                    list.filterNot { it.id == modelId && it.text.isBlank() }
                        .map { if (it.id == modelId) it.copy(isStreaming = false) else it }
                }
                _aiChatState.value = AiChatUiState.Error(
                    e.localizedMessage ?: "AI टीचर से जुड़ने में त्रुटि हुई। कृपया पुनः प्रयास करें।"
                )
            }
        }
    }

    fun clearAiChatError() {
        _aiChatState.value = AiChatUiState.Idle
    }

    // Online Content Updates
    fun downloadOnlineUpdates() {
        viewModelScope.launch {
            _onlineUpdateState.value = OnlineUpdateUiState.Loading
            val lvl = LearningLevel.fromCode(progress.value.selectedLevel)
            val result = repository.downloadOnlineLessonUpdates(lvl)
            _onlineUpdateState.value = result.fold(
                onSuccess = { OnlineUpdateUiState.Success(it) },
                onFailure = { OnlineUpdateUiState.Error(it.message ?: "अपडेट विफल रहा।") }
            )
        }
    }

    fun dismissOnlineUpdateStatus() {
        _onlineUpdateState.value = OnlineUpdateUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        speechManager.destroy()
        connectivityObserver.unregister()
    }
}
