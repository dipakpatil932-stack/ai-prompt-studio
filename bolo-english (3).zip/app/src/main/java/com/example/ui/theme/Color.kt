package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Editorial Learning Palette — Saffron Sun & Royal Indigo
val RoyalIndigo = Color(0xFF1E3A8A)
val RoyalIndigoLight = Color(0xFF3B5BDB)
val RoyalIndigoContainer = Color(0xFFE0E7FF)
val OnRoyalIndigoContainer = Color(0xFF112255)

val SaffronOrange = Color(0xFFE85D04)
val SaffronOrangeBright = Color(0xFFFF6B2C)
val SaffronContainer = Color(0xFFFFEDE1)
val OnSaffronContainer = Color(0xFF5C2200)

val EmeraldTeal = Color(0xFF0F766E)
val EmeraldTealBright = Color(0xFF14B8A6)
val EmeraldContainer = Color(0xFFCCFBF1)
val OnEmeraldContainer = Color(0xFF063D38)

val WarmIvory = Color(0xFFFDFBF7)
val WarmSurface = Color(0xFFFFFFFF)
val SoftSand = Color(0xFFF4EFE6)
val SoftSandBorder = Color(0xFFE5DDD0)

val InkPrimary = Color(0xFF181D27)
val InkSecondary = Color(0xFF535D6E)

val StatusAmberBg = Color(0xFFFFF4D6)
val StatusAmberText = Color(0xFF8A5200)
val ErrorCoral = Color(0xFFDC2626)
val ErrorCoralBg = Color(0xFFFEE2E2)

// Dark Theme Tokens
val DarkBackground = Color(0xFF0E1422)
val DarkSurface = Color(0xFF172033)
val DarkSurfaceVariant = Color(0xFF212D45)
val DarkPrimary = Color(0xFF93B4FF)
val DarkPrimaryContainer = Color(0xFF1E3A8A)
val DarkSecondary = Color(0xFFFF9B61)
val DarkSecondaryContainer = Color(0xFF6B2D05)
val DarkTertiary = Color(0xFF5EEAD4)
val DarkTertiaryContainer = Color(0xFF0F524C)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFFB6C2D4)
