package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.LearningLevel
import com.example.data.speech.SpeechUiState
import com.example.ui.components.OnlineStatusBadge
import com.example.ui.viewmodel.AiChatUiState
import com.example.ui.viewmodel.ChatMessageUi
import com.example.ui.viewmodel.MistakeCheckUiState

@Composable
fun AiTeacherScreen(
    isOnline: Boolean,
    selectedLevel: LearningLevel,
    messages: List<ChatMessageUi>,
    chatState: AiChatUiState,
    speechState: SpeechUiState,
    mistakeState: MistakeCheckUiState,
    onSendMessage: (String) -> Unit,
    onSpeakText: (String) -> Unit,
    onStartVoiceInput: () -> Unit,
    onCheckSentenceMistake: (String) -> Unit,
    onClearError: () -> Unit,
    onOpenOfflineSentences: () -> Unit,
    onOpenOfflineSpeaking: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    var showMistakeChecker by remember { mutableStateOf(false) }
    var sentenceToCheck by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onStartVoiceInput()
    }

    LaunchedEffect(speechState) {
        if (speechState is SpeechUiState.Result) {
            inputText = speechState.text
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val quickPrompts = listOf(
        "I want to practice introducing myself in English.",
        "Let's practice a restaurant conversation.",
        "I am going to market yesterday. Is this right?",
        "Teach me 3 polite office phrases with Hindi meaning."
    )

    Column(modifier = modifier.fillMaxSize()) {
        // Teacher Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_ai_teacher),
                    contentDescription = "प्रिया मैम AI इंग्लिश टीचर",
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "प्रिया मैम • AI इंग्लिश टीचर",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "स्तर: ${selectedLevel.titleHindi}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OnlineStatusBadge(isOnline = isOnline)
            }
        }

        if (!isOnline) {
            // Friendly Offline Notice — never blocks offline learning!
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.CloudOff, contentDescription = null)
                        Text(
                            text = "ऑफलाइन मोड सक्रिय है",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "ऑनलाइन AI टीचर चैट के लिए इंटरनेट आवश्यक है। इंटरनेट वापस आते ही यह अपने आप शुरू हो जाएगा। तब तक आप सभी 5000+ वाक्य, व्याकरण और बोलने का अभ्यास बिना इंटरनेट जारी रख सकते हैं!",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onOpenOfflineSentences,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("5000 वाक्य पढ़ें")
                        }
                        OutlinedButton(
                            onClick = onOpenOfflineSpeaking,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("माइक अभ्यास")
                        }
                    }
                }
            }
        }

        // Toggle Mistake Checker Drawer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(
                onClick = { showMistakeChecker = !showMistakeChecker },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Spellcheck, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (showMistakeChecker) "चैट पर वापस जाएँ" else "अपना अंग्रेज़ी वाक्य जाँचें (गलती हिंदी में समझें)")
            }
        }

        if (showMistakeChecker) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "कोई भी अंग्रेज़ी वाक्य लिखें — AI आपकी गलती हिंदी में समझाएगा",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            OutlinedTextField(
                                value = sentenceToCheck,
                                onValueChange = { sentenceToCheck = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("उदाहरण: He don't knows my name.") },
                                maxLines = 4
                            )
                            Button(
                                onClick = { onCheckSentenceMistake(sentenceToCheck) },
                                enabled = isOnline && sentenceToCheck.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("गलती जाँचें और हिंदी में समझें")
                            }
                        }
                    }
                }
                if (mistakeState !is MistakeCheckUiState.Idle) {
                    item {
                        MistakeAnalysisCard(
                            state = mistakeState,
                            onSpeakCorrected = onSpeakText
                        )
                    }
                }
            }
        } else {
            // Quick topic chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickPrompts) { prompt ->
                    AssistChip(
                        onClick = { if (isOnline) onSendMessage(prompt) },
                        label = { Text(prompt, maxLines = 1) }
                    )
                }
            }

            // Chat Messages
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.isFromTeacher) Arrangement.Start else Arrangement.End
                    ) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 18.dp,
                                topEnd = 18.dp,
                                bottomStart = if (msg.isFromTeacher) 4.dp else 18.dp,
                                bottomEnd = if (msg.isFromTeacher) 18.dp else 4.dp
                            ),
                            color = if (msg.isFromTeacher) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.primary
                            },
                            contentColor = if (msg.isFromTeacher) {
                                MaterialTheme.colorScheme.onSurface
                            } else {
                                MaterialTheme.colorScheme.onPrimary
                            },
                            border = if (msg.isFromTeacher) BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null,
                            modifier = Modifier.fillMaxWidth(0.88f)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (msg.text.isBlank() && msg.isStreaming) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                        Text("प्रिया मैम लिख रही हैं...", style = MaterialTheme.typography.bodySmall)
                                    }
                                } else {
                                    Text(
                                        text = msg.text,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }

                                if (msg.isFromTeacher && msg.text.isNotBlank() && !msg.isStreaming) {
                                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                        AssistChip(
                                            onClick = { onSpeakText(msg.text) },
                                            label = { Text("सुनें") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.AutoMirrored.Filled.VolumeUp,
                                                    contentDescription = "जवाब सुनें",
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (chatState is AiChatUiState.Error) {
                    item {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = chatState.message,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                                FilledTonalButton(onClick = onClearError) {
                                    Text("ठीक है")
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Chat Input Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalIconButton(
                        onClick = {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) onStartVoiceInput() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Filled.Mic, contentDescription = "बोलकर टाइप करें")
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_chat_input"),
                        placeholder = {
                            Text(if (isOnline) "अंग्रेज़ी या हिंदी में संदेश लिखें..." else "ऑनलाइन होने पर चैट करें")
                        },
                        maxLines = 3,
                        shape = RoundedCornerShape(24.dp)
                    )

                    FilledIconButton(
                        onClick = {
                            val msg = inputText.trim()
                            if (msg.isNotEmpty()) {
                                onSendMessage(msg)
                                inputText = ""
                            }
                        },
                        enabled = isOnline && inputText.isNotBlank() && chatState !is AiChatUiState.Streaming,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("ai_chat_send_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "भेजें")
                    }
                }
            }
        }
    }
}
