package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.LearningLevel
import com.example.data.local.SentenceEntity
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.theme.StatusAmberBg
import com.example.ui.theme.StatusAmberText

@Composable
fun OnlineStatusBadge(
    isOnline: Boolean,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = if (isOnline) EmeraldContainer else StatusAmberBg,
        label = "status_bg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (isOnline) OnEmeraldContainer else StatusAmberText,
        label = "status_fg"
    )

    Surface(
        modifier = modifier.testTag("online_status_badge"),
        color = bgColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(50.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = if (isOnline) Icons.Filled.CloudDone else Icons.Filled.CloudOff,
                contentDescription = if (isOnline) "ऑनलाइन" else "ऑफलाइन",
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = if (isOnline) "ऑनलाइन" else "ऑफलाइन",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun LevelSelectorBar(
    selectedLevel: LearningLevel,
    onSelectLevel: (LearningLevel) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        LearningLevel.entries.forEach { level ->
            val selected = level == selectedLevel
            val shortHindi = when (level) {
                LearningLevel.BEGINNER -> "प्रारंभिक"
                LearningLevel.INTERMEDIATE -> "मध्यम"
                LearningLevel.ADVANCED -> "उन्नत"
            }
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectLevel(level) }
                    .testTag("level_pill_${level.code.lowercase()}"),
                color = if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
                contentColor = if (selected) {
                    MaterialTheme.colorScheme.onPrimary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                shape = RoundedCornerShape(14.dp),
                border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = shortHindi,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun SentenceCard(
    sentence: SentenceEntity,
    onSpeakNormal: () -> Unit,
    onSpeakSlow: () -> Unit,
    onToggleBookmark: () -> Unit,
    onToggleMastered: () -> Unit,
    onPracticeMic: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (sentence.isMastered) {
                MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(
            1.dp,
            if (sentence.isMastered) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.outline
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top chips row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = categoryHindiLabel(sentence.category),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = levelHindiLabel(sentence.level),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    if (sentence.isOnlineUpdate) {
                        Surface(
                            color = EmeraldContainer,
                            contentColor = OnEmeraldContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "नया",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(
                        onClick = onToggleBookmark,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("bookmark_btn_${sentence.id}"),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = if (sentence.isBookmarked) {
                                MaterialTheme.colorScheme.secondaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            }
                        )
                    ) {
                        Icon(
                            imageVector = if (sentence.isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "सेव करें",
                            tint = if (sentence.isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // English sentence
            Text(
                text = sentence.english,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Hindi meaning
            Text(
                text = sentence.hindi,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )

            if (sentence.pronunciationHint.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "उच्चारण: ${sentence.pronunciationHint}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action bar with generous touch targets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AssistChip(
                    onClick = onSpeakNormal,
                    label = { Text("सुनें") },
                    leadingIcon = {
                        Icon(
                            Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "अंग्रेज़ी सुनें",
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        labelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        leadingIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier.height(44.dp)
                )

                AssistChip(
                    onClick = onSpeakSlow,
                    label = { Text("धीमे") },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.SlowMotionVideo,
                            contentDescription = "धीमी गति में सुनें",
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier.height(44.dp)
                )

                AssistChip(
                    onClick = onPracticeMic,
                    label = { Text("बोलें") },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = "माइक से बोलने का अभ्यास",
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        labelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        leadingIconContentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    modifier = Modifier.height(44.dp)
                )

                Spacer(modifier = Modifier.weight(1f))

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (sentence.isMastered) MaterialTheme.colorScheme.tertiary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable { onToggleMastered() }
                        .testTag("mastered_btn_${sentence.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (sentence.isMastered) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                        contentDescription = if (sentence.isMastered) "सीखा हुआ" else "सीखा चिह्नित करें",
                        tint = if (sentence.isMastered) MaterialTheme.colorScheme.onTertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

fun categoryHindiLabel(cat: String): String = when (cat.lowercase()) {
    "greetings" -> "अभिवादन"
    "home" -> "घर-परिवार"
    "office" -> "ऑफिस"
    "travel" -> "यात्रा"
    "shopping" -> "खरीदारी"
    "food" -> "भोजन"
    "health" -> "स्वास्थ्य"
    "phone" -> "फ़ोन कॉल"
    "emotions" -> "भावनाएँ"
    "social" -> "बातचीत"
    "daily use" -> "दैनिक उपयोग"
    else -> cat
}

fun levelHindiLabel(level: String): String = when (level.uppercase()) {
    "BEGINNER" -> "प्रारंभिक"
    "INTERMEDIATE" -> "मध्यम"
    "ADVANCED" -> "उन्नत"
    else -> level
}
