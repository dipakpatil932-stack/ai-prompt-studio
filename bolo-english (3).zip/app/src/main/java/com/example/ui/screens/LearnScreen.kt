package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ConversationEntity
import com.example.data.local.GrammarLessonEntity
import com.example.data.local.SentenceEntity
import com.example.data.local.VocabularyEntity
import com.example.ui.components.OnlineStatusBadge
import com.example.ui.components.SentenceCard
import com.example.ui.components.categoryHindiLabel
import com.example.ui.components.levelHindiLabel
import com.example.ui.viewmodel.SentenceFilter
import com.example.ui.viewmodel.VocabFilter

@Composable
fun LearnScreen(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    isOnline: Boolean,
    // Sentences
    totalSentenceCount: Int,
    sentences: List<SentenceEntity>,
    sentenceCategories: List<String>,
    sentenceFilter: SentenceFilter,
    onUpdateSentenceFilter: ((SentenceFilter) -> SentenceFilter) -> Unit,
    onToggleSentenceBookmark: (Int) -> Unit,
    onToggleSentenceMastered: (SentenceEntity) -> Unit,
    onPracticeSentenceMic: (SentenceEntity) -> Unit,
    // Vocabulary
    vocabulary: List<VocabularyEntity>,
    vocabCategories: List<String>,
    vocabFilter: VocabFilter,
    onUpdateVocabFilter: ((VocabFilter) -> VocabFilter) -> Unit,
    onToggleVocabMastered: (VocabularyEntity) -> Unit,
    // Grammar
    grammarLessons: List<GrammarLessonEntity>,
    grammarLevelFilter: String,
    onSelectGrammarLevel: (String) -> Unit,
    onToggleGrammarCompleted: (GrammarLessonEntity) -> Unit,
    // Conversations
    conversations: List<ConversationEntity>,
    conversationLevelFilter: String,
    onSelectConversationLevel: (String) -> Unit,
    onMarkConversationCompleted: (Int) -> Unit,
    onPracticeConversationLine: (String, String) -> Unit,
    // Common TTS
    onSpeakEnglish: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = listOf("5000 वाक्य", "शब्दावली", "व्याकरण (हिंदी)", "दैनिक संवाद")

    Column(modifier = modifier.fillMaxSize()) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "सीखें (ऑफलाइन लाइब्रेरी)",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "बिना इंटरनेट भी सभी पाठ हमेशा उपलब्ध",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OnlineStatusBadge(isOnline = isOnline)
        }

        ScrollableTabRow(
            selectedTabIndex = selectedTab.coerceIn(0, tabs.lastIndex),
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { onSelectTab(idx) },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == idx) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    modifier = Modifier.testTag("learn_tab_$idx")
                )
            }
        }

        when (selectedTab) {
            0 -> SentencesTabContent(
                totalSentenceCount = totalSentenceCount,
                sentences = sentences,
                categories = sentenceCategories,
                filter = sentenceFilter,
                onUpdateFilter = onUpdateSentenceFilter,
                onSpeakEnglish = onSpeakEnglish,
                onToggleBookmark = onToggleSentenceBookmark,
                onToggleMastered = onToggleSentenceMastered,
                onPracticeMic = onPracticeSentenceMic
            )
            1 -> VocabularyTabContent(
                vocabulary = vocabulary,
                categories = vocabCategories,
                filter = vocabFilter,
                onUpdateFilter = onUpdateVocabFilter,
                onSpeakEnglish = { onSpeakEnglish(it, false) },
                onToggleMastered = onToggleVocabMastered
            )
            2 -> GrammarTabContent(
                lessons = grammarLessons,
                selectedLevel = grammarLevelFilter,
                onSelectLevel = onSelectGrammarLevel,
                onToggleCompleted = onToggleGrammarCompleted,
                onSpeakEnglish = { onSpeakEnglish(it, false) }
            )
            else -> ConversationsTabContent(
                conversations = conversations,
                selectedLevel = conversationLevelFilter,
                onSelectLevel = onSelectConversationLevel,
                onMarkCompleted = onMarkConversationCompleted,
                onSpeakEnglish = { onSpeakEnglish(it, false) },
                onPracticeLineMic = onPracticeConversationLine
            )
        }
    }
}

@Composable
private fun SentencesTabContent(
    totalSentenceCount: Int,
    sentences: List<SentenceEntity>,
    categories: List<String>,
    filter: SentenceFilter,
    onUpdateFilter: ((SentenceFilter) -> SentenceFilter) -> Unit,
    onSpeakEnglish: (String, Boolean) -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onToggleMastered: (SentenceEntity) -> Unit,
    onPracticeMic: (SentenceEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = filter.query,
                onValueChange = { q -> onUpdateFilter { it.copy(query = q) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sentence_search_input"),
                placeholder = { Text("हिंदी या अंग्रेज़ी में वाक्य खोजें... ($totalSentenceCount वाक्य)") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "खोजें") },
                trailingIcon = {
                    if (filter.query.isNotEmpty()) {
                        IconButton(onClick = { onUpdateFilter { it.copy(query = "") } }) {
                            Icon(Icons.Filled.Clear, contentDescription = "साफ़ करें")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )

            // Level + Bookmark chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = filter.bookmarkedOnly,
                        onClick = { onUpdateFilter { it.copy(bookmarkedOnly = !it.bookmarkedOnly) } },
                        label = { Text("सेव किए गए") },
                        leadingIcon = {
                            Icon(Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    )
                }
                val levels = listOf("ALL" to "सभी स्तर", "BEGINNER" to "प्रारंभिक", "INTERMEDIATE" to "मध्यम", "ADVANCED" to "उन्नत")
                items(levels) { (code, label) ->
                    FilterChip(
                        selected = filter.level == code,
                        onClick = { onUpdateFilter { it.copy(level = code) } },
                        label = { Text(label) }
                    )
                }
            }

            // Category chips
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = filter.category == "ALL",
                        onClick = { onUpdateFilter { it.copy(category = "ALL") } },
                        label = { Text("सभी विषय") }
                    )
                }
                items(categories) { cat ->
                    FilterChip(
                        selected = filter.category == cat,
                        onClick = { onUpdateFilter { it.copy(category = cat) } },
                        label = { Text(categoryHindiLabel(cat)) }
                    )
                }
            }
        }

        if (sentences.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "इस फ़िल्टर के लिए कोई वाक्य नहीं मिला",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = { onUpdateFilter { SentenceFilter() } }) {
                    Text("सभी $totalSentenceCount वाक्य दिखाएँ")
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "${sentences.size} वाक्य प्रदर्शित (कुल स्थानीय संग्रह: $totalSentenceCount)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(sentences, key = { it.id }) { item ->
                    SentenceCard(
                        sentence = item,
                        onSpeakNormal = { onSpeakEnglish(item.english, false) },
                        onSpeakSlow = { onSpeakEnglish(item.english, true) },
                        onToggleBookmark = { onToggleBookmark(item.id) },
                        onToggleMastered = { onToggleMastered(item) },
                        onPracticeMic = { onPracticeMic(item) }
                    )
                }
            }
        }
    }
}

@Composable
private fun VocabularyTabContent(
    vocabulary: List<VocabularyEntity>,
    categories: List<String>,
    filter: VocabFilter,
    onUpdateFilter: ((VocabFilter) -> VocabFilter) -> Unit,
    onSpeakEnglish: (String) -> Unit,
    onToggleMastered: (VocabularyEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = filter.query,
                onValueChange = { q -> onUpdateFilter { it.copy(query = q) } },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("शब्द या हिंदी अर्थ खोजें...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "खोजें") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val levels = listOf("ALL" to "सभी स्तर", "BEGINNER" to "प्रारंभिक", "INTERMEDIATE" to "मध्यम", "ADVANCED" to "उन्नत")
                items(levels) { (code, label) ->
                    FilterChip(
                        selected = filter.level == code,
                        onClick = { onUpdateFilter { it.copy(level = code) } },
                        label = { Text(label) }
                    )
                }
                items(categories) { cat ->
                    FilterChip(
                        selected = filter.category == cat,
                        onClick = {
                            onUpdateFilter {
                                it.copy(category = if (it.category == cat) "ALL" else cat)
                            }
                        },
                        label = { Text(categoryHindiLabel(cat)) }
                    )
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(vocabulary, key = { it.id }) { word ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (word.isMastered) {
                            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = word.word,
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = levelHindiLabel(word.level),
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${word.partOfSpeech} • उच्चारण: ${word.pronunciation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = { onSpeakEnglish(word.word) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "शब्द सुनें",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Text(
                            text = "अर्थ: ${word.hindiMeaning}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = word.exampleEnglish,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { onSpeakEnglish(word.exampleEnglish) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            Icons.AutoMirrored.Filled.VolumeUp,
                                            contentDescription = "उदाहरण सुनें",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = word.exampleHindi,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            AssistChip(
                                onClick = { onToggleMastered(word) },
                                label = { Text(if (word.isMastered) "याद हो गया ✓" else "याद किया चिह्नित करें") },
                                leadingIcon = {
                                    Icon(
                                        if (word.isMastered) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                                        contentDescription = null,
                                        tint = if (word.isMastered) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GrammarTabContent(
    lessons: List<GrammarLessonEntity>,
    selectedLevel: String,
    onSelectLevel: (String) -> Unit,
    onToggleCompleted: (GrammarLessonEntity) -> Unit,
    onSpeakEnglish: (String) -> Unit
) {
    var expandedId by remember { mutableStateOf<Int?>(lessons.firstOrNull()?.id) }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val levels = listOf("ALL" to "सभी पाठ", "BEGINNER" to "प्रारंभिक", "INTERMEDIATE" to "मध्यम", "ADVANCED" to "उन्नत")
            items(levels) { (code, label) ->
                FilterChip(
                    selected = selectedLevel == code,
                    onClick = { onSelectLevel(code) },
                    label = { Text(label) }
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(lessons, key = { it.id }) { lesson ->
                val isExpanded = expandedId == lesson.id
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (lesson.isCompleted) {
                            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f)
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedId = if (isExpanded) null else lesson.id },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = levelHindiLabel(lesson.level),
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    if (lesson.isCompleted) {
                                        Text(
                                            text = "पूरा हुआ ✓",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.tertiary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = lesson.titleHindi,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = lesson.titleEnglish,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                contentDescription = if (isExpanded) "समेटें" else "विस्तार से देखें",
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        AnimatedVisibility(visible = isExpanded) {
                            Column(
                                modifier = Modifier.padding(top = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = lesson.summaryHindi,
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                // Formula Box
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp)
                                    ) {
                                        Text(
                                            text = "सूत्र (Formula):",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = lesson.formula,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                // Rules
                                Text(
                                    text = lesson.explanationHindi,
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                // Examples
                                Text(
                                    text = "उदाहरण (सुनकर अभ्यास करें):",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                lesson.examplesEncoded.split(";;").forEach { pair ->
                                    val parts = pair.split("|")
                                    if (parts.size == 2) {
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = parts[0],
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = parts[1],
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                                IconButton(onClick = { onSpeakEnglish(parts[0]) }) {
                                                    Icon(
                                                        Icons.AutoMirrored.Filled.VolumeUp,
                                                        contentDescription = "सुनें",
                                                        tint = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Tip Box
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Icon(
                                            Icons.Filled.Lightbulb,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.secondary
                                        )
                                        Text(
                                            text = lesson.tipHindi,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }

                                Button(
                                    onClick = { onToggleCompleted(lesson) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (lesson.isCompleted) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
                                    )
                                ) {
                                    Icon(Icons.Filled.CheckCircle, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(if (lesson.isCompleted) "पाठ पूरा हुआ (बदलें)" else "पाठ पूरा किया (+20 XP)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationsTabContent(
    conversations: List<ConversationEntity>,
    selectedLevel: String,
    onSelectLevel: (String) -> Unit,
    onMarkCompleted: (Int) -> Unit,
    onSpeakEnglish: (String) -> Unit,
    onPracticeLineMic: (String, String) -> Unit
) {
    var expandedId by remember { mutableStateOf<Int?>(conversations.firstOrNull()?.id) }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val levels = listOf("ALL" to "सभी संवाद", "BEGINNER" to "प्रारंभिक", "INTERMEDIATE" to "मध्यम", "ADVANCED" to "उन्नत")
            items(levels) { (code, label) ->
                FilterChip(
                    selected = selectedLevel == code,
                    onClick = { onSelectLevel(code) },
                    label = { Text(label) }
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(conversations, key = { it.id }) { convo ->
                val isExpanded = expandedId == convo.id
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedId = if (isExpanded) null else convo.id },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = levelHindiLabel(convo.level),
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    if (convo.isCompleted) {
                                        Text(
                                            text = "अभ्यास पूर्ण ✓",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.tertiary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = convo.titleHindi,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = convo.situationHindi,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                contentDescription = null
                            )
                        }

                        AnimatedVisibility(visible = isExpanded) {
                            Column(
                                modifier = Modifier.padding(top = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                HorizontalDivider()
                                val turns = convo.turnsEncoded.split(";;")
                                turns.forEachIndexed { idx, turnStr ->
                                    val parts = turnStr.split("|")
                                    if (parts.size >= 3) {
                                        val speaker = parts[0]
                                        val eng = parts[1]
                                        val hin = parts[2]
                                        val isEven = idx % 2 == 0
                                        Surface(
                                            color = if (isEven) {
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            shape = RoundedCornerShape(14.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    text = speaker,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                Text(
                                                    text = eng,
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = hin,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    AssistChip(
                                                        onClick = { onSpeakEnglish(eng) },
                                                        label = { Text("सुनें") },
                                                        leadingIcon = {
                                                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        }
                                                    )
                                                    AssistChip(
                                                        onClick = { onPracticeLineMic(eng, hin) },
                                                        label = { Text("बोलकर अभ्यास") },
                                                        leadingIcon = {
                                                            Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Button(
                                    onClick = { onMarkCompleted(convo.id) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                ) {
                                    Icon(Icons.Filled.CheckCircle, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(if (convo.isCompleted) "संवाद अभ्यास पूर्ण ✓" else "अभ्यास पूरा चिह्नित करें (+20 XP)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
