package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.LearningLevel
import com.example.data.local.PracticeAttemptEntity
import com.example.data.local.UserProgressEntity
import com.example.ui.components.OnlineStatusBadge

@Composable
fun ProgressScreen(
    isOnline: Boolean,
    progress: UserProgressEntity,
    totalSentences: Int,
    masteredSentences: Int,
    totalVocab: Int,
    masteredVocab: Int,
    totalGrammar: Int,
    completedGrammar: Int,
    recentAttempts: List<PracticeAttemptEntity>,
    onUpdateTtsSpeed: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val level = LearningLevel.fromCode(progress.selectedLevel)
    val quizAvg = if (progress.totalQuizQuestions > 0) {
        (progress.totalQuizScore * 100) / progress.totalQuizQuestions
    } else 0
    val speakingAvg = if (progress.speakingAttempts > 0) {
        progress.totalSpeakingScore / progress.speakingAttempts
    } else 0

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "मेरी सीखने की प्रगति",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Room डेटाबेस में सुरक्षित (ऑफलाइन भी उपलब्ध)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OnlineStatusBadge(isOnline = isOnline)
            }
        }

        // XP & Streak Hero Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(30.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${progress.xpPoints} XP",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "कुल अंक",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(30.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${progress.streakDays} दिन",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "लगातार स्ट्रीक",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(30.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = level.titleEnglish,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "वर्तमान स्तर",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        // Progress Metrics Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ProgressBarCard(
                    title = "सीखे गए वाक्य (5000+ संग्रह)",
                    valueLabel = "$masteredSentences / $totalSentences",
                    fraction = if (totalSentences > 0) masteredSentences.toFloat() / totalSentences else 0f,
                    icon = Icons.Filled.CheckCircle
                )
                ProgressBarCard(
                    title = "शब्दावली (Words Mastered)",
                    valueLabel = "$masteredVocab / $totalVocab",
                    fraction = if (totalVocab > 0) masteredVocab.toFloat() / totalVocab else 0f,
                    icon = Icons.AutoMirrored.Filled.MenuBook
                )
                ProgressBarCard(
                    title = "व्याकरण के पाठ (Grammar Lessons)",
                    valueLabel = "$completedGrammar / $totalGrammar",
                    fraction = if (totalGrammar > 0) completedGrammar.toFloat() / totalGrammar else 0f,
                    icon = Icons.Filled.School
                )
            }
        }

        // Quiz & Speaking Summary Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatSmallCard(
                    title = "क्विज़ औसत",
                    value = "$quizAvg%",
                    subtitle = "${progress.quizzesTaken} टेस्ट पूरे",
                    icon = Icons.Filled.Quiz,
                    modifier = Modifier.weight(1f)
                )
                StatSmallCard(
                    title = "बोलने का स्कोर",
                    value = "$speakingAvg%",
                    subtitle = "${progress.speakingAttempts} अभ्यास",
                    icon = Icons.Filled.Mic,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // TTS Pronunciation Speed Setting
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "अंग्रेज़ी बोलने की गति (Audio Speed)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val speeds = listOf(0.75f to "धीमा (0.75x)", 0.95f to "सामान्य (1.0x)", 1.15f to "तेज़ (1.15x)")
                        speeds.forEach { (spd, label) ->
                            FilterChip(
                                selected = kotlin.math.abs(progress.ttsSpeed - spd) < 0.08f,
                                onClick = { onUpdateTtsSpeed(spd) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }
        }

        // Recent Speaking Attempts
        item {
            Text(
                text = "हालिया बोलने का अभ्यास",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        if (recentAttempts.isEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "अभी तक कोई बोलने का अभ्यास दर्ज नहीं हुआ है। 'अभ्यास' टैब में जाकर माइक से पहला वाक्य बोलें!",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    )
                }
            }
        } else {
            items(recentAttempts, key = { it.id }) { attempt ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "लक्ष्य: ${attempt.targetEnglish}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${attempt.accuracyPercent}%",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "आपने बोला: ${attempt.spokenText}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressBarCard(
    title: String,
    valueLabel: String,
    fraction: Float,
    icon: ImageVector
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = valueLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
            LinearProgressIndicator(
                progress = { fraction.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(50.dp))
            )
        }
    }
}

@Composable
private fun StatSmallCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
