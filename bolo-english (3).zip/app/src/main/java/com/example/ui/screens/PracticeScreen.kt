package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.local.SentenceEntity
import com.example.data.speech.PronunciationEvaluation
import com.example.data.speech.SpeechUiState
import com.example.ui.components.OnlineStatusBadge
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.ErrorCoral
import com.example.ui.theme.ErrorCoralBg
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.viewmodel.MistakeCheckUiState
import com.example.ui.viewmodel.QuizUiState

@Composable
fun PracticeScreen(
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    isOnline: Boolean,
    // Speaking practice
    targetSentence: SentenceEntity,
    speechState: SpeechUiState,
    spokenInputText: String,
    evaluation: PronunciationEvaluation?,
    mistakeState: MistakeCheckUiState,
    onSpeakEnglish: (String, Boolean) -> Unit,
    onNextSentence: () -> Unit,
    onStartMic: () -> Unit,
    onStopMic: () -> Unit,
    onUpdateSpokenText: (String) -> Unit,
    onEvaluateText: () -> Unit,
    onExplainMistakeWithAi: (String?, Boolean) -> Unit,
    // Quiz
    quizState: QuizUiState,
    onStartQuiz: (String) -> Unit,
    onSelectQuizOption: (Int) -> Unit,
    onNextQuizQuestion: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = listOf("बोलने का अभ्यास (Mic)", "क्विज़ व टेस्ट")

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "अभ्यास व परीक्षा",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "माइक से बोलें, उच्चारण जाँचें और टेस्ट दें",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OnlineStatusBadge(isOnline = isOnline)
        }

        TabRow(selectedTabIndex = selectedTab.coerceIn(0, 1)) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { onSelectTab(idx) },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == idx) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    modifier = Modifier.testTag("practice_tab_$idx")
                )
            }
        }

        if (selectedTab == 0) {
            SpeakingPracticeTab(
                isOnline = isOnline,
                targetSentence = targetSentence,
                speechState = speechState,
                spokenInputText = spokenInputText,
                evaluation = evaluation,
                mistakeState = mistakeState,
                onSpeakEnglish = onSpeakEnglish,
                onNextSentence = onNextSentence,
                onStartMic = onStartMic,
                onStopMic = onStopMic,
                onUpdateSpokenText = onUpdateSpokenText,
                onEvaluateText = onEvaluateText,
                onExplainMistakeWithAi = onExplainMistakeWithAi
            )
        } else {
            QuizTabContent(
                quizState = quizState,
                onStartQuiz = onStartQuiz,
                onSelectOption = onSelectQuizOption,
                onNextQuestion = onNextQuizQuestion,
                onSpeakEnglish = { onSpeakEnglish(it, false) }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpeakingPracticeTab(
    isOnline: Boolean,
    targetSentence: SentenceEntity,
    speechState: SpeechUiState,
    spokenInputText: String,
    evaluation: PronunciationEvaluation?,
    mistakeState: MistakeCheckUiState,
    onSpeakEnglish: (String, Boolean) -> Unit,
    onNextSentence: () -> Unit,
    onStartMic: () -> Unit,
    onStopMic: () -> Unit,
    onUpdateSpokenText: (String) -> Unit,
    onEvaluateText: () -> Unit,
    onExplainMistakeWithAi: (String?, Boolean) -> Unit
) {
    val context = LocalContext.current
    var permissionDeniedNote by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            permissionDeniedNote = false
            onStartMic()
        } else {
            permissionDeniedNote = true
        }
    }

    val isListening = speechState is SpeechUiState.Listening || speechState is SpeechUiState.Partial
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "pulse"
    )

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Target Sentence Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "यह वाक्य बोलकर अभ्यास करें:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(
                            onClick = onNextSentence,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("दूसरा वाक्य")
                        }
                    }

                    Text(
                        text = targetSentence.english,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = targetSentence.hindi,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (targetSentence.pronunciationHint.isNotBlank()) {
                        Text(
                            text = "बोलने का तरीका: ${targetSentence.pronunciationHint}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(
                            onClick = { onSpeakEnglish(targetSentence.english, false) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("सही उच्चारण सुनें")
                        }
                        OutlinedButton(
                            onClick = { onSpeakEnglish(targetSentence.english, true) },
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(Icons.Filled.SlowMotionVideo, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("धीमे")
                        }
                    }
                }
            }
        }

        // Mic Action Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            if (isListening) {
                                onStopMic()
                            } else {
                                val hasPerm = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (hasPerm) {
                                    permissionDeniedNote = false
                                    onStartMic()
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        modifier = Modifier
                            .size(88.dp)
                            .scale(if (isListening) pulseScale else 1f)
                            .testTag("mic_practice_button"),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                            contentDescription = if (isListening) "रिकॉर्डिंग रोकें" else "माइक से बोलें",
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Text(
                        text = when (speechState) {
                            is SpeechUiState.Listening -> "सुन रहा हूँ... अब अंग्रेज़ी में बोलें!"
                            is SpeechUiState.Partial -> "सुन रहा हूँ: ${speechState.text}"
                            is SpeechUiState.Result -> "आपने बोला: \"${speechState.text}\""
                            is SpeechUiState.Error -> speechState.messageHindi
                            SpeechUiState.Idle -> if (isOnline) {
                                "माइक दबाएँ और ऊपर लिखा वाक्य बोलें"
                            } else {
                                "ऑफलाइन माइक मोड तैयार • माइक दबाकर बोलें"
                            }
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (speechState is SpeechUiState.Error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )

                    if (permissionDeniedNote) {
                        Text(
                            text = "माइक से अभ्यास के लिए माइक्रोफ़ोन की अनुमति आवश्यक है। आप नीचे लिखकर भी जाँच सकते हैं।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    OutlinedTextField(
                        value = spokenInputText,
                        onValueChange = onUpdateSpokenText,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("spoken_text_input"),
                        label = { Text("या अपना अंग्रेज़ी वाक्य यहाँ लिखें / संपादित करें") },
                        singleLine = false,
                        maxLines = 3,
                        shape = RoundedCornerShape(14.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onEvaluateText,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("evaluate_offline_btn")
                        ) {
                            Text("ऑफलाइन स्कोर जाँचें")
                        }
                        FilledTonalButton(
                            onClick = { onExplainMistakeWithAi(spokenInputText, true) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("explain_mistake_ai_btn")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("AI हिंदी समीक्षा")
                        }
                    }
                }
            }
        }

        // Offline Pronunciation Evaluation Card
        if (evaluation != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "उच्चारण सटीकता (ऑफलाइन परिणाम)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = if (evaluation.accuracyPercent >= 70) EmeraldContainer else ErrorCoralBg,
                                shape = RoundedCornerShape(50.dp)
                            ) {
                                Text(
                                    text = "${evaluation.accuracyPercent}%",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (evaluation.accuracyPercent >= 70) OnEmeraldContainer else ErrorCoral,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = evaluation.feedbackHindi,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            evaluation.wordResults.forEach { wr ->
                                Surface(
                                    color = if (wr.matched) EmeraldContainer else ErrorCoralBg,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = wr.word,
                                        color = if (wr.matched) OnEmeraldContainer else ErrorCoral,
                                        style = MaterialTheme.typography.labelLarge,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Online AI Mistake Explainer Card
        if (mistakeState !is MistakeCheckUiState.Idle) {
            item {
                MistakeAnalysisCard(
                    state = mistakeState,
                    onSpeakCorrected = { onSpeakEnglish(it, false) }
                )
            }
        }
    }
}

@Composable
fun MistakeAnalysisCard(
    state: MistakeCheckUiState,
    onSpeakCorrected: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                Text(
                    text = "AI गलती सुधार (हिंदी में व्याख्या)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            when (state) {
                MistakeCheckUiState.Loading -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("AI आपके वाक्य का विश्लेषण कर रहा है...")
                    }
                }
                is MistakeCheckUiState.Error -> {
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                is MistakeCheckUiState.Success -> {
                    val analysis = state.analysis
                    Surface(
                        color = if (analysis.isCorrect) EmeraldContainer else MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (analysis.isCorrect) "बिल्कुल सही वाक्य! ✓" else "सही अंग्रेज़ी वाक्य:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = analysis.correctedEnglish,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            FilledTonalButton(onClick = { onSpeakCorrected(analysis.correctedEnglish) }) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "सही वाक्य सुनें")
                            }
                        }
                    }

                    Text(
                        text = analysis.hindiExplanation,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    if (analysis.grammarRuleHindi.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "व्याकरण नियम: ${analysis.grammarRuleHindi}",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp)
                            )
                        }
                    }

                    if (analysis.pronunciationTipHindi.isNotBlank()) {
                        Text(
                            text = "उच्चारण टिप: ${analysis.pronunciationTipHindi}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (analysis.betterAlternative.isNotBlank()) {
                        Text(
                            text = "बेहतर विकल्प: \"${analysis.betterAlternative}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                MistakeCheckUiState.Idle -> {}
            }
        }
    }
}

@Composable
private fun QuizTabContent(
    quizState: QuizUiState,
    onStartQuiz: (String) -> Unit,
    onSelectOption: (Int) -> Unit,
    onNextQuestion: () -> Unit,
    onSpeakEnglish: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Level filter row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val levels = listOf("ALL" to "मिश्रित", "BEGINNER" to "प्रारंभिक", "INTERMEDIATE" to "मध्यम", "ADVANCED" to "उन्नत")
            items(levels) { (code, label) ->
                FilterChip(
                    selected = quizState.selectedLevel == code,
                    onClick = { onStartQuiz(code) },
                    label = { Text(label) }
                )
            }
        }

        if (quizState.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return
        }

        if (quizState.questions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Button(onClick = { onStartQuiz(quizState.selectedLevel) }) {
                    Text("क्विज़ शुरू करें")
                }
            }
            return
        }

        if (quizState.isFinished) {
            val total = quizState.questions.size
            val pct = if (total > 0) (quizState.score * 100) / total else 0
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "टेस्ट पूरा हुआ!",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "आपका स्कोर: ${quizState.score} / $total ($pct%)",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = when {
                            pct >= 80 -> "अद्भुत प्रदर्शन! आपकी अंग्रेज़ी पकड़ मज़बूत हो रही है।"
                            pct >= 50 -> "अच्छा प्रयास! थोड़ा और अभ्यास आपको और बेहतर बनाएगा।"
                            else -> "चिंता न करें, व्याकरण और 5000 वाक्य पढ़कर फिर से प्रयास करें!"
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onStartQuiz(quizState.selectedLevel) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("restart_quiz_btn")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("नया क्विज़ शुरू करें")
                    }
                }
            }
            return
        }

        val currentQ = quizState.questions[quizState.currentIndex]
        val options = listOf(currentQ.optionA, currentQ.optionB, currentQ.optionC, currentQ.optionD)
        val isAnswered = quizState.selectedOption != null

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "प्रश्न ${quizState.currentIndex + 1} / ${quizState.questions.size}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "स्कोर: ${quizState.score}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (quizState.currentIndex + 1).toFloat() / quizState.questions.size.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50.dp))
                    )
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = currentQ.promptEnglish,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = currentQ.questionHindi,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            items(options.indices.toList()) { idx ->
                val optionText = options[idx]
                val isSelected = quizState.selectedOption == idx
                val isCorrectOption = idx == currentQ.correctIndex

                val bgColor = when {
                    !isAnswered -> MaterialTheme.colorScheme.surface
                    isCorrectOption -> EmeraldContainer
                    isSelected && !isCorrectOption -> ErrorCoralBg
                    else -> MaterialTheme.colorScheme.surface
                }
                val borderColor = when {
                    !isAnswered -> MaterialTheme.colorScheme.outline
                    isCorrectOption -> MaterialTheme.colorScheme.tertiary
                    isSelected && !isCorrectOption -> ErrorCoral
                    else -> MaterialTheme.colorScheme.outline
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quiz_option_$idx"),
                    shape = RoundedCornerShape(16.dp),
                    color = bgColor,
                    border = BorderStroke(1.5.dp, borderColor),
                    onClick = { onSelectOption(idx) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${('A' + idx)}.  $optionText",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = if (isSelected || (isAnswered && isCorrectOption)) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                        if (isAnswered) {
                            FilledTonalButton(
                                onClick = { onSpeakEnglish(optionText) },
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "सुनें", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            if (isAnswered) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = if (quizState.selectedOption == currentQ.correctIndex) {
                                    "सही जवाब! ✓"
                                } else {
                                    "सही उत्तर: ${options[currentQ.correctIndex]}"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = currentQ.explanationHindi,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }

                item {
                    Button(
                        onClick = onNextQuestion,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("quiz_next_btn")
                    ) {
                        Text(
                            text = if (quizState.currentIndex + 1 >= quizState.questions.size) "परिणाम देखें" else "अगला प्रश्न"
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    }
                }
            }
        }
    }
}
