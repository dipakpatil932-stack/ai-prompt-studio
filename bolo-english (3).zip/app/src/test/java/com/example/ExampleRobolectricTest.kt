package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.BoloDatabase
import com.example.data.local.DatabaseInitializer
import com.example.data.local.LearningLevel
import com.example.data.local.SentenceEntity
import com.example.data.local.UserProgressEntity
import com.example.ui.screens.AiTeacherScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.BoloEnglishTheme
import com.example.ui.viewmodel.AiChatUiState
import com.example.ui.viewmodel.ChatMessageUi
import com.example.ui.viewmodel.MistakeCheckUiState
import com.example.ui.viewmodel.OnlineUpdateUiState
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `read string from context returns Bolo English`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Bolo English", appName)
    }

    @Test
    fun `offline room database seeds 5000 sentences and daily 10`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, BoloDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val initializer = DatabaseInitializer(context, db)
            initializer.ensureInitialized()

            assertEquals(5000, db.sentenceDao().getCount())
            assertTrue(db.vocabularyDao().getCount() >= 40)
            assertTrue(db.grammarDao().getCount() >= 14)
            assertTrue(db.conversationDao().getCount() >= 8)
            assertTrue(db.quizDao().getCount() >= 25)

            val daily = db.sentenceDao().observeDailySentences().first()
            assertEquals(10, daily.size)

            // Test offline search query
            val searchRes = db.sentenceDao().observeFilteredSentences("ALL", "ALL", false, "water").first()
            assertTrue(searchRes.isNotEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `home screen renders offline status badge and daily 10`() {
        val sampleDaily = listOf(
            SentenceEntity(
                id = 1,
                english = "Good morning, how are you?",
                hindi = "सुप्रभात, आप कैसे हैं?",
                pronunciationHint = "गुड मॉर्निंग, हाउ आर यू?",
                category = "Greetings",
                level = "BEGINNER",
                isDailyBatch = true
            )
        )
        var selectedLevel = LearningLevel.BEGINNER

        composeTestRule.setContent {
            BoloEnglishTheme {
                HomeScreen(
                    isOnline = false,
                    progress = UserProgressEntity(xpPoints = 120, streakDays = 3),
                    dailySentences = sampleDaily,
                    totalSentenceCount = 5000,
                    onlineUpdateState = OnlineUpdateUiState.Idle,
                    onSelectLevel = { selectedLevel = it },
                    onRefreshDaily10 = {},
                    onSpeakSentence = { _, _ -> },
                    onToggleDailyMastered = {},
                    onPracticeDailySentence = {},
                    onNavigateToLearnTab = {},
                    onNavigateToPracticeTab = {},
                    onNavigateToAiTeacher = {},
                    onNavigateToProgress = {},
                    onDownloadOnlineUpdates = {},
                    onDismissUpdateStatus = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("online_status_badge").assertIsDisplayed()
        composeTestRule.onNodeWithText("ऑफलाइन").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_lazy_column")
            .performScrollToNode(hasTestTag("level_pill_intermediate"))
        composeTestRule.onNodeWithTag("level_pill_intermediate").performClick()
        assertEquals(LearningLevel.INTERMEDIATE, selectedLevel)
    }

    @Test
    fun `ai teacher screen handles offline and online states gracefully`() {
        var sentMessage = ""
        composeTestRule.setContent {
            BoloEnglishTheme {
                AiTeacherScreen(
                    isOnline = false,
                    selectedLevel = LearningLevel.BEGINNER,
                    messages = listOf(
                        ChatMessageUi("1", true, "नमस्ते! मैं प्रिया मैम हूँ।")
                    ),
                    chatState = AiChatUiState.Idle,
                    speechState = com.example.data.speech.SpeechUiState.Idle,
                    mistakeState = MistakeCheckUiState.Idle,
                    onSendMessage = { sentMessage = it },
                    onSpeakText = {},
                    onStartVoiceInput = {},
                    onCheckSentenceMistake = {},
                    onClearError = {},
                    onOpenOfflineSentences = {},
                    onOpenOfflineSpeaking = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("ऑफलाइन मोड सक्रिय है").assertIsDisplayed()
        composeTestRule.onNodeWithText("5000 वाक्य पढ़ें").assertIsDisplayed()
    }

    @Test
    fun `ai teacher screen sends message when online`() {
        var sentMessage = ""
        composeTestRule.setContent {
            BoloEnglishTheme {
                AiTeacherScreen(
                    isOnline = true,
                    selectedLevel = LearningLevel.INTERMEDIATE,
                    messages = listOf(
                        ChatMessageUi("1", true, "Hello! How can I help you today?")
                    ),
                    chatState = AiChatUiState.Idle,
                    speechState = com.example.data.speech.SpeechUiState.Idle,
                    mistakeState = MistakeCheckUiState.Idle,
                    onSendMessage = { sentMessage = it },
                    onSpeakText = {},
                    onStartVoiceInput = {},
                    onCheckSentenceMistake = {},
                    onClearError = {},
                    onOpenOfflineSentences = {},
                    onOpenOfflineSpeaking = {}
                )
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText("ऑनलाइन").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_chat_input").performTextInput("Hello teacher")
        composeTestRule.onNodeWithTag("ai_chat_send_btn").performClick()
        assertEquals("Hello teacher", sentMessage)
    }
}
