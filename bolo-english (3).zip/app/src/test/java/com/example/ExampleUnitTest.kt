package com.example

import com.example.data.local.LearningLevel
import com.example.data.speech.SpeechPracticeManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun `pronunciation evaluation returns 100 for exact match`() {
        val result = SpeechPracticeManager.evaluatePronunciation(
            target = "Please speak slowly.",
            spoken = "please speak slowly"
        )
        assertEquals(100, result.accuracyPercent)
        assertTrue(result.wordResults.all { it.matched })
    }

    @Test
    fun `pronunciation evaluation highlights missed words`() {
        val result = SpeechPracticeManager.evaluatePronunciation(
            target = "Could you repeat that please?",
            spoken = "Could you please"
        )
        assertEquals(60, result.accuracyPercent)
        assertFalse(result.wordResults.first { it.word == "repeat" }.matched)
        assertTrue(result.wordResults.first { it.word == "could" }.matched)
    }

    @Test
    fun `learning level fromCode resolves safely`() {
        assertEquals(LearningLevel.BEGINNER, LearningLevel.fromCode("BEGINNER"))
        assertEquals(LearningLevel.INTERMEDIATE, LearningLevel.fromCode("intermediate"))
        assertEquals(LearningLevel.ADVANCED, LearningLevel.fromCode("ADVANCED"))
        assertEquals(LearningLevel.BEGINNER, LearningLevel.fromCode("unknown"))
    }
}
