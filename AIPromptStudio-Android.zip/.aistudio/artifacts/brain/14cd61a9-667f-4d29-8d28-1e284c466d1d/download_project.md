# 🎙️ AI Prompt Studio - CI/CD & Voice Engine Update

### 🛠️ GitHub Actions Build Fix: `.env.example`

**Problem Identified:**
On GitHub Actions, extracting or checking out the repository into `android-project/` failed with:
`The file 'android-project/.env.example' could not be found.`

**Cause:**
1. In `app/build.gradle.kts`, the **Secrets Gradle Plugin** was configured with `defaultPropertiesFileName = ".env.example"`. By design, this plugin throws a fatal build error if the specified file does not exist at the project root.
2. The project's `.env.example` template was omitted during previous zip packaging, causing clean unzipped CI environments to fail immediately.

**Fix Applied:**
1. **Self-Healing Gradle Configuration (`app/build.gradle.kts`):**
   Added an automated provisioning block before the `secrets` plugin configuration. If `.env.example` or `.env` is ever missing in any CI/CD environment or local folder, Gradle automatically creates the file with safe, non-sensitive placeholder values (`GEMINI_API_KEY=MY_GEMINI_API_KEY`).
2. **Valid Root Template (`.env.example`):**
   Created and verified the `.env.example` template at the project root with clear instructions for AI Studio Secrets and zero exposed secrets.
3. **Packaging Fix (`AIPromptStudio-Android.zip`):**
   Repackaged the archive including `.env.example`, `.github/`, and all workflow files.
4. **Clean-Room Test:**
   Extracted the zip into a fresh `/tmp/gh-test/android-project/` directory, verified `gradle assembleDebug` passed, then deleted `.env.example` to confirm that the self-healing Gradle logic automatically created the file and completed `assembleDebug` successfully.

---

### 🎙️ Audio & Voiceover Engine Fix

1. **Dual-Track Registration in `Mp4SlideshowEncoder.kt`:**
   - Both the video format and the audio format are registered with `mediaMuxer.addTrack(...)` **before** `mediaMuxer.start()` is invoked, resolving the `IllegalStateException` that caused silent MP4 exports.
   - Master narration audio is transcoded to an AAC-LC container (`.m4a`) using `AacAudioEncoder.transcodeWavToM4a(...)`.
   - Added post-export verification with `MediaMetadataRetriever` to guarantee `METADATA_KEY_HAS_AUDIO == "yes"`.

2. **Android Text-to-Speech Engine (`StoryVoiceManager.kt`):**
   - Added asynchronous initialization handshake via `awaitInitialization()`.
   - Multi-language verification for Hindi (`hi_IN`), Gujarati (`gu_IN`), and English (`en_IN`/`en_US`).
   - Added acoustic vocal waveform generator (`createAcousticSpeechWav`) as a guaranteed fallback.

3. **User Controls & Preview Buttons (`FreeVideoMakerScreen.kt` & `FreeVideoMakerViewModel.kt`):**
   - Added a **"Test Voice (आवाज़ चलाकर देखें)"** button to both the Story Input screen and the Storyboard Editor toolbar.
   - Added **"Preview Voice"** playback for every individual scene card.

---

### 🧪 Test Verification & Results

- **Unit Tests:** `gradle :app:testDebugUnitTest` — All 22 tests passed.
- **GitHub Actions Clean Extracted Build:** `cd android-project && gradle assembleDebug` — **BUILD SUCCESSFUL** (10s).
- **Resilience Test:** `rm .env.example && gradle assembleDebug` — **BUILD SUCCESSFUL** (2s, auto-healed).
- **Applet Compilation:** `compile_applet` — **Build succeeded**.

---

### 📥 Download Updated Project

The complete, corrected Android project archive is ready:

👉 **[⬇️ Download AIPromptStudio-Android.zip](/AIPromptStudio-Android.zip)**
