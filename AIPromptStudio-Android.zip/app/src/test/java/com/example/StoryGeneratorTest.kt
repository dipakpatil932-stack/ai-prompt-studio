package com.example

import com.example.data.remote.GeminiStoryGenerator
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StoryGeneratorTest {

    private val generator = GeminiStoryGenerator()

    @Test
    fun testLocalStoryPlanGeneration() = runTest {
        val plan = generator.generateStoryPlan(
            userStory = "एक पारंपरिक हवेली में सास-बहू के बीच पूजा को लेकर तकरार और फिर मिलाप।",
            storyType = "सास–बहू",
            duration = "60 sec",
            aspectRatio = "9:16",
            generateAllScenes = true
        )

        assertNotNull(plan)
        assertTrue(plan.title.isNotBlank())
        assertEquals("सास–बहू", plan.storyType)
        assertTrue(plan.scenes.isNotEmpty())
        assertTrue(plan.characterPrompts.isNotBlank())
        assertTrue(plan.characterConsistency.isNotBlank())
        assertTrue(plan.visualStyle.contains("Photorealistic Indian cinematic style"))
        assertTrue(plan.negativePrompt.isNotBlank())

        val firstScene = plan.scenes.first()
        assertEquals(1, firstScene.sceneNumber)
        assertTrue(firstScene.visualPrompt.isNotBlank())
        assertTrue(firstScene.dialogue.isNotBlank())
        assertTrue(firstScene.camera.isNotBlank())
        assertTrue(firstScene.lighting.isNotBlank())
        assertTrue(firstScene.audio.isNotBlank())
        assertTrue(firstScene.continuity.contains("Same characters"))
    }
}
