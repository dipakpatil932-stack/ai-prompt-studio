package com.example

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.example.data.media.ImageImportHelper
import com.example.ui.viewmodel.AnimateImageViewModel
import com.example.ui.viewmodel.FreeVideoMakerViewModel
import com.example.ui.viewmodel.ImageStudioViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
class ImageImportIntegrationTest {

    private fun createBitmapBytes(format: Bitmap.CompressFormat, width: Int = 120, height: Int = 120): ByteArray {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(android.graphics.Color.rgb(32, 148, 224))
        val baos = ByteArrayOutputStream()
        bmp.compress(format, 90, baos)
        bmp.recycle()
        return baos.toByteArray()
    }

    @Test
    fun `format validation supports jpg jpeg png webp and rejects non-images`() {
        assertTrue(ImageImportHelper.isSupportedFormat("image/jpeg", "photo.jpg"))
        assertTrue(ImageImportHelper.isSupportedFormat("image/jpg", "photo.jpeg"))
        assertTrue(ImageImportHelper.isSupportedFormat("image/png", "photo.png"))
        assertTrue(ImageImportHelper.isSupportedFormat("image/webp", "photo.webp"))
        assertTrue(ImageImportHelper.isSupportedFormat(null, "sample.webp"))

        assertFalse(ImageImportHelper.isSupportedFormat("application/pdf", "doc.pdf"))
        assertFalse(ImageImportHelper.isSupportedFormat("video/mp4", "clip.mp4"))
        assertFalse(ImageImportHelper.isSupportedFormat(null, "notes.txt"))
    }

    @Test
    fun `imports jpg png and webp from file uri and local path cleanly`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val tempDir = File(app.cacheDir, "test_img_imports").apply { mkdirs() }

        val pngFile = File(tempDir, "sample.png")
        FileOutputStream(pngFile).use { it.write(createBitmapBytes(Bitmap.CompressFormat.PNG, 160, 120)) }

        val jpgFile = File(tempDir, "sample.jpg")
        FileOutputStream(jpgFile).use { it.write(createBitmapBytes(Bitmap.CompressFormat.JPEG, 200, 100)) }

        @Suppress("DEPRECATION")
        val webpFile = File(tempDir, "sample.webp")
        @Suppress("DEPRECATION")
        FileOutputStream(webpFile).use { it.write(createBitmapBytes(Bitmap.CompressFormat.WEBP, 140, 140)) }

        // Test local path PNG
        val pngRes = ImageImportHelper.importImageToLocalStorage(app, pngFile.absolutePath)
        assertTrue("PNG import should succeed", pngRes.isSuccess)
        val pngData = pngRes.getOrThrow()
        assertTrue(File(pngData.localFilePath).exists())
        assertEquals("image/png", pngData.mimeType)
        assertEquals(160, pngData.width)
        assertEquals(120, pngData.height)

        // Test file:// URI JPG
        val jpgFileUri = Uri.fromFile(jpgFile).toString()
        val jpgRes = ImageImportHelper.importImageToLocalStorage(app, jpgFileUri)
        assertTrue("file:// JPG import should succeed", jpgRes.isSuccess)
        val jpgData = jpgRes.getOrThrow()
        assertTrue(File(jpgData.localFilePath).exists())
        assertEquals("image/jpeg", jpgData.mimeType)

        // Test file:// URI WEBP
        val webpUri = Uri.fromFile(webpFile).toString()
        val webpRes = ImageImportHelper.importImageToLocalStorage(app, webpUri)
        assertTrue("file:// WEBP import should succeed", webpRes.isSuccess)
        val webpData = webpRes.getOrThrow()
        assertTrue(File(webpData.localFilePath).exists())
        assertEquals("image/webp", webpData.mimeType)
    }

    @Test
    fun `imports content uri via content resolver and opens streams consistently`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val pngBytes = createBitmapBytes(Bitmap.CompressFormat.PNG, 180, 180)
        val contentUri = Uri.parse("content://com.example.mockpicker/media/42")

        val shadowResolver = Shadows.shadowOf(app.contentResolver)
        shadowResolver.registerInputStream(contentUri, ByteArrayInputStream(pngBytes))

        val res = ImageImportHelper.importImageToLocalStorage(app, contentUri.toString())
        assertTrue("content:// URI import should succeed: ${res.exceptionOrNull()?.message}", res.isSuccess)
        val imported = res.getOrThrow()
        assertTrue(File(imported.localFilePath).exists())
        assertTrue(imported.fileSizeBytes > 0L)
        assertEquals(180, imported.width)

        // Ensure openUriInputStream & toCoilModel resolve local paths and file:// URIs
        ImageImportHelper.openUriInputStream(app, imported.localFilePath)?.use { stream ->
            assertTrue(stream.readBytes().isNotEmpty())
        } ?: error("Expected non-null stream for imported local file")

        val coilModel = ImageImportHelper.toCoilModel(imported.localFilePath)
        assertTrue(coilModel is File)
    }

    @Test
    fun `corrupt and missing image files fail gracefully with clear error`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val tempDir = File(app.cacheDir, "test_img_bad").apply { mkdirs() }
        val corruptFile = File(tempDir, "broken.jpg")
        corruptFile.writeText("NOT_A_REAL_IMAGE_BYTES")

        val corruptRes = ImageImportHelper.importImageToLocalStorage(app, corruptFile.absolutePath)
        assertTrue(corruptRes.isFailure)
        assertNotNull(corruptRes.exceptionOrNull()?.message)

        val missingRes = ImageImportHelper.importImageToLocalStorage(app, "/nonexistent/missing.png")
        assertTrue(missingRes.isFailure)

        val blankRes = ImageImportHelper.importImageToLocalStorage(app, "   ")
        assertTrue(blankRes.isFailure)
    }

    @Test
    fun `viewmodels stage selected gallery images and expose ready paths for preview and video creation`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val testImg = File(app.cacheDir, "vm_pick_photo.jpg")
        FileOutputStream(testImg).use { it.write(createBitmapBytes(Bitmap.CompressFormat.JPEG, 240, 320)) }
        val fileUri = Uri.fromFile(testImg).toString()

        suspend fun idleUntil(condition: () -> Boolean) {
            repeat(60) {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                if (condition()) return
                delay(25)
            }
            Shadows.shadowOf(Looper.getMainLooper()).idle()
        }

        // 1. AnimateImageViewModel (Image-to-Video)
        val animateVm = AnimateImageViewModel(app)
        animateVm.setSelectedImage(fileUri)
        idleUntil { !animateVm.uiState.value.isImportingImage && animateVm.uiState.value.selectedImageUri != null }
        val animState = animateVm.uiState.value
        assertFalse(animState.isImportingImage)
        assertNull(animState.imageImportError)
        assertNotNull(animState.selectedImageUri)
        assertTrue(File(animState.selectedImageUri!!).exists())

        // 2. ImageStudioViewModel (Edit Image upload)
        val imageVm = ImageStudioViewModel(app)
        imageVm.setUploadedImage(fileUri)
        idleUntil { !imageVm.uiState.value.isImportingImage && imageVm.uiState.value.uploadedImageUri != null }
        val imgState = imageVm.uiState.value
        assertFalse(imgState.isImportingImage)
        assertNull(imgState.imageImportError)
        assertNotNull(imgState.uploadedImageUri)
        assertTrue(File(imgState.uploadedImageUri!!).exists())

        // 3. FreeVideoMakerViewModel (Scene gallery photo selection)
        val freeVm = FreeVideoMakerViewModel(app)
        freeVm.createScenesManually()
        freeVm.setActiveSceneForPicker(0)
        freeVm.onImageSelected(fileUri)
        idleUntil { !freeVm.uiState.value.isImportingImage && freeVm.uiState.value.project.scenes.first().imageUri != null }
        val freeState = freeVm.uiState.value
        assertFalse(freeState.isImportingImage)
        val scene0Img = freeState.project.scenes.first().imageUri
        assertNotNull(scene0Img)
        assertTrue(File(scene0Img!!).exists())
    }
}
