package com.example

import com.example.data.model.AllInOneStep
import com.example.data.model.MotionEffect
import com.example.data.model.StoryCharacter
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoStyle
import com.example.data.model.VoiceGender
import com.example.data.remote.FreeVideoStoryGenerator
import com.example.data.remote.GoogleAiStudioService
import com.example.data.remote.video.GoogleVeoRequestBuilder
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class StudioFeaturesTest {

    @Test
    fun `aspect ratio 4_5 and motion effects are registered`() {
        val ratios = VideoAspectRatio.entries.map { it.ratio }
        assertTrue(ratios.contains("9:16"))
        assertTrue(ratios.contains("16:9"))
        assertTrue(ratios.contains("1:1"))
        assertTrue(ratios.contains("4:5"))

        assertTrue(MotionEffect.entries.size >= 6)
        assertEquals(8, AllInOneStep.entries.size)
        assertEquals(1, AllInOneStep.STEP_1_STORY.stepNumber)
        assertEquals(8, AllInOneStep.STEP_8_EXPORT.stepNumber)
    }

    @Test
    fun `google veo request builder supports image to video and normalizes 4_5 ratio`() {
        val req = GoogleVeoRequestBuilder.buildRequestJson(
            prompt = "A calm river flowing through village",
            style = "Cinematic",
            aspectRatio = "4:5",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            imageBase64 = "ZmFrZUJhc2U2NA==",
            imageMimeType = "image/jpeg"
        )
        GoogleVeoRequestBuilder.validateRequestJson(req)

        val instance = req.getJSONArray("instances").getJSONObject(0)
        assertTrue(instance.has("image"))
        assertEquals("ZmFrZUJhc2U2NA==", instance.getJSONObject("image").getString("bytesBase64Encoded"))
        assertEquals("image/jpeg", instance.getJSONObject("image").getString("mimeType"))

        val params = req.getJSONObject("parameters")
        assertEquals("9:16", params.getString("aspectRatio"))
        assertFalse(req.has("language"))
        assertFalse(params.has("language"))
    }

    @Test
    fun `character consistency prompt and google ai service parsing work accurately`() {
        val character = StoryCharacter(
            name = "Aarav",
            age = "10",
            facialFeatures = "bright eyes, joyful smile",
            hairAndStyle = "short dark hair",
            clothingAndColors = "sky-blue cotton shirt",
            voiceGender = VoiceGender.MALE,
            voiceTone = "Youthful"
        )
        val summary = character.toConsistencyPrompt()
        assertTrue(summary.contains("Aarav"))
        assertTrue(summary.contains("sky-blue cotton shirt"))
        assertTrue(summary.contains("bright eyes"))

        val aiService = GoogleAiStudioService()
        val parsedIds = aiService.parseAvailableModelIds(
            """
            {
              "models": [
                {"name": "models/gemini-2.5-flash"},
                {"name": "models/gemini-2.5-flash-image"},
                {"name": "models/veo-2.0-generate-001"}
              ]
            }
            """.trimIndent()
        )
        assertTrue(parsedIds.contains("gemini-2.5-flash"))
        assertTrue(parsedIds.contains("gemini-2.5-flash-image"))
        assertTrue(parsedIds.contains("veo-2.0-generate-001"))

        val err403 = aiService.mapHttpError(403, """{"error":{"message":"Billing not enabled"}}""", "Imagen 3")
        assertTrue(err403.contains("403"))
        assertTrue(err403.contains("Billing not enabled"))

        val localChars = aiService.buildLocalConsistentCharacters("एक किसान अपने खेत में काम कर रहा था", VideoStyle.CARTOON_3D, "Hindi")
        assertTrue(localChars.isNotEmpty())
        assertTrue(localChars.first().clothingAndColors.isNotBlank())
    }

    @Test
    fun `storyboard generator injects consistent characters into scene image prompts`() = runBlocking {
        val generator = FreeVideoStoryGenerator()
        val characters = listOf(
            StoryCharacter(
                name = "Meera",
                age = "24",
                facialFeatures = "warm smile",
                clothingAndColors = "saffron silk dupatta",
                voiceGender = VoiceGender.FEMALE
            )
        )
        val project = generator.generateStoryboard(
            storyIdea = "Meera teaches solar energy in her village",
            language = "English",
            aspectRatio = "4:5",
            targetDurationSeconds = 15,
            style = VideoStyle.CARTOON_3D,
            characters = characters,
            apiKeyOverride = ""
        )
        assertEquals("4:5", project.aspectRatio)
        assertTrue(project.scenes.isNotEmpty())
        assertTrue(project.scenes.first().imagePrompt.contains("saffron silk dupatta"))
    }
}
