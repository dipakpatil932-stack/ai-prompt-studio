package com.example

import androidx.test.core.app.ApplicationProvider
import com.example.data.local.UserSettings
import com.example.data.local.VideoJobEntity
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import com.example.data.remote.video.GoogleVeoRequestBuilder
import com.example.data.remote.video.VideoConfigException
import com.example.data.remote.video.VideoGenerationService
import kotlinx.coroutines.test.runTest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class VideoGenerationServiceTest {

    @Test
    fun testInputValidationForBlankPrompt() = runTest {
        val service = VideoGenerationService(ApplicationProvider.getApplicationContext())
        val settings = UserSettings(
            providerType = VideoProviderType.GOOGLE_VEO,
            providerApiKey = "test_key"
        )

        val result = service.submitJob(
            prompt = "   ",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "9:16",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            settings = settings
        )

        assertTrue(result.isFailure)
        val error = result.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
        assertTrue(error?.message?.contains("Please enter a story") == true)
    }

    @Test
    fun testMissingCustomBackendFailsWithConfigException() = runTest {
        val service = VideoGenerationService(ApplicationProvider.getApplicationContext())
        val settings = UserSettings(
            providerType = VideoProviderType.CUSTOM_BACKEND,
            customBackendUrl = ""
        )

        val result = service.submitJob(
            prompt = "एक बच्चा गांव में खेल रहा है",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "9:16",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            settings = settings
        )

        assertTrue(result.isFailure)
        val error = result.exceptionOrNull()
        assertTrue(error is VideoConfigException)
        assertTrue(error?.message?.contains("Custom Video Server URL is not configured") == true)
    }

    @Test
    fun testMissingApiKeyFailsCleanly() = runTest {
        val service = VideoGenerationService(ApplicationProvider.getApplicationContext())
        val settings = UserSettings(
            providerType = VideoProviderType.LUMA_DREAM_MACHINE,
            providerApiKey = ""
        )

        val result = service.submitJob(
            prompt = "Indian village festival celebration",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "16:9",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            settings = settings
        )

        assertTrue(result.isFailure)
        val error = result.exceptionOrNull()
        assertTrue(error is VideoConfigException)
        assertTrue(error?.message?.contains("Luma Dream Machine API API key is not configured") == true)
    }

    @Test
    fun testGoogleVeoRequestBuilderCreatesValidOfficialSchema() {
        val json = GoogleVeoRequestBuilder.buildRequestJson(
            prompt = "गांव की सुबह का खूबसूरत दृश्य",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "9:16",
            duration = "5 sec",
            dialogueLanguage = "Hindi"
        )

        // 1. Verify ONLY supported root fields exist
        val rootKeys = json.keys().asSequence().toSet()
        assertEquals(setOf("instances", "parameters"), rootKeys)

        // 2. Verify root MUST NOT contain invalid fields
        assertFalse("Must not have root 'prompt'", json.has("prompt"))
        assertFalse("Must not have root 'aspectRatio'", json.has("aspectRatio"))
        assertFalse("Must not have root 'durationSeconds'", json.has("durationSeconds"))
        assertFalse("Must not have root 'language'", json.has("language"))

        // 3. Verify instances
        val instances = json.getJSONArray("instances")
        assertEquals(1, instances.length())
        val instance0 = instances.getJSONObject(0)
        val promptText = instance0.getString("prompt")
        assertTrue("Prompt must contain user prompt", promptText.contains("गांव की सुबह"))
        assertTrue("Prompt must contain cinematic style modifier", promptText.contains("Photorealistic Indian cinematic"))
        assertTrue("Prompt must contain Hindi dialogue instructions", promptText.contains("Hindi"))

        // 4. Verify parameters
        val parameters = json.getJSONObject("parameters")
        assertEquals(1, parameters.getInt("sampleCount"))
        assertEquals("9:16", parameters.getString("aspectRatio"))
        assertEquals(5, parameters.getInt("durationSeconds"))
        assertFalse("Parameters must not contain 'language'", parameters.has("language"))
        assertFalse("Parameters must not contain 'prompt'", parameters.has("prompt"))

        // 5. Validator must pass
        GoogleVeoRequestBuilder.validateRequestJson(json)
    }

    @Test
    fun testGoogleVeoValidationRejectsUnsupportedRootFields() {
        // Attempt with legacy invalid schema (containing top-level prompt)
        val invalidJson = JSONObject().apply {
            put("prompt", "invalid prompt at root")
            put("aspectRatio", "16:9")
            put("durationSeconds", 5)
            put("language", "Hindi")
            put("instances", JSONArray().apply {
                put(JSONObject().apply { put("prompt", "valid") })
            })
            put("parameters", JSONObject().apply {
                put("sampleCount", 1)
                put("aspectRatio", "16:9")
            })
        }

        try {
            GoogleVeoRequestBuilder.validateRequestJson(invalidJson)
            fail("Expected IllegalArgumentException for invalid root fields")
        } catch (e: IllegalArgumentException) {
            assertTrue(
                "Error should mention unsupported root field or Cannot find field",
                e.message?.contains("Unknown name") == true || e.message?.contains("unsupported root fields") == true
            )
        }
    }

    @Test
    fun testGoogleVeoValidationRejectsLanguageInParameters() {
        val json = JSONObject().apply {
            put("instances", JSONArray().apply {
                put(JSONObject().apply { put("prompt", "test prompt") })
            })
            put("parameters", JSONObject().apply {
                put("sampleCount", 1)
                put("aspectRatio", "16:9")
                put("language", "Hindi") // Unsupported parameter
            })
        }

        try {
            GoogleVeoRequestBuilder.validateRequestJson(json)
            fail("Expected IllegalArgumentException for 'language' parameter")
        } catch (e: IllegalArgumentException) {
            assertTrue(
                "Error should specifically mention 'language' is not supported",
                e.message?.contains("Unknown name 'language'") == true
            )
        }
    }

    @Test
    fun testGoogleVeoAspectRatioMapping() {
        val json916 = GoogleVeoRequestBuilder.buildRequestJson("prompt", aspectRatio = "9:16")
        assertEquals("9:16", json916.getJSONObject("parameters").getString("aspectRatio"))

        val json169 = GoogleVeoRequestBuilder.buildRequestJson("prompt", aspectRatio = "16:9")
        assertEquals("16:9", json169.getJSONObject("parameters").getString("aspectRatio"))

        val json11 = GoogleVeoRequestBuilder.buildRequestJson("prompt", aspectRatio = "1:1")
        assertEquals("1:1", json11.getJSONObject("parameters").getString("aspectRatio"))
    }

    @Test
    fun testGoogleVeoDurationMapping() {
        val json5s = GoogleVeoRequestBuilder.buildRequestJson("prompt", duration = "5 sec")
        assertEquals(5, json5s.getJSONObject("parameters").getInt("durationSeconds"))

        val json10s = GoogleVeoRequestBuilder.buildRequestJson("prompt", duration = "10 sec")
        assertEquals(8, json10s.getJSONObject("parameters").getInt("durationSeconds"))
    }

    @Test
    fun testGoogleVeoErrorParsing400WithFieldViolations() {
        val errorJson = """
            {
              "error": {
                "code": 400,
                "message": "Invalid JSON payload received. Unknown name 'prompt': Cannot find field.",
                "status": "INVALID_ARGUMENT",
                "details": [
                  {
                    "@type": "type.googleapis.com/google.rpc.BadRequest",
                    "fieldViolations": [
                      {
                        "field": "prompt",
                        "description": "Unknown name 'prompt': Cannot find field."
                      },
                      {
                        "field": "language",
                        "description": "Unknown name 'language': Cannot find field."
                      }
                    ]
                  }
                ]
              }
            }
        """.trimIndent()

        val parsed = GoogleVeoRequestBuilder.parseGoogleApiError(errorJson, 400)
        assertTrue(parsed.contains("400"))
        assertTrue(parsed.contains("INVALID_ARGUMENT"))
        assertTrue(parsed.contains("Unknown name 'prompt': Cannot find field."))
    }

    @Test
    fun testGoogleVeoErrorParsing429QuotaExceeded() {
        val errorJson = """
            {
              "error": {
                "code": 429,
                "message": "Resource has been exhausted (e.g. check quota).",
                "status": "RESOURCE_EXHAUSTED"
              }
            }
        """.trimIndent()

        val parsed = GoogleVeoRequestBuilder.parseGoogleApiError(errorJson, 429)
        assertTrue(parsed.contains("429"))
        assertTrue(parsed.contains("Quota exceeded"))
    }

    @Test
    fun testGoogleVeoExtractVideoUri() {
        // Format: response.generateVideoResponse.generatedSamples[0].video.uri
        val sampleJson1 = JSONObject("""
            {
              "name": "operations/123",
              "done": true,
              "response": {
                "generateVideoResponse": {
                  "generatedSamples": [
                    {
                      "video": {
                        "uri": "https://generativelanguage.googleapis.com/v1beta/files/abc123xyz:download?alt=media"
                      }
                    }
                  ]
                }
              }
            }
        """.trimIndent())

        val uri1 = GoogleVeoRequestBuilder.extractVideoUri(sampleJson1)
        assertEquals("https://generativelanguage.googleapis.com/v1beta/files/abc123xyz:download?alt=media", uri1)

        // Format: response.videos[0].uri
        val sampleJson2 = JSONObject("""
            {
              "name": "operations/456",
              "done": true,
              "response": {
                "videos": [
                  {
                    "uri": "https://storage.googleapis.com/bucket/video.mp4"
                  }
                ]
              }
            }
        """.trimIndent())

        val uri2 = GoogleVeoRequestBuilder.extractVideoUri(sampleJson2)
        assertEquals("https://storage.googleapis.com/bucket/video.mp4", uri2)
    }

    @Test
    fun testVideoJobEntityConversion() {
        val job = VideoJob(
            id = 42L,
            jobId = "veo_test_123",
            prompt = "दादी और पोता चूल्हे पर खाना बना रहे हैं",
            style = VideoStyle.REALISTIC.displayName,
            aspectRatio = VideoAspectRatio.RATIO_9_16.ratio,
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            provider = VideoProviderType.GOOGLE_VEO.displayName,
            status = VideoJobStatus.COMPLETED,
            progressPercent = 100,
            statusMessage = "Video Ready",
            videoUrl = "https://example.com/test.mp4",
            localVideoPath = "/data/user/0/com.example/files/videos/video_123.mp4"
        )

        val entity = VideoJobEntity.fromDomain(job)
        assertEquals(42L, entity.id)
        assertEquals("veo_test_123", entity.jobId)
        assertEquals(VideoJobStatus.COMPLETED.name, entity.status)
        assertEquals("https://example.com/test.mp4", entity.videoUrl)

        val convertedBack = entity.toDomain()
        assertEquals(job.id, convertedBack.id)
        assertEquals(job.jobId, convertedBack.jobId)
        assertEquals(job.prompt, convertedBack.prompt)
        assertEquals(VideoJobStatus.COMPLETED, convertedBack.status)
        assertEquals(job.localVideoPath, convertedBack.localVideoPath)
    }
}
