package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.audio.StoryAudioMixer
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.StoryEmotion
import com.example.data.model.VoiceGender
import com.example.data.remote.FreeVideoStoryGenerator
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FreeVideoMakerTest {

    private val generator = FreeVideoStoryGenerator()

    @Test
    fun testGenerateStoryboardHindi() = runTest {
        val storyIdea = "गांव के एक छोटे लड़के ने अपनी मेहनत और ईमानदारी से गांव के स्कूल को पहला पुरस्कार दिलवाया।"
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "Hindi",
            aspectRatio = "9:16",
            targetDurationSeconds = 20
        )

        assertNotNull(project)
        assertEquals("Hindi", project.language)
        assertEquals("9:16", project.aspectRatio)
        assertTrue("Project title should not be blank", project.title.isNotBlank())
        assertTrue("Scenes should not be empty", project.scenes.isNotEmpty())
        assertEquals(6, project.scenes.size)

        project.scenes.forEachIndexed { index, scene ->
            assertEquals(index + 1, scene.sceneNumber)
            assertTrue("Scene ${scene.sceneNumber} title should not be blank", scene.title.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} image prompt should not be blank", scene.imagePrompt.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} caption should not be blank", scene.caption.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} narration or music should not be blank", scene.narrationText.isNotBlank() || scene.bgMusicDescription.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} duration should be > 0", scene.durationSeconds > 0)
        }
    }

    @Test
    fun testGenerateStoryboardGujarati() = runTest {
        val storyIdea = "એક ખેડૂતનો પુત્ર નવી ટેકનોલોજીનો ઉપયોગ કરીને પોતાના ગામનું ગૌરવ વધારે છે."
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "Gujarati",
            aspectRatio = "16:9",
            targetDurationSeconds = 16
        )

        assertNotNull(project)
        assertEquals("Gujarati", project.language)
        assertEquals("16:9", project.aspectRatio)
        assertTrue(project.title.isNotBlank())
        assertTrue(project.scenes.isNotEmpty())
        assertEquals(6, project.scenes.size)

        val firstScene = project.scenes.first()
        assertTrue("First scene should have title in Gujarati", firstScene.title.contains("દ્રશ્ય") || firstScene.title.isNotBlank())
        assertTrue(firstScene.caption.isNotBlank())
        assertTrue(firstScene.imagePrompt.isNotBlank())
    }

    @Test
    fun testGenerateStoryboardEnglish() = runTest {
        val storyIdea = "A young innovator builds a solar-powered lamp to help children study at night."
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "English",
            aspectRatio = "1:1",
            targetDurationSeconds = 12
        )

        assertNotNull(project)
        assertEquals("English", project.language)
        assertEquals("1:1", project.aspectRatio)
        assertTrue(project.title.isNotBlank())
        assertTrue(project.scenes.isNotEmpty())

        val totalDuration = project.scenes.sumOf { it.durationSeconds }
        assertTrue("Total duration should be positive", totalDuration > 0)
    }

    @Test
    fun testEmotionDetectionAndPresets() {
        val devotionalStory = "भगवान श्रीकृष्ण के पावन मंदिर में सुबह की आरती और कीर्तन।"
        val horrorStory = "अंधेरी रात में उस पुराने खंडहर में एक डरावनी आवाज सुनाई दी।"
        val happyStory = "गांव में बंपर फसल होने पर सभी किसानों ने खुशी से उत्सव मनाया।"
        val sadStory = "अपने पुराने घर को छोड़ते समय उसकी आंखों से आंसू छलक पड़े।"

        assertEquals(StoryEmotion.DEVOTIONAL, StoryEmotion.detectEmotion(devotionalStory))
        assertEquals(StoryEmotion.HORROR, StoryEmotion.detectEmotion(horrorStory))
        assertEquals(StoryEmotion.HAPPY, StoryEmotion.detectEmotion(happyStory))
        assertEquals(StoryEmotion.SAD, StoryEmotion.detectEmotion(sadStory))

        // Check speech rates and pitches
        assertTrue(StoryEmotion.HORROR.speechRate < 1.0f)
        assertTrue(StoryEmotion.HAPPY.pitch > 1.0f)
        assertTrue(StoryEmotion.DEVOTIONAL.speechRate <= 1.0f)
    }

    @Test
    fun testFreeVideoProjectSceneManipulation() {
        val initialScenes = listOf(
            FreeVideoScene(sceneNumber = 1, title = "Scene 1", caption = "Opening", narrationText = "Voice 1", durationSeconds = 5),
            FreeVideoScene(sceneNumber = 2, title = "Scene 2", caption = "Middle", narrationText = "Voice 2", durationSeconds = 6),
            FreeVideoScene(sceneNumber = 3, title = "Scene 3", caption = "Ending", narrationText = "Voice 3", durationSeconds = 4)
        )

        val project = FreeVideoProject(
            title = "Test Slideshow",
            storyPrompt = "Test story idea",
            aspectRatio = "9:16",
            emotion = StoryEmotion.MOTIVATIONAL,
            voiceGender = VoiceGender.FEMALE,
            scenes = initialScenes
        )

        assertEquals(3, project.scenes.size)
        assertEquals(15, project.scenes.sumOf { it.durationSeconds })
        assertEquals(StoryEmotion.MOTIVATIONAL, project.emotion)
        assertEquals(VoiceGender.FEMALE, project.voiceGender)

        // Test reordering (move middle scene to first)
        val reordered = project.scenes.toMutableList().apply {
            val item = removeAt(1)
            add(0, item)
        }
        assertEquals("Scene 2", reordered[0].title)
        assertEquals("Scene 1", reordered[1].title)

        // Test removing a scene
        val deleted = reordered.toMutableList().apply { removeAt(2) }
        assertEquals(2, deleted.size)
        assertEquals(11, deleted.sumOf { it.durationSeconds })
    }

    @Test
    fun testAcousticWavSynthesisAndDurationCalculation() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "audio_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val testWav = File(tempDir, "test_hindi_narration.wav")

        try {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val voiceManager = com.example.data.audio.StoryVoiceManager(context)
            val testSentence = "एक छोटे से सुंदर गांव में मोहन नाम का एक बहुत मेहनती बालक रहता था।"
            val expectedDurationSeconds = 4

            voiceManager.createAcousticSpeechWav(
                text = testSentence,
                outputFile = testWav,
                durationSeconds = expectedDurationSeconds,
                emotion = StoryEmotion.MOTIVATIONAL
            )

            assertTrue("Test WAV file should exist", testWav.exists())
            assertTrue("Test WAV file should have data > 44 bytes", testWav.length() > 44)

            // Verify WAV header
            val header = ByteArray(44)
            java.io.FileInputStream(testWav).use { it.read(header) }
            val riff = String(header, 0, 4)
            val wave = String(header, 8, 4)
            val fmt = String(header, 12, 4)
            val data = String(header, 36, 4)

            assertEquals("RIFF", riff)
            assertEquals("WAVE", wave)
            assertEquals("fmt ", fmt)
            assertEquals("data", data)

            // Verify duration calculation
            val calculatedMs = voiceManager.computeWavDurationMs(testWav)
            assertTrue("Duration should be approximately 4000ms: $calculatedMs", calculatedMs in 3800L..4200L)

            // Verify AacAudioEncoder can parse this WAV's MediaFormat
            val aacEncoder = com.example.data.audio.AacAudioEncoder()
            val format = aacEncoder.createAudioFormatFromWav(testWav)
            assertNotNull("MediaFormat should be created from WAV", format)
            assertEquals("audio/mp4a-latm", format?.getString(android.media.MediaFormat.KEY_MIME))
            assertEquals(com.example.data.audio.StoryVoiceManager.SYNTHESIS_SAMPLE_RATE, format?.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE))
            assertEquals(1, format?.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT))

        } finally {
            testWav.delete()
            tempDir.delete()
        }
    }
}
