package com.example

import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.remote.FreeVideoStoryGenerator
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeVideoMakerTest {

    private val generator = FreeVideoStoryGenerator()

    @Test
    fun testGenerateStoryboardHindi() = runTest {
        val storyIdea = "गांव के एक छोटे लड़के ने अपनी मेहनत और ईमानदारी से गांव के स्कूल को पहला पुरस्कार दिलवाया।"
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "Hindi",
            aspectRatio = "9:16",
            targetDurationSeconds = 20
        )

        assertNotNull(project)
        assertEquals("Hindi", project.language)
        assertEquals("9:16", project.aspectRatio)
        assertTrue("Project title should not be blank", project.title.isNotBlank())
        assertTrue("Scenes should not be empty", project.scenes.isNotEmpty())
        assertEquals(6, project.scenes.size)

        project.scenes.forEachIndexed { index, scene ->
            assertEquals(index + 1, scene.sceneNumber)
            assertTrue("Scene ${scene.sceneNumber} title should not be blank", scene.title.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} image prompt should not be blank", scene.imagePrompt.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} caption should not be blank", scene.caption.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} narration or music should not be blank", scene.narrationText.isNotBlank() || scene.bgMusicDescription.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} duration should be > 0", scene.durationSeconds > 0)
        }
    }

    @Test
    fun testGenerateStoryboardGujarati() = runTest {
        val storyIdea = "એક ખેડૂતનો પુત્ર નવી ટેકનોલોજીનો ઉપયોગ કરીને પોતાના ગામનું ગૌરવ વધારે છે."
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "Gujarati",
            aspectRatio = "16:9",
            targetDurationSeconds = 16
        )

        assertNotNull(project)
        assertEquals("Gujarati", project.language)
        assertEquals("16:9", project.aspectRatio)
        assertTrue(project.title.isNotBlank())
        assertTrue(project.scenes.isNotEmpty())
        assertEquals(6, project.scenes.size)

        val firstScene = project.scenes.first()
        assertTrue("First scene should have title in Gujarati", firstScene.title.contains("દ્રશ્ય") || firstScene.title.isNotBlank())
        assertTrue(firstScene.caption.isNotBlank())
        assertTrue(firstScene.imagePrompt.isNotBlank())
    }

    @Test
    fun testGenerateStoryboardEnglish() = runTest {
        val storyIdea = "A young innovator builds a solar-powered lamp to help children study at night."
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "English",
            aspectRatio = "1:1",
            targetDurationSeconds = 12
        )

        assertNotNull(project)
        assertEquals("English", project.language)
        assertEquals("1:1", project.aspectRatio)
        assertTrue(project.title.isNotBlank())
        assertTrue(project.scenes.isNotEmpty())

        val totalDuration = project.scenes.sumOf { it.durationSeconds }
        assertTrue("Total duration should be positive", totalDuration > 0)
    }

    @Test
    fun testFreeVideoProjectSceneManipulation() {
        val initialScenes = listOf(
            FreeVideoScene(sceneNumber = 1, title = "Scene 1", caption = "Opening", durationSeconds = 5),
            FreeVideoScene(sceneNumber = 2, title = "Scene 2", caption = "Middle", durationSeconds = 6),
            FreeVideoScene(sceneNumber = 3, title = "Scene 3", caption = "Ending", durationSeconds = 4)
        )

        val project = FreeVideoProject(
            title = "Test Slideshow",
            storyPrompt = "Test story idea",
            aspectRatio = "9:16",
            scenes = initialScenes
        )

        assertEquals(3, project.scenes.size)
        assertEquals(15, project.scenes.sumOf { it.durationSeconds })

        // Test reordering (move middle scene to first)
        val reordered = project.scenes.toMutableList().apply {
            val item = removeAt(1)
            add(0, item)
        }
        assertEquals("Scene 2", reordered[0].title)
        assertEquals("Scene 1", reordered[1].title)

        // Test removing a scene
        val deleted = reordered.toMutableList().apply { removeAt(2) }
        assertEquals(2, deleted.size)
        assertEquals(11, deleted.sumOf { it.durationSeconds })
    }
}
