package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.audio.StoryAudioMixer
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.StoryEmotion
import com.example.data.model.VoiceGender
import com.example.data.remote.FreeVideoStoryGenerator
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FreeVideoMakerTest {

    private val generator = FreeVideoStoryGenerator()

    @Test
    fun testGenerateStoryboardHindi() = runTest {
        val storyIdea = "गांव के एक छोटे लड़के ने अपनी मेहनत और ईमानदारी से गांव के स्कूल को पहला पुरस्कार दिलवाया।"
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "Hindi",
            aspectRatio = "9:16",
            targetDurationSeconds = 20
        )

        assertNotNull(project)
        assertEquals("Hindi", project.language)
        assertEquals("9:16", project.aspectRatio)
        assertTrue("Project title should not be blank", project.title.isNotBlank())
        assertTrue("Scenes should not be empty", project.scenes.isNotEmpty())
        assertEquals(6, project.scenes.size)

        project.scenes.forEachIndexed { index, scene ->
            assertEquals(index + 1, scene.sceneNumber)
            assertTrue("Scene ${scene.sceneNumber} title should not be blank", scene.title.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} image prompt should not be blank", scene.imagePrompt.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} caption should not be blank", scene.caption.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} narration or music should not be blank", scene.narrationText.isNotBlank() || scene.bgMusicDescription.isNotBlank())
            assertTrue("Scene ${scene.sceneNumber} duration should be > 0", scene.durationSeconds > 0)
        }
    }

    @Test
    fun testGenerateStoryboardGujarati() = runTest {
        val storyIdea = "એક ખેડૂતનો પુત્ર નવી ટેકનોલોજીનો ઉપયોગ કરીને પોતાના ગામનું ગૌરવ વધારે છે."
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "Gujarati",
            aspectRatio = "16:9",
            targetDurationSeconds = 16
        )

        assertNotNull(project)
        assertEquals("Gujarati", project.language)
        assertEquals("16:9", project.aspectRatio)
        assertTrue(project.title.isNotBlank())
        assertTrue(project.scenes.isNotEmpty())
        assertEquals(6, project.scenes.size)

        val firstScene = project.scenes.first()
        assertTrue("First scene should have title in Gujarati", firstScene.title.contains("દ્રશ્ય") || firstScene.title.isNotBlank())
        assertTrue(firstScene.caption.isNotBlank())
        assertTrue(firstScene.imagePrompt.isNotBlank())
    }

    @Test
    fun testGenerateStoryboardEnglish() = runTest {
        val storyIdea = "A young innovator builds a solar-powered lamp to help children study at night."
        val project = generator.generateStoryboard(
            storyIdea = storyIdea,
            language = "English",
            aspectRatio = "1:1",
            targetDurationSeconds = 12
        )

        assertNotNull(project)
        assertEquals("English", project.language)
        assertEquals("1:1", project.aspectRatio)
        assertTrue(project.title.isNotBlank())
        assertTrue(project.scenes.isNotEmpty())

        val totalDuration = project.scenes.sumOf { it.durationSeconds }
        assertTrue("Total duration should be positive", totalDuration > 0)
    }

    @Test
    fun testEmotionDetectionAndPresets() {
        val devotionalStory = "भगवान श्रीकृष्ण के पावन मंदिर में सुबह की आरती और कीर्तन।"
        val horrorStory = "अंधेरी रात में उस पुराने खंडहर में एक डरावनी आवाज सुनाई दी।"
        val happyStory = "गांव में बंपर फसल होने पर सभी किसानों ने खुशी से उत्सव मनाया।"
        val sadStory = "अपने पुराने घर को छोड़ते समय उसकी आंखों से आंसू छलक पड़े।"

        assertEquals(StoryEmotion.DEVOTIONAL, StoryEmotion.detectEmotion(devotionalStory))
        assertEquals(StoryEmotion.HORROR, StoryEmotion.detectEmotion(horrorStory))
        assertEquals(StoryEmotion.HAPPY, StoryEmotion.detectEmotion(happyStory))
        assertEquals(StoryEmotion.SAD, StoryEmotion.detectEmotion(sadStory))

        // Check speech rates and pitches
        assertTrue(StoryEmotion.HORROR.speechRate < 1.0f)
        assertTrue(StoryEmotion.HAPPY.pitch > 1.0f)
        assertTrue(StoryEmotion.DEVOTIONAL.speechRate <= 1.0f)
    }

    @Test
    fun testFreeVideoProjectSceneManipulation() {
        val initialScenes = listOf(
            FreeVideoScene(sceneNumber = 1, title = "Scene 1", caption = "Opening", narrationText = "Voice 1", durationSeconds = 5),
            FreeVideoScene(sceneNumber = 2, title = "Scene 2", caption = "Middle", narrationText = "Voice 2", durationSeconds = 6),
            FreeVideoScene(sceneNumber = 3, title = "Scene 3", caption = "Ending", narrationText = "Voice 3", durationSeconds = 4)
        )

        val project = FreeVideoProject(
            title = "Test Slideshow",
            storyPrompt = "Test story idea",
            aspectRatio = "9:16",
            emotion = StoryEmotion.MOTIVATIONAL,
            voiceGender = VoiceGender.FEMALE,
            scenes = initialScenes
        )

        assertEquals(3, project.scenes.size)
        assertEquals(15, project.scenes.sumOf { it.durationSeconds })
        assertEquals(StoryEmotion.MOTIVATIONAL, project.emotion)
        assertEquals(VoiceGender.FEMALE, project.voiceGender)

        // Test reordering (move middle scene to first)
        val reordered = project.scenes.toMutableList().apply {
            val item = removeAt(1)
            add(0, item)
        }
        assertEquals("Scene 2", reordered[0].title)
        assertEquals("Scene 1", reordered[1].title)

        // Test removing a scene
        val deleted = reordered.toMutableList().apply { removeAt(2) }
        assertEquals(2, deleted.size)
        assertEquals(11, deleted.sumOf { it.durationSeconds })
    }

    @Test
    fun testAcousticWavSynthesisAndDurationCalculation() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "audio_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val testWav = File(tempDir, "test_hindi_narration.wav")

        try {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val voiceManager = com.example.data.audio.StoryVoiceManager(context)
            val testSentence = "एक छोटे से सुंदर गांव में मोहन नाम का एक बहुत मेहनती बालक रहता था।"
            val expectedDurationSeconds = 4

            voiceManager.createAcousticSpeechWav(
                text = testSentence,
                outputFile = testWav,
                durationSeconds = expectedDurationSeconds,
                emotion = StoryEmotion.MOTIVATIONAL
            )

            assertTrue("Test WAV file should exist", testWav.exists())
            assertTrue("Test WAV file should have data > 44 bytes", testWav.length() > 44)

            // Verify WAV header
            val header = ByteArray(44)
            java.io.FileInputStream(testWav).use { it.read(header) }
            val riff = String(header, 0, 4)
            val wave = String(header, 8, 4)
            val fmt = String(header, 12, 4)
            val data = String(header, 36, 4)

            assertEquals("RIFF", riff)
            assertEquals("WAVE", wave)
            assertEquals("fmt ", fmt)
            assertEquals("data", data)

            // Verify duration calculation
            val calculatedMs = voiceManager.computeWavDurationMs(testWav)
            assertTrue("Duration should be approximately 4000ms: $calculatedMs", calculatedMs in 3800L..4200L)

            // Verify AacAudioEncoder can parse this WAV's MediaFormat
            val aacEncoder = com.example.data.audio.AacAudioEncoder()
            val format = aacEncoder.createAudioFormatFromWav(testWav)
            assertNotNull("MediaFormat should be created from WAV", format)
            assertEquals("audio/mp4a-latm", format?.getString(android.media.MediaFormat.KEY_MIME))
            assertEquals(com.example.data.audio.StoryVoiceManager.SYNTHESIS_SAMPLE_RATE, format?.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE))
            assertEquals(1, format?.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT))

        } finally {
            testWav.delete()
            tempDir.delete()
        }
    }

    @Test
    fun testContinuousFourSceneHindiNarrationTimeline() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "hindi_timeline_test_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val voiceManager = com.example.data.audio.StoryVoiceManager(context)
            val audioMixer = StoryAudioMixer(context)

            // Four-scene Hindi story
            val hindiScenes = listOf(
                "दृश्य १: एक छोटे से हरे-भरे गांव में राहुल नाम का एक बहुत मेहनती बालक रहता था।",
                "दृश्य २: उसने बंजर पड़ी जमीन पर जैविक खेती करने का पक्का इरादा किया।",
                "दृश्य ३: कड़ी मेहनत और लगन से कुछ ही महीनों में उसके खेत लहलहा उठे।",
                "दृश्य ४: पूरे गांव ने राहुल के इस शानदार प्रयास की दिल से सराहना की और उससे प्रेरणा ली।"
            )

            val sceneAudioEntries = mutableListOf<StoryAudioMixer.SceneAudioEntry>()

            for ((index, text) in hindiScenes.withIndex()) {
                val sceneNum = index + 1
                val sceneWav = File(tempDir, "scene_${sceneNum}_narration.wav")
                val durationSec = 4

                voiceManager.createAcousticSpeechWav(
                    text = text,
                    outputFile = sceneWav,
                    durationSeconds = durationSec,
                    emotion = StoryEmotion.MOTIVATIONAL
                )

                assertTrue("Scene $sceneNum WAV must exist", sceneWav.exists())
                assertTrue("Scene $sceneNum WAV size must be > 44 bytes", sceneWav.length() > 44)

                val durationMs = voiceManager.computeWavDurationMs(sceneWav)
                val snugSec = maxOf(3, Math.ceil((durationMs + 350L) / 1000.0).toInt()).coerceIn(3, 30)

                sceneAudioEntries.add(
                    StoryAudioMixer.SceneAudioEntry(
                        sceneNumber = sceneNum,
                        sceneDurationSeconds = snugSec,
                        narrationWavPath = sceneWav.absolutePath
                    )
                )
            }

            assertEquals(4, sceneAudioEntries.size)

            val masterOutputWav = File(tempDir, "master_hindi_video_audio.wav")
            val mixSuccess = audioMixer.createMasterAudioTrack(
                sceneEntries = sceneAudioEntries,
                bgMusicUri = null,
                isMusicMuted = true,
                outputFile = masterOutputWav
            )

            assertTrue("Audio mix must succeed", mixSuccess)
            assertTrue("Master output WAV must exist", masterOutputWav.exists())
            assertTrue("Master output WAV size must be > 44 bytes", masterOutputWav.length() > 44)

            val validation = audioMixer.getLastValidation()
            assertNotNull("Audio validation result must not be null", validation)
            validation?.let { valResult ->
                assertTrue("Audio timeline validation must be valid: ${valResult.details}", valResult.isValid)
                assertEquals("All 4 scenes must have active audible speech", 4, valResult.scenesWithSpeechCount)
                assertEquals("Total scenes must be 4", 4, valResult.totalScenesCount)

                // Verify speech coverage is high (> 60%), meaning speech occupies most of the video
                assertTrue("Speech coverage should be > 60%: ${valResult.speechCoveragePercent}%", valResult.speechCoveragePercent >= 60f)

                // Verify maximum silent gap between scene narrations is small (< 1.8 seconds)
                assertTrue("Silent gap between scenes must be small (< 1.8s): ${valResult.maxSilentGapSeconds}s", valResult.maxSilentGapSeconds < 1.8f)
            }

        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun testSampleRateResamplingPreventsSilentGaps() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "resample_test_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val audioMixer = StoryAudioMixer(context)

            // Create a 22050 Hz 16-bit Mono WAV (similar to Android TTS 22.05kHz synthesis)
            val tts22050Wav = File(tempDir, "tts_22050_test.wav")
            val sampleRate = 22050
            val durationSec = 4
            val samplesCount = durationSec * sampleRate
            val pcm = ShortArray(samplesCount)
            for (i in 0 until samplesCount) {
                val t = i.toDouble() / sampleRate
                pcm[i] = (Math.sin(2.0 * Math.PI * 440.0 * t) * 0.5 * Short.MAX_VALUE).toInt().toShort()
            }

            // Write 22.05kHz WAV
            java.io.FileOutputStream(tts22050Wav).use { out ->
                val byteData = ByteArray(pcm.size * 2)
                java.nio.ByteBuffer.wrap(byteData).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm)
                val totalDataLen = byteData.size + 36
                val byteRate = sampleRate * 1 * 2

                val header = ByteArray(44)
                header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
                header[4] = (totalDataLen and 0xff).toByte(); header[5] = ((totalDataLen shr 8) and 0xff).toByte()
                header[6] = ((totalDataLen shr 16) and 0xff).toByte(); header[7] = ((totalDataLen shr 24) and 0xff).toByte()
                header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
                header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
                header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0
                header[20] = 1; header[21] = 0 // PCM
                header[22] = 1; header[23] = 0 // Mono
                header[24] = (sampleRate and 0xff).toByte(); header[25] = ((sampleRate shr 8) and 0xff).toByte()
                header[26] = ((sampleRate shr 16) and 0xff).toByte(); header[27] = ((sampleRate shr 24) and 0xff).toByte()
                header[28] = (byteRate and 0xff).toByte(); header[29] = ((byteRate shr 8) and 0xff).toByte()
                header[30] = ((byteRate shr 16) and 0xff).toByte(); header[31] = ((byteRate shr 24) and 0xff).toByte()
                header[32] = 2; header[33] = 0 // block align
                header[34] = 16; header[35] = 0 // 16 bits
                header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
                header[40] = (byteData.size and 0xff).toByte(); header[41] = ((byteData.size shr 8) and 0xff).toByte()
                header[42] = ((byteData.size shr 16) and 0xff).toByte(); header[43] = ((byteData.size shr 24) and 0xff).toByte()

                out.write(header)
                out.write(byteData)
            }

            val entry = StoryAudioMixer.SceneAudioEntry(
                sceneNumber = 1,
                sceneDurationSeconds = 4,
                narrationWavPath = tts22050Wav.absolutePath
            )

            val masterOut = File(tempDir, "resampled_master.wav")
            val mixSuccess = audioMixer.createMasterAudioTrack(
                sceneEntries = listOf(entry),
                bgMusicUri = null,
                isMusicMuted = true,
                outputFile = masterOut
            )

            assertTrue("Mix of 22050Hz WAV must succeed", mixSuccess)
            val validation = audioMixer.getLastValidation()
            assertNotNull(validation)
            // Due to linear interpolation resampling, 4 seconds of 22.05kHz speech must span ~3.88s of the 4.0s master buffer
            assertTrue("Speech coverage must be > 80% with proper resampling: ${validation?.speechCoveragePercent}%", (validation?.speechCoveragePercent ?: 0f) >= 80f)
            assertTrue("Speech duration must be ~3.8s, NOT 2.0s: ${validation?.speechDurationSeconds}s", (validation?.speechDurationSeconds ?: 0f) >= 3.5f)

        } finally {
            tempDir.deleteRecursively()
        }
    }
}
