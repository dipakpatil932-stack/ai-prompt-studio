package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoStyle
import com.example.ui.screens.FreeVideoMakerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImagePromptScreen
import com.example.ui.screens.MyVideosScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SimpleVideoGeneratorScreen
import com.example.ui.screens.StoryToVideoScreen
import com.example.ui.screens.VideoResultScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.FreeVideoMakerViewModel
import com.example.ui.viewmodel.StoryViewModel
import com.example.ui.viewmodel.VideoGeneratorViewModel

enum class AppScreen(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Home", Icons.Default.Home),
    FREE_VIDEO_MAKER("Free Maker", Icons.Default.VideoLibrary),
    GENERATE_VIDEO("Video", Icons.Default.VideoCameraBack),
    STORY_TO_VIDEO("Story", Icons.AutoMirrored.Filled.MenuBook),
    IMAGE_PROMPT("Image", Icons.Default.Image),
    MY_VIDEOS("History", Icons.Default.History),
    SETTINGS("Settings", Icons.Default.Settings),
    VIDEO_RESULT("Result", Icons.Default.Movie)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(
    storyViewModel: StoryViewModel = viewModel(),
    videoViewModel: VideoGeneratorViewModel = viewModel(),
    freeVideoViewModel: FreeVideoMakerViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    val storyState by storyViewModel.uiState.collectAsStateWithLifecycle()
    val savedStories by storyViewModel.savedStories.collectAsStateWithLifecycle()

    val videoState by videoViewModel.uiState.collectAsStateWithLifecycle()
    val savedVideos by videoViewModel.savedVideos.collectAsStateWithLifecycle()
    val settings by videoViewModel.settings.collectAsStateWithLifecycle()

    val freeVideoState by freeVideoViewModel.uiState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Intercept hardware / system back gesture
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        currentScreen = AppScreen.HOME
    }

    // Automatically navigate to VideoResultScreen when generation completes
    LaunchedEffect(videoState.currentStatus, videoState.activeJob) {
        if (videoState.currentStatus == VideoJobStatus.COMPLETED && videoState.activeJob != null && currentScreen == AppScreen.GENERATE_VIDEO) {
            currentScreen = AppScreen.VIDEO_RESULT
        }
    }

    LaunchedEffect(storyState.snackbarMessage) {
        val msg = storyState.snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            storyViewModel.clearSnackbar()
        }
    }

    LaunchedEffect(freeVideoState.errorMessage) {
        val err = freeVideoState.errorMessage
        if (err != null) {
            snackbarHostState.showSnackbar(err)
            freeVideoViewModel.clearError()
        }
    }

    val isProviderConfigured = settings.providerApiKey.isNotBlank() || settings.customBackendUrl.isNotBlank() || runCatching {
        val k = BuildConfig.GEMINI_API_KEY
        k.isNotBlank() && k != "MY_GEMINI_API_KEY"
    }.getOrDefault(false)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (currentScreen) {
                            AppScreen.HOME -> "AI Prompt Studio"
                            AppScreen.FREE_VIDEO_MAKER -> "Free Video Maker"
                            AppScreen.GENERATE_VIDEO -> "Generate Video"
                            AppScreen.STORY_TO_VIDEO -> "Story to Video"
                            AppScreen.IMAGE_PROMPT -> "Image Prompt"
                            AppScreen.MY_VIDEOS -> "My Videos"
                            AppScreen.SETTINGS -> "Settings"
                            AppScreen.VIDEO_RESULT -> "Video Result"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    if (currentScreen != AppScreen.HOME) {
                        IconButton(onClick = { currentScreen = AppScreen.HOME }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Home",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = "App Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                },
                actions = {
                    if (currentScreen != AppScreen.SETTINGS) {
                        IconButton(onClick = { currentScreen = AppScreen.SETTINGS }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val navItems = listOf(
                    AppScreen.HOME,
                    AppScreen.FREE_VIDEO_MAKER,
                    AppScreen.GENERATE_VIDEO,
                    AppScreen.STORY_TO_VIDEO,
                    AppScreen.MY_VIDEOS,
                    AppScreen.SETTINGS
                )

                navItems.forEach { screen ->
                    val isSelected = currentScreen == screen || (screen == AppScreen.GENERATE_VIDEO && currentScreen == AppScreen.VIDEO_RESULT)
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title
                            )
                        },
                        label = { Text(screen.title, fontSize = 10.sp) },
                        modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreen(
                        settings = settings,
                        isProviderConfigured = isProviderConfigured,
                        onNavigateToFreeVideoMaker = { currentScreen = AppScreen.FREE_VIDEO_MAKER },
                        onNavigateToGenerateVideo = { currentScreen = AppScreen.GENERATE_VIDEO },
                        onNavigateToStoryToVideo = { currentScreen = AppScreen.STORY_TO_VIDEO },
                        onNavigateToImagePrompt = { currentScreen = AppScreen.IMAGE_PROMPT },
                        onNavigateToHistory = { currentScreen = AppScreen.MY_VIDEOS },
                        onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                    )
                }

                AppScreen.FREE_VIDEO_MAKER -> {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    FreeVideoMakerScreen(
                        state = freeVideoState,
                        onStoryPromptChange = freeVideoViewModel::updateStoryPrompt,
                        onSelectLanguage = freeVideoViewModel::selectLanguage,
                        onSelectAspectRatio = freeVideoViewModel::selectAspectRatio,
                        onSelectTargetDuration = freeVideoViewModel::selectTargetDuration,
                        onSetSamplePrompt = freeVideoViewModel::setSamplePrompt,
                        onGenerateStoryboard = freeVideoViewModel::generateStoryboard,
                        onCreateScenesManually = freeVideoViewModel::createScenesManually,
                        onSetActiveSceneForPicker = freeVideoViewModel::setActiveSceneForPicker,
                        onImageSelected = freeVideoViewModel::onImageSelected,
                        onRemoveSceneImage = freeVideoViewModel::removeSceneImage,
                        onUpdateSceneCaption = freeVideoViewModel::updateSceneCaption,
                        onUpdateSceneTitle = freeVideoViewModel::updateSceneTitle,
                        onUpdateSceneDuration = freeVideoViewModel::updateSceneDuration,
                        onMoveSceneUp = freeVideoViewModel::moveSceneUp,
                        onMoveSceneDown = freeVideoViewModel::moveSceneDown,
                        onDeleteScene = freeVideoViewModel::deleteScene,
                        onAddNewScene = freeVideoViewModel::addNewScene,
                        onStartCreateMp4 = freeVideoViewModel::startCreateMp4,
                        onCancelExport = freeVideoViewModel::cancelExport,
                        onBackToEditor = freeVideoViewModel::backToEditor,
                        onBackToStoryInput = freeVideoViewModel::backToStoryInput,
                        onSaveToGallery = { freeVideoViewModel.saveVideoToGallery(context) },
                        onShareVideo = { freeVideoViewModel.shareVideo(context) },
                        onBackToHome = { currentScreen = AppScreen.HOME }
                    )
                }

                AppScreen.GENERATE_VIDEO -> {
                    SimpleVideoGeneratorScreen(
                        state = videoState,
                        settings = settings,
                        isProviderConfigured = isProviderConfigured,
                        onPromptChange = videoViewModel::updatePrompt,
                        onSelectStyle = videoViewModel::selectStyle,
                        onSelectAspectRatio = videoViewModel::selectAspectRatio,
                        onSelectDuration = videoViewModel::selectDuration,
                        onSelectLanguage = videoViewModel::selectDialogueLanguage,
                        onSetSample = videoViewModel::setSamplePrompt,
                        onGenerateClick = videoViewModel::generateVideo,
                        onCancelGeneration = videoViewModel::cancelGeneration,
                        onNavigateToSettings = { currentScreen = AppScreen.SETTINGS },
                        onDismissSetupPrompt = videoViewModel::dismissSetupPrompt
                    )
                }

                AppScreen.VIDEO_RESULT -> {
                    val active = videoState.activeJob
                    if (active != null) {
                        VideoResultScreen(
                            videoJob = active,
                            onSaveToGallery = videoViewModel::saveVideoToGallery,
                            onShareVideo = videoViewModel::shareVideo,
                            onRegenerate = {
                                videoViewModel.retryJob(active)
                                currentScreen = AppScreen.GENERATE_VIDEO
                            },
                            onBackToHome = { currentScreen = AppScreen.HOME }
                        )
                    } else {
                        currentScreen = AppScreen.GENERATE_VIDEO
                    }
                }

                AppScreen.STORY_TO_VIDEO -> {
                    StoryToVideoScreen(
                        state = storyState,
                        onStoryTextChange = storyViewModel::updateStoryText,
                        onStoryTypeSelect = storyViewModel::selectStoryType,
                        onDurationSelect = storyViewModel::selectDuration,
                        onAspectRatioSelect = storyViewModel::selectAspectRatio,
                        onGenerateAllScenesToggle = storyViewModel::toggleGenerateAllScenes,
                        onGenerateClick = storyViewModel::generatePlan,
                        onRegenerateScene = storyViewModel::regenerateScene,
                        onSaveCurrentPlan = storyViewModel::saveCurrentPlan,
                        onSetSample = storyViewModel::setSamplePrompt,
                        onGenerateActualVideo = { prompt ->
                            videoViewModel.updatePrompt(prompt)
                            currentScreen = AppScreen.GENERATE_VIDEO
                        }
                    )
                }

                AppScreen.IMAGE_PROMPT -> {
                    ImagePromptScreen()
                }

                AppScreen.MY_VIDEOS -> {
                    MyVideosScreen(
                        savedVideos = savedVideos,
                        savedStories = savedStories,
                        onOpenVideo = { video ->
                            videoViewModel.openVideoJob(video)
                            currentScreen = AppScreen.VIDEO_RESULT
                        },
                        onRetryVideo = { video ->
                            videoViewModel.retryJob(video)
                            currentScreen = AppScreen.GENERATE_VIDEO
                        },
                        onDeleteVideo = videoViewModel::deleteVideoJob,
                        onShareVideo = videoViewModel::shareVideo,
                        onSelectStory = { story ->
                            storyViewModel.loadStoryFromHistory(story)
                            currentScreen = AppScreen.STORY_TO_VIDEO
                        },
                        onDeleteStory = storyViewModel::deleteStory
                    )
                }

                AppScreen.SETTINGS -> {
                    SettingsScreen(
                        settings = settings,
                        isTestingConnection = videoState.isTestingConnection,
                        connectionTestResult = videoState.connectionTestResult,
                        onUpdateProvider = videoViewModel::updateProvider,
                        onUpdateApiKey = videoViewModel::updateApiKey,
                        onUpdateBackendUrl = videoViewModel::updateBackendUrl,
                        onUpdateGeminiKey = videoViewModel::updateGeminiApiKeyOverride,
                        onTestConnection = videoViewModel::testConnection
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
