package com.example.data.media

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

data class ImportedImageResult(
    val localFilePath: String,
    val displayName: String,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fileSizeBytes: Long
)

/**
 * Handles reliable importing, validation, and local staging of user-selected images
 * from Android Photo Picker (`PickVisualMedia`), Storage Access Framework (`OpenDocument`),
 * `content://` URIs, `file://` URIs, and local filesystem paths.
 *
 * Supports JPG, JPEG, PNG, and WEBP formats and copies selected images into app-private
 * persistent storage (`filesDir/imported_images`) so previews and MP4 video generation
 * never break when temporary system URI grants expire.
 */
object ImageImportHelper {

    private const val TAG = "ImageImportHelper"
    private const val MAX_DECODE_DIMENSION = 2048

    val SUPPORTED_IMAGE_MIMES = arrayOf(
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/webp"
    )

    val SUPPORTED_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp")

    fun resolveDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") {
            return uri.lastPathSegment ?: "image.jpg"
        }
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx)?.takeIf { it.isNotBlank() } else null
                } else null
            } ?: uri.lastPathSegment ?: "selected_image.jpg"
        } catch (_: Exception) {
            uri.lastPathSegment ?: "selected_image.jpg"
        }
    }

    fun inferExtension(mimeType: String?, fileName: String): String {
        val lowerMime = mimeType?.lowercase().orEmpty()
        val lowerName = fileName.lowercase()
        return when {
            lowerMime.contains("png") || lowerName.endsWith(".png") -> "png"
            lowerMime.contains("webp") || lowerName.endsWith(".webp") -> "webp"
            lowerMime.contains("jpeg") || lowerMime.contains("jpg") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") -> "jpg"
            else -> "jpg"
        }
    }

    fun isSupportedFormat(mimeType: String?, fileName: String): Boolean {
        val lowerMime = mimeType?.lowercase().orEmpty()
        if (lowerMime.startsWith("image/")) {
            return lowerMime == "image/jpeg" ||
                lowerMime == "image/jpg" ||
                lowerMime == "image/png" ||
                lowerMime == "image/webp" ||
                lowerMime == "image/*"
        }
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return ext.isBlank() || ext in SUPPORTED_EXTENSIONS
    }

    /**
     * Checks magic file signatures for JPEG (FF D8 FF), PNG (89 50 4E 47 0D 0A 1A 0A),
     * and WEBP (RIFF....WEBP) so corrupt or non-image files are rejected reliably.
     */
    fun hasValidImageSignature(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val isJpeg = (bytes[0].toInt() and 0xFF) == 0xFF &&
            (bytes[1].toInt() and 0xFF) == 0xD8 &&
            (bytes[2].toInt() and 0xFF) == 0xFF
        val isPng = (bytes[0].toInt() and 0xFF) == 0x89 &&
            bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() &&
            bytes[3] == 0x47.toByte() &&
            bytes[4] == 0x0D.toByte() &&
            bytes[5] == 0x0A.toByte() &&
            bytes[6] == 0x1A.toByte() &&
            bytes[7] == 0x0A.toByte()
        val isWebp = bytes[0] == 'R'.code.toByte() &&
            bytes[1] == 'I'.code.toByte() &&
            bytes[2] == 'F'.code.toByte() &&
            bytes[3] == 'F'.code.toByte() &&
            bytes[8] == 'W'.code.toByte() &&
            bytes[9] == 'E'.code.toByte() &&
            bytes[10] == 'B'.code.toByte() &&
            bytes[11] == 'P'.code.toByte()
        return isJpeg || isPng || isWebp
    }

    /**
     * Imports a selected `content://`, `file://`, or local path image into `filesDir/imported_images`.
     * Validates that the image decodes properly and returns image metadata + permanent path.
     */
    suspend fun importImageToLocalStorage(
        context: Context,
        uriOrPath: String
    ): Result<ImportedImageResult> = withContext(Dispatchers.IO) {
        val cleanInput = uriOrPath.trim()
        if (cleanInput.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("No image selected."))
        }

        try {
            val uri = if (cleanInput.startsWith("/")) {
                Uri.fromFile(File(cleanInput))
            } else {
                Uri.parse(cleanInput)
            }

            // Attempt persistable read grant when provided by OpenDocument (ignored cleanly for Photo Picker)
            if (uri.scheme == "content") {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                    // Photo Picker URIs are one-time read grants and do not need persistable grants once copied locally.
                } catch (_: Exception) {
                }
            }

            val rawMime = if (uri.scheme == "content") {
                runCatching { context.contentResolver.getType(uri) }.getOrNull()
            } else null

            val displayName = resolveDisplayName(context, uri)
            if (!isSupportedFormat(rawMime, displayName)) {
                return@withContext Result.failure(
                    IllegalArgumentException(
                        "Unsupported format ($rawMime). Please select a JPG, JPEG, PNG, or WEBP image."
                    )
                )
            }

            val bytes = openUriInputStream(context, cleanInput, uri)?.use { it.readBytes() }
                ?: return@withContext Result.failure(
                    IllegalStateException(
                        "Unable to open selected image. The file may have been moved or permission was denied."
                    )
                )

            if (bytes.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("Selected image file is empty (0 bytes)."))
            }

            if (!hasValidImageSignature(bytes)) {
                return@withContext Result.failure(
                    IllegalArgumentException("Selected file is not a valid JPG, JPEG, PNG, or WEBP image.")
                )
            }

            // Validate image headers and inspect dimensions
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) {
                return@withContext Result.failure(
                    IllegalArgumentException("Selected file is not a valid JPG, JPEG, PNG, or WEBP image.")
                )
            }

            val ext = inferExtension(rawMime ?: boundsOpts.outMimeType, displayName)
            val destDir = File(context.filesDir, "imported_images").apply { mkdirs() }
            val destFile = File(destDir, "img_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.$ext")

            // If reasonably sized and native JPG/PNG/WEBP, preserve exact bytes; otherwise normalize safely
            val outMime = when (ext) {
                "png" -> "image/png"
                "webp" -> "image/webp"
                else -> "image/jpeg"
            }

            if (boundsOpts.outWidth <= MAX_DECODE_DIMENSION && boundsOpts.outHeight <= MAX_DECODE_DIMENSION) {
                FileOutputStream(destFile).use { it.write(bytes) }
            } else {
                var sample = 1
                while (boundsOpts.outWidth / sample > MAX_DECODE_DIMENSION ||
                    boundsOpts.outHeight / sample > MAX_DECODE_DIMENSION
                ) {
                    sample *= 2
                }
                val decoded = BitmapFactory.decodeByteArray(
                    bytes,
                    0,
                    bytes.size,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                ) ?: return@withContext Result.failure(IllegalStateException("Failed to decode high-resolution image."))

                val compressFmt = when (ext) {
                    "png" -> Bitmap.CompressFormat.PNG
                    "webp" -> {
                        @Suppress("DEPRECATION")
                        Bitmap.CompressFormat.WEBP
                    }
                    else -> Bitmap.CompressFormat.JPEG
                }
                FileOutputStream(destFile).use { fos ->
                    decoded.compress(compressFmt, 92, fos)
                }
                decoded.recycle()
            }

            val verifyBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(destFile.absolutePath, verifyBounds)

            Log.i(TAG, "Imported image: $displayName (${verifyBounds.outWidth}x${verifyBounds.outHeight}, $outMime) -> ${destFile.absolutePath}")
            Result.success(
                ImportedImageResult(
                    localFilePath = destFile.absolutePath,
                    displayName = displayName,
                    mimeType = outMime,
                    width = verifyBounds.outWidth.coerceAtLeast(boundsOpts.outWidth),
                    height = verifyBounds.outHeight.coerceAtLeast(boundsOpts.outHeight),
                    fileSizeBytes = destFile.length()
                )
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException reading URI: $uriOrPath", e)
            Result.failure(Exception("Permission denied reading selected image. Please pick the image again.", e))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to import image: $uriOrPath", e)
            Result.failure(Exception("Could not load image: ${e.message ?: "Unknown error"}", e))
        }
    }

    fun openUriInputStream(context: Context, rawPath: String, parsedUri: Uri = Uri.parse(rawPath)): InputStream? {
        if (rawPath.startsWith("/")) {
            val f = File(rawPath)
            return if (f.exists() && f.canRead()) FileInputStream(f) else null
        }
        if (parsedUri.scheme == "file" && !parsedUri.path.isNullOrBlank()) {
            val f = File(parsedUri.path!!)
            return if (f.exists() && f.canRead()) FileInputStream(f) else null
        }
        return context.contentResolver.openInputStream(parsedUri)
    }

    /**
     * Converts any stored `content://`, `file://`, or `/path` into a Coil-compatible model (`File` if local path).
     */
    fun toCoilModel(uriOrPath: String): Any {
        return when {
            uriOrPath.startsWith("/") -> File(uriOrPath)
            uriOrPath.startsWith("file://") -> {
                val p = Uri.parse(uriOrPath).path
                if (!p.isNullOrBlank()) File(p) else uriOrPath
            }
            else -> Uri.parse(uriOrPath)
        }
    }
}
