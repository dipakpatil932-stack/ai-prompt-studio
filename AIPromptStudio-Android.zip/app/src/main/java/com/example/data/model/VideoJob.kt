package com.example.data.model

enum class VideoJobStatus(val label: String, val hindiLabel: String) {
    IDLE("Ready", "तैयार"),
    SUBMITTING("Submitting Request", "सर्वर पर अनुरोध भेजा जा रहा है"),
    PROCESSING("Generating Video", "AI वीडियो तैयार कर रहा है"),
    COMPLETED("Video Ready", "वीडियो तैयार है"),
    FAILED("Generation Failed", "वीडियो निर्माण विफल रहा"),
    CANCELLED("Cancelled", "रद्द किया गया")
}

enum class VideoStyle(val displayName: String, val hindiName: String, val promptModifier: String) {
    CINEMATIC(
        "Cinematic",
        "सिनेमैटिक",
        "Photorealistic Indian cinematic 4K style, dramatic Bollywood lighting, realistic skin texture, shallow depth of field, anamorphic 35mm lens."
    ),
    CARTOON_3D(
        "3D Cartoon",
        "3D कार्टून",
        "3D Pixar and Disney animation style, vibrant colorful lighting, expressive characters, cute stylized Indian aesthetics, high quality render."
    ),
    REALISTIC(
        "Realistic",
        "यथार्थवादी",
        "Ultra-realistic documentary film style, natural sunlight, authentic Indian atmosphere, lifelike organic motion, 4K resolution."
    ),
    ANIMATED(
        "Animated",
        "एनिमेटेड",
        "Rich 2D Indian animated art style, fluid motion, warm hand-painted textures, vibrant cultural colors, high detail."
    )
}

enum class VideoAspectRatio(val ratio: String, val label: String, val hindiLabel: String) {
    RATIO_9_16("9:16", "9:16 Vertical", "रील्स / शॉर्ट्स"),
    RATIO_16_9("16:9", "16:9 Landscape", "यूट्यूब / सिनेमा"),
    RATIO_1_1("1:1", "1:1 Square", "स्क्वायर"),
    RATIO_4_5("4:5", "4:5 Social Post", "सोशल मीडिया पोस्ट")
}

enum class MotionEffect(
    val id: String,
    val displayName: String,
    val hindiName: String,
    val promptDescription: String
) {
    KEN_BURNS_ZOOM_IN(
        "zoom_in",
        "Zoom In (पुश-इन)",
        "धीमा ज़ूम इन",
        "Smooth cinematic slow push-in camera zoom towards the subject with gentle parallax depth"
    ),
    KEN_BURNS_ZOOM_OUT(
        "zoom_out",
        "Zoom Out (पुल-बैक)",
        "धीमा ज़ूम आउट",
        "Smooth cinematic pull-back camera reveal expanding from close subject to wide scene"
    ),
    PAN_LEFT_TO_RIGHT(
        "pan_right",
        "Pan Right (बाएं → दाएं)",
        "बाएं से दाएं पैन",
        "Steady horizontal tracking camera pan gliding from left to right"
    ),
    PAN_RIGHT_TO_LEFT(
        "pan_left",
        "Pan Left (दाएं → बाएं)",
        "दाएं से बाएं पैन",
        "Steady horizontal tracking camera pan gliding from right to left"
    ),
    CINEMATIC_DRIFT(
        "drift",
        "Cinematic Drift (ड्रिफ्ट)",
        "सिनेमैटिक ड्रिफ्ट",
        "Organic floating camera motion with warm atmospheric light shimmer and film vignette"
    ),
    PARALLAX_PULSE(
        "pulse",
        "Dynamic Motion (जीवंत पल्स)",
        "डायनामिक मोशन",
        "Lively rhythmic zoom breathing motion ideal for 3D cartoon and energetic scenes"
    )
}

enum class VideoProviderType(val displayName: String, val defaultEndpoint: String, val isPaid: Boolean = false) {
    FREE_MODE(
        "Free Mode (100% Free • Slideshow Video)",
        "local_slideshow_generator",
        isPaid = false
    ),
    GOOGLE_VEO(
        "Google Veo / Vertex AI (Paid Cloud)",
        "https://us-central1-aiplatform.googleapis.com/v1/projects",
        isPaid = true
    ),
    LUMA_DREAM_MACHINE(
        "Luma Dream Machine API (Paid Cloud)",
        "https://api.lumalabs.ai/dream-machine/v1/generations",
        isPaid = true
    ),
    RUNWAY_GEN3(
        "Runway Gen-3 Alpha API (Paid Cloud)",
        "https://api.dev.runwayml.com/v1/image_to_video",
        isPaid = true
    ),
    CUSTOM_BACKEND(
        "Custom Video Server / Proxy",
        "https://your-video-backend.run.app/api/v1/generate",
        isPaid = false
    )
}

data class VideoJob(
    val id: Long = 0,
    val jobId: String,
    val prompt: String,
    val style: String = VideoStyle.CINEMATIC.displayName,
    val aspectRatio: String = "9:16",
    val duration: String = "5 sec",
    val dialogueLanguage: String = "Hindi",
    val provider: String = VideoProviderType.FREE_MODE.displayName,
    val status: VideoJobStatus = VideoJobStatus.IDLE,
    val progressPercent: Int = 0,
    val statusMessage: String = "",
    val videoUrl: String? = null,
    val localVideoPath: String? = null,
    val errorMessage: String? = null,
    val isSlideshow: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
