package com.example.data.model

data class StoryPlan(
    val id: Long = 0,
    val title: String,
    val storyType: String,
    val originalPrompt: String,
    val duration: String,
    val aspectRatio: String,
    val characterPrompts: String,
    val characterConsistency: String,
    val visualStyle: String,
    val negativePrompt: String,
    val finalMessage: String,
    val scenes: List<SceneItem>,
    val timestamp: Long = System.currentTimeMillis()
)
