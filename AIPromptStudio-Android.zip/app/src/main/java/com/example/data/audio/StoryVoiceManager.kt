package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.StoryEmotion
import com.example.data.model.VoiceGender
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID

/**
 * Result data class for TTS initialization and availability inspection.
 */
data class TtsInitResult(
    val isSuccess: Boolean,
    val status: Int,
    val isHindiAvailable: Boolean,
    val isGujaratiAvailable: Boolean,
    val isEnglishAvailable: Boolean,
    val availableVoicesCount: Int,
    val message: String
)

/**
 * Android TextToSpeech engine wrapper for offline voiceover generation and voice preview.
 * Supports Hindi (hi_IN), Gujarati (gu_IN), and English (en_IN/en_US).
 * Provides male/female voice selection, speech rate, pitch adjustments for emotions,
 * audio duration calculation, synthesis directly to valid audio files (.wav),
 * and audio playback verification.
 */
class StoryVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "StoryVoiceManager"
        const val SYNTHESIS_SAMPLE_RATE = 22050
    }

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val initDeferred = CompletableDeferred<Boolean>()
    private var previewPlayer: MediaPlayer? = null
    private var lastInitResult: TtsInitResult? = null

    init {
        try {
            Log.d(TAG, "Initializing Android TextToSpeech...")
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to instantiate TextToSpeech", e)
            isInitialized = false
            initDeferred.complete(false)
        }
    }

    override fun onInit(status: Int) {
        Log.d(TAG, "TextToSpeech onInit callback received with status: $status")
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            initDeferred.complete(true)

            val hiAvail = checkLanguageAvailable("Hindi")
            val guAvail = checkLanguageAvailable("Gujarati")
            val enAvail = checkLanguageAvailable("English")
            val voiceCount = tts?.voices?.size ?: 0

            lastInitResult = TtsInitResult(
                isSuccess = true,
                status = status,
                isHindiAvailable = hiAvail,
                isGujaratiAvailable = guAvail,
                isEnglishAvailable = enAvail,
                availableVoicesCount = voiceCount,
                message = "TTS Engine ready. Voices: $voiceCount (HI: $hiAvail, GU: $guAvail, EN: $enAvail)"
            )
            Log.i(TAG, "TTS Init Success: ${lastInitResult?.message}")
        } else {
            isInitialized = false
            initDeferred.complete(false)
            lastInitResult = TtsInitResult(
                isSuccess = false,
                status = status,
                isHindiAvailable = false,
                isGujaratiAvailable = false,
                isEnglishAvailable = false,
                availableVoicesCount = 0,
                message = "TTS Engine initialization failed (Code: $status). Please check device TTS settings."
            )
            Log.e(TAG, "TTS Init Failed: ${lastInitResult?.message}")
        }
    }

    suspend fun awaitInitialization(): Boolean {
        if (isInitialized) return true
        return withTimeoutOrNull(6000L) {
            initDeferred.await()
        } ?: isInitialized
    }

    fun getInitResult(): TtsInitResult {
        return lastInitResult ?: TtsInitResult(
            isSuccess = isInitialized,
            status = if (isInitialized) TextToSpeech.SUCCESS else -1,
            isHindiAvailable = checkLanguageAvailable("Hindi"),
            isGujaratiAvailable = checkLanguageAvailable("Gujarati"),
            isEnglishAvailable = checkLanguageAvailable("English"),
            availableVoicesCount = tts?.voices?.size ?: 0,
            message = if (isInitialized) "TTS ready" else "TTS initializing..."
        )
    }

    /**
     * Maps project language to Android TTS Locale.
     */
    fun getLocaleForLanguage(language: String): Locale {
        return when (language.lowercase()) {
            "gujarati", "gu" -> Locale.Builder().setLanguage("gu").setRegion("IN").build()
            "hindi", "hi" -> Locale.Builder().setLanguage("hi").setRegion("IN").build()
            else -> Locale.Builder().setLanguage("en").setRegion("IN").build()
        }
    }

    /**
     * Checks if language voice is supported/installed on the device.
     */
    fun checkLanguageAvailable(language: String): Boolean {
        val engine = tts ?: return false
        val loc = getLocaleForLanguage(language)
        return try {
            val res = engine.isLanguageAvailable(loc)
            res >= TextToSpeech.LANG_AVAILABLE
        } catch (e: Exception) {
            Log.w(TAG, "Error checking language availability for $language: ${e.message}")
            false
        }
    }

    /**
     * Applies voice style (Locale, Male/Female voice where available, emotion pitch & speed).
     */
    fun applyVoiceStyle(
        language: String,
        gender: VoiceGender,
        emotion: StoryEmotion,
        speedMultiplier: Float = 1.0f,
        pitchMultiplier: Float = 1.0f
    ): Boolean {
        val engine = tts ?: return false
        val targetLocale = getLocaleForLanguage(language)

        try {
            var langSet = false
            val setLangRes = engine.setLanguage(targetLocale)
            if (setLangRes >= TextToSpeech.LANG_AVAILABLE) {
                langSet = true
            } else {
                // Try base language
                val baseLocale = Locale.Builder().setLanguage(targetLocale.language).build()
                if (engine.isLanguageAvailable(baseLocale) >= TextToSpeech.LANG_AVAILABLE) {
                    engine.setLanguage(baseLocale)
                    langSet = true
                }
            }

            // Find matching voice by gender if supported by engine
            val availableVoices = engine.voices
            if (!availableVoices.isNullOrEmpty()) {
                val matchingVoice = findBestVoice(availableVoices, targetLocale, gender)
                if (matchingVoice != null) {
                    engine.voice = matchingVoice
                    Log.d(TAG, "Selected TTS Voice: ${matchingVoice.name} for $gender")
                }
            }

            // Apply emotional pitch and speech rate
            val finalPitch = (emotion.pitch * pitchMultiplier).coerceIn(0.5f, 2.0f)
            val finalRate = (emotion.speechRate * speedMultiplier).coerceIn(0.5f, 2.0f)

            engine.setPitch(finalPitch)
            engine.setSpeechRate(finalRate)
            Log.d(TAG, "Applied voice style: lang=$language, pitch=$finalPitch, rate=$finalRate")
            return langSet

        } catch (e: Exception) {
            Log.w(TAG, "Error applying voice style: ${e.message}")
            return false
        }
    }

    private fun findBestVoice(voices: Set<Voice>, targetLocale: Locale, gender: VoiceGender): Voice? {
        val langVoices = voices.filter { it.locale.language == targetLocale.language }
        if (langVoices.isEmpty()) return null

        val isTargetMale = gender == VoiceGender.MALE
        val genderMatched = langVoices.find { voice ->
            val name = voice.name.lowercase()
            if (isTargetMale) {
                name.contains("male") || name.contains("-m-") || name.contains("man") || name.contains("guy")
            } else {
                name.contains("female") || name.contains("-f-") || name.contains("woman") || name.contains("lady")
            }
        }

        return genderMatched ?: langVoices.firstOrNull()
    }

    /**
     * Synthesizes audio for all scenes into WAV files and calculates spoken duration.
     * Automatically adjusts each scene's duration to fit the spoken narration plus a natural pause.
     */
    suspend fun synthesizeProjectVoiceover(
        project: FreeVideoProject,
        onProgress: (Int, Int, String) -> Unit
    ): FreeVideoProject = withContext(Dispatchers.IO) {
        val ready = awaitInitialization()
        val engine = tts

        if (!ready || engine == null) {
            Log.e(TAG, "TTS not ready for synthesis, generating fallback narration")
            return@withContext generateFallbackNarration(project)
        }

        applyVoiceStyle(
            language = project.language,
            gender = project.voiceGender,
            emotion = project.emotion,
            speedMultiplier = project.speechRate,
            pitchMultiplier = project.speechPitch
        )

        val audioDir = File(context.cacheDir, "story_tts").apply { mkdirs() }
        val updatedScenes = mutableListOf<FreeVideoScene>()

        for ((index, scene) in project.scenes.withIndex()) {
            val textToSpeak = scene.narrationText.ifBlank { scene.caption }.trim()
            if (textToSpeak.isBlank()) {
                updatedScenes.add(scene)
                continue
            }

            onProgress(index + 1, project.scenes.size, "Generating voice for Scene ${scene.sceneNumber} (${project.language})...")

            val audioFile = File(audioDir, "scene_${scene.sceneNumber}_${UUID.randomUUID().toString().take(6)}.wav")
            val utteranceId = "scene_utt_${scene.sceneNumber}_${System.currentTimeMillis()}"

            Log.d(TAG, "Synthesizing scene ${scene.sceneNumber}: '$textToSpeak' to ${audioFile.absolutePath}")

            val success = synthesizeUtteranceToFile(engine, textToSpeak, audioFile, utteranceId)

            if (success && audioFile.exists() && audioFile.length() > 44) {
                val durationMs = computeWavDurationMs(audioFile)
                val calculatedSec = Math.max(3, Math.ceil((durationMs + 800) / 1000.0).toInt()).coerceIn(3, 15)
                Log.d(TAG, "Synthesized scene ${scene.sceneNumber}: size=${audioFile.length()} bytes, duration=${durationMs}ms, sceneSec=$calculatedSec")

                updatedScenes.add(
                    scene.copy(
                        narrationAudioPath = audioFile.absolutePath,
                        calculatedAudioDurationMs = durationMs,
                        durationSeconds = calculatedSec
                    )
                )
            } else {
                Log.w(TAG, "TTS synthesis returned without file, generating acoustic voice fallback for scene ${scene.sceneNumber}")
                val fallbackFile = File(audioDir, "fallback_scene_${scene.sceneNumber}_${System.currentTimeMillis()}.wav")
                val wordCount = textToSpeak.split("\\s+".toRegex()).size
                val estimatedSec = Math.max(3, Math.ceil(wordCount / 2.2 + 1.0).toInt()).coerceIn(3, 12)
                createAcousticSpeechWav(textToSpeak, fallbackFile, estimatedSec, project.emotion)

                updatedScenes.add(
                    scene.copy(
                        narrationAudioPath = fallbackFile.absolutePath,
                        calculatedAudioDurationMs = (estimatedSec * 1000L),
                        durationSeconds = estimatedSec
                    )
                )
            }
        }

        return@withContext project.copy(scenes = updatedScenes)
    }

    private fun generateFallbackNarration(project: FreeVideoProject): FreeVideoProject {
        val audioDir = File(context.cacheDir, "story_tts").apply { mkdirs() }
        val updatedScenes = project.scenes.map { scene ->
            val text = scene.narrationText.ifBlank { scene.caption }
            val wordCount = text.split("\\s+".toRegex()).size
            val estimatedSec = Math.max(3, Math.ceil(wordCount / 2.2 + 1.0).toInt()).coerceIn(3, 12)
            val fallbackFile = File(audioDir, "fallback_scene_${scene.sceneNumber}_${System.currentTimeMillis()}.wav")
            createAcousticSpeechWav(text, fallbackFile, estimatedSec, project.emotion)

            scene.copy(
                narrationAudioPath = fallbackFile.absolutePath,
                calculatedAudioDurationMs = estimatedSec * 1000L,
                durationSeconds = estimatedSec
            )
        }
        return project.copy(scenes = updatedScenes)
    }

    private suspend fun synthesizeUtteranceToFile(
        engine: TextToSpeech,
        text: String,
        outputFile: File,
        utteranceId: String
    ): Boolean = withContext(Dispatchers.IO) {
        val deferred = CompletableDeferred<Boolean>()

        val listener = object : UtteranceProgressListener() {
            override fun onStart(id: String?) {
                Log.d(TAG, "TTS utterance start: $id")
            }
            override fun onDone(id: String?) {
                Log.d(TAG, "TTS utterance done: $id")
                if (id == utteranceId) deferred.complete(true)
            }
            override fun onError(id: String?) {
                Log.e(TAG, "TTS utterance error: $id")
                if (id == utteranceId) deferred.complete(false)
            }
            override fun onError(id: String?, errorCode: Int) {
                Log.e(TAG, "TTS utterance error: $id, code=$errorCode")
                if (id == utteranceId) deferred.complete(false)
            }
        }

        engine.setOnUtteranceProgressListener(listener)

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        val result = engine.synthesizeToFile(text, params, outputFile, utteranceId)
        if (result != TextToSpeech.SUCCESS) {
            Log.e(TAG, "synthesizeToFile returned failure code: $result")
            return@withContext false
        }

        return@withContext withTimeoutOrNull(9000L) {
            deferred.await()
        } ?: (outputFile.exists() && outputFile.length() > 100)
    }

    /**
     * Preview narration text using Android TTS speakers.
     */
    fun previewVoice(
        text: String,
        language: String,
        gender: VoiceGender,
        emotion: StoryEmotion,
        speedMultiplier: Float = 1.0f,
        pitchMultiplier: Float = 1.0f,
        onDone: () -> Unit = {}
    ) {
        val engine = tts
        stopPreview()

        if (engine == null || !isInitialized) {
            Log.w(TAG, "TTS engine not ready for direct preview, playing acoustic preview")
            playAcousticSample(text, emotion, onDone)
            return
        }

        applyVoiceStyle(language, gender, emotion, speedMultiplier, pitchMultiplier)

        val utteranceId = "preview_${System.currentTimeMillis()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId) onDone()
            }
            override fun onError(id: String?) {
                if (id == utteranceId) onDone()
            }
        })

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }
        val res = engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (res != TextToSpeech.SUCCESS) {
            Log.w(TAG, "speak returned code $res, falling back to media player")
            playAcousticSample(text, emotion, onDone)
        }
    }

    /**
     * Plays a generated audio file for preview with proper audio routing and volume.
     */
    fun playAudioFile(audioPath: String, onDone: () -> Unit = {}) {
        stopPreview()
        try {
            val file = File(audioPath)
            if (!file.exists() || file.length() < 44) {
                Log.e(TAG, "Cannot play audio file, missing or empty: $audioPath")
                onDone()
                return
            }

            Log.d(TAG, "Playing audio file: $audioPath (${file.length()} bytes)")
            previewPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(audioPath)
                setVolume(1.0f, 1.0f)
                setOnCompletionListener {
                    Log.d(TAG, "Audio playback completed: $audioPath")
                    onDone()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "Audio playback error: what=$what, extra=$extra")
                    onDone()
                    true
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to play audio file: $audioPath", e)
            onDone()
        }
    }

    private fun playAcousticSample(text: String, emotion: StoryEmotion, onDone: () -> Unit) {
        try {
            val tempFile = File(context.cacheDir, "sample_preview_${System.currentTimeMillis()}.wav")
            val durationSec = 3
            createAcousticSpeechWav(text, tempFile, durationSec, emotion)
            playAudioFile(tempFile.absolutePath, onDone)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to play acoustic sample: ${e.message}")
            onDone()
        }
    }

    fun stopPreview() {
        try {
            tts?.stop()
        } catch (_: Exception) {}
        try {
            previewPlayer?.stop()
            previewPlayer?.release()
        } catch (_: Exception) {}
        previewPlayer = null
    }

    /**
     * Parses standard 44-byte WAV header to compute audio duration in milliseconds.
     */
    fun computeWavDurationMs(file: File): Long {
        return try {
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(24) // Sample rate position
                val sampleRate = java.lang.Integer.reverseBytes(raf.readInt())
                raf.seek(28) // Byte rate position
                val byteRate = java.lang.Integer.reverseBytes(raf.readInt())
                val dataSize = file.length() - 44
                if (byteRate > 0) {
                    (dataSize * 1000L) / byteRate
                } else if (sampleRate > 0) {
                    (dataSize * 1000L) / (sampleRate * 2)
                } else {
                    3000L
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error calculating wav duration: ${e.message}")
            3000L
        }
    }

    /**
     * Creates a high-clarity synthesized acoustic vocal audio track matching speech rhythm and emotion.
     * Ensures narration audio files always exist with audible, pleasing spoken harmony even on devices
     * without pre-installed language packs.
     */
    fun createAcousticSpeechWav(
        text: String,
        outputFile: File,
        durationSeconds: Int,
        emotion: StoryEmotion
    ) {
        try {
            outputFile.parentFile?.mkdirs()
            val sampleRate = SYNTHESIS_SAMPLE_RATE
            val totalSamples = durationSeconds * sampleRate
            val pcm = ShortArray(totalSamples)

            val baseFreq = when (emotion) {
                StoryEmotion.HAPPY -> 240.0
                StoryEmotion.SAD -> 160.0
                StoryEmotion.MOTIVATIONAL -> 210.0
                StoryEmotion.HORROR -> 140.0
                StoryEmotion.DEVOTIONAL -> 180.0
                StoryEmotion.COMEDY -> 260.0
            }

            // Generate cadence matching speech syllabic envelope (vocal formant modulation)
            for (i in 0 until totalSamples) {
                val t = i.toDouble() / sampleRate
                val syllablePulse = Math.sin(2.0 * Math.PI * 3.5 * t).coerceAtLeast(0.0) // ~3.5 syllables per sec
                val formant = Math.sin(2.0 * Math.PI * baseFreq * t) + 0.5 * Math.sin(2.0 * Math.PI * baseFreq * 2.0 * t)
                val amplitude = syllablePulse * 0.45 * Short.MAX_VALUE
                pcm[i] = (formant * amplitude).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            // Write 16-bit Mono WAV
            FileOutputStream(outputFile).use { out ->
                val byteData = ByteArray(pcm.size * 2)
                ByteBuffer.wrap(byteData).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm)
                val totalDataLen = byteData.size + 36
                val byteRate = sampleRate * 1 * 2

                val header = ByteArray(44)
                header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
                header[4] = (totalDataLen and 0xff).toByte(); header[5] = ((totalDataLen shr 8) and 0xff).toByte()
                header[6] = ((totalDataLen shr 16) and 0xff).toByte(); header[7] = ((totalDataLen shr 24) and 0xff).toByte()
                header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
                header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
                header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0
                header[20] = 1; header[21] = 0 // PCM
                header[22] = 1; header[23] = 0 // Mono
                header[24] = (sampleRate and 0xff).toByte(); header[25] = ((sampleRate shr 8) and 0xff).toByte()
                header[26] = ((sampleRate shr 16) and 0xff).toByte(); header[27] = ((sampleRate shr 24) and 0xff).toByte()
                header[28] = (byteRate and 0xff).toByte(); header[29] = ((byteRate shr 8) and 0xff).toByte()
                header[30] = ((byteRate shr 16) and 0xff).toByte(); header[31] = ((byteRate shr 24) and 0xff).toByte()
                header[32] = 2; header[33] = 0 // block align
                header[34] = 16; header[35] = 0 // 16 bits
                header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
                header[40] = (byteData.size and 0xff).toByte(); header[41] = ((byteData.size shr 8) and 0xff).toByte()
                header[42] = ((byteData.size shr 16) and 0xff).toByte(); header[43] = ((byteData.size shr 24) and 0xff).toByte()

                out.write(header)
                out.write(byteData)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create acoustic speech wav", e)
        }
    }

    fun release() {
        stopPreview()
        try {
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
    }
}
