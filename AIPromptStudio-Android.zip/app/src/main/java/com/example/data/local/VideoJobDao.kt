package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoJobDao {
    @Query("SELECT * FROM video_jobs ORDER BY createdAt DESC")
    fun getAllVideoJobs(): Flow<List<VideoJobEntity>>

    @Query("SELECT * FROM video_jobs WHERE id = :id")
    fun getVideoJobById(id: Long): Flow<VideoJobEntity?>

    @Query("SELECT * FROM video_jobs WHERE jobId = :jobId LIMIT 1")
    suspend fun getVideoJobByRemoteId(jobId: String): VideoJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideoJob(job: VideoJobEntity): Long

    @Update
    suspend fun updateVideoJob(job: VideoJobEntity)

    @Query("DELETE FROM video_jobs WHERE id = :id")
    suspend fun deleteVideoJob(id: Long)

    @Query("DELETE FROM video_jobs")
    suspend fun clearAllVideoJobs()
}
