package com.example.data.remote

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import com.example.data.model.StoryCharacter
import com.example.data.model.VideoStyle
import com.example.data.model.VoiceGender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.concurrent.TimeUnit

data class ModelAvailabilityStatus(
    val modelId: String,
    val featureLabel: String,
    val isAvailable: Boolean,
    val note: String
)

data class GoogleAiCapabilityReport(
    val isKeyValid: Boolean,
    val httpCode: Int,
    val summaryMessage: String,
    val billingOrQuotaNote: String,
    val models: List<ModelAvailabilityStatus>
)

/**
 * Official Google AI Studio / Generative Language API v1beta service
 * (`https://generativelanguage.googleapis.com/v1beta`).
 *
 * Implements:
 * - API key & model capability/billing/quota inspection (`GET /v1beta/models`)
 * - Consistent multi-scene character sheet extraction (`gemini-2.5-flash`)
 * - AI Image Creation & Uploaded Image Editing (`gemini-2.5-flash-image` / `imagen-3.0-generate-002`)
 * - Cloud AI Natural Voice TTS (`gemini-2.5-flash-preview-tts`)
 *
 * Security: API keys are passed via `x-goog-api-key` headers and never logged or hardcoded.
 */
class GoogleAiStudioService {

    companion object {
        private const val TAG = "GoogleAiStudioService"
        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        const val MODEL_TEXT = "gemini-2.5-flash"
        const val MODEL_IMAGE_GEMINI = "gemini-2.5-flash-image"
        const val MODEL_IMAGE_IMAGEN = "imagen-3.0-generate-002"
        const val MODEL_VEO = "veo-2.0-generate-001"
        const val MODEL_TTS = "gemini-2.5-flash-preview-tts"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(40, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun checkApiCapabilities(apiKey: String): Result<GoogleAiCapabilityReport> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank() || cleanKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.success(
                GoogleAiCapabilityReport(
                    isKeyValid = false,
                    httpCode = 0,
                    summaryMessage = "No Google AI / Gemini API key configured.",
                    billingOrQuotaNote = "Add GEMINI_API_KEY in AI Studio Secrets or Settings to enable cloud AI image/video/TTS models. On-device Free Mode remains active.",
                    models = buildDefaultModelStatuses(emptySet())
                )
            )
        }

        try {
            val request = Request.Builder()
                .url("$BASE_URL/models?pageSize=100")
                .addHeader("x-goog-api-key", cleanKey)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val mapped = mapHttpError(response.code, body, "Google AI API Check")
                    return@withContext Result.success(
                        GoogleAiCapabilityReport(
                            isKeyValid = false,
                            httpCode = response.code,
                            summaryMessage = mapped,
                            billingOrQuotaNote = when (response.code) {
                                401 -> "Invalid API key. Verify your Gemini API key in Settings or AI Studio Secrets."
                                403 -> "Permission denied or project API disabled / billing required for selected model."
                                429 -> "Rate limit or free tier quota exceeded (HTTP 429). Retry shortly or use Free Mode."
                                else -> "Server returned HTTP ${response.code}."
                            },
                            models = buildDefaultModelStatuses(emptySet())
                        )
                    )
                }

                val availableIds = parseAvailableModelIds(body)
                val statuses = buildDefaultModelStatuses(availableIds)
                val veoReady = statuses.firstOrNull { it.modelId == MODEL_VEO }?.isAvailable == true
                val imageReady = statuses.any { (it.modelId == MODEL_IMAGE_GEMINI || it.modelId == MODEL_IMAGE_IMAGEN) && it.isAvailable }

                val summary = buildString {
                    append("Google AI API Connected (${availableIds.size} models visible). ")
                    if (imageReady) append("Image AI ready. ") else append("Image models may require billing/whitelist. ")
                    if (veoReady) append("Veo Video ready.") else append("Veo Video requires Cloud Billing / whitelist.")
                }

                Result.success(
                    GoogleAiCapabilityReport(
                        isKeyValid = true,
                        httpCode = response.code,
                        summaryMessage = summary,
                        billingOrQuotaNote = "Note: Google Veo ($MODEL_VEO) & Imagen 3 typically require a Google Cloud billing-enabled project, while Gemini Flash/Free Mode works on standard quotas.",
                        models = statuses
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "API capability check failed", e)
            Result.failure(Exception("Network error checking Google AI access: ${e.message}", e))
        }
    }

    fun parseAvailableModelIds(jsonBody: String): Set<String> {
        val result = mutableSetOf<String>()
        try {
            val root = JSONObject(jsonBody)
            val arr = root.optJSONArray("models") ?: return result
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val fullName = obj.optString("name", "")
                if (fullName.isNotBlank()) {
                    result.add(fullName.removePrefix("models/"))
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse models list: ${e.message}")
        }
        return result
    }

    private fun buildDefaultModelStatuses(availableIds: Set<String>): List<ModelAvailabilityStatus> {
        val catalog = listOf(
            Triple(MODEL_TEXT, "Story, Script & Character Consistency", "Free tier & Pay-as-you-go"),
            Triple(MODEL_IMAGE_GEMINI, "Create & Edit Images (Gemini Flash Image)", "Multimodal generation/editing"),
            Triple(MODEL_IMAGE_IMAGEN, "High-Res Photo/3D Image (Imagen 3)", "Requires billing-enabled project"),
            Triple(MODEL_VEO, "AI Video & Image-to-Video (Google Veo 2)", "Requires paid Cloud Billing / whitelist"),
            Triple(MODEL_TTS, "Cloud AI Voiceover (Gemini TTS)", "Experimental natural speech synthesis")
        )
        return catalog.map { (id, label, note) ->
            val avail = availableIds.any { it.equals(id, ignoreCase = true) || it.startsWith(id, ignoreCase = true) }
            ModelAvailabilityStatus(
                modelId = id,
                featureLabel = label,
                isAvailable = avail,
                note = if (avail) "Available on key • $note" else if (availableIds.isEmpty()) note else "Not listed on key • $note"
            )
        }
    }

    suspend fun generateConsistentCharacters(
        apiKey: String,
        storyText: String,
        style: VideoStyle,
        language: String
    ): Result<List<StoryCharacter>> = withContext(Dispatchers.IO) {
        val cleanStory = storyText.trim()
        if (cleanStory.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter a story first."))
        }

        val cleanKey = apiKey.trim()
        if (cleanKey.isNotBlank() && cleanKey != "MY_GEMINI_API_KEY") {
            try {
                val url = "$BASE_URL/models/$MODEL_TEXT:generateContent"
                val prompt = """
                    Extract 2 to 4 main characters from this story so all video scenes maintain identical faces, clothes, colors, and voices.
                    Story: $cleanStory
                    Visual Style: ${style.displayName} (${style.promptModifier})
                    Language: $language
                    
                    Return ONLY valid JSON:
                    {
                      "characters": [
                        {
                          "name": "Character Name",
                          "age": "e.g. 28 years",
                          "facialFeatures": "exact face structure, skin tone, eye shape, expression",
                          "hairAndStyle": "exact hairstyle, bindi/beard/spectacles",
                          "clothingAndColors": "exact outfit colors and traditional/modern details that never change across scenes",
                          "voiceGender": "FEMALE" or "MALE",
                          "voiceTone": "e.g. Warm & Maternal / Calm & Brave"
                        }
                      ]
                    }
                """.trimIndent()

                val body = JSONObject().apply {
                    put("contents", JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", prompt) })
                            })
                        })
                    })
                    put("generationConfig", JSONObject().apply {
                        put("responseMimeType", "application/json")
                        put("temperature", 0.4)
                    })
                }

                val req = Request.Builder()
                    .url(url)
                    .addHeader("x-goog-api-key", cleanKey)
                    .addHeader("Content-Type", "application/json")
                    .post(body.toString().toRequestBody(jsonMediaType))
                    .build()

                client.newCall(req).execute().use { resp ->
                    val respStr = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val root = JSONObject(respStr)
                        val text = root.optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                            ?.optString("text").orEmpty()
                        val cleaned = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                        val arr = JSONObject(cleaned).optJSONArray("characters")
                        if (arr != null && arr.length() > 0) {
                            val list = mutableListOf<StoryCharacter>()
                            for (i in 0 until arr.length()) {
                                val c = arr.optJSONObject(i) ?: continue
                                val gStr = c.optString("voiceGender", "FEMALE")
                                list.add(
                                    StoryCharacter(
                                        name = c.optString("name", "Character ${i + 1}"),
                                        age = c.optString("age", ""),
                                        facialFeatures = c.optString("facialFeatures", ""),
                                        hairAndStyle = c.optString("hairAndStyle", ""),
                                        clothingAndColors = c.optString("clothingAndColors", ""),
                                        voiceGender = if (gStr.equals("MALE", true)) VoiceGender.MALE else VoiceGender.FEMALE,
                                        voiceTone = c.optString("voiceTone", "Warm & Clear")
                                    )
                                )
                            }
                            if (list.isNotEmpty()) return@withContext Result.success(list)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Cloud character extraction fallback triggered: ${e.message}")
            }
        }

        // Intelligent local character continuity builder (works 100% offline / Free Mode)
        return@withContext Result.success(buildLocalConsistentCharacters(cleanStory, style, language))
    }

    fun buildLocalConsistentCharacters(
        storyText: String,
        style: VideoStyle,
        language: String
    ): List<StoryCharacter> {
        val lower = storyText.lowercase()
        val isHindi = language.contains("Hindi", true) || storyText.any { it in '\u0900'..'\u097F' }
        val styleOutfitSuffix = if (style == VideoStyle.CARTOON_3D) {
            "stylized 3D Pixar-inspired textures, crisp bright colors"
        } else {
            "authentic natural fabric folds, photorealistic detail"
        }

        return when {
            lower.contains("किसान") || lower.contains("farmer") || lower.contains("खेत") || lower.contains("ગામ") -> listOf(
                StoryCharacter(
                    name = if (isHindi) "रामू किसान" else "Ramesh (Farmer)",
                    age = "45",
                    facialFeatures = "Warm sun-tanned Indian face, kind determined eyes, light trimmed moustache",
                    hairAndStyle = "Short dark pepper-grey hair under neat white cotton pagdi turban",
                    clothingAndColors = "Crisp off-white cotton kurta, maroon waistcoat, yellow gamchha scarf ($styleOutfitSuffix)",
                    voiceGender = VoiceGender.MALE,
                    voiceTone = "Earthy, warm & inspiring"
                ),
                StoryCharacter(
                    name = if (isHindi) "आरव (बेटा)" else "Aarav (Son)",
                    age = "10",
                    facialFeatures = "Bright innocent eyes, cheerful round Indian face, joyful smile",
                    hairAndStyle = "Neatly parted shiny black hair",
                    clothingAndColors = "Sky-blue cotton half-sleeve shirt and dark navy shorts ($styleOutfitSuffix)",
                    voiceGender = VoiceGender.MALE,
                    voiceTone = "Youthful & curious"
                )
            )
            lower.contains("दादी") || lower.contains("माँ") || lower.contains("बहू") || lower.contains("girl") || lower.contains("princess") -> listOf(
                StoryCharacter(
                    name = if (isHindi) "सुमित्रा देवी" else "Sumitra Devi",
                    age = "54",
                    facialFeatures = "Graceful expressive eyes, warm Indian wheatish complexion, small maroon bindi",
                    hairAndStyle = "Silver-streaked black hair tied in a neat low bun",
                    clothingAndColors = "Deep crimson silk saree with golden zari border and pearl earrings ($styleOutfitSuffix)",
                    voiceGender = VoiceGender.FEMALE,
                    voiceTone = "Maternal, composed & expressive"
                ),
                StoryCharacter(
                    name = if (isHindi) "अन्या" else "Anya",
                    age = "22",
                    facialFeatures = "Gentle almond eyes, radiant warm smile, natural skin texture",
                    hairAndStyle = "Long wavy dark brown hair braided to one side",
                    clothingAndColors = "Emerald green embroidered salwar kameez with cream dupatta ($styleOutfitSuffix)",
                    voiceGender = VoiceGender.FEMALE,
                    voiceTone = "Sweet, earnest & hopeful"
                )
            )
            else -> listOf(
                StoryCharacter(
                    name = if (isHindi) "मुख्य नायक (आर्यन)" else "Aryan (Lead)",
                    age = "28",
                    facialFeatures = "Expressive focused eyes, warm Indian complexion, confident calm expression",
                    hairAndStyle = "Styled medium black hair, clean jawline",
                    clothingAndColors = "Mustard ochre linen jacket over crisp charcoal shirt ($styleOutfitSuffix)",
                    voiceGender = VoiceGender.MALE,
                    voiceTone = "Clear, resonant & cinematic"
                ),
                StoryCharacter(
                    name = if (isHindi) "मीरा (सहयोगी)" else "Meera (Companion)",
                    age = "26",
                    facialFeatures = "Bright attentive eyes, warm genuine expression, subtle smile",
                    hairAndStyle = "Shoulder-length dark hair tucked behind ear with silver jhumkas",
                    clothingAndColors = "Teal blue handloom kurti with ivory scarf ($styleOutfitSuffix)",
                    voiceGender = VoiceGender.FEMALE,
                    voiceTone = "Warm, melodic & engaging"
                )
            )
        }
    }

    /**
     * Generates a real AI image via Google Gemini Flash Image (`gemini-2.5-flash-image:generateContent`)
     * or falls back to Imagen 3 (`imagen-3.0-generate-002:predict`).
     * Never returns fake placeholder artwork as AI-generated output; surfaces clear API/billing errors.
     */
    suspend fun generateImageWithGoogleAi(
        apiKey: String,
        prompt: String,
        style: VideoStyle,
        aspectRatio: String,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank() || cleanKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException(
                    "Google AI API key is missing. Add your Gemini API key in Settings or AI Studio Secrets to generate cloud AI images."
                )
            )
        }

        val fullPrompt = "${prompt.trim()}. ${style.promptModifier} Composition aspect ratio: $aspectRatio."

        // Primary: Gemini 2.5 Flash Image (`generateContent` with responseModalities: ["TEXT", "IMAGE"])
        val geminiResult = callGeminiFlashImageApi(cleanKey, fullPrompt, inlineImageBase64 = null, inlineMimeType = null, outputFile = outputFile)
        if (geminiResult.isSuccess) return@withContext geminiResult

        val firstError = geminiResult.exceptionOrNull()
        val msg = firstError?.message.orEmpty()
        // If authentication/billing/quota error, don't mask it; if 404/model unsupported, also try Imagen 3
        if (msg.contains("404") || msg.contains("not found", true) || msg.contains("does not contain image", true)) {
            val imagenResult = callImagen3PredictApi(cleanKey, fullPrompt, aspectRatio, outputFile)
            if (imagenResult.isSuccess) return@withContext imagenResult
            return@withContext Result.failure(
                Exception("${firstError?.message}\n\nImagen 3 fallback: ${imagenResult.exceptionOrNull()?.message}")
            )
        }
        return@withContext geminiResult
    }

    /**
     * Edits an uploaded user image using text instructions via official Gemini Flash Image API.
     */
    suspend fun editImageWithGoogleAi(
        apiKey: String,
        imageBytes: ByteArray,
        mimeType: String,
        instruction: String,
        style: VideoStyle,
        aspectRatio: String,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank() || cleanKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException(
                    "Google AI API key is required for AI Image Editing. Enter your Gemini API key in Settings or Secrets."
                )
            )
        }
        if (instruction.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter edit instructions."))
        }

        // Resize large uploads to keep payload crisp and fast (< 1280px)
        val normalizedBytes = downscaleImageBytesForApi(imageBytes, 1280)
        val base64 = Base64.encodeToString(normalizedBytes, Base64.NO_WRAP)
        val editPrompt = "Edit the provided image carefully according to this instruction: ${instruction.trim()}. " +
            "Apply visual style: ${style.displayName} (${style.promptModifier}). Maintain subject identity and frame cleanly for $aspectRatio."

        return@withContext callGeminiFlashImageApi(
            apiKey = cleanKey,
            prompt = editPrompt,
            inlineImageBase64 = base64,
            inlineMimeType = if (mimeType.startsWith("image/")) mimeType else "image/jpeg",
            outputFile = outputFile
        )
    }

    private fun callGeminiFlashImageApi(
        apiKey: String,
        prompt: String,
        inlineImageBase64: String?,
        inlineMimeType: String?,
        outputFile: File
    ): Result<File> {
        val parts = JSONArray().apply {
            put(JSONObject().apply { put("text", prompt) })
            if (!inlineImageBase64.isNullOrBlank()) {
                put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", inlineMimeType ?: "image/jpeg")
                        put("data", inlineImageBase64)
                    })
                })
            }
        }

        val bodyJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", parts)
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().apply {
                    put("TEXT")
                    put("IMAGE")
                })
                put("temperature", 0.4)
            })
        }

        val req = Request.Builder()
            .url("$BASE_URL/models/$MODEL_IMAGE_GEMINI:generateContent")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(req).execute().use { response ->
            val respBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                return Result.failure(Exception(mapHttpError(response.code, respBody, "Gemini Image API")))
            }

            val root = JSONObject(respBody)
            val respParts = root.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")

            if (respParts != null) {
                for (i in 0 until respParts.length()) {
                    val part = respParts.optJSONObject(i) ?: continue
                    val inlineData = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
                    val b64 = inlineData?.optString("data", "").orEmpty()
                    if (b64.isNotBlank()) {
                        val decoded = Base64.decode(b64, Base64.DEFAULT)
                        outputFile.parentFile?.mkdirs()
                        FileOutputStream(outputFile).use { it.write(decoded) }
                        return Result.success(outputFile)
                    }
                }
            }

            return Result.failure(
                Exception("API response did not contain generated image data. Your API project or region may not have image generation enabled.")
            )
        }
    }

    private fun callImagen3PredictApi(
        apiKey: String,
        prompt: String,
        aspectRatio: String,
        outputFile: File
    ): Result<File> {
        val ratio = when (aspectRatio) {
            "9:16", "16:9", "1:1" -> aspectRatio
            "4:5" -> "3:4" // Closest portrait ratio supported by Imagen 3
            else -> "1:1"
        }

        val bodyJson = JSONObject().apply {
            put("instances", JSONArray().apply {
                put(JSONObject().apply { put("prompt", prompt) })
            })
            put("parameters", JSONObject().apply {
                put("sampleCount", 1)
                put("aspectRatio", ratio)
                put("outputMimeType", "image/png")
            })
        }

        val req = Request.Builder()
            .url("$BASE_URL/models/$MODEL_IMAGE_IMAGEN:predict")
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(req).execute().use { response ->
            val respBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                return Result.failure(Exception(mapHttpError(response.code, respBody, "Imagen 3 API")))
            }

            val root = JSONObject(respBody)
            val pred = root.optJSONArray("predictions")?.optJSONObject(0)
            val b64 = pred?.optString("bytesBase64Encoded", "").orEmpty()
            if (b64.isNotBlank()) {
                val decoded = Base64.decode(b64, Base64.DEFAULT)
                outputFile.parentFile?.mkdirs()
                FileOutputStream(outputFile).use { it.write(decoded) }
                return Result.success(outputFile)
            }
            return Result.failure(Exception("Imagen 3 returned empty prediction payload."))
        }
    }

    /**
     * Synthesizes natural AI speech via official Google Gemini TTS (`gemini-2.5-flash-preview-tts`).
     * Prebuilt voices include "Kore" (Female clear), "Aoede" (Female warm), "Puck" (Male friendly), "Charon" (Male deep).
     * Decodes returned PCM L16 audio to a valid 24kHz Mono WAV file.
     */
    suspend fun synthesizeCloudVoiceWithGemini(
        apiKey: String,
        text: String,
        voiceName: String = "Kore",
        language: String = "Hindi",
        outputWavFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank() || cleanKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key required for Cloud AI Voice. Use Free On-Device Voiceover instead.")
            )
        }

        val styledPrompt = "Speak naturally in $language with clear expressive studio narration: ${text.trim()}"
        val bodyJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", styledPrompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().apply { put("AUDIO") })
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }

        val req = Request.Builder()
            .url("$BASE_URL/models/$MODEL_TTS:generateContent")
            .addHeader("x-goog-api-key", cleanKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(req).execute().use { response ->
                val respBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception(mapHttpError(response.code, respBody, "Gemini Cloud TTS")))
                }

                val root = JSONObject(respBody)
                val part = root.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                val inlineData = part?.optJSONObject("inlineData") ?: part?.optJSONObject("inline_data")
                val b64 = inlineData?.optString("data", "").orEmpty()
                val mime = inlineData?.optString("mimeType", "audio/L16;rate=24000").orEmpty()

                if (b64.isBlank()) {
                    return@withContext Result.failure(Exception("Cloud TTS did not return audio data."))
                }

                val rawAudio = Base64.decode(b64, Base64.DEFAULT)
                val sampleRate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                outputWavFile.parentFile?.mkdirs()

                if (mime.contains("wav", ignoreCase = true) && rawAudio.size > 44 && String(rawAudio, 0, 4) == "RIFF") {
                    FileOutputStream(outputWavFile).use { it.write(rawAudio) }
                } else {
                    writePcmBytesAsWav(rawAudio, outputWavFile, sampleRate, channels = 1)
                }

                return@withContext Result.success(outputWavFile)
            }
        } catch (e: Exception) {
            return@withContext Result.failure(Exception("Cloud AI voice failed: ${e.message}", e))
        }
    }

    private fun downscaleImageBytesForApi(rawBytes: ByteArray, maxDim: Int): ByteArray {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, opts)
            var sampleSize = 1
            while ((opts.outWidth / sampleSize) > maxDim || (opts.outHeight / sampleSize) > maxDim) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val bmp = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, decodeOpts) ?: return rawBytes
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
            bmp.recycle()
            out.toByteArray()
        } catch (_: Exception) {
            rawBytes
        }
    }

    private fun writePcmBytesAsWav(pcmBytes: ByteArray, outFile: File, sampleRate: Int, channels: Int) {
        val totalDataLen = pcmBytes.size + 36
        val byteRate = sampleRate * channels * 2
        val header = ByteArray(44)
        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte(); header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        ByteBuffer.wrap(header, 4, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(totalDataLen)
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte(); header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte(); header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        header[16] = 16
        header[20] = 1
        header[22] = channels.toByte()
        ByteBuffer.wrap(header, 24, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(sampleRate)
        ByteBuffer.wrap(header, 28, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(byteRate)
        header[32] = (channels * 2).toByte()
        header[34] = 16
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte(); header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        ByteBuffer.wrap(header, 40, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(pcmBytes.size)

        FileOutputStream(outFile).use { fos ->
            fos.write(header)
            fos.write(pcmBytes)
        }
    }

    fun mapHttpError(code: Int, body: String, apiName: String): String {
        val coreMsg = try {
            val errObj = JSONObject(body).optJSONObject("error")
            errObj?.optString("message").orEmpty()
        } catch (_: Exception) {
            ""
        }
        return when (code) {
            400 -> "$apiName Error (400): ${coreMsg.ifBlank { "Invalid request parameters" }}"
            401 -> "$apiName Auth Failed (401): Invalid API key. Please check Settings."
            403 -> "$apiName Permission / Billing Required (403): ${coreMsg.ifBlank { "Your API key does not have billing or permission enabled for this model." }}"
            404 -> "$apiName Model Not Found (404): ${coreMsg.ifBlank { "Requested model is not available on this endpoint/key." }}"
            429 -> "$apiName Quota Exceeded (429): Rate limit or quota reached. Wait a moment or use Free Mode."
            else -> "$apiName Error ($code): ${coreMsg.ifBlank { body.take(180) }}"
        }
    }
}
