package com.example.data.audio

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Transcodes 16-bit PCM WAV audio file to AAC (audio/mp4a-latm) and writes directly into MediaMuxer.
 * Handles audio format changes and precise timestamp pacing.
 */
class AacAudioEncoder {

    companion object {
        private const val TAG = "AacAudioEncoder"
        private const val AAC_MIME = MediaFormat.MIMETYPE_AUDIO_AAC
        private const val TIMEOUT_USEC = 10000L
        private const val AAC_BITRATE = 128000
    }

    /**
     * Encodes PCM WAV file into AAC and writes samples into the supplied already-started MediaMuxer.
     * @param wavFile The 16-bit PCM WAV file
     * @param mediaMuxer An active (started) MediaMuxer
     * @param audioTrackIndex The track index previously returned by mediaMuxer.addTrack(...)
     */
    fun encodeWavToMuxerTrack(wavFile: File, mediaMuxer: MediaMuxer, audioTrackIndex: Int): Boolean {
        if (!wavFile.exists() || wavFile.length() <= 44) {
            Log.e(TAG, "Cannot encode WAV to AAC: File does not exist or empty: ${wavFile.absolutePath}")
            return false
        }

        var codec: MediaCodec? = null
        var inputStream: FileInputStream? = null

        try {
            inputStream = FileInputStream(wavFile)
            val header = ByteArray(44)
            val headerRead = inputStream.read(header)
            if (headerRead < 44) {
                Log.e(TAG, "WAV header too short: $headerRead bytes")
                return false
            }

            val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val channels = bb.getShort(22).toInt().coerceAtLeast(1)
            val sampleRate = bb.getInt(24).coerceAtLeast(8000)

            Log.i(TAG, "Configuring AAC encoder: sampleRate=$sampleRate, channels=$channels, wavSize=${wavFile.length()} bytes")

            val aacFormat = MediaFormat.createAudioFormat(AAC_MIME, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, AAC_BITRATE)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }

            codec = MediaCodec.createEncoderByType(AAC_MIME)
            codec.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            val inputChunk = ByteArray(4096)
            var isInputEos = false
            var totalBytesRead = 0L
            var samplesWritten = 0

            while (true) {
                if (!isInputEos) {
                    val inputBufIndex = codec.dequeueInputBuffer(TIMEOUT_USEC)
                    if (inputBufIndex >= 0) {
                        val inputBuf = codec.getInputBuffer(inputBufIndex)
                        if (inputBuf != null) {
                            val bytesRead = inputStream.read(inputChunk)
                            if (bytesRead < 0) {
                                codec.queueInputBuffer(inputBufIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isInputEos = true
                                Log.d(TAG, "Queued EOS to AAC encoder after $totalBytesRead bytes")
                            } else {
                                inputBuf.clear()
                                inputBuf.put(inputChunk, 0, bytesRead)
                                val pts = (totalBytesRead * 1_000_000L) / (sampleRate * channels * 2)
                                codec.queueInputBuffer(inputBufIndex, 0, bytesRead, pts, 0)
                                totalBytesRead += bytesRead
                            }
                        }
                    }
                }

                val outputBufIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC)
                if (outputBufIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (isInputEos) break
                } else if (outputBufIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    Log.d(TAG, "AAC encoder output format changed: ${codec.outputFormat}")
                } else if (outputBufIndex >= 0) {
                    val outputBuf = codec.getOutputBuffer(outputBufIndex)
                    if (outputBuf != null) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }

                        if (bufferInfo.size > 0) {
                            outputBuf.position(bufferInfo.offset)
                            outputBuf.limit(bufferInfo.offset + bufferInfo.size)
                            mediaMuxer.writeSampleData(audioTrackIndex, outputBuf, bufferInfo)
                            samplesWritten++
                        }
                    }
                    codec.releaseOutputBuffer(outputBufIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        Log.d(TAG, "AAC encoder reached EOS. Total samples written: $samplesWritten")
                        break
                    }
                }
            }

            Log.i(TAG, "AAC Audio muxing finished successfully. Samples written: $samplesWritten")
            return samplesWritten > 0

        } catch (e: Exception) {
            Log.e(TAG, "Failed to encode WAV to AAC muxer track", e)
            return false
        } finally {
            try {
                inputStream?.close()
            } catch (_: Exception) {}
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Transcodes a 16-bit PCM WAV file to a standalone MPEG-4 AAC (.m4a) file.
     * Guarantees a fully valid audio track with standard CSD-0 for muxing into MP4.
     */
    fun transcodeWavToM4a(wavFile: File, outputM4aFile: File): Boolean {
        if (!wavFile.exists() || wavFile.length() <= 44) {
            Log.e(TAG, "Cannot transcode WAV: File does not exist or empty: ${wavFile.absolutePath}")
            return false
        }
        outputM4aFile.parentFile?.mkdirs()
        if (outputM4aFile.exists()) outputM4aFile.delete()

        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputStream: FileInputStream? = null

        try {
            inputStream = FileInputStream(wavFile)
            val header = ByteArray(44)
            val headerRead = inputStream.read(header)
            if (headerRead < 44) {
                Log.e(TAG, "WAV header too short: $headerRead bytes")
                return false
            }

            val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val channels = bb.getShort(22).toInt().coerceAtLeast(1)
            val sampleRate = bb.getInt(24).coerceAtLeast(8000)

            Log.i(TAG, "Transcoding WAV to M4A: rate=$sampleRate, channels=$channels, file=${wavFile.name}")

            val aacFormat = MediaFormat.createAudioFormat(AAC_MIME, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, AAC_BITRATE)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }

            codec = MediaCodec.createEncoderByType(AAC_MIME)
            codec.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            muxer = MediaMuxer(outputM4aFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var audioTrackIndex = -1
            var muxerStarted = false

            val bufferInfo = MediaCodec.BufferInfo()
            val inputChunk = ByteArray(4096)
            var isInputEos = false
            var totalBytesRead = 0L
            var samplesWritten = 0

            while (true) {
                if (!isInputEos) {
                    val inputBufIndex = codec.dequeueInputBuffer(TIMEOUT_USEC)
                    if (inputBufIndex >= 0) {
                        val inputBuf = codec.getInputBuffer(inputBufIndex)
                        if (inputBuf != null) {
                            val bytesRead = inputStream.read(inputChunk)
                            if (bytesRead < 0) {
                                codec.queueInputBuffer(inputBufIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isInputEos = true
                                Log.d(TAG, "Queued EOS for M4A transcode after $totalBytesRead bytes")
                            } else {
                                inputBuf.clear()
                                inputBuf.put(inputChunk, 0, bytesRead)
                                val pts = (totalBytesRead * 1_000_000L) / (sampleRate * channels * 2)
                                codec.queueInputBuffer(inputBufIndex, 0, bytesRead, pts, 0)
                                totalBytesRead += bytesRead
                            }
                        }
                    }
                }

                val outputBufIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC)
                if (outputBufIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (isInputEos) break
                } else if (outputBufIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxerStarted) {
                        val newFormat = codec.outputFormat
                        Log.i(TAG, "M4A audio format ready: $newFormat")
                        audioTrackIndex = muxer.addTrack(newFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                } else if (outputBufIndex >= 0) {
                    val outputBuf = codec.getOutputBuffer(outputBufIndex)
                    if (outputBuf != null && muxerStarted) {
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0) {
                            outputBuf.position(bufferInfo.offset)
                            outputBuf.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(audioTrackIndex, outputBuf, bufferInfo)
                            samplesWritten++
                        }
                    }
                    codec.releaseOutputBuffer(outputBufIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }

            Log.i(TAG, "Transcoded WAV to M4A finished: ${outputM4aFile.length()} bytes, samples=$samplesWritten")
            return samplesWritten > 0 && outputM4aFile.exists() && outputM4aFile.length() > 0
        } catch (e: Exception) {
            Log.e(TAG, "Failed to transcode WAV to M4A: ${e.message}", e)
            return false
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    /**
     * Determines AAC MediaFormat from a WAV file header before muxer start.
     */
    fun createAudioFormatFromWav(wavFile: File): MediaFormat? {
        if (!wavFile.exists() || wavFile.length() < 44) return null
        return try {
            FileInputStream(wavFile).use { input ->
                val header = ByteArray(44)
                input.read(header)
                val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
                val channels = bb.getShort(22).toInt().coerceAtLeast(1)
                val sampleRate = bb.getInt(24).coerceAtLeast(8000)

                MediaFormat.createAudioFormat(AAC_MIME, sampleRate, channels).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, AAC_BITRATE)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating audio format from WAV", e)
            null
        }
    }
}
