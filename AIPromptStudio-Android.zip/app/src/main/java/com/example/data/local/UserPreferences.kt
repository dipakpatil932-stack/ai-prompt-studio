package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.example.data.model.VideoProviderType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSettings(
    val providerType: VideoProviderType = VideoProviderType.FREE_MODE,
    val providerApiKey: String = "",
    val customBackendUrl: String = "",
    val geminiApiKeyOverride: String = "",
    val dialogueLanguage: String = "Hindi"
)

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_prompt_studio_prefs", Context.MODE_PRIVATE)

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow: StateFlow<UserSettings> = _settingsFlow.asStateFlow()

    private fun loadSettings(): UserSettings {
        val providerStr = prefs.getString(KEY_PROVIDER_TYPE, VideoProviderType.FREE_MODE.name) ?: VideoProviderType.FREE_MODE.name
        val providerType = runCatching { VideoProviderType.valueOf(providerStr) }.getOrDefault(VideoProviderType.FREE_MODE)
        val apiKey = prefs.getString(KEY_PROVIDER_API_KEY, "") ?: ""
        val backendUrl = prefs.getString(KEY_CUSTOM_BACKEND_URL, "") ?: ""
        val geminiOverride = prefs.getString(KEY_GEMINI_KEY_OVERRIDE, "") ?: ""
        val language = prefs.getString(KEY_DIALOGUE_LANGUAGE, "Hindi") ?: "Hindi"

        return UserSettings(
            providerType = providerType,
            providerApiKey = apiKey,
            customBackendUrl = backendUrl,
            geminiApiKeyOverride = geminiOverride,
            dialogueLanguage = language
        )
    }

    fun updateProvider(type: VideoProviderType) {
        prefs.edit().putString(KEY_PROVIDER_TYPE, type.name).apply()
        _settingsFlow.value = loadSettings()
    }

    fun updateApiKey(apiKey: String) {
        prefs.edit().putString(KEY_PROVIDER_API_KEY, apiKey.trim()).apply()
        _settingsFlow.value = loadSettings()
    }

    fun updateCustomBackendUrl(url: String) {
        prefs.edit().putString(KEY_CUSTOM_BACKEND_URL, url.trim()).apply()
        _settingsFlow.value = loadSettings()
    }

    fun updateGeminiApiKeyOverride(key: String) {
        prefs.edit().putString(KEY_GEMINI_KEY_OVERRIDE, key.trim()).apply()
        _settingsFlow.value = loadSettings()
    }

    fun updateDialogueLanguage(language: String) {
        prefs.edit().putString(KEY_DIALOGUE_LANGUAGE, language).apply()
        _settingsFlow.value = loadSettings()
    }

    fun isConfigured(): Boolean {
        val current = _settingsFlow.value
        return when (current.providerType) {
            VideoProviderType.FREE_MODE -> true
            VideoProviderType.CUSTOM_BACKEND -> current.customBackendUrl.isNotBlank()
            VideoProviderType.GOOGLE_VEO -> {
                current.providerApiKey.isNotBlank() || isBuildConfigGeminiKeyAvailable()
            }
            VideoProviderType.LUMA_DREAM_MACHINE -> {
                current.providerApiKey.isNotBlank() || isBuildConfigLumaKeyAvailable()
            }
            VideoProviderType.RUNWAY_GEN3 -> {
                current.providerApiKey.isNotBlank()
            }
        }
    }

    fun getEffectiveGeminiApiKey(): String {
        val override = _settingsFlow.value.geminiApiKeyOverride
        if (override.isNotBlank()) return override
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key != "MY_GEMINI_API_KEY") key else ""
        } catch (_: Throwable) {
            ""
        }
    }

    fun getEffectiveLumaApiKey(): String {
        val key = _settingsFlow.value.providerApiKey
        if (key.isNotBlank()) return key.trim().removePrefix("Bearer ").trim()
        return try {
            val field = BuildConfig::class.java.getField("LUMA_API_KEY")
            val buildKey = field.get(null) as? String ?: ""
            if (buildKey.isNotBlank() && buildKey != "MY_LUMA_API_KEY") buildKey.trim().removePrefix("Bearer ").trim() else ""
        } catch (_: Throwable) {
            ""
        }
    }

    private fun isBuildConfigGeminiKeyAvailable(): Boolean {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            key.isNotBlank() && key != "MY_GEMINI_API_KEY"
        } catch (_: Throwable) {
            false
        }
    }

    private fun isBuildConfigLumaKeyAvailable(): Boolean {
        return try {
            val field = BuildConfig::class.java.getField("LUMA_API_KEY")
            val key = field.get(null) as? String ?: ""
            key.isNotBlank() && key != "MY_LUMA_API_KEY"
        } catch (_: Throwable) {
            false
        }
    }

    companion object {
        private const val KEY_PROVIDER_TYPE = "provider_type"
        private const val KEY_PROVIDER_API_KEY = "provider_api_key"
        private const val KEY_CUSTOM_BACKEND_URL = "custom_backend_url"
        private const val KEY_GEMINI_KEY_OVERRIDE = "gemini_key_override"
        private const val KEY_DIALOGUE_LANGUAGE = "dialogue_language"
    }
}
