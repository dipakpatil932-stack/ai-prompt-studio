package com.example.data.remote.video

import com.example.data.model.VideoStyle
import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds and validates requests for the Google Veo Video Generation API
 * (`models/veo-2.0-generate-001:predictLongRunning`).
 *
 * Official schema strictly requires:
 * {
 *   "instances": [
 *     { "prompt": "..." }
 *   ],
 *   "parameters": {
 *     "sampleCount": 1,
 *     "aspectRatio": "16:9",
 *     "durationSeconds": 5
 *   }
 * }
 *
 * Top-level fields MUST NOT contain "prompt", "aspectRatio", "durationSeconds", or "language".
 * Dialogue language preferences are incorporated directly into the prompt.
 */
object GoogleVeoRequestBuilder {

    const val DEFAULT_MODEL = "veo-2.0-generate-001"
    const val BASE_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta"

    fun buildPredictionUrl(model: String = DEFAULT_MODEL): String {
        return "$BASE_ENDPOINT/models/$model:predictLongRunning"
    }

    fun buildPollingUrl(operationName: String): String {
        val cleanName = operationName.trim().removePrefix("/")
        return "$BASE_ENDPOINT/$cleanName"
    }

    /**
     * Constructs the official Google Veo request JSON.
     */
    fun buildRequestJson(
        prompt: String,
        style: String = "",
        aspectRatio: String = "16:9",
        duration: String = "5 sec",
        dialogueLanguage: String = "Hindi"
    ): JSONObject {
        val promptParts = mutableListOf<String>()
        val cleanPrompt = prompt.trim().trimEnd('.')
        if (cleanPrompt.isNotBlank()) {
            promptParts.add(cleanPrompt)
        }

        val styleModifier = VideoStyle.entries.find { it.displayName.equals(style, ignoreCase = true) }?.promptModifier
        if (!styleModifier.isNullOrBlank()) {
            promptParts.add(styleModifier.trim().trimEnd('.'))
        } else if (style.isNotBlank()) {
            promptParts.add("Visual style: $style")
        }

        if (dialogueLanguage.isNotBlank() && !dialogueLanguage.equals("None", ignoreCase = true)) {
            promptParts.add("Characters speak in $dialogueLanguage language with authentic cultural nuances")
        }

        val finalPrompt = promptParts.joinToString(". ") + "."

        val normalizedRatio = when {
            aspectRatio.contains("9:16") -> "9:16"
            aspectRatio.contains("1:1") -> "1:1"
            else -> "16:9"
        }

        val rawSec = duration.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 5
        val durationSec = when {
            rawSec >= 8 -> 8
            rawSec <= 5 -> 5
            else -> rawSec
        }

        val json = JSONObject()

        // instances: array of objects with "prompt"
        val instanceObj = JSONObject().apply {
            put("prompt", finalPrompt)
        }
        json.put("instances", JSONArray().apply { put(instanceObj) })

        // parameters: sampleCount, aspectRatio, durationSeconds (NO language)
        val paramsObj = JSONObject().apply {
            put("sampleCount", 1)
            put("aspectRatio", normalizedRatio)
            put("durationSeconds", durationSec)
        }
        json.put("parameters", paramsObj)

        return json
    }

    /**
     * Validates that the JSON strictly matches the Google Veo request schema.
     * Throws IllegalArgumentException on any schema violation.
     */
    fun validateRequestJson(json: JSONObject) {
        // Verify root fields
        val rootKeys = json.keys().asSequence().toSet()
        val forbiddenRootKeys = setOf("prompt", "aspectRatio", "durationSeconds", "language")
        val foundForbidden = rootKeys.intersect(forbiddenRootKeys)
        if (foundForbidden.isNotEmpty()) {
            throw IllegalArgumentException(
                "Unknown name '${foundForbidden.first()}': Cannot find field at root level. " +
                "Google Veo API accepts only 'instances' and 'parameters' at root."
            )
        }

        val allowedRootKeys = setOf("instances", "parameters")
        val unknownKeys = rootKeys - allowedRootKeys
        if (unknownKeys.isNotEmpty()) {
            throw IllegalArgumentException("Unknown root field(s): $unknownKeys. Only 'instances' and 'parameters' are supported.")
        }

        // Verify instances
        if (!json.has("instances")) {
            throw IllegalArgumentException("Missing required 'instances' array in Google Veo request.")
        }
        val instances = json.getJSONArray("instances")
        if (instances.length() == 0) {
            throw IllegalArgumentException("'instances' array must not be empty.")
        }
        val firstInstance = instances.getJSONObject(0)
        val instancePrompt = firstInstance.optString("prompt", "").trim()
        if (instancePrompt.isBlank()) {
            throw IllegalArgumentException("Prompt inside 'instances' must not be blank.")
        }

        // Verify parameters
        if (json.has("parameters")) {
            val params = json.getJSONObject("parameters")
            val paramKeys = params.keys().asSequence().toSet()
            if (paramKeys.contains("language")) {
                throw IllegalArgumentException("Unknown name 'language': field is not supported by Google Veo parameters. Include language in prompt instead.")
            }
            if (paramKeys.contains("prompt")) {
                throw IllegalArgumentException("Unknown name 'prompt': cannot be inside 'parameters'.")
            }
            val allowedParamKeys = setOf("sampleCount", "aspectRatio", "durationSeconds", "resolution", "personGeneration", "fps")
            val unknownParams = paramKeys - allowedParamKeys
            if (unknownParams.isNotEmpty()) {
                throw IllegalArgumentException("Unsupported parameter(s): $unknownParams.")
            }
            if (params.has("aspectRatio")) {
                val ratio = params.getString("aspectRatio")
                if (ratio !in setOf("16:9", "9:16", "1:1")) {
                    throw IllegalArgumentException("Unsupported aspectRatio '$ratio'. Must be '16:9', '9:16', or '1:1'.")
                }
            }
            if (params.has("durationSeconds")) {
                val duration = params.getInt("durationSeconds")
                if (duration <= 0) {
                    throw IllegalArgumentException("durationSeconds must be greater than 0.")
                }
            }
        }
    }

    /**
     * Parses completed video URI from Google Veo / Gemini API operation response.
     */
    fun extractVideoUri(json: JSONObject): String {
        val direct = json.optString("videoUrl", "")
        if (direct.isNotBlank()) return direct

        val resp = json.optJSONObject("response") ?: return ""

        val genVidResp = resp.optJSONObject("generateVideoResponse")
        val samples = (genVidResp ?: resp).optJSONArray("generatedSamples")
        if (samples != null && samples.length() > 0) {
            val sample = samples.optJSONObject(0)
            val uri = sample?.optJSONObject("video")?.optString("uri", "").orEmpty()
            if (uri.isNotBlank()) return uri
        }

        val videos = resp.optJSONArray("videos") ?: resp.optJSONObject("output")?.optJSONArray("videos")
        if (videos != null && videos.length() > 0) {
            val uri = videos.optJSONObject(0)?.optString("uri", "").orEmpty()
            if (uri.isNotBlank()) return uri
        }

        return ""
    }

    /**
     * Parses Google API error response into a clean, actionable message.
     */
    fun parseGoogleApiError(body: String, code: Int): String {
        if (body.isBlank()) {
            return when (code) {
                401, 403 -> "Authentication failed: invalid or unauthorized API key (अमान्य API कुंजी)."
                429 -> "Quota exceeded: Google AI Studio rate limit or quota reached (कोटा समाप्त)."
                500, 502, 503 -> "Google Veo service temporarily busy (सर्वर व्यस्त है). Please try again shortly."
                else -> "HTTP status $code"
            }
        }

        try {
            val json = JSONObject(body)
            val errorObj = json.optJSONObject("error")
            if (errorObj != null) {
                val message = errorObj.optString("message", "")
                val status = errorObj.optString("status", "")
                val fieldViolations = mutableListOf<String>()

                val details = errorObj.optJSONArray("details")
                if (details != null) {
                    for (i in 0 until details.length()) {
                        val detail = details.optJSONObject(i) ?: continue
                        val violations = detail.optJSONArray("fieldViolations")
                        if (violations != null) {
                            for (j in 0 until violations.length()) {
                                val v = violations.optJSONObject(j) ?: continue
                                val desc = v.optString("description", "")
                                if (desc.isNotBlank()) {
                                    fieldViolations.add(desc)
                                }
                            }
                        }
                    }
                }

                val violationText = if (fieldViolations.isNotEmpty()) {
                    ": " + fieldViolations.joinToString(", ")
                } else ""

                val coreMessage = if (message.isNotBlank()) message else "Request failed"

                return when (code) {
                    400 -> "Google Veo Error (400 $status): $coreMessage$violationText"
                    401, 403 -> "Authentication failed ($code $status): Please verify your Gemini API key in Settings (⚙️)."
                    429 -> "Quota exceeded (429 $status): Google Veo rate limit or credit limit reached (कोटा समाप्त)."
                    500, 502, 503 -> "Google Veo service unavailable ($code $status): Server is busy, please retry shortly."
                    else -> "Google Veo Error ($code $status): $coreMessage$violationText"
                }
            }

            val directMsg = json.optString("message", json.optString("detail", ""))
            if (directMsg.isNotBlank()) return "Google Veo Error ($code): $directMsg"
        } catch (_: Exception) {
            // Raw text response
        }

        return "Google Veo Error ($code): ${body.take(200)}"
    }
}
