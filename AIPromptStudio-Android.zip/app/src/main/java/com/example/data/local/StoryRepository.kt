package com.example.data.local

import com.example.data.model.StoryPlan
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class StoryRepository(private val dao: StoryPlanDao) {
    val allStories: Flow<List<StoryPlan>> = dao.getAllStories().map { list ->
        list.map { it.toDomain() }
    }

    fun getStoryById(id: Long): Flow<StoryPlan?> = dao.getStoryById(id).map { it?.toDomain() }

    suspend fun saveStory(plan: StoryPlan): Long {
        return dao.insertStory(StoryPlanEntity.fromDomain(plan))
    }

    suspend fun updateStory(plan: StoryPlan) {
        dao.updateStory(StoryPlanEntity.fromDomain(plan))
    }

    suspend fun deleteStory(id: Long) {
        dao.deleteStoryById(id)
    }

    suspend fun clearHistory() {
        dao.clearAllStories()
    }
}
