package com.example.data.remote.video

import android.content.Context
import android.util.Log
import com.example.data.local.UserSettings
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

class VideoConfigException(message: String) : Exception(message)

data class VideoGenerationSubmission(
    val jobId: String,
    val initialStatus: VideoJobStatus,
    val initialMessage: String,
    val directVideoUrl: String? = null
)

data class VideoPollProgress(
    val jobId: String,
    val status: VideoJobStatus,
    val progressPercent: Int,
    val statusMessage: String,
    val videoUrl: String? = null,
    val errorMessage: String? = null
)

class VideoGenerationService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun submitJob(
        prompt: String,
        style: String,
        aspectRatio: String,
        duration: String,
        dialogueLanguage: String,
        settings: UserSettings,
        imageBase64: String? = null,
        imageMimeType: String = "image/jpeg"
    ): Result<VideoGenerationSubmission> = withContext(Dispatchers.IO) {
        val trimmedPrompt = prompt.trim()
        if (trimmedPrompt.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter a story or video idea (कृपया कहानी दर्ज करें)."))
        }

        // Verify provider credentials / backend URL
        val provider = settings.providerType
        val apiKey = settings.providerApiKey.ifBlank {
            when (provider) {
                VideoProviderType.GOOGLE_VEO -> {
                    settings.geminiApiKeyOverride.ifBlank {
                        try {
                            com.example.BuildConfig.GEMINI_API_KEY.takeIf { it != "MY_GEMINI_API_KEY" } ?: ""
                        } catch (_: Throwable) { "" }
                    }
                }
                VideoProviderType.LUMA_DREAM_MACHINE -> {
                    try {
                        val field = com.example.BuildConfig::class.java.getField("LUMA_API_KEY")
                        (field.get(null) as? String)?.takeIf { it != "MY_LUMA_API_KEY" } ?: ""
                    } catch (_: Throwable) { "" }
                }
                else -> ""
            }
        }

        val backendUrl = settings.customBackendUrl

        if (provider == VideoProviderType.CUSTOM_BACKEND && backendUrl.isBlank()) {
            return@withContext Result.failure(
                VideoConfigException(
                    "Custom Video Server URL is not configured. Please enter your backend endpoint in Settings.\n(कस्टम वीडियो सर्वर URL सेटिंग्स में कॉन्फ़िगर करें।)"
                )
            )
        }

        if (provider != VideoProviderType.FREE_MODE && provider != VideoProviderType.CUSTOM_BACKEND && apiKey.isBlank()) {
            val providerName = provider.displayName
            return@withContext Result.failure(
                VideoConfigException(
                    "$providerName API key is not configured. Please open Settings (⚙️) to set your API credentials or configure a backend proxy.\n($providerName API कुंजी सेटिंग्स में दर्ज करें।)"
                )
            )
        }

        try {
            when (provider) {
                VideoProviderType.FREE_MODE -> Result.failure<VideoGenerationSubmission>(
                    IllegalStateException("Free Mode generates videos on-device. Use VideoGeneratorViewModel.startFreeModeGeneration()")
                )
                VideoProviderType.GOOGLE_VEO -> submitGoogleVeoJob(trimmedPrompt, style, aspectRatio, duration, dialogueLanguage, apiKey, backendUrl, imageBase64, imageMimeType)
                VideoProviderType.LUMA_DREAM_MACHINE -> submitLumaJob(trimmedPrompt, style, aspectRatio, duration, apiKey)
                VideoProviderType.RUNWAY_GEN3 -> submitRunwayJob(trimmedPrompt, style, aspectRatio, duration, apiKey)
                VideoProviderType.CUSTOM_BACKEND -> submitCustomBackendJob(trimmedPrompt, style, aspectRatio, duration, dialogueLanguage, backendUrl, apiKey)
            }
        } catch (e: Exception) {
            Log.e("VideoGenerationService", "Job submission failed for ${provider.displayName}", e)
            val friendlyMsg = mapExceptionToMessage(e)
            Result.failure<VideoGenerationSubmission>(Exception(friendlyMsg, e))
        }
    }

    private fun submitGoogleVeoJob(
        prompt: String,
        style: String,
        aspectRatio: String,
        duration: String,
        dialogueLanguage: String,
        apiKey: String,
        backendUrl: String,
        imageBase64: String? = null,
        imageMimeType: String = "image/jpeg"
    ): Result<VideoGenerationSubmission> {
        // Construct the compliant Google Veo request (instances + parameters only)
        val requestJson = GoogleVeoRequestBuilder.buildRequestJson(
            prompt = prompt,
            style = style,
            aspectRatio = aspectRatio,
            duration = duration,
            dialogueLanguage = dialogueLanguage,
            imageBase64 = imageBase64,
            imageMimeType = imageMimeType
        )

        // Strict schema validation before making the API call
        GoogleVeoRequestBuilder.validateRequestJson(requestJson)

        val targetUrl = if (backendUrl.isNotBlank()) {
            "$backendUrl/v1/video/generate"
        } else {
            GoogleVeoRequestBuilder.buildPredictionUrl()
        }

        val request = Request.Builder()
            .url(targetUrl)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errorDetails = GoogleVeoRequestBuilder.parseGoogleApiError(body, response.code)
                return Result.failure(Exception(errorDetails))
            }

            val json = JSONObject(body)
            // Operation name: e.g. "operations/123456789" or "models/veo-2.0-generate-001/operations/..."
            val opName = json.optString("name", json.optString("jobId", json.optString("id", "")))
            val directUri = GoogleVeoRequestBuilder.extractVideoUri(json)

            val jobId = if (opName.isNotBlank()) opName else "veo_${UUID.randomUUID().toString().take(12)}"

            return Result.success(
                VideoGenerationSubmission(
                    jobId = jobId,
                    initialStatus = if (directUri.isNotBlank()) VideoJobStatus.COMPLETED else VideoJobStatus.PROCESSING,
                    initialMessage = "Google Veo video generation initialized (Google Veo वीडियो निर्माण शुरू हुआ)",
                    directVideoUrl = directUri.ifBlank { null }
                )
            )
        }
    }

    private fun submitLumaJob(
        prompt: String,
        style: String,
        aspectRatio: String,
        duration: String,
        apiKey: String
    ): Result<VideoGenerationSubmission> {
        val cleanApiKey = apiKey.trim().removePrefix("Bearer ").trim()
        val styleModifier = VideoStyle.entries.find { it.displayName == style }?.promptModifier ?: ""
        val fullPrompt = "$prompt. $styleModifier"

        val requestJson = JSONObject().apply {
            put("prompt", fullPrompt)
            put("aspect_ratio", aspectRatio)
            put("loop", false)
        }

        val request = Request.Builder()
            .url("https://api.lumalabs.ai/dream-machine/v1/generations")
            .addHeader("Authorization", "Bearer $cleanApiKey")
            .addHeader("Accept", "application/json")
            .addHeader("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = parseErrorResponseBody(body, response.code)
                return Result.failure(Exception("Luma Dream Machine Error (${response.code}): $err"))
            }

            val json = JSONObject(body)
            val jobId = json.getString("id")
            val state = json.optString("state", "queued")

            return Result.success(
                VideoGenerationSubmission(
                    jobId = jobId,
                    initialStatus = VideoJobStatus.PROCESSING,
                    initialMessage = "Luma Dream Machine job queued ($state)"
                )
            )
        }
    }

    private fun submitRunwayJob(
        prompt: String,
        style: String,
        aspectRatio: String,
        duration: String,
        apiKey: String
    ): Result<VideoGenerationSubmission> {
        val styleModifier = VideoStyle.entries.find { it.displayName == style }?.promptModifier ?: ""
        val fullPrompt = "$prompt. $styleModifier"
        val durationSec = duration.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 5

        val requestJson = JSONObject().apply {
            put("promptText", fullPrompt)
            put("model", "gen3a_turbo")
            put("duration", durationSec)
            put("ratio", aspectRatio)
        }

        val request = Request.Builder()
            .url("https://api.dev.runwayml.com/v1/image_to_video")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("X-Runway-Version", "2024-09-13")
            .addHeader("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = parseErrorResponseBody(body, response.code)
                return Result.failure(Exception("Runway Gen-3 Error (${response.code}): $err"))
            }

            val json = JSONObject(body)
            val jobId = json.getString("id")

            return Result.success(
                VideoGenerationSubmission(
                    jobId = jobId,
                    initialStatus = VideoJobStatus.PROCESSING,
                    initialMessage = "Runway Gen-3 task created ($jobId)"
                )
            )
        }
    }

    private fun submitCustomBackendJob(
        prompt: String,
        style: String,
        aspectRatio: String,
        duration: String,
        dialogueLanguage: String,
        backendUrl: String,
        apiKey: String
    ): Result<VideoGenerationSubmission> {
        val requestJson = JSONObject().apply {
            put("prompt", prompt)
            put("style", style)
            put("aspectRatio", aspectRatio)
            put("duration", duration)
            put("dialogueLanguage", dialogueLanguage)
        }

        val builder = Request.Builder()
            .url(backendUrl)
            .addHeader("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody(jsonMediaType))

        if (apiKey.isNotBlank()) {
            builder.addHeader("Authorization", "Bearer $apiKey")
        }

        client.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = parseErrorResponseBody(body, response.code)
                return Result.failure(Exception("Backend Server Error (${response.code}): $err"))
            }

            val json = JSONObject(body)
            val jobId = json.optString("jobId", json.optString("id", UUID.randomUUID().toString()))
            val directUrl = json.optString("videoUrl", "")

            return Result.success(
                VideoGenerationSubmission(
                    jobId = jobId,
                    initialStatus = if (directUrl.isNotBlank()) VideoJobStatus.COMPLETED else VideoJobStatus.PROCESSING,
                    initialMessage = "Job submitted to custom server",
                    directVideoUrl = directUrl.ifBlank { null }
                )
            )
        }
    }

    suspend fun pollJobStatus(
        jobId: String,
        settings: UserSettings,
        elapsedSeconds: Int
    ): VideoPollProgress = withContext(Dispatchers.IO) {
        val provider = settings.providerType
        val apiKey = settings.providerApiKey.ifBlank {
            if (provider == VideoProviderType.GOOGLE_VEO) {
                settings.geminiApiKeyOverride.ifBlank {
                    try {
                        com.example.BuildConfig.GEMINI_API_KEY.takeIf { it != "MY_GEMINI_API_KEY" } ?: ""
                    } catch (_: Throwable) { "" }
                }
            } else ""
        }

        val backendUrl = settings.customBackendUrl

        try {
            when (provider) {
                VideoProviderType.FREE_MODE -> VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.COMPLETED,
                    progressPercent = 100,
                    statusMessage = "Local Free Mode generation completed",
                    errorMessage = null
                )
                VideoProviderType.GOOGLE_VEO -> pollGoogleVeoJob(jobId, apiKey, backendUrl, elapsedSeconds)
                VideoProviderType.LUMA_DREAM_MACHINE -> pollLumaJob(jobId, apiKey, elapsedSeconds)
                VideoProviderType.RUNWAY_GEN3 -> pollRunwayJob(jobId, apiKey, elapsedSeconds)
                VideoProviderType.CUSTOM_BACKEND -> pollCustomBackendJob(jobId, backendUrl, apiKey, elapsedSeconds)
            }
        } catch (e: Exception) {
            Log.e("VideoGenerationService", "Polling error for $jobId", e)
            VideoPollProgress(
                jobId = jobId,
                status = VideoJobStatus.PROCESSING,
                progressPercent = minOf(90, 10 + elapsedSeconds * 2),
                statusMessage = "Connecting to generation server... (सर्वर से संपर्क हो रहा है)",
                errorMessage = null
            )
        }
    }

    private fun pollGoogleVeoJob(
        jobId: String,
        apiKey: String,
        backendUrl: String,
        elapsedSeconds: Int
    ): VideoPollProgress {
        val url = if (backendUrl.isNotBlank()) {
            "$backendUrl/v1/video/status/$jobId"
        } else {
            GoogleVeoRequestBuilder.buildPollingUrl(jobId)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errorDetails = GoogleVeoRequestBuilder.parseGoogleApiError(body, response.code)
                return VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.FAILED,
                    progressPercent = 100,
                    statusMessage = "Polling failed (${response.code})",
                    errorMessage = errorDetails
                )
            }

            val json = JSONObject(body)
            val done = json.optBoolean("done", false)
            if (done) {
                val errorObj = json.optJSONObject("error")
                if (errorObj != null) {
                    val errDetails = GoogleVeoRequestBuilder.parseGoogleApiError(body, 400)
                    return VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.FAILED,
                        progressPercent = 100,
                        statusMessage = "Generation failed",
                        errorMessage = errDetails
                    )
                }

                val videoUri = GoogleVeoRequestBuilder.extractVideoUri(json)

                if (videoUri.isBlank()) {
                    return VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.FAILED,
                        progressPercent = 100,
                        statusMessage = "Operation finished without video payload",
                        errorMessage = "Google Veo reported completion, but no video URI was returned in the response."
                    )
                }

                return VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.COMPLETED,
                    progressPercent = 100,
                    statusMessage = "Google Veo video generated successfully!",
                    videoUrl = videoUri
                )
            } else {
                val progress = minOf(95, 10 + (elapsedSeconds * 3))
                return VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.PROCESSING,
                    progressPercent = progress,
                    statusMessage = "AI rendering cinematic frames... (फ्रेम तैयार हो रहे हैं: ${progress}%)"
                )
            }
        }
    }

    private fun pollLumaJob(
        jobId: String,
        apiKey: String,
        elapsedSeconds: Int
    ): VideoPollProgress {
        val cleanApiKey = apiKey.trim().removePrefix("Bearer ").trim()
        val request = Request.Builder()
            .url("https://api.lumalabs.ai/dream-machine/v1/generations/$jobId")
            .addHeader("Authorization", "Bearer $cleanApiKey")
            .addHeader("Accept", "application/json")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = parseErrorResponseBody(body, response.code)
                if (response.code in listOf(400, 401, 403, 404)) {
                    return VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.FAILED,
                        progressPercent = 100,
                        statusMessage = "Luma Generation Failed (${response.code})",
                        errorMessage = "Luma API Error (${response.code}): $err"
                    )
                }
                return VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.PROCESSING,
                    progressPercent = minOf(90, 15 + elapsedSeconds),
                    statusMessage = "Luma is generating video (${elapsedSeconds}s)"
                )
            }

            val json = JSONObject(body)
            val state = json.optString("state", "dreaming")

            return when (state.lowercase()) {
                "completed" -> {
                    val videoUrl = json.optJSONObject("assets")?.optString("video", "")
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.COMPLETED,
                        progressPercent = 100,
                        statusMessage = "Luma Dream Machine video ready!",
                        videoUrl = videoUrl
                    )
                }
                "failed" -> {
                    val failureReason = json.optString("failure_reason", "Luma generation failed")
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.FAILED,
                        progressPercent = 100,
                        statusMessage = "Generation failed",
                        errorMessage = failureReason
                    )
                }
                else -> {
                    val progress = if (state == "queued") 15 else minOf(95, 20 + elapsedSeconds * 2)
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.PROCESSING,
                        progressPercent = progress,
                        statusMessage = if (state == "queued") "In queue (कतार में है)..." else "Dreaming video (वीडियो प्रोसेस हो रहा है)..."
                    )
                }
            }
        }
    }

    private fun pollRunwayJob(
        jobId: String,
        apiKey: String,
        elapsedSeconds: Int
    ): VideoPollProgress {
        val request = Request.Builder()
            .url("https://api.dev.runwayml.com/v1/tasks/$jobId")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("X-Runway-Version", "2024-09-13")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                return VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.PROCESSING,
                    progressPercent = minOf(90, 15 + elapsedSeconds),
                    statusMessage = "Checking Runway task status..."
                )
            }

            val json = JSONObject(body)
            val status = json.optString("status", "RUNNING")
            val progressRatio = json.optDouble("progressRatio", 0.0)
            val calculatedPercent = if (progressRatio > 0.0) (progressRatio * 100).toInt() else minOf(95, 15 + elapsedSeconds * 2)

            return when (status.uppercase()) {
                "SUCCEEDED" -> {
                    val outputArr = json.optJSONArray("output")
                    val videoUrl = outputArr?.optString(0, "") ?: ""
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.COMPLETED,
                        progressPercent = 100,
                        statusMessage = "Runway Gen-3 video finished!",
                        videoUrl = videoUrl
                    )
                }
                "FAILED" -> {
                    val failure = json.optString("failure", "Runway task failed")
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.FAILED,
                        progressPercent = 100,
                        statusMessage = "Task failed",
                        errorMessage = failure
                    )
                }
                else -> {
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.PROCESSING,
                        progressPercent = calculatedPercent,
                        statusMessage = "Runway rendering ($calculatedPercent%)..."
                    )
                }
            }
        }
    }

    private fun pollCustomBackendJob(
        jobId: String,
        backendUrl: String,
        apiKey: String,
        elapsedSeconds: Int
    ): VideoPollProgress {
        val cleanUrl = backendUrl.trimEnd('/')
        val statusUrl = if (cleanUrl.contains("?")) "$cleanUrl&jobId=$jobId" else "$cleanUrl/status/$jobId"

        val builder = Request.Builder().url(statusUrl).get()
        if (apiKey.isNotBlank()) builder.addHeader("Authorization", "Bearer $apiKey")

        client.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                return VideoPollProgress(
                    jobId = jobId,
                    status = VideoJobStatus.PROCESSING,
                    progressPercent = minOf(90, 15 + elapsedSeconds),
                    statusMessage = "Waiting for server response..."
                )
            }

            val json = JSONObject(body)
            val statusStr = json.optString("status", "processing").lowercase()
            val progress = json.optInt("progress", minOf(95, 10 + elapsedSeconds * 2))

            return when (statusStr) {
                "completed", "success", "done" -> {
                    val videoUrl = json.optString("videoUrl", json.optString("url", ""))
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.COMPLETED,
                        progressPercent = 100,
                        statusMessage = "Video generation complete!",
                        videoUrl = videoUrl
                    )
                }
                "failed", "error" -> {
                    val err = json.optString("error", json.optString("message", "Backend reported failure"))
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.FAILED,
                        progressPercent = 100,
                        statusMessage = "Backend generation failed",
                        errorMessage = err
                    )
                }
                else -> {
                    VideoPollProgress(
                        jobId = jobId,
                        status = VideoJobStatus.PROCESSING,
                        progressPercent = progress,
                        statusMessage = "Server rendering frames ($progress%)..."
                    )
                }
            }
        }
    }

    suspend fun downloadVideoLocally(
        videoUrl: String,
        jobId: String,
        apiKey: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val videosDir = File(context.filesDir, "videos")
            if (!videosDir.exists()) videosDir.mkdirs()

            val sanitizedId = jobId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val targetFile = File(videosDir, "video_$sanitizedId.mp4")

            if (targetFile.exists() && targetFile.length() > 1024) {
                return@withContext Result.success(targetFile.absolutePath)
            }

            val requestBuilder = Request.Builder().url(videoUrl)
            if (apiKey.isNotBlank() && (videoUrl.contains("googleapis.com") || videoUrl.contains("generativelanguage"))) {
                requestBuilder.addHeader("x-goog-api-key", apiKey)
            } else if (apiKey.isNotBlank() && videoUrl.contains("lumalabs.ai")) {
                requestBuilder.addHeader("Authorization", "Bearer ${apiKey.trim().removePrefix("Bearer ").trim()}")
            }
            val request = requestBuilder.build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("Failed to download video: HTTP ${response.code}"))
                }

                val body = response.body ?: return@withContext Result.failure(IOException("Empty video stream"))
                val tempFile = File(videosDir, "temp_$sanitizedId.mp4")

                body.byteStream().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (tempFile.renameTo(targetFile)) {
                    Result.success(targetFile.absolutePath)
                } else {
                    Result.success(tempFile.absolutePath)
                }
            }
        } catch (e: Exception) {
            Log.e("VideoGenerationService", "Failed to cache video file", e)
            Result.failure(e)
        }
    }

    suspend fun testConnection(settings: UserSettings): Result<String> = withContext(Dispatchers.IO) {
        val provider = settings.providerType
        val apiKey = settings.providerApiKey.ifBlank {
            when (provider) {
                VideoProviderType.GOOGLE_VEO -> {
                    settings.geminiApiKeyOverride.ifBlank {
                        try {
                            com.example.BuildConfig.GEMINI_API_KEY.takeIf { it != "MY_GEMINI_API_KEY" } ?: ""
                        } catch (_: Throwable) { "" }
                    }
                }
                VideoProviderType.LUMA_DREAM_MACHINE -> {
                    try {
                        val field = com.example.BuildConfig::class.java.getField("LUMA_API_KEY")
                        (field.get(null) as? String)?.takeIf { it != "MY_LUMA_API_KEY" } ?: ""
                    } catch (_: Throwable) { "" }
                }
                else -> ""
            }
        }

        if (provider == VideoProviderType.CUSTOM_BACKEND) {
            val url = settings.customBackendUrl.trim()
            if (url.isBlank()) return@withContext Result.failure(Exception("Backend URL is empty (URL खाली है)."))
            try {
                val req = Request.Builder().url(url).head().build()
                client.newCall(req).execute().use { resp ->
                    return@withContext Result.success("Connected to server! (HTTP ${resp.code})")
                }
            } catch (e: Exception) {
                return@withContext Result.failure(Exception("Connection failed: ${e.message}"))
            }
        }

        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("API Key is missing for ${provider.displayName}."))
        }

        try {
            when (provider) {
                VideoProviderType.GOOGLE_VEO -> {
                    // 1. First test specific Google Veo model availability
                    val veoTestUrl = "https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-001?key=$apiKey"
                    val reqVeo = Request.Builder().url(veoTestUrl).get().build()
                    val veoCode = client.newCall(reqVeo).execute().use { it.code }

                    if (veoCode == 200) {
                        Result.success("Google Veo (veo-2.0-generate-001) API key verified & active!")
                    } else {
                        // Test general Gemini API access
                        val testUrl = "https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey"
                        val req = Request.Builder().url(testUrl).get().build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) {
                                Result.success("Gemini API key is active. (Note: Direct veo-2.0-generate-001 model access requires Vertex AI / whitelist; you can also use Luma Dream Machine, a Custom Backend, or Free Video Maker).")
                            } else {
                                Result.failure(Exception("API check failed (HTTP ${resp.code})"))
                            }
                        }
                    }
                }
                VideoProviderType.LUMA_DREAM_MACHINE -> {
                    val cleanKey = apiKey.trim().removePrefix("Bearer ").trim()
                    val req = Request.Builder()
                        .url("https://api.lumalabs.ai/dream-machine/v1/generations?limit=1")
                        .addHeader("Authorization", "Bearer $cleanKey")
                        .addHeader("Accept", "application/json")
                        .get()
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) Result.success("Luma Dream Machine API key verified & active!")
                        else Result.failure(Exception("Luma authentication error (HTTP ${resp.code})"))
                    }
                }
                VideoProviderType.RUNWAY_GEN3 -> {
                    val req = Request.Builder()
                        .url("https://api.dev.runwayml.com/v1/tasks?limit=1")
                        .addHeader("Authorization", "Bearer $apiKey")
                        .addHeader("X-Runway-Version", "2024-09-13")
                        .get()
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) Result.success("Runway Gen-3 API key verified!")
                        else Result.failure(Exception("Runway authentication error (HTTP ${resp.code})"))
                    }
                }
                else -> Result.success("OK")
            }
        } catch (e: Exception) {
            Result.failure(Exception("Connection test error: ${e.message}"))
        }
    }

    private fun parseErrorResponseBody(body: String, code: Int): String {
        return try {
            val json = JSONObject(body)
            val errObj = json.optJSONObject("error")
            val msg = errObj?.optString("message") ?: json.optString("message", json.optString("detail", ""))
            if (msg.isNotBlank()) msg else "HTTP $code"
        } catch (_: Exception) {
            when (code) {
                401, 403 -> "Authentication failed: invalid or unauthorized API key (अमान्य API कुंजी)."
                429 -> "Quota or rate limit reached for video provider (क्रेडिट या कोटा समाप्त)."
                500, 502, 503 -> "Provider server temporarily unavailable (सर्वर व्यस्त है)."
                else -> "HTTP status $code"
            }
        }
    }

    private fun mapExceptionToMessage(e: Exception): String {
        val msg = e.message.orEmpty()
        return when {
            msg.contains("Failed to connect") || msg.contains("Unable to resolve host") ->
                "Network unavailable. Please check your internet connection (इंटरनेट कनेक्शन की जांच करें)."
            msg.contains("timeout", ignoreCase = true) ->
                "Connection timed out. Please retry (सर्वर टाइमआउट, कृपया पुनः प्रयास करें)."
            else -> msg
        }
    }
}
