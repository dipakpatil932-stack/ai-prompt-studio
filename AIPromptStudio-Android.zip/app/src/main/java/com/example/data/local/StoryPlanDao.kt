package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StoryPlanDao {
    @Query("SELECT * FROM story_plans ORDER BY timestamp DESC")
    fun getAllStories(): Flow<List<StoryPlanEntity>>

    @Query("SELECT * FROM story_plans WHERE id = :id")
    fun getStoryById(id: Long): Flow<StoryPlanEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryPlanEntity): Long

    @Update
    suspend fun updateStory(story: StoryPlanEntity)

    @Query("DELETE FROM story_plans WHERE id = :id")
    suspend fun deleteStoryById(id: Long)

    @Query("DELETE FROM story_plans")
    suspend fun clearAllStories()
}
