package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

class FreeVideoStoryGenerator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateStoryboard(
        storyIdea: String,
        language: String,
        aspectRatio: String,
        targetDurationSeconds: Int = 20
    ): FreeVideoProject = withContext(Dispatchers.IO) {
        val sceneCount = when {
            targetDurationSeconds <= 15 -> 4
            targetDurationSeconds <= 30 -> 6
            else -> 8
        }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY.takeIf { it.isNotBlank() && it != "MY_GEMINI_API_KEY" } ?: ""
        } catch (_: Throwable) { "" }

        if (apiKey.isNotBlank()) {
            try {
                val apiProject = callGeminiForStoryboard(apiKey, storyIdea, language, aspectRatio, sceneCount)
                if (apiProject != null && apiProject.scenes.isNotEmpty()) {
                    return@withContext apiProject
                }
            } catch (e: Exception) {
                Log.e("FreeVideoStoryGen", "Gemini API call failed, using local generator", e)
            }
        }

        // Local generator fallback for Hindi, Gujarati, or English
        return@withContext generateLocalStoryboard(storyIdea, language, aspectRatio, sceneCount)
    }

    private fun callGeminiForStoryboard(
        apiKey: String,
        storyIdea: String,
        language: String,
        aspectRatio: String,
        sceneCount: Int
    ): FreeVideoProject? {
        val systemPrompt = """
            You are a creative film director and storyboard artist.
            Turn the user's story into a $sceneCount-scene visual slideshow video storyboard.
            Language for title, captions, and narration MUST be strictly in: $language.
            
            Format: Output ONLY valid JSON matching this schema:
            {
              "title": "Short catchy title in $language",
              "scenes": [
                {
                  "sceneNumber": 1,
                  "title": "Scene 1 title in $language",
                  "caption": "1-2 short subtitle sentences in $language to show on screen",
                  "narrationText": "Spoken voiceover script in $language for this scene",
                  "imagePrompt": "Detailed 4K photorealistic prompt for AI image generator depicting the scene, specifying camera angle, lighting, Indian cultural details, and consistent character appearance in aspect ratio $aspectRatio",
                  "bgMusicDescription": "Suggested background instruments and ambience (e.g., Soft bansuri flute, Indian village morning birds)",
                  "durationSeconds": 4
                }
              ]
            }
        """.trimIndent()

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "$systemPrompt\n\nUser Story: $storyIdea")
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("responseMimeType", "application/json")
            })
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(requestBody.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body?.string().orEmpty()
            val root = JSONObject(body)
            val textContent = root.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")
                .orEmpty()

            if (textContent.isBlank()) return null

            val cleaned = textContent.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val parsedJson = JSONObject(cleaned)
            val title = parsedJson.optString("title", "My Video Story")
            val scenesArr = parsedJson.optJSONArray("scenes") ?: return null

            val scenes = mutableListOf<FreeVideoScene>()
            for (i in 0 until scenesArr.length()) {
                val scObj = scenesArr.optJSONObject(i) ?: continue
                scenes.add(
                    FreeVideoScene(
                        id = UUID.randomUUID().toString(),
                        sceneNumber = scObj.optInt("sceneNumber", i + 1),
                        title = scObj.optString("title", "Scene ${i + 1}"),
                        caption = scObj.optString("caption", ""),
                        narrationText = scObj.optString("narrationText", scObj.optString("caption", "")),
                        durationSeconds = scObj.optInt("durationSeconds", 4).coerceIn(2, 10),
                        imagePrompt = scObj.optString("imagePrompt", ""),
                        bgMusicDescription = scObj.optString("bgMusicDescription", "Traditional Indian ambient music")
                    )
                )
            }

            return FreeVideoProject(
                title = title,
                storyPrompt = storyIdea,
                language = language,
                aspectRatio = aspectRatio,
                scenes = scenes
            )
        }
    }

    private fun generateLocalStoryboard(
        storyIdea: String,
        language: String,
        aspectRatio: String,
        sceneCount: Int
    ): FreeVideoProject {
        val trimmed = storyIdea.trim().ifBlank { "A heartwarming village story" }

        val scenes = mutableListOf<FreeVideoScene>()

        when (language.lowercase()) {
            "gujarati", "ગુજરાતી" -> {
                val title = if (trimmed.contains("ગામ") || trimmed.contains("ખેડૂત")) {
                    "મહેનત અને સપનાં: એક ગામની સુંદર વાર્તા"
                } else {
                    "સુંદર વાર્તા: $trimmed"
                }

                val sceneTemplates = listOf(
                    Triple(
                        "શરૂઆત: શાંત સવાર",
                        "સૂર્યના પ્રથમ કિરણો સાથે ગામમાં નવી આશા જાગે છે.",
                        "ગોકુળિયું ગામ, શાંત સવારની તાજગી અને પંખીઓનો કલરવ."
                    ),
                    Triple(
                        "પાત્ર પરિચય: સંઘર્ષ અને લગન",
                        "પરિશ્રમ અને સાચા દિલથી કરેલા કામમાં જ સાચો આનંદ છે.",
                        "ખેતરમાં મહેનત કરતો ઉત્સાહી ખેડૂત, પરંપરાગત ગુજરાતી પહેરવેશ."
                    ),
                    Triple(
                        "સફળતા અને એકતા",
                        "બધા મળીને મુશ્કેલીઓનો સામનો કરે છે અને સફળ થાય છે.",
                        "ગામના લોકોનો સ્નેહ અને સહકાર, સાંજના સમયે મંદિરનો ઘંટારવ."
                    ),
                    Triple(
                        "સમાપન: ખુશીઓની ઉજવણી",
                        "સત્ય અને પ્રામાણિકતા હંમેશા જીવનમાં મીઠો રંગ ભરે છે.",
                        "ખુશીઓથી છલકાતું આંગણું, દીવાઓનો પ્રકાશ અને ઉત્સાહ."
                    ),
                    Triple(
                        "નવી પેઢી માટે સંદેશ",
                        "આપણી સંસ્કૃતિ અને સંસ્કારો જ આપણી સાચી ધરોહર છે.",
                        "વડીલોના આશીર્વાદ અને બાળકોનું નિર્દોષ હાસ્ય."
                    ),
                    Triple(
                        "અંતિમ ક્ષણ: આનંદ",
                        "જીવન એક સુંદર પ્રવાસ છે, સદાય હસતા રહો.",
                        "સોનેરી સાંજ, ગામની ભાગોળે શાંત વાતાવરણ."
                    )
                )

                for (i in 0 until sceneCount) {
                    val t = sceneTemplates[i % sceneTemplates.size]
                    scenes.add(
                        FreeVideoScene(
                            sceneNumber = i + 1,
                            title = t.first,
                            caption = t.second,
                            narrationText = "${t.first}: ${t.second}",
                            imagePrompt = "Cinematic Indian rural Gujarat landscape, ${t.third}, photorealistic 4k, warm golden morning light, highly detailed, $aspectRatio",
                            bgMusicDescription = "Warm Gujarati santur, bansuri flute and temple bells",
                            durationSeconds = 4
                        )
                    )
                }

                return FreeVideoProject(
                    title = title,
                    storyPrompt = storyIdea,
                    language = "Gujarati",
                    aspectRatio = aspectRatio,
                    scenes = scenes
                )
            }
            "english" -> {
                val title = "The Journey of Hope: $trimmed"
                val sceneTemplates = listOf(
                    Triple(
                        "The Beginning",
                        "In a quiet landscape, a new dawn brings promise and hope.",
                        "Golden morning mist over countryside, peaceful sunrise, ultra-realistic."
                    ),
                    Triple(
                        "The Determination",
                        "Hard work and perseverance guide the path forward every single day.",
                        "Heroic character focused in authentic setting, dramatic sunlight, 35mm lens."
                    ),
                    Triple(
                        "Overcoming Challenges",
                        "When facing the storm, unity and courage make all the difference.",
                        "Dynamic atmosphere, cinematic rain clearing, vibrant natural lighting."
                    ),
                    Triple(
                        "Celebration and Triumph",
                        "Together, they celebrate the harvest of dreams and friendship.",
                        "Joyful gathering, warm festival lanterns, smiling faces, 4K resolution."
                    ),
                    Triple(
                        "A New Tomorrow",
                        "Every fulfilled dream plants seeds for the future generation.",
                        "Vast horizon, peaceful sunset glow, inspirational atmosphere."
                    ),
                    Triple(
                        "Final Reflection",
                        "Belief in oneself turns every struggle into a masterpiece.",
                        "Serene evening ambience, soft cinematic bokeh, peaceful."
                    )
                )

                for (i in 0 until sceneCount) {
                    val t = sceneTemplates[i % sceneTemplates.size]
                    scenes.add(
                        FreeVideoScene(
                            sceneNumber = i + 1,
                            title = t.first,
                            caption = t.second,
                            narrationText = "${t.first}: ${t.second}",
                            imagePrompt = "${t.third}, cinematic framing, realistic textures, vibrant natural colors, aspect ratio $aspectRatio",
                            bgMusicDescription = "Inspiring acoustic guitar and soft ambient strings",
                            durationSeconds = 4
                        )
                    )
                }

                return FreeVideoProject(
                    title = title,
                    storyPrompt = storyIdea,
                    language = "English",
                    aspectRatio = aspectRatio,
                    scenes = scenes
                )
            }
            else -> { // Default Hindi
                val title = if (trimmed.contains("गांव") || trimmed.contains("किसान")) {
                    "गांव की माटी: एक प्रेरणादायक कहानी"
                } else {
                    "एक अनोखी कहानी: $trimmed"
                }

                val sceneTemplates = listOf(
                    Triple(
                        "दृश्य 1: सुबह की नई किरण",
                        "सूरज की पहली किरण के साथ गांव में एक नई उम्मीद जागती है।",
                        "भारतीय गांव की शांत सुबह, चूल्हे से उठता हल्का धुआं, पक्षियों की चहचहाहट, सुनहरी धूप।"
                    ),
                    Triple(
                        "दृश्य 2: मेहनत और संकल्प",
                        "सच्ची लगन और परिश्रम से ही हर कठिन रास्ता आसान बनता है।",
                        "खेत में कर्मठता से काम करता भारतीय ग्रामीण, धोती-कुर्ता, यथार्थवादी भाव, 4K।"
                    ),
                    Triple(
                        "दृश्य 3: संघर्ष का सामना",
                        "जब मुश्किलें सामने आईं, तो पूरे परिवार ने एक-दूसरे का हाथ थाम लिया।",
                        "परिवार की एकता, आंगन में साथ बैठे लोग, शाम की चौपाल, भावनात्मक प्रकाश।"
                    ),
                    Triple(
                        "दृश्य 4: खुशियों की बहार",
                        "मेहनत रंग लाई और चारों तरफ खुशियों का माहौल छा गया।",
                        "गांव का उत्सव, रंग-बिरंगे पारंपरिक वस्त्र, मुस्कराते चेहरे, दीयों की रोशनी।"
                    ),
                    Triple(
                        "दृश्य 5: सफलता की प्रेरणा",
                        "यह सिर्फ एक जीत नहीं, आने वाली पीढ़ियों के लिए एक सीख थी।",
                        "बुजुर्ग का आशीर्वाद, बच्चों का उत्साह, प्राकृतिक सौंदर्य, भारतीय परिवेश।"
                    ),
                    Triple(
                        "दृश्य 6: सुंदर समापन",
                        "सपने उन्हीं के सच होते हैं जो उम्मीद का दामन नहीं छोड़ते।",
                        "डूबते सूरज की लालिमा, पीपल की छांव, मधुर बांसुरी की धुन, सिनेमाई अंत।"
                    )
                )

                for (i in 0 until sceneCount) {
                    val t = sceneTemplates[i % sceneTemplates.size]
                    scenes.add(
                        FreeVideoScene(
                            sceneNumber = i + 1,
                            title = t.first,
                            caption = t.second,
                            narrationText = "${t.first}: ${t.second}",
                            imagePrompt = "Photorealistic Indian cinematic style, ${t.third}, 35mm anamorphic lens, realistic skin texture, authentic lighting, $aspectRatio",
                            bgMusicDescription = "Soothing Indian bansuri flute, tanpura, and gentle tabla rhythm",
                            durationSeconds = 4
                        )
                    )
                }

                return FreeVideoProject(
                    title = title,
                    storyPrompt = storyIdea,
                    language = "Hindi",
                    aspectRatio = aspectRatio,
                    scenes = scenes
                )
            }
        }
    }
}
