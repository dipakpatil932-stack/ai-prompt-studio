package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus

@Entity(tableName = "video_jobs")
data class VideoJobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobId: String,
    val prompt: String,
    val style: String,
    val aspectRatio: String,
    val duration: String,
    val dialogueLanguage: String,
    val provider: String,
    val status: String,
    val progressPercent: Int,
    val statusMessage: String,
    val videoUrl: String?,
    val localVideoPath: String?,
    val errorMessage: String?,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): VideoJob = VideoJob(
        id = id,
        jobId = jobId,
        prompt = prompt,
        style = style,
        aspectRatio = aspectRatio,
        duration = duration,
        dialogueLanguage = dialogueLanguage,
        provider = provider,
        status = runCatching { VideoJobStatus.valueOf(status) }.getOrDefault(VideoJobStatus.IDLE),
        progressPercent = progressPercent,
        statusMessage = statusMessage,
        videoUrl = videoUrl,
        localVideoPath = localVideoPath,
        errorMessage = errorMessage,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomain(domain: VideoJob): VideoJobEntity = VideoJobEntity(
            id = domain.id,
            jobId = domain.jobId,
            prompt = domain.prompt,
            style = domain.style,
            aspectRatio = domain.aspectRatio,
            duration = domain.duration,
            dialogueLanguage = domain.dialogueLanguage,
            provider = domain.provider,
            status = domain.status.name,
            progressPercent = domain.progressPercent,
            statusMessage = domain.statusMessage,
            videoUrl = domain.videoUrl,
            localVideoPath = domain.localVideoPath,
            errorMessage = domain.errorMessage,
            createdAt = domain.createdAt,
            updatedAt = domain.updatedAt
        )
    }
}
