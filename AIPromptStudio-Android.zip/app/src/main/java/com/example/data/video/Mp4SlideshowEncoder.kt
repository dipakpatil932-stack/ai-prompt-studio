package com.example.data.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import android.view.Surface
import com.example.data.model.FreeVideoScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CancellationException

class Mp4SlideshowEncoder(private val context: Context) {

    companion object {
        private const val TAG = "Mp4SlideshowEncoder"
        private const val MIME_TYPE = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val FRAME_RATE = 25
        private const val I_FRAME_INTERVAL = 1
        private const val TIMEOUT_USEC = 10_000L
    }

    suspend fun encodeSlideshow(
        scenes: List<FreeVideoScene>,
        aspectRatio: String,
        outputFile: File,
        audioUri: Uri? = null,
        masterAudioFile: File? = null,
        onProgress: (progress: Float, message: String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        if (scenes.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No scenes available to create video."))
        }

        val (videoWidth, videoHeight) = when (aspectRatio) {
            "16:9" -> 1280 to 720
            "1:1" -> 720 to 720
            else -> 720 to 1280 // Standard 9:16 vertical
        }

        var mediaCodec: MediaCodec? = null
        var mediaMuxer: MediaMuxer? = null
        var eglHelper: CodecEglHelper? = null
        var audioExtractor: MediaExtractor? = null
        var tempM4aFile: File? = null

        val hasMasterAudio = masterAudioFile != null && masterAudioFile.exists() && masterAudioFile.length() > 44
        val expectAudio = hasMasterAudio || audioUri != null

        try {
            onProgress(0.05f, "Preparing audio & video engine (ऑडियो व वीडियो इंजन तैयार हो रहा है)...")

            // 1. Prepare output directory
            outputFile.parentFile?.mkdirs()
            if (outputFile.exists()) outputFile.delete()

            // 2. Prepare audio source if available
            var audioFormat: MediaFormat? = null
            var audioTrackInExtractor = -1

            if (masterAudioFile != null && hasMasterAudio) {
                onProgress(0.08f, "Transcoding narration audio (वॉइसओवर एन्कोड किया जा रहा है)...")
                val aacEncoder = com.example.data.audio.AacAudioEncoder()
                val tempM4a = File(context.cacheDir, "story_audio_${System.currentTimeMillis()}.m4a")
                val transcodeSuccess = aacEncoder.transcodeWavToM4a(masterAudioFile, tempM4a)
                if (transcodeSuccess && tempM4a.exists() && tempM4a.length() > 0) {
                    tempM4aFile = tempM4a
                    Log.i(TAG, "Master narration transcoded to M4A: ${tempM4a.absolutePath} (${tempM4a.length()} bytes)")
                    try {
                        val extractor = MediaExtractor()
                        extractor.setDataSource(tempM4a.absolutePath)
                        for (i in 0 until extractor.trackCount) {
                            val fmt = extractor.getTrackFormat(i)
                            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                            if (mime.startsWith("audio/")) {
                                audioFormat = fmt
                                audioTrackInExtractor = i
                                extractor.selectTrack(i)
                                audioExtractor = extractor
                                Log.i(TAG, "Audio track selected from M4A: $mime, channels=${fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT, 1)}")
                                break
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to inspect transcoded M4A with extractor", e)
                    }
                } else {
                    Log.w(TAG, "Master audio transcode failed; proceeding with fallback")
                }
            } else if (audioUri != null) {
                onProgress(0.08f, "Reading background music (संगीत ट्रैक लोड हो रहा है)...")
                try {
                    val extractor = MediaExtractor()
                    extractor.setDataSource(context, audioUri, null)
                    for (i in 0 until extractor.trackCount) {
                        val fmt = extractor.getTrackFormat(i)
                        val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("audio/")) {
                            audioFormat = fmt
                            audioTrackInExtractor = i
                            extractor.selectTrack(i)
                            audioExtractor = extractor
                            Log.i(TAG, "Audio track selected from Uri: $mime")
                            break
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to inspect audioUri with extractor: ${e.message}")
                }
            }

            // 3. Configure Video MediaFormat
            val bitRate = when {
                videoWidth * videoHeight >= 1280 * 720 -> 3_500_000
                else -> 2_500_000
            }

            val videoFormat = MediaFormat.createVideoFormat(MIME_TYPE, videoWidth, videoHeight).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL)
            }

            mediaCodec = MediaCodec.createEncoderByType(MIME_TYPE)
            mediaCodec.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = mediaCodec.createInputSurface()
            mediaCodec.start()

            // 4. Initialize EGL surface on encoder input surface
            eglHelper = CodecEglHelper(inputSurface)
            eglHelper.makeCurrent()

            // 5. Initialize GL Texture Renderer
            val textureRenderer = TextureRenderer()
            textureRenderer.surfaceCreated()

            // 6. Initialize MediaMuxer
            mediaMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var audioTrackIndexInMuxer = -1
            var muxerStarted = false

            val bufferInfo = MediaCodec.BufferInfo()
            var globalFrameIndex = 0L

            // Calculate total frames
            val totalFrames = scenes.sumOf { it.durationSeconds.coerceIn(3, 30) * FRAME_RATE }

            // 7. Loop through each scene and render frames
            for ((sceneIndex, scene) in scenes.withIndex()) {
                val sceneMsg = "Rendering Scene ${sceneIndex + 1} of ${scenes.size} (${scene.title.ifBlank { "Scene" }})..."
                val baseProgress = 0.1f + (sceneIndex.toFloat() / scenes.size.toFloat()) * 0.75f
                onProgress(baseProgress, sceneMsg)

                // Generate composite frame bitmap for this scene
                val sceneBitmap = createSceneBitmap(scene, videoWidth, videoHeight)

                // Load bitmap into OpenGL texture
                val textureId = textureRenderer.loadBitmap(sceneBitmap)

                val sceneDurationFrames = scene.durationSeconds.coerceIn(3, 30) * FRAME_RATE

                for (frame in 0 until sceneDurationFrames) {
                    // Check drain output before writing
                    val drainResult = drainEncoder(
                        mediaCodec = mediaCodec,
                        mediaMuxer = mediaMuxer,
                        bufferInfo = bufferInfo,
                        endOfStream = false,
                        videoTrackIndex = videoTrackIndex,
                        audioTrackIndex = audioTrackIndexInMuxer,
                        audioFormat = audioFormat,
                        muxerStarted = muxerStarted
                    )
                    videoTrackIndex = drainResult.first
                    audioTrackIndexInMuxer = drainResult.second
                    muxerStarted = drainResult.third

                    // Render texture onto EGL surface
                    textureRenderer.drawFrame(videoWidth, videoHeight, textureId)

                    // Presentation time in nanoseconds
                    val ptsNanos = globalFrameIndex * (1_000_000_000L / FRAME_RATE)
                    eglHelper.setPresentationTime(ptsNanos)
                    eglHelper.swapBuffers()

                    globalFrameIndex++
                }

                // Delete texture after scene finishes
                textureRenderer.deleteTexture(textureId)
                sceneBitmap.recycle()
            }

            // 8. Signal End Of Stream to MediaCodec
            onProgress(0.88f, "Finalizing video frames (फ्रेम तैयार किए जा रहे हैं)...")
            mediaCodec.signalEndOfInputStream()

            // Drain remaining buffers until EOS
            val finalDrain = drainEncoder(
                mediaCodec = mediaCodec,
                mediaMuxer = mediaMuxer,
                bufferInfo = bufferInfo,
                endOfStream = true,
                videoTrackIndex = videoTrackIndex,
                audioTrackIndex = audioTrackIndexInMuxer,
                audioFormat = audioFormat,
                muxerStarted = muxerStarted
            )
            videoTrackIndex = finalDrain.first
            audioTrackIndexInMuxer = finalDrain.second
            muxerStarted = finalDrain.third

            // 9. Mux Audio track samples into the active muxer
            if (audioTrackIndexInMuxer != -1 && audioExtractor != null && muxerStarted) {
                onProgress(0.94f, "Writing audio track into video (ऑडियो ट्रैक जोड़ा जा रहा है)...")
                try {
                    val maxBufferSize = if (audioFormat?.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE) == true) {
                        audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                    } else 64 * 1024

                    val dstBuf = ByteBuffer.allocate(maxBufferSize)
                    val audioBufferInfo = MediaCodec.BufferInfo()
                    var audioSamplesCount = 0

                    while (true) {
                        audioBufferInfo.offset = 0
                        audioBufferInfo.size = audioExtractor.readSampleData(dstBuf, 0)
                        if (audioBufferInfo.size < 0) break

                        audioBufferInfo.presentationTimeUs = audioExtractor.sampleTime
                        audioBufferInfo.flags = audioExtractor.sampleFlags
                        mediaMuxer.writeSampleData(audioTrackIndexInMuxer, dstBuf, audioBufferInfo)
                        audioExtractor.advance()
                        audioSamplesCount++
                    }
                    Log.i(TAG, "Muxed $audioSamplesCount audio packets into track $audioTrackIndexInMuxer")
                } catch (e: Exception) {
                    Log.e(TAG, "Audio sample writing error: ${e.message}", e)
                }
            }

            // Stop and release muxer cleanly
            try {
                mediaMuxer.stop()
            } catch (e: Exception) {
                Log.w(TAG, "MediaMuxer stop warning: ${e.message}")
            }
            try {
                mediaMuxer.release()
                mediaMuxer = null
            } catch (_: Exception) {}

            // 10. Post-export audio & video verification
            val retriever = android.media.MediaMetadataRetriever()
            try {
                retriever.setDataSource(outputFile.absolutePath)
                val hasAudioMeta = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
                val hasVideoMeta = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
                val durationMsMeta = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                Log.i(TAG, "Exported MP4 verification: hasVideo=$hasVideoMeta, hasAudio=$hasAudioMeta, duration=${durationMsMeta}ms, size=${outputFile.length()} bytes")

                if (expectAudio && hasAudioMeta != "yes") {
                    throw IllegalStateException("Video exported but failed to include audio track. Verification failed.")
                }
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }

            onProgress(1.0f, "Video ready with sound! (आवाज़ के साथ वीडियो तैयार है)")
            return@withContext Result.success(outputFile)

        } catch (e: CancellationException) {
            outputFile.delete()
            return@withContext Result.failure(Exception("Video creation cancelled (वीडियो निर्माण रद्द किया गया)."))
        } catch (e: Exception) {
            Log.e(TAG, "Video encoding failed", e)
            outputFile.delete()
            return@withContext Result.failure(Exception("Video encoding failed: ${e.message ?: "Unknown error"}", e))
        } finally {
            try { tempM4aFile?.delete() } catch (_: Exception) {}
            try { audioExtractor?.release() } catch (_: Exception) {}
            try { mediaCodec?.stop() } catch (_: Exception) {}
            try { mediaCodec?.release() } catch (_: Exception) {}
            try { eglHelper?.release() } catch (_: Exception) {}
            try { mediaMuxer?.stop() } catch (_: Exception) {}
            try { mediaMuxer?.release() } catch (_: Exception) {}
        }
    }

    private fun drainEncoder(
        mediaCodec: MediaCodec,
        mediaMuxer: MediaMuxer?,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        videoTrackIndex: Int,
        audioTrackIndex: Int,
        audioFormat: MediaFormat?,
        muxerStarted: Boolean
    ): Triple<Int, Int, Boolean> {
        var currentVideoTrack = videoTrackIndex
        var currentAudioTrack = audioTrackIndex
        var isMuxerStarted = muxerStarted

        while (true) {
            val encoderStatus = mediaCodec.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC)
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (isMuxerStarted) {
                    throw IllegalStateException("Output format changed after muxer started")
                }
                val newVideoFormat = mediaCodec.outputFormat
                if (mediaMuxer != null) {
                    currentVideoTrack = mediaMuxer.addTrack(newVideoFormat)
                    Log.i(TAG, "Added video track to muxer at index $currentVideoTrack: $newVideoFormat")

                    // CRITICAL FIX: Add audio track BEFORE calling mediaMuxer.start()!
                    if (audioFormat != null) {
                        try {
                            currentAudioTrack = mediaMuxer.addTrack(audioFormat)
                            Log.i(TAG, "Added audio track to muxer at index $currentAudioTrack: $audioFormat")
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to add audio track to muxer: ${e.message}", e)
                        }
                    }

                    mediaMuxer.start()
                    isMuxerStarted = true
                    Log.i(TAG, "MediaMuxer started with videoTrack=$currentVideoTrack, audioTrack=$currentAudioTrack")
                }
            } else if (encoderStatus < 0) {
                // Ignore unexpected status code
            } else {
                val encodedData = mediaCodec.getOutputBuffer(encoderStatus)
                    ?: throw RuntimeException("Encoder output buffer $encoderStatus was null")

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    bufferInfo.size = 0
                }

                if (bufferInfo.size != 0) {
                    if (!isMuxerStarted) {
                        throw RuntimeException("Muxer has not started yet")
                    }
                    encodedData.position(bufferInfo.offset)
                    encodedData.limit(bufferInfo.offset + bufferInfo.size)
                    mediaMuxer?.writeSampleData(currentVideoTrack, encodedData, bufferInfo)
                }

                mediaCodec.releaseOutputBuffer(encoderStatus, false)

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break
                }
            }
        }

        return Triple(currentVideoTrack, currentAudioTrack, isMuxerStarted)
    }

    /**
     * Creates a high-resolution composite Bitmap with photo/artwork and clean captions.
     */
    private fun createSceneBitmap(scene: FreeVideoScene, width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        var photoLoaded = false
        if (!scene.imageUri.isNullOrBlank()) {
            try {
                val uri = Uri.parse(scene.imageUri)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val userPhoto = decodeSampledBitmap(stream, width, height)
                    if (userPhoto != null) {
                        drawCenterCrop(canvas, userPhoto, width, height)
                        photoLoaded = true
                        userPhoto.recycle()
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to load user image ${scene.imageUri}: ${e.message}")
            }
        }

        // If no user photo was loaded, paint an elegant Indian cinematic backdrop
        if (!photoLoaded) {
            val sceneNumber = scene.sceneNumber
            val gradients = listOf(
                intArrayOf(Color.parseColor("#B45309"), Color.parseColor("#1E1B4B")), // Saffron to Midnight
                intArrayOf(Color.parseColor("#1D4ED8"), Color.parseColor("#0F172A")), // Deep Royal Blue
                intArrayOf(Color.parseColor("#047857"), Color.parseColor("#064E3B")), // Forest Emerald
                intArrayOf(Color.parseColor("#7C2D12"), Color.parseColor("#450A0A")), // Sunset Amber
                intArrayOf(Color.parseColor("#6B21A8"), Color.parseColor("#18181B"))  // Velvet Purple
            )
            val colors = gradients[(sceneNumber - 1) % gradients.size]
            val bgPaint = Paint().apply {
                shader = LinearGradient(0f, 0f, 0f, height.toFloat(), colors[0], colors[1], Shader.TileMode.CLAMP)
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

            // Draw artistic motif circles
            val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                alpha = 25
                style = Paint.Style.STROKE
                strokeWidth = 4f
            }
            canvas.drawCircle(width / 2f, height * 0.35f, width * 0.28f, circlePaint)
            canvas.drawCircle(width / 2f, height * 0.35f, width * 0.20f, circlePaint)

            // Draw central icon/text
            val motifPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                alpha = 220
                textSize = width * 0.08f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("🎬 SCENE ${scene.sceneNumber}", width / 2f, height * 0.36f, motifPaint)
        }

        // Draw dark gradient scrim at the bottom for crystal-clear caption contrast
        val scrimPaint = Paint().apply {
            shader = LinearGradient(
                0f, height * 0.55f, 0f, height.toFloat(),
                Color.TRANSPARENT, Color.argb(230, 0, 0, 0),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, height * 0.55f, width.toFloat(), height.toFloat(), scrimPaint)

        // Draw Top Badge: "Scene X • AI Prompt Studio"
        val topBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(170, 0, 0, 0)
        }
        val topBadgeRect = RectF(24f, 24f, (width * 0.55f), 76f)
        canvas.drawRoundRect(topBadgeRect, 16f, 16f, topBadgePaint)

        val topTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("⭐ SCENE ${scene.sceneNumber} / FREE MAKER", 42f, 58f, topTextPaint)

        // Draw Caption & Title
        val captionText = scene.caption.ifBlank { scene.narrationText.ifBlank { scene.title } }
        val titleText = scene.title.ifBlank { "Scene ${scene.sceneNumber}" }

        // Draw Scene Title
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FBBF24") // Warm golden amber
            textSize = (width * 0.046f).coerceIn(28f, 44f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(6f, 0f, 3f, Color.BLACK)
        }
        canvas.drawText(titleText, 32f, height * 0.75f, titlePaint)

        // Draw Caption multiline using StaticLayout
        val captionPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = (width * 0.040f).coerceIn(24f, 36f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            setShadowLayer(8f, 0f, 4f, Color.BLACK)
        }

        val textWidth = (width - 64).coerceAtLeast(100)
        val staticLayout = StaticLayout.Builder.obtain(
            captionText, 0, captionText.length, captionPaint, textWidth
        ).setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(4f, 1.15f)
            .build()

        canvas.save()
        canvas.translate(32f, height * 0.79f)
        staticLayout.draw(canvas)
        canvas.restore()

        return bitmap
    }

    private fun drawCenterCrop(canvas: Canvas, bitmap: Bitmap, targetW: Int, targetH: Int) {
        val srcW = bitmap.width.toFloat()
        val srcH = bitmap.height.toFloat()

        val scale = maxOf(targetW / srcW, targetH / srcH)
        val scaledW = srcW * scale
        val scaledH = srcH * scale

        val left = (targetW - scaledW) / 2f
        val top = (targetH - scaledH) / 2f

        val destRect = RectF(left, top, left + scaledW, top + scaledH)
        canvas.drawBitmap(bitmap, null, destRect, null)
    }

    private fun decodeSampledBitmap(stream: InputStream, reqWidth: Int, reqHeight: Int): Bitmap? {
        val bytes = stream.readBytes()
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)

        var inSampleSize = 1
        if (options.outHeight > reqHeight || options.outWidth > reqWidth) {
            val halfHeight = options.outHeight / 2
            val halfWidth = options.outWidth / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions)
    }

    private fun muxAudioTrack(context: Context, audioUri: Uri, mediaMuxer: MediaMuxer) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, audioUri, null)
            val numTracks = extractor.trackCount
            var audioTrackIndex = -1
            for (i in 0 until numTracks) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    val newAudioTrack = mediaMuxer.addTrack(format)
                    extractor.selectTrack(audioTrackIndex)

                    val maxBufferSize = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                    } else 64 * 1024

                    val dstBuf = ByteBuffer.allocate(maxBufferSize)
                    val bufferInfo = MediaCodec.BufferInfo()

                    while (true) {
                        bufferInfo.offset = 0
                        bufferInfo.size = extractor.readSampleData(dstBuf, 0)
                        if (bufferInfo.size < 0) break

                        bufferInfo.presentationTimeUs = extractor.sampleTime
                        bufferInfo.flags = extractor.sampleFlags
                        mediaMuxer.writeSampleData(newAudioTrack, dstBuf, bufferInfo)
                        extractor.advance()
                    }
                    break
                }
            }
        } finally {
            extractor.release()
        }
    }
}

/**
 * Manages EGL14 context connected to MediaCodec's input surface.
 */
class CodecEglHelper(private val surface: Surface) {
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    init {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (eglDisplay === EGL14.EGL_NO_DISPLAY) {
            throw RuntimeException("Unable to get EGL14 display")
        }

        val version = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
            eglDisplay = EGL14.EGL_NO_DISPLAY
            throw RuntimeException("Unable to initialize EGL14")
        }

        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )

        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        if (!EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, configs.size, numConfigs, 0)) {
            throw RuntimeException("Unable to find suitable EGLConfig for video surface")
        }

        val contextAttribs = intArrayOf(
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
        )

        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
        if (eglContext === EGL14.EGL_NO_CONTEXT) {
            throw RuntimeException("Failed to create EGL context")
        }

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], surface, surfaceAttribs, 0)
        if (eglSurface === EGL14.EGL_NO_SURFACE) {
            throw RuntimeException("Failed to create EGL window surface")
        }
    }

    fun makeCurrent() {
        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            throw RuntimeException("eglMakeCurrent failed")
        }
    }

    fun setPresentationTime(nsecs: Long) {
        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, nsecs)
    }

    fun swapBuffers(): Boolean {
        return EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun release() {
        if (eglDisplay !== EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(eglDisplay, eglSurface)
            EGL14.eglDestroyContext(eglDisplay, eglContext)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(eglDisplay)
        }
        surface.release()
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }
}

/**
 * Simple OpenGL ES 2.0 full-screen textured quad renderer.
 */
class TextureRenderer {

    private val vertexShaderSource = """
        attribute vec4 aPosition;
        attribute vec2 aTextureCoord;
        varying vec2 vTextureCoord;
        void main() {
            gl_Position = aPosition;
            vTextureCoord = aTextureCoord;
        }
    """.trimIndent()

    private val fragmentShaderSource = """
        precision mediump float;
        varying vec2 vTextureCoord;
        uniform sampler2D uTexture;
        void main() {
            gl_FragColor = texture2D(uTexture, vTextureCoord);
        }
    """.trimIndent()

    // Full screen quad in normalized device coordinates
    private val triangleVerticesData = floatArrayOf(
        -1.0f, -1.0f, 0.0f, 0.0f, 1.0f,
         1.0f, -1.0f, 0.0f, 1.0f, 1.0f,
        -1.0f,  1.0f, 0.0f, 0.0f, 0.0f,
         1.0f,  1.0f, 0.0f, 1.0f, 0.0f
    )

    private val triangleVertices: FloatBuffer = ByteBuffer.allocateDirect(triangleVerticesData.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(triangleVerticesData)
            position(0)
        }

    private var program = 0
    private var aPositionHandle = 0
    private var aTextureCoordHandle = 0
    private var uTextureHandle = 0

    fun surfaceCreated() {
        program = createProgram(vertexShaderSource, fragmentShaderSource)
        if (program == 0) throw RuntimeException("Failed to create GL shader program")

        aPositionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        aTextureCoordHandle = GLES20.glGetAttribLocation(program, "aTextureCoord")
        uTextureHandle = GLES20.glGetUniformLocation(program, "uTexture")
    }

    fun loadBitmap(bitmap: Bitmap): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        val textureId = textures[0]

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        return textureId
    }

    fun drawFrame(width: Int, height: Int, textureId: Int) {
        GLES20.glViewport(0, 0, width, height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        GLES20.glUseProgram(program)

        triangleVertices.position(0)
        GLES20.glVertexAttribPointer(aPositionHandle, 3, GLES20.GL_FLOAT, false, 5 * 4, triangleVertices)
        GLES20.glEnableVertexAttribArray(aPositionHandle)

        triangleVertices.position(3)
        GLES20.glVertexAttribPointer(aTextureCoordHandle, 2, GLES20.GL_FLOAT, false, 5 * 4, triangleVertices)
        GLES20.glEnableVertexAttribArray(aTextureCoordHandle)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glUniform1i(uTextureHandle, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPositionHandle)
        GLES20.glDisableVertexAttribArray(aTextureCoordHandle)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0)
    }

    fun deleteTexture(textureId: Int) {
        if (textureId > 0) {
            GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
        }
    }

    private fun loadShader(shaderType: Int, source: String): Int {
        val shader = GLES20.glCreateShader(shaderType)
        if (shader != 0) {
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val compiled = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
            if (compiled[0] == 0) {
                val info = GLES20.glGetShaderInfoLog(shader)
                GLES20.glDeleteShader(shader)
                throw RuntimeException("Could not compile shader $shaderType: $info")
            }
        }
        return shader
    }

    private fun createProgram(vertexSource: String, fragmentSource: String): Int {
        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val pixelShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)

        val program = GLES20.glCreateProgram()
        if (program != 0) {
            GLES20.glAttachShader(program, vertexShader)
            GLES20.glAttachShader(program, pixelShader)
            GLES20.glLinkProgram(program)
            val linkStatus = IntArray(1)
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] != GLES20.GL_TRUE) {
                val info = GLES20.glGetProgramInfoLog(program)
                GLES20.glDeleteProgram(program)
                throw RuntimeException("Could not link GL program: $info")
            }
        }
        return program
    }
}
