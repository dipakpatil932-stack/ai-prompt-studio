package com.example.data.model

import java.util.UUID

/**
 * Story emotion mood presets for TTS voice expression & music style.
 */
enum class StoryEmotion(
    val id: String,
    val displayName: String,
    val hindiName: String,
    val speechRate: Float,
    val pitch: Float,
    val defaultMusicDesc: String
) {
    HAPPY("happy", "Happy (आनंदमय)", "खुशहाल / उत्सव", 1.05f, 1.15f, "Upbeat joyful Indian acoustic, cheerful sitar & festive rhythm"),
    SAD("sad", "Sad (भावुक)", "भावुक / मार्मिक", 0.85f, 0.90f, "Gentle melancholy bansuri flute and soft emotional strings"),
    MOTIVATIONAL("motivational", "Motivational (प्रेरणादायक)", "जोशीला / प्रेरणा", 1.08f, 1.05f, "Inspiring energetic cinematic build, dholak beat & uplifting brass"),
    HORROR("horror", "Suspense / Horror (रहस्यमयी)", "रहस्यमयी / डर", 0.82f, 0.85f, "Eerie dark ambient drone, ticking clock & suspense strings"),
    DEVOTIONAL("devotional", "Devotional (भक्तिमय)", "शांत / भक्ति", 0.90f, 0.95f, "Calm spiritual tanpura, sacred harmonium & morning temple bells"),
    COMEDY("comedy", "Comedy (हास्यपद)", "मज़ेदार / हास्य", 1.12f, 1.20f, "Playful quirky bounce, funny tabla accents & lively rhythm");

    companion object {
        fun fromId(id: String): StoryEmotion = entries.find { it.id.equals(id, ignoreCase = true) } ?: MOTIVATIONAL

        fun detectEmotion(storyText: String): StoryEmotion {
            val lower = storyText.lowercase()
            return when {
                lower.contains("भगवान") || lower.contains("मंदिर") || lower.contains("पूजा") || lower.contains("प्रार्थना") ||
                        lower.contains("god") || lower.contains("devotion") || lower.contains("prayer") || lower.contains("ભગવાન") || lower.contains("મંદિર") -> DEVOTIONAL
                lower.contains("भूत") || lower.contains("डर") || lower.contains("अंधेरा") || lower.contains("चीख") ||
                        lower.contains("horror") || lower.contains("fear") || lower.contains("ghost") || lower.contains("scary") || lower.contains("ભય") || lower.contains("ડર") -> HORROR
                lower.contains("हँसी") || lower.contains("मज़ाक") || lower.contains("जोक") || lower.contains("हंस") ||
                        lower.contains("funny") || lower.contains("comedy") || lower.contains("laugh") || lower.contains("રમુજી") || lower.contains("મજાક") -> COMEDY
                lower.contains("रोया") || lower.contains("दुख") || lower.contains("आंसू") || lower.contains("गम") ||
                        lower.contains("sad") || lower.contains("cry") || lower.contains("tears") || lower.contains("દુઃખ") || lower.contains("આંસુ") -> SAD
                lower.contains("खुशी") || lower.contains("जीत") || lower.contains("उत्सव") || lower.contains("नाच") ||
                        lower.contains("happy") || lower.contains("joy") || lower.contains("celebration") || lower.contains("આનંદ") || lower.contains("ઉત્સવ") -> HAPPY
                else -> MOTIVATIONAL
            }
        }
    }
}

/**
 * Voice Gender choice for TTS synthesis.
 */
enum class VoiceGender(val displayName: String) {
    FEMALE("Female (महिला)"),
    MALE("Male (पुरुष)")
}

/**
 * Data model for an individual scene in the Free Video Maker.
 */
data class FreeVideoScene(
    val id: String = UUID.randomUUID().toString(),
    val sceneNumber: Int,
    val title: String = "",
    val caption: String = "",
    val narrationText: String = "",
    val imageUri: String? = null,
    val durationSeconds: Int = 4,
    val imagePrompt: String = "",
    val bgMusicDescription: String = "",
    // Voiceover narration audio file generated via Android TTS
    val narrationAudioPath: String? = null,
    val calculatedAudioDurationMs: Long = 0L,
    val isTtsGenerating: Boolean = false
)

/**
 * Complete project state for a Free Video Maker creation.
 */
data class FreeVideoProject(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "My Story Video",
    val storyPrompt: String = "",
    val language: String = "Hindi", // "Hindi", "Gujarati", "English"
    val aspectRatio: String = "9:16", // "9:16", "16:9", "1:1"
    val scenes: List<FreeVideoScene> = emptyList(),
    val audioUri: String? = null, // Background music URI from phone
    val bgMusicName: String? = null,
    val isMusicMuted: Boolean = false,
    val emotion: StoryEmotion = StoryEmotion.MOTIVATIONAL,
    val voiceGender: VoiceGender = VoiceGender.FEMALE,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val isAutoVoiceEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

enum class FreeVideoStep {
    STORY_INPUT,
    SCENE_EDITOR,
    EXPORTING,
    RESULT
}
