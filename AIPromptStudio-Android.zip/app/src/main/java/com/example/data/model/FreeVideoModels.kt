package com.example.data.model

import java.util.UUID

/**
 * Data model for an individual scene in the Free Video Maker.
 */
data class FreeVideoScene(
    val id: String = UUID.randomUUID().toString(),
    val sceneNumber: Int,
    val title: String = "",
    val caption: String = "",
    val narrationText: String = "",
    val imageUri: String? = null,
    val durationSeconds: Int = 4,
    val imagePrompt: String = "",
    val bgMusicDescription: String = ""
)

/**
 * Complete project state for a Free Video Maker creation.
 */
data class FreeVideoProject(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "My Story Video",
    val storyPrompt: String = "",
    val language: String = "Hindi", // "Hindi", "Gujarati", "English"
    val aspectRatio: String = "9:16", // "9:16", "16:9", "1:1"
    val scenes: List<FreeVideoScene> = emptyList(),
    val audioUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

enum class FreeVideoStep {
    STORY_INPUT,
    SCENE_EDITOR,
    EXPORTING,
    RESULT
}
