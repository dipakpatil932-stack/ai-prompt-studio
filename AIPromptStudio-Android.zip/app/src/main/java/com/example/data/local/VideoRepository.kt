package com.example.data.local

import com.example.data.model.VideoJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class VideoRepository(private val videoJobDao: VideoJobDao) {

    val allVideoJobs: Flow<List<VideoJob>> = videoJobDao.getAllVideoJobs()
        .map { entities -> entities.map { it.toDomain() } }

    fun getVideoJobById(id: Long): Flow<VideoJob?> {
        return videoJobDao.getVideoJobById(id).map { it?.toDomain() }
    }

    suspend fun saveVideoJob(job: VideoJob): Long {
        val entity = VideoJobEntity.fromDomain(job)
        return videoJobDao.insertVideoJob(entity)
    }

    suspend fun updateVideoJob(job: VideoJob) {
        val entity = VideoJobEntity.fromDomain(job)
        videoJobDao.updateVideoJob(entity)
    }

    suspend fun deleteVideoJob(id: Long) {
        videoJobDao.deleteVideoJob(id)
    }
}
