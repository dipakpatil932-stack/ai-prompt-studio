package com.example.data.audio

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class AudioExportResult(
    val filePath: String,
    val mediaStoreUri: Uri?,
    val displayName: String,
    val formatExtension: String,
    val mimeType: String,
    val note: String
)

/**
 * Exports synthesized voiceover audio (.wav) into downloadable user audio files
 * saved cleanly in Music/AIPromptStudio via Android MediaStore.
 *
 * Checks hardware/OEM MediaCodec support for MP3 ("audio/mpeg"); if unavailable on the device,
 * encodes directly to universal MPEG-4 AAC Audio (.m4a) via AacAudioEncoder without fake containers.
 */
class AudioDownloadExporter(private val context: Context) {

    companion object {
        private const val TAG = "AudioDownloadExporter"
    }

    fun isDeviceMp3EncoderAvailable(): Boolean {
        return try {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            list.codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals("audio/mpeg", ignoreCase = true) }
            }
        } catch (_: Exception) {
            false
        }
    }

    fun exportVoiceAudio(
        sourceWavFile: File,
        preferredTitle: String = "Voiceover"
    ): Result<AudioExportResult> {
        if (!sourceWavFile.exists() || sourceWavFile.length() <= 44) {
            return Result.failure(IllegalArgumentException("Audio file is empty or missing. Please generate voice first."))
        }

        val safeTitle = preferredTitle.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(24).ifBlank { "Voice" }
        val stamp = System.currentTimeMillis()
        val exportCacheDir = File(context.filesDir, "exported_audio").apply { mkdirs() }

        // 1. Attempt native MP3 encoder if hardware/OEM provides audio/mpeg MediaCodec encoder
        if (isDeviceMp3EncoderAvailable()) {
            val mp3File = File(exportCacheDir, "${safeTitle}_$stamp.mp3")
            if (tryEncodeWavToMp3(sourceWavFile, mp3File) && mp3File.exists() && mp3File.length() > 128) {
                val uri = saveFileToMediaStore(mp3File, mp3File.name, "audio/mpeg")
                return Result.success(
                    AudioExportResult(
                        filePath = mp3File.absolutePath,
                        mediaStoreUri = uri,
                        displayName = mp3File.name,
                        formatExtension = "mp3",
                        mimeType = "audio/mpeg",
                        note = "Saved genuine MP3 audio to Music/AIPromptStudio/${mp3File.name}"
                    )
                )
            }
        }

        // 2. Standard Android hardware AAC M4A export (compatible with all players, WhatsApp, Reels, CapCut)
        val m4aFile = File(exportCacheDir, "${safeTitle}_$stamp.m4a")
        val aacSuccess = AacAudioEncoder().transcodeWavToM4a(sourceWavFile, m4aFile)
        if (aacSuccess && m4aFile.exists() && m4aFile.length() > 128) {
            val uri = saveFileToMediaStore(m4aFile, m4aFile.name, "audio/mp4")
            return Result.success(
                AudioExportResult(
                    filePath = m4aFile.absolutePath,
                    mediaStoreUri = uri,
                    displayName = m4aFile.name,
                    formatExtension = "m4a",
                    mimeType = "audio/mp4",
                    note = "Saved HD AAC Audio (.m4a) to Music/AIPromptStudio/${m4aFile.name} (compatible with all video & audio players)"
                )
            )
        }

        // 3. Lossless WAV fallback
        val wavCopy = File(exportCacheDir, "${safeTitle}_$stamp.wav")
        sourceWavFile.copyTo(wavCopy, overwrite = true)
        val uri = saveFileToMediaStore(wavCopy, wavCopy.name, "audio/wav")
        return Result.success(
            AudioExportResult(
                filePath = wavCopy.absolutePath,
                mediaStoreUri = uri,
                displayName = wavCopy.name,
                formatExtension = "wav",
                mimeType = "audio/wav",
                note = "Saved studio WAV audio to Music/AIPromptStudio/${wavCopy.name}"
            )
        )
    }

    private fun tryEncodeWavToMp3(wavFile: File, mp3OutFile: File): Boolean {
        var codec: MediaCodec? = null
        var inputStream: FileInputStream? = null
        var fos: FileOutputStream? = null
        return try {
            inputStream = FileInputStream(wavFile)
            val header = ByteArray(44)
            if (inputStream.read(header) < 44) return false
            val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            val channels = bb.getShort(22).toInt().coerceAtLeast(1)
            val sampleRate = bb.getInt(24).coerceAtLeast(8000)

            val mp3Format = MediaFormat.createAudioFormat("audio/mpeg", sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, 128000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }

            codec = MediaCodec.createEncoderByType("audio/mpeg")
            codec.configure(mp3Format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            fos = FileOutputStream(mp3OutFile)
            val bufferInfo = MediaCodec.BufferInfo()
            val chunk = ByteArray(4096)
            var isEos = false
            var totalBytes = 0L

            while (true) {
                if (!isEos) {
                    val inIdx = codec.dequeueInputBuffer(10000L)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        val read = inputStream.read(chunk)
                        if (read < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isEos = true
                        } else if (inBuf != null) {
                            inBuf.clear()
                            inBuf.put(chunk, 0, read)
                            val pts = (totalBytes * 1_000_000L) / (sampleRate * channels * 2)
                            codec.queueInputBuffer(inIdx, 0, read, pts, 0)
                            totalBytes += read
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 10000L)
                if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER && isEos) break
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        val outBytes = ByteArray(bufferInfo.size)
                        outBuf.position(bufferInfo.offset)
                        outBuf.get(outBytes)
                        fos.write(outBytes)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }
            true
        } catch (e: Exception) {
            Log.d(TAG, "Hardware MP3 encoder unavailable/skipped: ${e.message}")
            false
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
            try { fos?.close() } catch (_: Exception) {}
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
        }
    }

    private fun saveFileToMediaStore(file: File, displayName: String, mimeType: String): Uri? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/AIPromptStudio")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(file).use { input -> input.copyTo(out) }
                    }
                    values.clear()
                    values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                }
                uri
            } else {
                val musicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                val appDir = File(musicDir, "AIPromptStudio").apply { mkdirs() }
                val dest = File(appDir, displayName)
                file.copyTo(dest, overwrite = true)
                Uri.fromFile(dest)
            }
        } catch (e: Exception) {
            Log.w(TAG, "MediaStore audio insert failed, keeping internal export: ${e.message}")
            null
        }
    }
}
