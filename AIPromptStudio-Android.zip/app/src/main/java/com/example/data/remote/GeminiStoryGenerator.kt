package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.SceneItem
import com.example.data.model.StoryPlan
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiStoryGenerator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateStoryPlan(
        userStory: String,
        storyType: String,
        duration: String,
        aspectRatio: String,
        generateAllScenes: Boolean = true
    ): StoryPlan = withContext(Dispatchers.IO) {
        val targetSceneCount = when (duration) {
            "30 sec" -> 3
            "60 sec" -> if (generateAllScenes) 6 else 4
            "2 min" -> if (generateAllScenes) 10 else 5
            "5 min" -> if (generateAllScenes) 14 else 6
            else -> 4
        }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val planFromApi = callGeminiApi(apiKey, userStory, storyType, duration, aspectRatio, targetSceneCount)
                if (planFromApi != null && planFromApi.scenes.isNotEmpty()) {
                    return@withContext planFromApi
                }
            } catch (e: Exception) {
                Log.e("GeminiStoryGenerator", "API call failed, falling back to local cinematic generator", e)
            }
        }

        // High fidelity local cinematic generator for Indian stories
        return@withContext generateCinematicPlanLocally(
            userStory = userStory,
            storyType = storyType,
            duration = duration,
            aspectRatio = aspectRatio,
            sceneCount = targetSceneCount
        )
    }

    suspend fun regenerateScene(
        storyPlan: StoryPlan,
        sceneNumber: Int
    ): SceneItem = withContext(Dispatchers.IO) {
        val existingScene = storyPlan.scenes.find { it.sceneNumber == sceneNumber }
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val regenerated = callGeminiForSceneRegen(apiKey, storyPlan, sceneNumber)
                if (regenerated != null) {
                    return@withContext regenerated
                }
            } catch (e: Exception) {
                Log.e("GeminiStoryGenerator", "Scene regen API call failed, using fallback", e)
            }
        }

        return@withContext generateAlternativeSceneLocally(storyPlan, sceneNumber, existingScene)
    }

    private fun callGeminiApi(
        apiKey: String,
        userStory: String,
        storyType: String,
        duration: String,
        aspectRatio: String,
        targetSceneCount: Int
    ): StoryPlan? {
        val systemPrompt = """
            You are a master Bollywood director and AI Video Prompt Engineer specializing in Indian cinematic storytelling.
            Convert the given Hindi story or master prompt into a complete, professional scene-by-scene video production plan.
            
            IMPORTANT RULES:
            1. Visual Style: Photorealistic Indian cinematic style, realistic skin texture, natural facial expressions, authentic Indian clothing (saree, kurta, jewellery), cinematic depth of field, anamorphic bokeh, realistic lighting, 4K, aspect ratio $aspectRatio.
            2. Character Consistency: Maintain exact same character appearance, clothing, hairstyle, facial structure, skin tone across all scenes.
            3. Hindi Dialogue: Natural, conversational Hindi dialogue suitable for 8–10 second scenes (not overly long, lip-sync friendly).
            4. Each scene must have:
               - sceneNumber (integer)
               - duration ("8–10 seconds")
               - visualPrompt (rich cinematic prompt for AI image/video generator)
               - dialogue (in format "Character name: Hindi dialogue")
               - camera (angle + dynamic movement)
               - lighting (lighting setup, color temperature, time of day)
               - audio (voice delivery instructions + authentic Indian background ambience like sitar, birds, footsteps)
               - continuity ("Same characters, clothing, hairstyle, age and appearance as previous scenes.")
               - imagePrompt (Midjourney/Flux prompt)
               - videoPrompt (Runway Gen-3/Luma motion prompt)
               - facialExpression (exact facial emotion)
               - voiceInstruction (emotional vocal cadence)
               
            Return ONLY a valid JSON object with:
            {
              "title": "Story Title in Hindi / English",
              "storyType": "$storyType",
              "characterPrompts": "Detailed character visual descriptions",
              "characterConsistency": "Specific instructions on keeping face, clothing, and environment consistent",
              "visualStyle": "Photorealistic Indian cinematic style, realistic skin texture, 4K, $aspectRatio",
              "negativePrompt": "deformed anatomy, disfigured faces, bad hands, cartoon, 3D render, low resolution, blurry, oversaturated, unnatural plastic skin",
              "finalMessage": "Concluding climactic message or moral takeaway",
              "scenes": [
                 {
                   "sceneNumber": 1,
                   "duration": "8–10 seconds",
                   "visualPrompt": "...",
                   "dialogue": "...",
                   "camera": "...",
                   "lighting": "...",
                   "audio": "...",
                   "continuity": "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                   "imagePrompt": "...",
                   "videoPrompt": "...",
                   "facialExpression": "...",
                   "voiceInstruction": "..."
                 }
              ]
            }
            Generate exactly $targetSceneCount scenes.
        """.trimIndent()

        val userPrompt = """
            Story / Master Prompt: $userStory
            Story Genre: $storyType
            Duration: $duration
            Aspect Ratio: $aspectRatio
        """.trimIndent()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val requestJson = JSONObject().apply {
            val contentsArr = JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "$systemPrompt\n\n$userPrompt")
                        })
                    })
                })
            }
            put("contents", contentsArr)
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return null
        val jsonRoot = JSONObject(responseBody)
        val candidates = jsonRoot.optJSONArray("candidates") ?: return null
        val firstCandidate = candidates.optJSONObject(0) ?: return null
        val content = firstCandidate.optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        val rawText = parts.optJSONObject(0)?.optString("text") ?: return null

        val cleanJson = rawText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val parsed = JSONObject(cleanJson)

        val title = parsed.optString("title", "भारतीय सिनेमाई दृश्य योजना")
        val parsedStoryType = parsed.optString("storyType", storyType)
        val characterPrompts = parsed.optString("characterPrompts", "Indian characters in traditional attire")
        val characterConsistency = parsed.optString("characterConsistency", "Maintain consistent facial bone structure, skin complexion, and traditional wardrobe.")
        val visualStyle = parsed.optString("visualStyle", "Photorealistic Indian cinematic style, realistic skin texture, natural facial expressions, authentic clothing, cinematic depth of field, realistic lighting, 4K, $aspectRatio.")
        val negativePrompt = parsed.optString("negativePrompt", "deformed, extra limbs, bad eyes, cartoon, blur, unnatural skin")
        val finalMessage = parsed.optString("finalMessage", "कहानी का एक मार्मिक और प्रभावशाली अंत।")

        val scenesList = mutableListOf<SceneItem>()
        val scenesArray = parsed.optJSONArray("scenes")
        if (scenesArray != null) {
            for (i in 0 until scenesArray.length()) {
                val sc = scenesArray.getJSONObject(i)
                scenesList.add(
                    SceneItem(
                        sceneNumber = sc.optInt("sceneNumber", i + 1),
                        duration = sc.optString("duration", "8–10 seconds"),
                        visualPrompt = sc.optString("visualPrompt", ""),
                        dialogue = sc.optString("dialogue", ""),
                        camera = sc.optString("camera", ""),
                        lighting = sc.optString("lighting", ""),
                        audio = sc.optString("audio", ""),
                        continuity = sc.optString("continuity", "Same characters, clothing, hairstyle, age and appearance as previous scenes."),
                        imagePrompt = sc.optString("imagePrompt", ""),
                        videoPrompt = sc.optString("videoPrompt", ""),
                        facialExpression = sc.optString("facialExpression", ""),
                        voiceInstruction = sc.optString("voiceInstruction", "")
                    )
                )
            }
        }

        return StoryPlan(
            title = title,
            storyType = parsedStoryType,
            originalPrompt = userStory,
            duration = duration,
            aspectRatio = aspectRatio,
            characterPrompts = characterPrompts,
            characterConsistency = characterConsistency,
            visualStyle = visualStyle,
            negativePrompt = negativePrompt,
            finalMessage = finalMessage,
            scenes = scenesList
        )
    }

    private fun callGeminiForSceneRegen(
        apiKey: String,
        storyPlan: StoryPlan,
        sceneNumber: Int
    ): SceneItem? {
        val prompt = """
            Regenerate Scene $sceneNumber for the story titled "${storyPlan.title}".
            Story Type: ${storyPlan.storyType}
            Visual Style: ${storyPlan.visualStyle}
            Character Consistency: ${storyPlan.characterConsistency}
            Negative Prompt: ${storyPlan.negativePrompt}
            
            Provide a fresh, highly cinematic creative variation for Scene $sceneNumber adhering to Indian cinematic photorealism.
            Return ONLY a valid JSON object matching:
            {
              "sceneNumber": $sceneNumber,
              "duration": "8–10 seconds",
              "visualPrompt": "Detailed visual prompt",
              "dialogue": "Character Name: Hindi dialogue",
              "camera": "Camera movement and angle",
              "lighting": "Lighting instruction",
              "audio": "Voice instruction and background audio ambience",
              "continuity": "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
              "imagePrompt": "Detailed prompt for 4K generation",
              "videoPrompt": "Video prompt with motion dynamics",
              "facialExpression": "Facial expression details",
              "voiceInstruction": "Voice tone and delivery details"
            }
        """.trimIndent()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val requestJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.8)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody(jsonMediaType))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return null
        val jsonRoot = JSONObject(responseBody)
        val text = jsonRoot.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
            ?.optString("text") ?: return null

        val cleanJson = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val sc = JSONObject(cleanJson)
        return SceneItem(
            sceneNumber = sc.optInt("sceneNumber", sceneNumber),
            duration = sc.optString("duration", "8–10 seconds"),
            visualPrompt = sc.optString("visualPrompt", ""),
            dialogue = sc.optString("dialogue", ""),
            camera = sc.optString("camera", ""),
            lighting = sc.optString("lighting", ""),
            audio = sc.optString("audio", ""),
            continuity = sc.optString("continuity", "Same characters, clothing, hairstyle, age and appearance as previous scenes."),
            imagePrompt = sc.optString("imagePrompt", ""),
            videoPrompt = sc.optString("videoPrompt", ""),
            facialExpression = sc.optString("facialExpression", ""),
            voiceInstruction = sc.optString("voiceInstruction", "")
        )
    }

    private fun generateAlternativeSceneLocally(
        storyPlan: StoryPlan,
        sceneNumber: Int,
        existing: SceneItem?
    ): SceneItem {
        val aspect = storyPlan.aspectRatio
        return when (storyPlan.storyType) {
            "सास–बहू" -> SceneItem(
                sceneNumber = sceneNumber,
                duration = "8–10 seconds",
                visualPrompt = "Cinematic medium close-up in a lavish Rajasthani haveli courtyard. Sumitra Devi (56, regal maroon silk saree with zari border, gold choker necklace, stern dignified gaze) and Priya (26, delicate emerald green georgette saree, silver jhumkas, tearful determination). Natural sunlight through intricately carved jharokhas, warm dust motes floating in air. Photorealistic Indian cinematic style, 4K, $aspect.",
                dialogue = "सुमित्रा देवी: 'रिश्ते गहनों से नहीं, समर्पण और मर्यादा से टिकते हैं बहू।' / प्रिया: 'और माँ जी, सम्मान एकतरफा नहीं होता।'",
                camera = "Slow cinematic push-in from wide two-shot into dramatic eye-level split-focus tension.",
                lighting = "Chiaroscuro golden hour light, warm rim lighting on silver earrings, deep shadows in antique wooden corridors.",
                audio = "Deep emotional cello swell combined with low sitar resonant drone, authentic Hindi vocal delivery with subtle trembling breath.",
                continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                imagePrompt = "Cinematic 4K shot, Indian family drama, elegant middle aged Indian mother in maroon silk saree confronting young daughter in law, traditional haveli interior, photorealistic skin texture, dramatic cinematic lighting --ar ${aspect.replace(":", " ")}",
                videoPrompt = "Slow dolly push toward the two women standing face to face, tension escalating, delicate saree pallu fluttering slightly in evening breeze, 24fps cinema look.",
                facialExpression = "Stern yet vulnerable matriarchal authority clashing with respectful assertiveness.",
                voiceInstruction = "Controlled, dignified, low pitch with firm moral weight."
            )
            "Village Life" -> SceneItem(
                sceneNumber = sceneNumber,
                duration = "8–10 seconds",
                visualPrompt = "Rustic Indian village morning. Rameshwar (48, sun-weathered face, traditional cotton dhoti-kurta, saffron gamchha on shoulder) walking past lush green sugarcane fields towards an old well. Morning mist lifting, water droplets glistening on leaves. Photorealistic Indian rural life, 4K, $aspect.",
                dialogue = "रामेश्वर: 'इस मिट्टी की खुशबू कभी धोखा नहीं देती बेटा।' / नन्हे: 'बापू, इस बार फसल सबसे अच्छी होगी!'",
                camera = "Low angle tracking shot moving parallel to footsteps, panning gently towards the golden sunrise horizon.",
                lighting = "Soft diffused morning dawn light, warm orange sun flare breaking through banyan tree foliage.",
                audio = "Chirping of sparrows, distant rooster crowing, creaking wooden bullock cart in the distance, warm acoustic flute melody.",
                continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                imagePrompt = "Indian rural farmer and young son at dawn in mustard field, golden morning light, realistic soil and clothing textures, highly detailed 8K --ar ${aspect.replace(":", " ")}",
                videoPrompt = "Smooth gimbal tracking shot accompanying farmer walking through dewy crops, natural morning breeze in cotton fabric.",
                facialExpression = "Warm, content smile showing resilience and deep hope for the harvest.",
                voiceInstruction = "Earthy, affectionate, natural rural cadence."
            )
            "Horror" -> SceneItem(
                sceneNumber = sceneNumber,
                duration = "8–10 seconds",
                visualPrompt = "Eerie dilapidated colonial mansion in Shimla hill station at midnight. Aman (28, woollen dark jacket, holding a flickering brass lantern) notices shadows twisting unnaturally on the damp wall. Cold breath visible in chilly air. Photorealistic Indian psychological horror, 4K, $aspect.",
                dialogue = "अमन: 'वहाँ कोई है? मैंने साफ़ किसी के चलने की आहट सुनी है...'",
                camera = "Unsettling Dutch tilt combined with a slow creep-in, rack focusing from trembling brass lantern to dark doorway.",
                lighting = "High contrast moonlight through broken window panes, deep blue ambient shadows pierced by flickering amber flame.",
                audio = "Sudden silence followed by faint ghungroo (anklet) chime in the attic, howling mountain wind, whispered chant.",
                continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                imagePrompt = "Atmospheric Indian gothic horror, old dark wooden bungalow, foggy midnight, single lantern light casting long shadows --ar ${aspect.replace(":", " ")}",
                videoPrompt = "Slow zoom on character's terrified eyes as lantern flame flickers violently, shadow moving across doorway background.",
                facialExpression = "Widened eyes, swallowed dread, hyper-vigilant pulse visible at neck.",
                voiceInstruction = "Husky, frightened whisper, breathless delivery."
            )
            else -> SceneItem(
                sceneNumber = sceneNumber,
                duration = "8–10 seconds",
                visualPrompt = "Cinematic medium shot. Lead characters in photorealistic Indian setting. Expressive natural acting, rich cultural aesthetics, cinematic color grading, 4K, $aspect.",
                dialogue = "मुख्य पात्र: 'वक़्त बदल जाता है, लेकिन हमारे वादे हमेशा ज़िंदा रहते हैं।'",
                camera = "Dynamic 45-degree orbit shot, settling into an emotive medium close-up.",
                lighting = "Three-point cinematic lighting with soft golden key and moody cyan back-fill.",
                audio = "Heartfelt traditional instrumental motif, clear dialogue with natural room reverberation.",
                continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                imagePrompt = "Photorealistic Indian cinematic scene, realistic skin texture, expressive eyes, authentic Indian attire --ar ${aspect.replace(":", " ")}",
                videoPrompt = "Cinematic slow motion push-in with gentle camera drift, hyper-realistic character performance.",
                facialExpression = "Deep introspection and unwavering resolve.",
                voiceInstruction = "Warm, earnest, resonant."
            )
        }
    }

    private fun generateCinematicPlanLocally(
        userStory: String,
        storyType: String,
        duration: String,
        aspectRatio: String,
        sceneCount: Int
    ): StoryPlan {
        val aspect = aspectRatio
        val promptClean = if (userStory.isBlank()) "एक प्रेरणादायक भारतीय पारिवारिक कहानी" else userStory

        val title = when (storyType) {
            "सास–बहू" -> "मर्यादा और ममता: हवेली की दास्तान"
            "Emotional Family" -> "अटूट बंधन: रिश्तों का सफर"
            "Mythological" -> "धर्मक्षेत्रे: सत्य और तपस्या की विजय"
            "Kids" -> "जादुई गाँव और नन्हे दोस्त"
            "Horror" -> "काली हवेली का पुराना राज़"
            "Village Life" -> "माटी की सौगंध: गाँव की सुबह"
            else -> "सिनेमाई गाथा: जीवन का सच"
        }

        val characterPrompts = when (storyType) {
            "सास–बहू" -> """
                1. सुमित्रा देवी (उम्र 56): हवेली की मुखिया, रोबीला व्यक्तित्व, गहरे महरून कांजीवरम सिल्क साड़ी, सोने का पारंपरिक चोकर, माथे पर बड़ी गोल लाल बिंदी, बालों में सलीके से बंधा जूड़ा, तीखे नैन-नक्श।
                2. प्रिया (उम्र 26): आधुनिक विचारों वाली संस्कारी बहू, हल्के हरे रंग की जॉर्जेट साड़ी, चांदी के नाजुक झुमके, आँखों में स्वाभिमान और ममता, प्राकृतिक भारतीय सांवला निखार।
            """.trimIndent()
            "Village Life" -> """
                1. रामेश्वर (उम्र 48): कर्मठ किसान, धूप में तपी तांबे जैसी त्वचा, सफ़ेद सूती धोती-कुर्ता, कंधे पर पीला गमछा, आँखों में आत्मीयता।
                2. नन्हे (उम्र 10): चंचल ग्रामीण बालक, नीली सूती कुर्ती, पैरों में धूल, चेहरे पर मासूम मुस्कान।
            """.trimIndent()
            "Mythological" -> """
                1. वीर अर्जुन (उम्र 32): तेजस्वी योद्धा, स्वर्ण कवच और कुंडल, दिव्य गांडीव धनुष, माथे पर चंदन तिलक, सुगठित काया, दृष्टि में असीम संकल्प।
                2. वासुदेव कृष्ण (उम्र 34): पीतांबर धारी, मोरपंख मुकुट, मोहिनी मुस्कान, श्याम वर्ण, दिव्य अलौकिक आभामंडल।
            """.trimIndent()
            "Horror" -> """
                1. अमन (उम्र 28): युवा खोजी पत्रकार, गहरे रंग की ऊनी जैकेट, चेहरे पर चिंता की लकीरें, हाथ में पीतल की जलती लालटेन।
                2. रहस्यमयी साया: धुंधला स्त्री स्वरूप, पुरानी श्वेत साड़ी, पैरों में घुंघरू, परछाई जो रोशनी से नहीं डरती।
            """.trimIndent()
            "Kids" -> """
                1. आरव (उम्र 8): साहसी जिज्ञासु बच्चा, लाल टी-शर्ट, नीली शॉर्ट्स, कंधे पर छोटा स्कूल बैग।
                2. चीकू (जादुई गिलहरी): सुनहरी फर, चमकदार बड़ी आँखें, हवा में तैरने की क्षमता।
            """.trimIndent()
            else -> """
                1. मुख्य पात्र 1: प्रामाणिक भारतीय वेशभूषा, उम्र 30-35, गरिमापूर्ण व्यक्तित्व, स्वाभाविक चेहरे की बनावट।
                2. मुख्य पात्र 2: पारंपरिक वेशभूषा, उम्र 50-55, अनुभवी और भावुक चेहरे के भाव।
            """.trimIndent()
        }

        val characterConsistency = """
            - सभी दृश्यों में पात्रों के चेहरे की बनावट, त्वचा का रंग (Indian skin tone), बालों का स्टाइल और कपड़े बिल्कुल समान रहेंगे।
            - सुमित्रा देवी की महरून सिल्क साड़ी और प्रिया की हरी साड़ी का रंग और डिज़ाइन प्रत्येक दृश्य में एक जैसा रहेगा।
            - आभूषण (ज्वेलरी), बिंदी, तिलक और एक्सेसरीज़ में पूर्ण निरंतरता (Continuity) सुरक्षित रहेगी।
            - प्रकाश के कोण के अनुसार त्वचा पर यथार्थवादी छाया और हाइलाइट्स बनी रहेंगी।
        """.trimIndent()

        val visualStyle = "Photorealistic Indian cinematic style, realistic skin texture, natural facial expressions, authentic clothing, cinematic depth of field, realistic lighting, 4K, vertical $aspectRatio."

        val negativePrompt = "deformed limbs, extra fingers, cartoonish, 3D animated, wax skin, blurry, oversaturated colors, Western modern clothing where Indian traditional requested, disfigured eyes, duplicate faces, low quality video artifacts."

        val finalMessage = when (storyType) {
            "सास–बहू" -> "परिवार तकरार से नहीं, एक-दूसरे के आत्मसम्मान को समझने से मजबूत बनता है।"
            "Emotional Family" -> "घर ईंट-पत्थरों से नहीं, अपनों के प्यार और विश्वास से आबाद होता है।"
            "Mythological" -> "जहाँ धर्म और सत्य का साथ है, विजय वहीं निश्चित है।"
            "Village Life" -> "माटी की महक और अपनों का साथ ही जीवन का सबसे बड़ा धन है।"
            "Horror" -> "अतीत के राज़ जब खुलते हैं, तो सच रूह को भी कंपा देता है।"
            else -> "सच्चे जज़्बात हर फासले को मिटा देते हैं।"
        }

        val scenes = generateScenesForType(storyType, aspect, sceneCount)

        return StoryPlan(
            title = title,
            storyType = storyType,
            originalPrompt = promptClean,
            duration = duration,
            aspectRatio = aspectRatio,
            characterPrompts = characterPrompts,
            characterConsistency = characterConsistency,
            visualStyle = visualStyle,
            negativePrompt = negativePrompt,
            finalMessage = finalMessage,
            scenes = scenes
        )
    }

    private fun generateScenesForType(storyType: String, aspect: String, count: Int): List<SceneItem> {
        val list = mutableListOf<SceneItem>()

        when (storyType) {
            "सास–बहू" -> {
                val templates = listOf(
                    SceneItem(
                        sceneNumber = 1,
                        duration = "8–10 seconds",
                        visualPrompt = "Wide cinematic establishing shot of a grand royal Rajasthani haveli at sunrise. Marble pillars, intricate jali screens, brass temple bells. In the courtyard, Sumitra Devi stands erect in a deep maroon Kanjivaram silk saree, holding a bronze puja thali with fresh marigold flowers. Warm golden rays piercing morning mist. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "सुमित्रा देवी: 'सुबह के सात बज चुके हैं... और इस हवेली में पूजा का समय कभी बदला नहीं है।'",
                        camera = "High angle crane shot descending smoothly into an eye-level medium-wide profile of Sumitra Devi.",
                        lighting = "Soft golden hour morning sunbeams cutting through courtyard jharokhas with atmospheric dust motes.",
                        audio = "Morning temple conch shell reverberating softly, distant shehnai notes, firm authoritative Hindi voice.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Photorealistic 4K cinematic still, royal Indian haveli courtyard at sunrise, dignified elderly matriarch in maroon saree holding brass thali, golden light --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Smooth crane descending shot, morning light slowly illuminating temple thali, marigold petals swaying gently, cinema 24fps.",
                        facialExpression = "Dignified, disciplined, expectant matriarchal expression.",
                        voiceInstruction = "Deep, steady, authoritative Hindi tone."
                    ),
                    SceneItem(
                        sceneNumber = 2,
                        duration = "8–10 seconds",
                        visualPrompt = "Medium shot inside the haveli hallway. Priya enters briskly wearing an emerald green georgette saree, holding freshly pressed silk shawls for the elders. She pauses as she catches Sumitra Devi's stern gaze. Subtle tension in the air. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "प्रिया: 'माँ जी, पंडित जी के लिए शॉल तैयार कर रही थी। पूजा में कोई कमी नहीं रहेगी।'",
                        camera = "Tracking push-in towards Priya's eyes, revealing respect mixed with nervous resolve.",
                        lighting = "Warm ambient indoor daylight with soft contrast, gentle catchlight in Priya's expressive eyes.",
                        audio = "Rustle of georgette fabric, gentle clinking of silver bangles, calm polite Hindi speech.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Indian young daughter-in-law in green saree holding shawls in antique haveli corridor, soft lighting, sharp focus on expressive eyes --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Dolly tracking shot following Priya as she stops, slow eye contact exchange with mother-in-law.",
                        facialExpression = "Respectful, composed, polite yet firm inner dignity.",
                        voiceInstruction = "Soft-spoken, melodic, humble but confident."
                    ),
                    SceneItem(
                        sceneNumber = 3,
                        duration = "8–10 seconds",
                        visualPrompt = "Tight two-shot at the home temple altar. Gilded brass idols of Radha Krishna lit by multiple ghee diyas. Sumitra Devi looks closely into Priya's hands as Priya carefully arranges the sacred tulsi leaves with reverence. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "सुमित्रा देवी: 'परंपराएँ सिर्फ नियम नहीं होतीं बहू, ये हमारे कुल की आत्मा हैं।' / प्रिया: 'और मैं इस आत्मा को हमेशा सहेज कर रखूँगी माँ जी।'",
                        camera = "Slow dolly move across the warm flame of the diya, shifting focus from mother-in-law to daughter-in-law.",
                        lighting = "Warm amber glow from flickering oil lamps casting soft dancing shadows against carved sandstone.",
                        audio = "Soothing acoustic sitar melody, crackle of burning camphor, heartfelt devotional atmosphere.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Close-up cinematic two-shot at Hindu home altar, diya flame foreground bokeh, two Indian women in sarees placing tulsi leaves --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Rack focus from trembling golden diya flame to the warm, emotional eye exchange of the two women.",
                        facialExpression = "Thawing strictness into reluctant appreciation; young woman's genuine devotion.",
                        voiceInstruction = "Solemn and gentle, heartfelt cadence."
                    ),
                    SceneItem(
                        sceneNumber = 4,
                        duration = "8–10 seconds",
                        visualPrompt = "Wide climactic scene in the grand haveli living room. Family members gathered. Sumitra Devi places her warm hand gently over Priya's shoulder and offers her the ancestral silver key ring. Tearful smile of mutual understanding. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "सुमित्रा देवी: 'आज से इस घर की मान-मर्यादा की रखवाली तुम्हारे हाथों में है बहू।' / प्रिया: 'आपका यह विश्वास मेरा सबसे बड़ा गहना है माँ जी।'",
                        camera = "Slow 360-degree emotional arc shot enveloping the two women in a heartwarming embrace.",
                        lighting = "Rich, golden evening chandelier lighting blending with blue twilight outside the arched windows.",
                        audio = "Emotional swelling sarangi and flute symphony, subtle tear drop sound, joyful family murmur.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Climactic Indian family emotional scene, mother-in-law giving ancestral silver keys to daughter-in-law, tearful smiles, cinematic lighting --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Slow circular camera rotation around the two smiling women as silver keys reflect chandelier sparkles.",
                        facialExpression = "Deep pride and maternal affection; overwhelmed joy and gratitude.",
                        voiceInstruction = "Choked with emotion, warm and maternal."
                    )
                )

                for (i in 0 until count) {
                    val base = templates[i % templates.size]
                    list.add(base.copy(sceneNumber = i + 1))
                }
            }
            "Village Life" -> {
                val templates = listOf(
                    SceneItem(
                        sceneNumber = 1,
                        duration = "8–10 seconds",
                        visualPrompt = "Wide panoramic shot of an Indian rural village at daybreak. Golden mustard fields stretching into horizon, traditional mud-walled huts with tiled roofs, blue smoke rising from earthen chulhas. Rameshwar (48) steps out adjusting his saffron gamchha. Photorealistic Indian village life, 4K, $aspect.",
                        dialogue = "रामेश्वर: 'सूरज देवता निकल आए... आज खेत में पानी चढ़ाने का दिन है।'",
                        camera = "Slow sweeping jib shot panning from the glowing sunrise across dew-soaked wheat fields.",
                        lighting = "Crisp, golden dawn sunlight breaking through tall neem trees, morning ground fog.",
                        audio = "Cawing of crows, morning village bell, sound of wooden broom sweeping dusty courtyard.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Indian rural landscape dawn, mustard flowers, mud house, village man in dhoti gamchha, 4K cinematic photorealistic --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Slow smooth pan across green fields to farmer taking his first steps into the morning mist.",
                        facialExpression = "Fresh, energetic, hardworking determination.",
                        voiceInstruction = "Hearty, resonant, natural rural Hindi."
                    ),
                    SceneItem(
                        sceneNumber = 2,
                        duration = "8–10 seconds",
                        visualPrompt = "Medium shot at the village tube-well. Rameshwar washes his face with clear gushing water as young Nanhe (10) runs up balancing a bronze tiffin box. Pure joy and rural bonding. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "नन्हे: 'बापू! माँ ने बाजरे की ताज़ा रोटी और घर का सफेद मक्खन भेजा है!' / रामेश्वर: 'अरे वाह मेरे शेर, भूख से पेट में चूहे कूद रहे थे!'",
                        camera = "Low angle action shot catching splashing crystal-clear water drops backlit by sunbeams.",
                        lighting = "Direct morning sun creating sparkling specular highlights on flowing water and bronze tiffin.",
                        audio = "Sound of rhythmic gushing tubewell pump, childlike joyous Hindi laughter, chirping bulbuls.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Indian farmer splashing water from village tubewell, happy young son with tiffin box, realistic sun flare --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Dynamic water splash in slow motion as father playfully sprinkles drops on smiling child.",
                        facialExpression = "Fatherly amusement and hearty delight; boy's innocent cheerful pride.",
                        voiceInstruction = "Playful, exuberant and warm."
                    ),
                    SceneItem(
                        sceneNumber = 3,
                        duration = "8–10 seconds",
                        visualPrompt = "Close-up shot in the lush green field. Rameshwar kneels down, picks up a handful of dark fertile soil, lets it sift gently through his calloused fingers. Golden wheat stalks swaying behind him. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "रामेश्वर: 'ये माटी नहीं है बेटा, ये हमारी माँ है। जितना पसीना बहाओगे, उतना ही सोना उगलेगी।'",
                        camera = "Macro lens push-in on soil particles in rough hands, tilting up to meet Rameshwar's inspired eyes.",
                        lighting = "Warm afternoon backlighting casting glowing golden outlines along cotton kurta and soil granules.",
                        audio = "Rustle of wheat stalks in gentle wind, soft bansuri (bamboo flute) melody, deep reverent voice.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Macro cinematic photo of Indian farmer hands holding rich brown soil in wheat field, golden hour --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Extreme close up of fertile earth crumbling slowly through fingers with warm wind blowing wheat in background.",
                        facialExpression = "Deep philosophical contentment and gratitude to Mother Nature.",
                        voiceInstruction = "Reverent, emotional, grounded."
                    ),
                    SceneItem(
                        sceneNumber = 4,
                        duration = "8–10 seconds",
                        visualPrompt = "Wide sunset scene on the village unpaved road. Rameshwar carries Nanhe on his strong shoulders, walking towards home as silhouette of bullock carts pass by against a giant crimson sun. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "नन्हे: 'बापू, मैं भी बड़ा होकर आपके साथ खेत जोतूँगा!' / रामेश्वर: 'तू पढ़ेगा भी और इस माटी का नाम भी रोशन करेगा बेटा।' ",
                        camera = "Tracking silhouette shot moving backwards as father and son walk directly toward camera into sunset.",
                        lighting = "Dazzling crimson and violet sunset sky, dramatic warm rim light on edges of figures.",
                        audio = "Tinkling bullock bells, evening temple aarti bells in far distance, peaceful warm flute crescendo.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Silhouette of Indian farmer carrying son on shoulders walking against massive orange sunset, cinematic 8K --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Slow motion walking shot against dramatic sunset with dust kicked up by cattle glowing like gold dust.",
                        facialExpression = "Serene, fulfilled, looking towards a bright future.",
                        voiceInstruction = "Affectionate, promising, heartfelt."
                    )
                )

                for (i in 0 until count) {
                    val base = templates[i % templates.size]
                    list.add(base.copy(sceneNumber = i + 1))
                }
            }
            "Mythological" -> {
                val templates = listOf(
                    SceneItem(
                        sceneNumber = 1,
                        duration = "8–10 seconds",
                        visualPrompt = "Epic cinematic shot of the sacred battlefield of Kurukshetra at dusk. Conches resting on golden chariots, battle banners flapping in wind. Arjuna in resplendent golden armour lowers his Gandiva bow, eyes clouded with moral anguish. Photorealistic mythological Indian style, 4K, $aspect.",
                        dialogue = "अर्जुन: 'हे माधव! अपने ही बंधु-बांधवों पर शस्त्र उठाकर मुझे कैसा विजय सुख मिलेगा?'",
                        camera = "Slow Dutch tilt tracking shot circling Arjuna's chariot, highlighting his trembling fingers.",
                        lighting = "Dramatic stormy twilight sky with divine golden rays piercing dark thunderclouds.",
                        audio = "Ominous wind howling, distant thunder rumble, sorrowful Indian classical violin raga.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Cinematic mythological scene, warrior Arjuna in golden armor holding Gandiva bow on battlefield, divine lighting, 4K photorealistic --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Cinematic slow zoom into Arjuna's troubled face as royal flag flutters furiously in storm winds.",
                        facialExpression = "Intense moral conflict, profound grief, existential hesitance.",
                        voiceInstruction = "Trembling with sorrow, philosophically conflicted."
                    ),
                    SceneItem(
                        sceneNumber = 2,
                        duration = "8–10 seconds",
                        visualPrompt = "Divine medium shot of Lord Krishna holding the chariot reins. Peacocok feather in crowned locks, glowing yellow pitambar silk, a subtle compassionate smile illuminating his celestial face. Photorealistic Indian mythological cinema, 4K, $aspect.",
                        dialogue = "भगवान कृष्ण: 'पार्थ, मोह का त्याग करो। आत्मा न कभी मरती है, न कभी जन्म लेती है। कर्म ही तुम्हारा धर्म है।' ",
                        camera = "Smooth crane shot rising above chariot wheels to frame Krishna against celestial glow.",
                        lighting = "Ethereal divine halo of warm light radiating from Krishna, casting soft reflections on polished gold armor.",
                        audio = "Divine shankh (conch) drone, resonant flute melody, deep commanding yet infinitely compassionate voice.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Lord Krishna with peacock feather crown holding chariot reins, calm divine smile, celestial golden aura, photorealistic --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Gentle slow motion of divine peacock feather swaying as Krishna speaks eternal truth.",
                        facialExpression = "Omniscient calm, transcendental compassion and supreme confidence.",
                        voiceInstruction = "Deep, resonant, cosmic serenity."
                    ),
                    SceneItem(
                        sceneNumber = 3,
                        duration = "8–10 seconds",
                        visualPrompt = "Macro shot of Arjuna's hands as he firmly tightens his grip upon the celestial string of the Gandiva bow. Tears dry on his cheek, replaced by fierce divine resolve. Photorealistic Indian cinema, 4K, $aspect.",
                        dialogue = "अर्जुन: 'नष्टो मोहः स्मर्तिर्लब्धा... हे प्रभु! मेरा संशय मिट गया। मैं आपके आदेश का पालन करूँगा।' ",
                        camera = "Rapid whip-pan from Krishna's serene eyes down to the bowstring snapping taut with golden energy.",
                        lighting = "Brilliant golden lightning flash lighting up the chariot, sharp heroic rim lights.",
                        audio = "Deep twang of the celestial bowstring resonating like thunder, epic battle drums beating.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Epic close up of Indian mythological hero drawing celestial bow, sparks of golden light, heroic gaze --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "High speed 60fps shot of bowstring being pulled taut, golden aura enveloping warrior.",
                        facialExpression = "Fierce clarity, unshakeable courage and spiritual awakening.",
                        voiceInstruction = "Thundering, resolute, heroic Hindi delivery."
                    )
                )

                for (i in 0 until count) {
                    val base = templates[i % templates.size]
                    list.add(base.copy(sceneNumber = i + 1))
                }
            }
            else -> {
                // Emotional Family / Horror / Kids / Custom default generator
                val templates = listOf(
                    SceneItem(
                        sceneNumber = 1,
                        duration = "8–10 seconds",
                        visualPrompt = "Cinematic opening shot. Lead characters established in an authentic Indian environment with rich atmospheric detailing. Natural sunlight, intricate textures, expressive body language. Photorealistic Indian cinematic style, 4K, $aspect.",
                        dialogue = "पात्र 1: 'कुछ रिश्ते शब्दों के मोहताज नहीं होते, वो सिर्फ आँखों से बयां होते हैं।'",
                        camera = "Slow cinematic push-in from wide establishing angle to medium profile.",
                        lighting = "Natural golden daylight with soft shadows and cinematic color grade.",
                        audio = "Subtle sitar strums, authentic ambient environment sounds, crystal clear spoken Hindi.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Photorealistic Indian cinematic opening shot, authentic Indian aesthetics, 4K, high detail --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Smooth dolly in capturing natural movement and lifelike emotion at 24fps.",
                        facialExpression = "Contemplative, emotionally engaged.",
                        voiceInstruction = "Warm and intimate."
                    ),
                    SceneItem(
                        sceneNumber = 2,
                        duration = "8–10 seconds",
                        visualPrompt = "Medium close-up capturing a key dramatic confrontation or emotional turning point. High-detail facial expressions, micro-reactions, authentic traditional attire. Photorealistic Indian style, 4K, $aspect.",
                        dialogue = "पात्र 2: 'अगर आज हम सच नहीं कह पाए, तो शायद कल बहुत देर हो जाएगी।' ",
                        camera = "Over-the-shoulder shot with shallow depth of field focusing sharply on the speaker's eyes.",
                        lighting = "Dramatic side lighting emphasizing facial contours and emotional tension.",
                        audio = "Tension-building strings crescendo, subtle breath intake, intense Hindi dialogue.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Cinematic emotional close up of Indian actor, intense expressive gaze, shallow depth of field --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Slow push-in on character's eyes as subtle micro-expressions shift across the face.",
                        facialExpression = "Urgent, earnest, emotionally vulnerable.",
                        voiceInstruction = "Firm, urgent, heartfelt."
                    ),
                    SceneItem(
                        sceneNumber = 3,
                        duration = "8–10 seconds",
                        visualPrompt = "Climactic resolution scene. Characters coming together in mutual understanding or dramatic revelation. Warm lighting, celebratory or poignant visual tone. Photorealistic Indian style, 4K, $aspect.",
                        dialogue = "पात्र 1: 'भरोसा टूट सकता है, पर उम्मीद हमेशा नई राह दिखाती है।' / पात्र 2: 'और हम यह राह साथ तय करेंगे।' ",
                        camera = "Slow 180-degree emotional arc tracking shot settling on a united two-shot.",
                        lighting = "Warm ambient glow, rich golden highlights reflecting in eyes and clothing.",
                        audio = "Uplifting traditional instrumental melody, emotional Hindi dialogue, peaceful ambience.",
                        continuity = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
                        imagePrompt = "Emotional Indian cinema climax scene, two actors in heartfelt moment, warm golden lighting --ar ${aspect.replace(":", " ")}",
                        videoPrompt = "Graceful arc shot rotating around characters as emotional music swells.",
                        facialExpression = "Relief, renewed hope, deep affection.",
                        voiceInstruction = "Comforting, reassuring, resonant."
                    )
                )

                for (i in 0 until count) {
                    val base = templates[i % templates.size]
                    list.add(base.copy(sceneNumber = i + 1))
                }
            }
        }

        return list.take(count)
    }
}
