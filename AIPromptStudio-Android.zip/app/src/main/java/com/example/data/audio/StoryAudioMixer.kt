package com.example.data.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Audio processing engine that:
 * 1. Sequences multiple scene narration WAV files with precise timing/padding matching scene durations.
 * 2. Decodes background music (MP3/M4A/AAC/WAV) from user device into PCM.
 * 3. Applies intelligent audio ducking: reduces background music volume (e.g., 20%) while narration speaks,
 *    and smoothly restores music volume (e.g., 60-70%) during pauses and between scenes.
 * 4. Renders the composited PCM audio into a single synchronized master audio file (.wav) for MP4 muxing.
 */
class StoryAudioMixer(private val context: Context) {

    companion object {
        private const val TAG = "StoryAudioMixer"
        const val SAMPLE_RATE = 44100
        const val CHANNELS = 2 // Stereo
        private const val BYTES_PER_SAMPLE = 2 // 16-bit PCM
        private const val NARRATION_VOLUME = 1.0f
        private const val BG_MUSIC_DUCKED_VOLUME = 0.18f
        private const val BG_MUSIC_NORMAL_VOLUME = 0.65f
    }

    data class SceneAudioEntry(
        val sceneNumber: Int,
        val sceneDurationSeconds: Int,
        val narrationWavPath: String?
    )

    data class MasterAudioValidation(
        val isValid: Boolean,
        val totalDurationSeconds: Float,
        val speechDurationSeconds: Float,
        val speechCoveragePercent: Float,
        val maxSilentGapSeconds: Float,
        val scenesWithSpeechCount: Int,
        val totalScenesCount: Int,
        val details: String,
        val errorMessage: String? = null
    )

    private var lastValidation: MasterAudioValidation? = null

    fun getLastValidation(): MasterAudioValidation? = lastValidation

    /**
     * Builds a single synchronized master audio WAV file combining scene narration tracks
     * and background music with automatic ducking.
     */
    fun createMasterAudioTrack(
        sceneEntries: List<SceneAudioEntry>,
        bgMusicUri: Uri?,
        isMusicMuted: Boolean,
        outputFile: File
    ): Boolean {
        try {
            outputFile.parentFile?.mkdirs()
            if (outputFile.exists()) outputFile.delete()

            val totalDurationSeconds = sceneEntries.sumOf { it.sceneDurationSeconds }
            if (totalDurationSeconds <= 0) {
                lastValidation = MasterAudioValidation(
                    isValid = false,
                    totalDurationSeconds = 0f,
                    speechDurationSeconds = 0f,
                    speechCoveragePercent = 0f,
                    maxSilentGapSeconds = 0f,
                    scenesWithSpeechCount = 0,
                    totalScenesCount = sceneEntries.size,
                    details = "Total duration is zero or negative.",
                    errorMessage = "Total video duration must be greater than zero."
                )
                return false
            }

            val totalSamples = totalDurationSeconds * SAMPLE_RATE
            val narrationPcm = ShortArray(totalSamples * CHANNELS)
            val speechActiveMask = BooleanArray(totalSamples)

            // 1. Render all scene narrations into the master 44.1kHz PCM buffer with high-quality resampling
            var currentSampleOffset = 0
            var scenesWithSpeech = 0
            val sceneSpeechCounts = mutableListOf<Int>()

            for (scene in sceneEntries) {
                val sceneSampleCount = scene.sceneDurationSeconds * SAMPLE_RATE
                val path = scene.narrationWavPath
                var speechSamplesInScene = 0

                if (!path.isNullOrBlank()) {
                    val file = File(path)
                    if (file.exists() && file.length() > 44) {
                        speechSamplesInScene = renderWavIntoPcmBuffer(
                            file = file,
                            buffer = narrationPcm,
                            startSample = currentSampleOffset,
                            maxSamples = sceneSampleCount,
                            speechMask = speechActiveMask
                        )
                    }
                }

                sceneSpeechCounts.add(speechSamplesInScene)
                if (speechSamplesInScene > 0) {
                    scenesWithSpeech++
                }

                currentSampleOffset += sceneSampleCount
            }

            // 2. Validate speech coverage, gaps, and scene presence
            val validation = validateMasterAudioTimeline(
                sceneEntries = sceneEntries,
                speechActiveMask = speechActiveMask,
                sceneSpeechCounts = sceneSpeechCounts,
                totalSamples = totalSamples
            )
            lastValidation = validation
            Log.i(TAG, "Audio timeline validation: isValid=${validation.isValid}, coverage=${validation.speechCoveragePercent}%, maxGap=${validation.maxSilentGapSeconds}s, details='${validation.details}'")

            if (!validation.isValid) {
                Log.e(TAG, "Master audio validation failed: ${validation.errorMessage}")
                return false
            }

            // 3. Decode background music if provided and not muted
            var bgMusicPcm: ShortArray? = null
            if (bgMusicUri != null && !isMusicMuted) {
                try {
                    bgMusicPcm = decodeAudioUriToPcm(context, bgMusicUri, totalSamples)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not decode background music, continuing without music: ${e.message}")
                }
            }

            // 4. Composite narration + background music with ducking
            val finalMixedPcm = ShortArray(totalSamples * CHANNELS)
            val bgPcm = bgMusicPcm

            var currentDuckingVolume = if (speechActiveMask.isNotEmpty() && speechActiveMask[0]) BG_MUSIC_DUCKED_VOLUME else BG_MUSIC_NORMAL_VOLUME
            val smoothingFactor = 0.005f // Smooth audio ducking transition across frames

            for (i in 0 until totalSamples) {
                val isSpeechActive = speechActiveMask[i]
                val targetBgVolume = if (isSpeechActive) BG_MUSIC_DUCKED_VOLUME else BG_MUSIC_NORMAL_VOLUME
                currentDuckingVolume += (targetBgVolume - currentDuckingVolume) * smoothingFactor

                val leftNarration = narrationPcm[i * 2].toFloat() * NARRATION_VOLUME
                val rightNarration = narrationPcm[i * 2 + 1].toFloat() * NARRATION_VOLUME

                val leftBg = if (bgPcm != null && (i * 2 + 1) < bgPcm.size) {
                    bgPcm[i * 2].toFloat() * currentDuckingVolume
                } else 0f

                val rightBg = if (bgPcm != null && (i * 2 + 1) < bgPcm.size) {
                    bgPcm[i * 2 + 1].toFloat() * currentDuckingVolume
                } else 0f

                // Mix & Soft Clip
                finalMixedPcm[i * 2] = clampSample((leftNarration + leftBg).toInt())
                finalMixedPcm[i * 2 + 1] = clampSample((rightNarration + rightBg).toInt())
            }

            // 5. Write final PCM buffer to standard 44.1kHz Stereo 16-bit WAV file
            writePcmToWavFile(finalMixedPcm, outputFile, SAMPLE_RATE, CHANNELS)
            return outputFile.exists() && outputFile.length() > 44

        } catch (e: Exception) {
            Log.e(TAG, "Error mixing master audio track", e)
            lastValidation = MasterAudioValidation(
                isValid = false,
                totalDurationSeconds = 0f,
                speechDurationSeconds = 0f,
                speechCoveragePercent = 0f,
                maxSilentGapSeconds = 0f,
                scenesWithSpeechCount = 0,
                totalScenesCount = sceneEntries.size,
                details = "Exception during audio mix: ${e.message}",
                errorMessage = "Audio mixing error: ${e.message}"
            )
            return false
        }
    }

    private fun validateMasterAudioTimeline(
        sceneEntries: List<SceneAudioEntry>,
        speechActiveMask: BooleanArray,
        sceneSpeechCounts: List<Int>,
        totalSamples: Int
    ): MasterAudioValidation {
        val speechSamples = speechActiveMask.count { it }
        val totalSec = totalSamples.toFloat() / SAMPLE_RATE
        val speechSec = speechSamples.toFloat() / SAMPLE_RATE
        val coveragePercent = if (totalSamples > 0) (speechSamples.toFloat() / totalSamples.toFloat()) * 100f else 0f

        val expectedSpeechScenes = sceneEntries.count { !it.narrationWavPath.isNullOrBlank() }
        val actualSpeechScenes = sceneSpeechCounts.count { it > 0 }

        // Check if any expected scene has 0 speech samples
        for (i in sceneEntries.indices) {
            val scene = sceneEntries[i]
            if (!scene.narrationWavPath.isNullOrBlank() && sceneSpeechCounts[i] == 0) {
                return MasterAudioValidation(
                    isValid = false,
                    totalDurationSeconds = totalSec,
                    speechDurationSeconds = speechSec,
                    speechCoveragePercent = coveragePercent,
                    maxSilentGapSeconds = 0f,
                    scenesWithSpeechCount = actualSpeechScenes,
                    totalScenesCount = sceneEntries.size,
                    details = "Scene ${scene.sceneNumber} narration produced 0 audible speech samples.",
                    errorMessage = "Scene ${scene.sceneNumber} narration is missing or silent."
                )
            }
        }

        // Measure silent gaps between first active speech and last active speech
        val firstSpeech = speechActiveMask.indexOfFirst { it }
        val lastSpeech = speechActiveMask.indexOfLast { it }

        var maxSilentGapSamples = 0
        if (firstSpeech in 0..lastSpeech) {
            var currentGap = 0
            for (i in firstSpeech..lastSpeech) {
                if (!speechActiveMask[i]) {
                    currentGap++
                    if (currentGap > maxSilentGapSamples) {
                        maxSilentGapSamples = currentGap
                    }
                } else {
                    currentGap = 0
                }
            }
        }

        val maxSilentGapSec = maxSilentGapSamples.toFloat() / SAMPLE_RATE

        // Enforce timeline criteria:
        // Gaps between scene speech should not exceed 2.2 seconds.
        // Overall speech coverage should be at least 40% when all scenes have narration.
        if (expectedSpeechScenes > 0 && actualSpeechScenes < expectedSpeechScenes) {
            return MasterAudioValidation(
                isValid = false,
                totalDurationSeconds = totalSec,
                speechDurationSeconds = speechSec,
                speechCoveragePercent = coveragePercent,
                maxSilentGapSeconds = maxSilentGapSec,
                scenesWithSpeechCount = actualSpeechScenes,
                totalScenesCount = sceneEntries.size,
                details = "Only $actualSpeechScenes of $expectedSpeechScenes scenes have speech.",
                errorMessage = "Narration is incomplete: $actualSpeechScenes of $expectedSpeechScenes scenes synthesized."
            )
        }

        if (expectedSpeechScenes > 1 && maxSilentGapSec > 2.2f) {
            return MasterAudioValidation(
                isValid = false,
                totalDurationSeconds = totalSec,
                speechDurationSeconds = speechSec,
                speechCoveragePercent = coveragePercent,
                maxSilentGapSeconds = maxSilentGapSec,
                scenesWithSpeechCount = actualSpeechScenes,
                totalScenesCount = sceneEntries.size,
                details = "Maximum silent gap between narration segments is ${String.format("%.2f", maxSilentGapSec)}s (> 2.2s).",
                errorMessage = "Long silent gap detected (${String.format("%.1f", maxSilentGapSec)}s). Audio synchronization error."
            )
        }

        if (expectedSpeechScenes > 0 && coveragePercent < 38f) {
            return MasterAudioValidation(
                isValid = false,
                totalDurationSeconds = totalSec,
                speechDurationSeconds = speechSec,
                speechCoveragePercent = coveragePercent,
                maxSilentGapSeconds = maxSilentGapSec,
                scenesWithSpeechCount = actualSpeechScenes,
                totalScenesCount = sceneEntries.size,
                details = "Speech coverage is only ${String.format("%.1f", coveragePercent)}% (expected >= 38%).",
                errorMessage = "Audio timeline has excessive silence (${String.format("%.1f", coveragePercent)}% speech coverage)."
            )
        }

        return MasterAudioValidation(
            isValid = true,
            totalDurationSeconds = totalSec,
            speechDurationSeconds = speechSec,
            speechCoveragePercent = coveragePercent,
            maxSilentGapSeconds = maxSilentGapSec,
            scenesWithSpeechCount = actualSpeechScenes,
            totalScenesCount = sceneEntries.size,
            details = "Continuous narration timeline verified: ${actualSpeechScenes}/$expectedSpeechScenes scenes with voice, ${String.format("%.1f", coveragePercent)}% speech, max gap ${String.format("%.2f", maxSilentGapSec)}s."
        )
    }

    /**
     * Reads a WAV file of ANY sample rate (16k, 22.05k, 24k, 44.1k, 48k) and channel format,
     * performs linear interpolation resampling into 44.1kHz Stereo, inserts a small natural
     * 120ms lead-in, and renders into the master PCM buffer.
     * Returns the count of active speech samples.
     */
    private fun renderWavIntoPcmBuffer(
        file: File,
        buffer: ShortArray,
        startSample: Int,
        maxSamples: Int,
        speechMask: BooleanArray
    ): Int {
        try {
            val bytes = file.readBytes()
            if (bytes.size <= 44) return 0

            // Robust parsing of RIFF WAVE chunks
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val riff = String(bytes, 0, 4)
            val wave = String(bytes, 8, 4)
            if (riff != "RIFF" || wave != "WAVE") {
                Log.w(TAG, "Invalid WAV signature in ${file.name}")
                return 0
            }

            var offset = 12
            var channels = 1
            var srcSampleRate = 44100
            var bitsPerSample = 16
            var pcmDataOffset = -1
            var pcmDataLength = 0

            while (offset + 8 <= bytes.size) {
                val chunkId = String(bytes, offset, 4)
                val chunkSize = bb.getInt(offset + 4)
                if (chunkId == "fmt ") {
                    channels = bb.getShort(offset + 10).toInt().coerceAtLeast(1)
                    srcSampleRate = bb.getInt(offset + 12).coerceAtLeast(8000)
                    bitsPerSample = bb.getShort(offset + 22).toInt()
                } else if (chunkId == "data") {
                    pcmDataOffset = offset + 8
                    pcmDataLength = minOf(chunkSize, bytes.size - pcmDataOffset)
                    break
                }
                offset += 8 + chunkSize
            }

            if (pcmDataOffset == -1 || pcmDataLength <= 0 || bitsPerSample != 16) {
                pcmDataOffset = 44
                pcmDataLength = bytes.size - 44
                channels = bb.getShort(22).toInt().coerceAtLeast(1)
                srcSampleRate = bb.getInt(24).coerceAtLeast(8000)
            }

            val srcCount = pcmDataLength / (2 * channels)
            if (srcCount <= 0) return 0

            // Extract source 16-bit PCM samples into memory
            val srcLeft = ShortArray(srcCount)
            val srcRight = ShortArray(srcCount)
            for (i in 0 until srcCount) {
                val byteOffset = pcmDataOffset + i * channels * 2
                if (byteOffset + 2 > bytes.size) break
                val s1 = bb.getShort(byteOffset)
                val s2 = if (channels > 1 && byteOffset + 4 <= bytes.size) bb.getShort(byteOffset + 2) else s1
                srcLeft[i] = s1
                srcRight[i] = s2
            }

            // High-quality linear interpolation resampling:
            // srcSampleRate -> SAMPLE_RATE (44100 Hz)
            // This guarantees 1.0s of audio occupies exactly 1.0s (44100 samples) in the master buffer,
            // preventing the 2x speedup and resulting 15-second silent gaps!
            val resampledCount = ((srcCount.toDouble() * SAMPLE_RATE) / srcSampleRate).toInt()

            // Small 120ms lead-in so narration starts naturally after scene cut
            val leadIn = (0.120 * SAMPLE_RATE).toInt().coerceAtMost(maxSamples / 8)
            val usableDestSamples = minOf(resampledCount, maxSamples - leadIn)

            var speechSampleCount = 0
            val hangoverSamples = (0.150 * SAMPLE_RATE).toInt() // 150ms speech envelope hangover
            var currentHangover = 0

            for (j in 0 until usableDestSamples) {
                val targetIndex = startSample + leadIn + j
                if (targetIndex >= speechMask.size) break

                val srcPos = (j.toDouble() * srcSampleRate) / SAMPLE_RATE
                val idx0 = srcPos.toInt().coerceIn(0, srcCount - 1)
                val idx1 = (idx0 + 1).coerceIn(0, srcCount - 1)
                val frac = (srcPos - idx0).toFloat()

                val interpLeft = (srcLeft[idx0] * (1f - frac) + srcLeft[idx1] * frac).toInt().toShort()
                val interpRight = (srcRight[idx0] * (1f - frac) + srcRight[idx1] * frac).toInt().toShort()

                buffer[targetIndex * 2] = interpLeft
                buffer[targetIndex * 2 + 1] = interpRight

                // Mark speech active above ambient noise threshold with envelope smoothing
                if (Math.abs(interpLeft.toInt()) > 350 || Math.abs(interpRight.toInt()) > 350) {
                    currentHangover = hangoverSamples
                    speechSampleCount++
                }

                if (currentHangover > 0) {
                    speechMask[targetIndex] = true
                    currentHangover--
                }
            }

            Log.d(TAG, "Rendered ${file.name}: srcRate=$srcSampleRate, srcCount=$srcCount, resampledCount=$resampledCount, leadIn=$leadIn, speechSamples=$speechSampleCount")
            return speechSampleCount
        } catch (e: Exception) {
            Log.w(TAG, "Error rendering WAV into buffer: ${e.message}")
            return 0
        }
    }

    private fun decodeAudioUriToPcm(context: Context, uri: Uri, totalRequiredSamples: Int): ShortArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null

        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = selectAudioTrack(extractor)
            if (trackIndex < 0) return ShortArray(0)

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return ShortArray(0)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val outputStream = ByteArrayOutputStream()
            val bufferInfo = MediaCodec.BufferInfo()
            var isEos = false
            val timeoutUsec = 8000L

            while (!isEos && outputStream.size() < totalRequiredSamples * CHANNELS * BYTES_PER_SAMPLE) {
                val inputIndex = codec.dequeueInputBuffer(timeoutUsec)
                if (inputIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inputIndex)
                    if (inputBuffer != null) {
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isEos = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                var outputIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUsec)
                while (outputIndex >= 0) {
                    val outputBuffer = codec.getOutputBuffer(outputIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.get(chunk)
                        outputStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    outputIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
                }
            }

            val rawBytes = outputStream.toByteArray()
            if (rawBytes.isEmpty()) return ShortArray(0)

            val shortCount = rawBytes.size / 2
            val shortBuffer = ShortArray(shortCount)
            ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shortBuffer)

            // Loop music to fill totalRequiredSamples if music is shorter than video
            val result = ShortArray(totalRequiredSamples * CHANNELS)
            for (i in 0 until (totalRequiredSamples * CHANNELS)) {
                result[i] = shortBuffer[i % shortCount]
            }
            return result

        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Exception) {}
            try {
                extractor.release()
            } catch (_: Exception) {}
        }
    }

    private fun selectAudioTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) return i
        }
        return -1
    }

    private fun clampSample(value: Int): Short {
        return when {
            value > Short.MAX_VALUE -> Short.MAX_VALUE
            value < Short.MIN_VALUE -> Short.MIN_VALUE
            else -> value.toShort()
        }
    }

    private fun writePcmToWavFile(pcm: ShortArray, file: File, sampleRate: Int, channels: Int) {
        val byteData = ByteArray(pcm.size * 2)
        ByteBuffer.wrap(byteData).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm)

        val totalDataLen = byteData.size + 36
        val byteRate = sampleRate * channels * 2

        FileOutputStream(file).use { out ->
            val header = ByteArray(44)
            header[0] = 'R'.code.toByte() // RIFF
            header[1] = 'I'.code.toByte()
            header[2] = 'F'.code.toByte()
            header[3] = 'F'.code.toByte()
            header[4] = (totalDataLen and 0xff).toByte()
            header[5] = ((totalDataLen shr 8) and 0xff).toByte()
            header[6] = ((totalDataLen shr 16) and 0xff).toByte()
            header[7] = ((totalDataLen shr 24) and 0xff).toByte()
            header[8] = 'W'.code.toByte() // WAVE
            header[9] = 'A'.code.toByte()
            header[10] = 'V'.code.toByte()
            header[11] = 'E'.code.toByte()
            header[12] = 'f'.code.toByte() // 'fmt ' chunk
            header[13] = 'm'.code.toByte()
            header[14] = 't'.code.toByte()
            header[15] = ' '.code.toByte()
            header[16] = 16 // 4 bytes: size of 'fmt ' chunk
            header[17] = 0
            header[18] = 0
            header[19] = 0
            header[20] = 1 // format = 1 (PCM)
            header[21] = 0
            header[22] = channels.toByte()
            header[23] = 0
            header[24] = (sampleRate and 0xff).toByte()
            header[25] = ((sampleRate shr 8) and 0xff).toByte()
            header[26] = ((sampleRate shr 16) and 0xff).toByte()
            header[27] = ((sampleRate shr 24) and 0xff).toByte()
            header[28] = (byteRate and 0xff).toByte()
            header[29] = ((byteRate shr 8) and 0xff).toByte()
            header[30] = ((byteRate shr 16) and 0xff).toByte()
            header[31] = ((byteRate shr 24) and 0xff).toByte()
            header[32] = (channels * 2).toByte() // block align
            header[33] = 0
            header[34] = 16 // bits per sample
            header[35] = 0
            header[36] = 'd'.code.toByte() // data chunk
            header[37] = 'a'.code.toByte()
            header[38] = 't'.code.toByte()
            header[39] = 'a'.code.toByte()
            header[40] = (byteData.size and 0xff).toByte()
            header[41] = ((byteData.size shr 8) and 0xff).toByte()
            header[42] = ((byteData.size shr 16) and 0xff).toByte()
            header[43] = ((byteData.size shr 24) and 0xff).toByte()

            out.write(header, 0, 44)
            out.write(byteData)
        }
    }
}
