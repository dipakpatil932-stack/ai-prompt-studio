package com.example.data.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Audio processing engine that:
 * 1. Sequences multiple scene narration WAV files with precise timing/padding matching scene durations.
 * 2. Decodes background music (MP3/M4A/AAC/WAV) from user device into PCM.
 * 3. Applies intelligent audio ducking: reduces background music volume (e.g., 20%) while narration speaks,
 *    and smoothly restores music volume (e.g., 60-70%) during pauses and between scenes.
 * 4. Renders the composited PCM audio into a single synchronized master audio file (.wav) for MP4 muxing.
 */
class StoryAudioMixer(private val context: Context) {

    companion object {
        private const val TAG = "StoryAudioMixer"
        const val SAMPLE_RATE = 44100
        const val CHANNELS = 2 // Stereo
        private const val BYTES_PER_SAMPLE = 2 // 16-bit PCM
        private const val NARRATION_VOLUME = 1.0f
        private const val BG_MUSIC_DUCKED_VOLUME = 0.18f
        private const val BG_MUSIC_NORMAL_VOLUME = 0.65f
    }

    data class SceneAudioEntry(
        val sceneNumber: Int,
        val sceneDurationSeconds: Int,
        val narrationWavPath: String?
    )

    /**
     * Builds a single synchronized master audio WAV file combining scene narration tracks
     * and background music with automatic ducking.
     */
    fun createMasterAudioTrack(
        sceneEntries: List<SceneAudioEntry>,
        bgMusicUri: Uri?,
        isMusicMuted: Boolean,
        outputFile: File
    ): Boolean {
        try {
            outputFile.parentFile?.mkdirs()
            if (outputFile.exists()) outputFile.delete()

            val totalDurationSeconds = sceneEntries.sumOf { it.sceneDurationSeconds }
            if (totalDurationSeconds <= 0) return false

            val totalSamples = totalDurationSeconds * SAMPLE_RATE
            val narrationPcm = ShortArray(totalSamples * CHANNELS)
            val speechActiveMask = BooleanArray(totalSamples)

            // 1. Render all scene narrations into the narration PCM buffer
            var currentSampleOffset = 0
            for (scene in sceneEntries) {
                val sceneSampleCount = scene.sceneDurationSeconds * SAMPLE_RATE
                val path = scene.narrationWavPath

                if (!path.isNullOrBlank()) {
                    val file = File(path)
                    if (file.exists() && file.length() > 44) {
                        renderWavIntoPcmBuffer(
                            file = file,
                            buffer = narrationPcm,
                            startSample = currentSampleOffset,
                            maxSamples = sceneSampleCount,
                            speechMask = speechActiveMask
                        )
                    }
                }

                currentSampleOffset += sceneSampleCount
            }

            // 2. Decode background music if provided and not muted
            var bgMusicPcm: ShortArray? = null
            if (bgMusicUri != null && !isMusicMuted) {
                try {
                    bgMusicPcm = decodeAudioUriToPcm(context, bgMusicUri, totalSamples)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not decode background music, continuing without music: ${e.message}")
                }
            }

            // 3. Composite narration + background music with ducking
            val finalMixedPcm = ShortArray(totalSamples * CHANNELS)
            val bgPcm = bgMusicPcm

            var currentDuckingVolume = if (speechActiveMask.isNotEmpty() && speechActiveMask[0]) BG_MUSIC_DUCKED_VOLUME else BG_MUSIC_NORMAL_VOLUME
            val smoothingFactor = 0.005f // Smooth audio ducking transition across frames

            for (i in 0 until totalSamples) {
                val isSpeechActive = speechActiveMask[i]
                val targetBgVolume = if (isSpeechActive) BG_MUSIC_DUCKED_VOLUME else BG_MUSIC_NORMAL_VOLUME
                currentDuckingVolume += (targetBgVolume - currentDuckingVolume) * smoothingFactor

                val leftNarration = narrationPcm[i * 2].toFloat() * NARRATION_VOLUME
                val rightNarration = narrationPcm[i * 2 + 1].toFloat() * NARRATION_VOLUME

                val leftBg = if (bgPcm != null && (i * 2 + 1) < bgPcm.size) {
                    bgPcm[i * 2].toFloat() * currentDuckingVolume
                } else 0f

                val rightBg = if (bgPcm != null && (i * 2 + 1) < bgPcm.size) {
                    bgPcm[i * 2 + 1].toFloat() * currentDuckingVolume
                } else 0f

                // Mix & Soft Clip
                finalMixedPcm[i * 2] = clampSample((leftNarration + leftBg).toInt())
                finalMixedPcm[i * 2 + 1] = clampSample((rightNarration + rightBg).toInt())
            }

            // 4. Write final PCM buffer to standard 44.1kHz Stereo 16-bit WAV file
            writePcmToWavFile(finalMixedPcm, outputFile, SAMPLE_RATE, CHANNELS)
            return outputFile.exists() && outputFile.length() > 44

        } catch (e: Exception) {
            Log.e(TAG, "Error mixing master audio track", e)
            return false
        }
    }

    private fun renderWavIntoPcmBuffer(
        file: File,
        buffer: ShortArray,
        startSample: Int,
        maxSamples: Int,
        speechMask: BooleanArray
    ) {
        try {
            val bytes = file.readBytes()
            if (bytes.size <= 44) return

            // Parse WAV header
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val channels = bb.getShort(22).toInt()
            val sampleRate = bb.getInt(24)
            val bitsPerSample = bb.getShort(34).toInt()

            val pcmDataOffset = 44
            val pcmDataLength = bytes.size - pcmDataOffset
            val sampleCount = if (bitsPerSample == 16) pcmDataLength / (2 * channels) else 0

            val usableSamples = minOf(sampleCount, maxSamples)

            for (i in 0 until usableSamples) {
                val targetIndex = startSample + i
                if (targetIndex >= speechMask.size) break

                val sampleOffset = pcmDataOffset + i * channels * 2
                if (sampleOffset + 2 > bytes.size) break

                val leftSample = bb.getShort(sampleOffset)
                val rightSample = if (channels > 1 && sampleOffset + 4 <= bytes.size) bb.getShort(sampleOffset + 2) else leftSample

                buffer[targetIndex * 2] = leftSample
                buffer[targetIndex * 2 + 1] = rightSample

                // Mark speech active if above noise floor
                if (Math.abs(leftSample.toInt()) > 400 || Math.abs(rightSample.toInt()) > 400) {
                    speechMask[targetIndex] = true
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error rendering WAV into buffer: ${e.message}")
        }
    }

    private fun decodeAudioUriToPcm(context: Context, uri: Uri, totalRequiredSamples: Int): ShortArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null

        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = selectAudioTrack(extractor)
            if (trackIndex < 0) return ShortArray(0)

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return ShortArray(0)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val outputStream = ByteArrayOutputStream()
            val bufferInfo = MediaCodec.BufferInfo()
            var isEos = false
            val timeoutUsec = 8000L

            while (!isEos && outputStream.size() < totalRequiredSamples * CHANNELS * BYTES_PER_SAMPLE) {
                val inputIndex = codec.dequeueInputBuffer(timeoutUsec)
                if (inputIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inputIndex)
                    if (inputBuffer != null) {
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isEos = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                var outputIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUsec)
                while (outputIndex >= 0) {
                    val outputBuffer = codec.getOutputBuffer(outputIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.get(chunk)
                        outputStream.write(chunk)
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    outputIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
                }
            }

            val rawBytes = outputStream.toByteArray()
            if (rawBytes.isEmpty()) return ShortArray(0)

            val shortCount = rawBytes.size / 2
            val shortBuffer = ShortArray(shortCount)
            ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shortBuffer)

            // Loop music to fill totalRequiredSamples if music is shorter than video
            val result = ShortArray(totalRequiredSamples * CHANNELS)
            for (i in 0 until (totalRequiredSamples * CHANNELS)) {
                result[i] = shortBuffer[i % shortCount]
            }
            return result

        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Exception) {}
            try {
                extractor.release()
            } catch (_: Exception) {}
        }
    }

    private fun selectAudioTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) return i
        }
        return -1
    }

    private fun clampSample(value: Int): Short {
        return when {
            value > Short.MAX_VALUE -> Short.MAX_VALUE
            value < Short.MIN_VALUE -> Short.MIN_VALUE
            else -> value.toShort()
        }
    }

    private fun writePcmToWavFile(pcm: ShortArray, file: File, sampleRate: Int, channels: Int) {
        val byteData = ByteArray(pcm.size * 2)
        ByteBuffer.wrap(byteData).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(pcm)

        val totalDataLen = byteData.size + 36
        val byteRate = sampleRate * channels * 2

        FileOutputStream(file).use { out ->
            val header = ByteArray(44)
            header[0] = 'R'.code.toByte() // RIFF
            header[1] = 'I'.code.toByte()
            header[2] = 'F'.code.toByte()
            header[3] = 'F'.code.toByte()
            header[4] = (totalDataLen and 0xff).toByte()
            header[5] = ((totalDataLen shr 8) and 0xff).toByte()
            header[6] = ((totalDataLen shr 16) and 0xff).toByte()
            header[7] = ((totalDataLen shr 24) and 0xff).toByte()
            header[8] = 'W'.code.toByte() // WAVE
            header[9] = 'A'.code.toByte()
            header[10] = 'V'.code.toByte()
            header[11] = 'E'.code.toByte()
            header[12] = 'f'.code.toByte() // 'fmt ' chunk
            header[13] = 'm'.code.toByte()
            header[14] = 't'.code.toByte()
            header[15] = ' '.code.toByte()
            header[16] = 16 // 4 bytes: size of 'fmt ' chunk
            header[17] = 0
            header[18] = 0
            header[19] = 0
            header[20] = 1 // format = 1 (PCM)
            header[21] = 0
            header[22] = channels.toByte()
            header[23] = 0
            header[24] = (sampleRate and 0xff).toByte()
            header[25] = ((sampleRate shr 8) and 0xff).toByte()
            header[26] = ((sampleRate shr 16) and 0xff).toByte()
            header[27] = ((sampleRate shr 24) and 0xff).toByte()
            header[28] = (byteRate and 0xff).toByte()
            header[29] = ((byteRate shr 8) and 0xff).toByte()
            header[30] = ((byteRate shr 16) and 0xff).toByte()
            header[31] = ((byteRate shr 24) and 0xff).toByte()
            header[32] = (channels * 2).toByte() // block align
            header[33] = 0
            header[34] = 16 // bits per sample
            header[35] = 0
            header[36] = 'd'.code.toByte() // data chunk
            header[37] = 'a'.code.toByte()
            header[38] = 't'.code.toByte()
            header[39] = 'a'.code.toByte()
            header[40] = (byteData.size and 0xff).toByte()
            header[41] = ((byteData.size shr 8) and 0xff).toByte()
            header[42] = ((byteData.size shr 16) and 0xff).toByte()
            header[43] = ((byteData.size shr 24) and 0xff).toByte()

            out.write(header, 0, 44)
            out.write(byteData)
        }
    }
}
