package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.SceneItem
import org.json.JSONArray
import org.json.JSONObject

class Converters {
    @TypeConverter
    fun fromSceneList(scenes: List<SceneItem>?): String {
        if (scenes == null) return "[]"
        val array = JSONArray()
        for (scene in scenes) {
            val obj = JSONObject()
            obj.put("sceneNumber", scene.sceneNumber)
            obj.put("duration", scene.duration)
            obj.put("visualPrompt", scene.visualPrompt)
            obj.put("dialogue", scene.dialogue)
            obj.put("camera", scene.camera)
            obj.put("lighting", scene.lighting)
            obj.put("audio", scene.audio)
            obj.put("continuity", scene.continuity)
            obj.put("imagePrompt", scene.imagePrompt)
            obj.put("videoPrompt", scene.videoPrompt)
            obj.put("facialExpression", scene.facialExpression)
            obj.put("voiceInstruction", scene.voiceInstruction)
            array.put(obj)
        }
        return array.toString()
    }

    @TypeConverter
    fun toSceneList(json: String?): List<SceneItem> {
        if (json.isNullOrBlank()) return emptyList()
        val list = mutableListOf<SceneItem>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    SceneItem(
                        sceneNumber = obj.optInt("sceneNumber", i + 1),
                        duration = obj.optString("duration", "8–10 seconds"),
                        visualPrompt = obj.optString("visualPrompt", ""),
                        dialogue = obj.optString("dialogue", ""),
                        camera = obj.optString("camera", ""),
                        lighting = obj.optString("lighting", ""),
                        audio = obj.optString("audio", ""),
                        continuity = obj.optString("continuity", "Same characters, clothing, hairstyle, age and appearance as previous scenes."),
                        imagePrompt = obj.optString("imagePrompt", ""),
                        videoPrompt = obj.optString("videoPrompt", ""),
                        facialExpression = obj.optString("facialExpression", ""),
                        voiceInstruction = obj.optString("voiceInstruction", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }
}
