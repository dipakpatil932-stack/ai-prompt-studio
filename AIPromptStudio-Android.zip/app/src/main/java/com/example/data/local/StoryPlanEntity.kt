package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.SceneItem
import com.example.data.model.StoryPlan

@Entity(tableName = "story_plans")
data class StoryPlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val storyType: String,
    val originalPrompt: String,
    val duration: String,
    val aspectRatio: String,
    val characterPrompts: String,
    val characterConsistency: String,
    val visualStyle: String,
    val negativePrompt: String,
    val finalMessage: String,
    val scenes: List<SceneItem>,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toDomain(): StoryPlan = StoryPlan(
        id = id,
        title = title,
        storyType = storyType,
        originalPrompt = originalPrompt,
        duration = duration,
        aspectRatio = aspectRatio,
        characterPrompts = characterPrompts,
        characterConsistency = characterConsistency,
        visualStyle = visualStyle,
        negativePrompt = negativePrompt,
        finalMessage = finalMessage,
        scenes = scenes,
        timestamp = timestamp
    )

    companion object {
        fun fromDomain(plan: StoryPlan): StoryPlanEntity = StoryPlanEntity(
            id = plan.id,
            title = plan.title,
            storyType = plan.storyType,
            originalPrompt = plan.originalPrompt,
            duration = plan.duration,
            aspectRatio = plan.aspectRatio,
            characterPrompts = plan.characterPrompts,
            characterConsistency = plan.characterConsistency,
            visualStyle = plan.visualStyle,
            negativePrompt = plan.negativePrompt,
            finalMessage = plan.finalMessage,
            scenes = plan.scenes,
            timestamp = plan.timestamp
        )
    }
}
