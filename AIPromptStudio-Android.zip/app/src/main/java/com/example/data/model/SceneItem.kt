package com.example.data.model

data class SceneItem(
    val sceneNumber: Int,
    val duration: String = "8–10 seconds",
    val visualPrompt: String,
    val dialogue: String,
    val camera: String,
    val lighting: String,
    val audio: String,
    val continuity: String = "Same characters, clothing, hairstyle, age and appearance as previous scenes.",
    val imagePrompt: String = "",
    val videoPrompt: String = "",
    val facialExpression: String = "",
    val voiceInstruction: String = ""
)
