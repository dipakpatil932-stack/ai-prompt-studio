package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserSettings
import com.example.data.model.VideoProviderType

@Composable
fun HomeScreen(
    settings: UserSettings,
    isProviderConfigured: Boolean,
    onNavigateToFreeVideoMaker: () -> Unit,
    onNavigateToGenerateVideo: () -> Unit,
    onNavigateToStoryToVideo: () -> Unit,
    onNavigateToImagePrompt: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToAllInOneCreator: () -> Unit = {},
    onNavigateToAnimateImage: () -> Unit = {},
    onNavigateToImageStudio: () -> Unit = {},
    onNavigateToVoiceStudio: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header & Greeting
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(46.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Logo",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(10.dp)
                                    .fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AI Story-to-Video",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "कहानी से एआई वीडियो बनाएं",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Settings Icon Shortcut
                    Surface(
                        onClick = onNavigateToSettings,
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .padding(10.dp)
                                .fillMaxSize()
                        )
                    }
                }
            }
        }

        // Provider Status Banner
        item {
            val isFreeMode = settings.providerType == VideoProviderType.FREE_MODE
            val providerName = settings.providerType.displayName
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = when {
                    isFreeMode -> Color(0xFFECFDF5)
                    isProviderConfigured -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    else -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                },
                border = if (isFreeMode) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6EE7B7)) else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToSettings() }
                    .testTag("provider_status_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (isFreeMode || isProviderConfigured) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = when {
                                isFreeMode -> Color(0xFF059669)
                                isProviderConfigured -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.error
                            },
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = when {
                                    isFreeMode -> "AI Video Engine: 100% Free Mode (Active)"
                                    isProviderConfigured -> "AI Video Engine: $providerName (Active)"
                                    else -> "AI Video Setup Needed ($providerName)"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    isFreeMode -> Color(0xFF065F46)
                                    isProviderConfigured -> MaterialTheme.colorScheme.onPrimaryContainer
                                    else -> MaterialTheme.colorScheme.onErrorContainer
                                }
                            )
                            Text(
                                text = when {
                                    isFreeMode -> "On-device animated video generator & Hindi voiceover ready • No API key needed"
                                    isProviderConfigured -> "Ready for real video generation • Tap to view settings"
                                    else -> "Tap here to configure API Key or Server in Settings"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = if (isFreeMode) Color(0xFF047857) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Go",
                        tint = if (isFreeMode) Color(0xFF059669) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // 0. FEATURED: All-in-One 8-Step Story Video Studio
        item {
            Card(
                onClick = onNavigateToAllInOneCreator,
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_hero_all_in_one_creator")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF4338CA), Color(0xFF7C3AED))
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.22f)
                        ) {
                            Text(
                                text = "ALL-IN-ONE 8-STEP STUDIO",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "All-in-One Story Video Creator",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "1. Story -> 2. Characters -> 3. Images -> 4. Animate -> 5. Hindi Voice -> 6. Music/Subs -> 7. Preview -> 8. Export MP4",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.92f),
                            lineHeight = 17.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onNavigateToAllInOneCreator,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4338CA)),
                            modifier = Modifier.fillMaxWidth().height(46.dp).testTag("btn_open_all_in_one")
                        ) {
                            Text("Launch 8-Step Studio ->", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // 1. PROMINENT HERO CARD: 🎬 Free Video Maker (फ्री वीडियो मेकर)
        item {
            Card(
                onClick = onNavigateToFreeVideoMaker,
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_hero_free_video_maker")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xFF047857),
                                    Color(0xFF10B981)
                                )
                            )
                        )
                        .padding(22.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = "✨ 100% FREE • NO API KEY NEEDED",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "🎬 Free Video Maker",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "फ्री वीडियो मेकर (फोटो, कैप्शन व वॉइस से असली MP4 वीडियो बनाएं)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.95f)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Combine your phone gallery photos, scene captions, and audio into an actual playable MP4 slideshow video on-device. Works in Hindi, Gujarati, and English.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onNavigateToFreeVideoMaker,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color(0xFF047857)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("btn_open_free_video_maker")
                        ) {
                            Text(
                                text = "Open Free Video Maker (शुरू करें) ➔",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // 2. AI Video Generation (Cloud AI API / Requires API Key)
        item {
            Card(
                onClick = onNavigateToGenerateVideo,
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_hero_generate_video")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary,
                                    Color(0xFFEA580C)
                                )
                            )
                        )
                        .padding(22.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = "⚡ AI MOTION VIDEO (API/CREDITS)",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "🎥 AI Video Generation (Veo / Luma)",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "गूगल Veo से AI मोशन वीडियो (Requires API Key)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.9f)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Enter a story idea and generate realistic AI motion video using Google Veo or Luma Dream Machine via API.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onNavigateToGenerateVideo,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color(0xFFB45309)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text(
                                text = "Start AI Generation (AI वीडियो बनाएं) ➔",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // New Creative Tools Section
        item {
            Text(
                text = "Creative AI Tools (रचनात्मक टूल्स):",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        item {
            HomeOptionCard(
                icon = Icons.Default.Animation,
                title = "Animate Images into Video",
                hindiSubtitle = "गैलरी फोटो को एनिमेटेड MP4 वीडियो में बदलें",
                description = "Upload a photo and create smooth 25fps camera motion (Zoom, Pan, Drift, Parallax) MP4s or optional Google Veo I2V.",
                badge = "9:16 • 4:5",
                tag = "home_opt_animate_image",
                onClick = onNavigateToAnimateImage
            )
        }

        item {
            HomeOptionCard(
                icon = Icons.Default.Brush,
                title = "Create & Edit AI Images",
                hindiSubtitle = "3D कार्टून व रियलिस्टिक फोटो जनरेटर और एडिटर",
                description = "Generate 3D cartoon or realistic visuals and edit uploaded gallery photos with text instructions.",
                badge = "3D • Real",
                tag = "home_opt_image_studio",
                onClick = onNavigateToImageStudio
            )
        }

        item {
            HomeOptionCard(
                icon = Icons.Default.RecordVoiceOver,
                title = "AI Voice & Text-to-Speech",
                hindiSubtitle = "हिंदी, गुजराती व अंग्रेज़ी वॉइस और ऑडियो डाउनलोड",
                description = "Male/Female voices, speed & pitch sliders, instant playback preview, consistent narrator voice, and downloadable MP3/M4A audio.",
                badge = "HI • EN • GU",
                tag = "home_opt_voice_studio",
                onClick = onNavigateToVoiceStudio
            )
        }

        // Menu Section Header
        item {
            Text(
                text = "Other Studio Features (अन्य विकल्प):",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // 2. 📖 Story to Video (कहानी से वीडियो)
        item {
            HomeOptionCard(
                icon = Icons.AutoMirrored.Filled.MenuBook,
                title = "2. 📖 Story to Video",
                hindiSubtitle = "पूरी कहानी से मल्टी-सीन वीडियो स्क्रिप्ट व प्लान",
                description = "Director mode: Turn Hindi stories into scene-by-scene production plans with dialogues, camera cues, and character consistency.",
                badge = "Director Script",
                tag = "home_opt_story_to_video",
                onClick = onNavigateToStoryToVideo
            )
        }

        // 3. 🖼️ Image Prompt (इमेज प्रॉम्प्ट)
        item {
            HomeOptionCard(
                icon = Icons.Default.Image,
                title = "3. 🖼️ Image Prompt",
                hindiSubtitle = "4K इमेज प्रॉम्प्ट जनरेटर (Midjourney / Flux)",
                description = "Generate photorealistic 4K prompts for Indian cinematic scenes, havelis, characters, and costumes.",
                badge = "4K Visuals",
                tag = "home_opt_image_prompt",
                onClick = onNavigateToImagePrompt
            )
        }

        // 4. 🕘 My Videos / History (माई वीडियोज़ / इतिहास)
        item {
            HomeOptionCard(
                icon = Icons.Default.History,
                title = "4. 🕘 My Videos / History",
                hindiSubtitle = "सहेजे गए वीडियो और स्क्रिप्ट इतिहास",
                description = "Access all your generated videos, offline MP4 playback, share files to WhatsApp, and retry failed jobs.",
                badge = "Saved Library",
                tag = "home_opt_history",
                onClick = onNavigateToHistory
            )
        }

        // 5. ⚙️ Settings (सेटिंग्स)
        item {
            HomeOptionCard(
                icon = Icons.Default.Settings,
                title = "5. ⚙️ Settings",
                hindiSubtitle = "वीडियो इंजन और API सेटिंग्स",
                description = "Configure Google Veo, Luma Dream Machine, Runway, or custom backend server. Test connection in one tap.",
                badge = "Config & API",
                tag = "home_opt_settings",
                onClick = onNavigateToSettings
            )
        }
    }
}

@Composable
private fun HomeOptionCard(
    icon: ImageVector,
    title: String,
    hindiSubtitle: String,
    description: String,
    badge: String,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = hindiSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = badge,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}
