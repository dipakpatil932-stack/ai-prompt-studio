package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.StoryAudioMixer
import com.example.data.audio.StoryVoiceManager
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferences
import com.example.data.local.VideoRepository
import com.example.data.media.ImageImportHelper
import com.example.data.model.AllInOneStep
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.MotionEffect
import com.example.data.model.StoryCharacter
import com.example.data.model.StoryEmotion
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import com.example.data.model.VoiceGender
import com.example.data.remote.FreeVideoStoryGenerator
import com.example.data.remote.GoogleAiStudioService
import com.example.data.remote.video.VideoGenerationService
import com.example.data.video.Mp4SlideshowEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

sealed class PendingPaidAction {
    data class GenerateSceneImage(val sceneIndex: Int) : PendingPaidAction()
    data class AnimateSceneWithVeo(val sceneIndex: Int) : PendingPaidAction()
}

data class AllInOneCreatorUiState(
    val currentStep: AllInOneStep = AllInOneStep.STEP_1_STORY,
    val project: FreeVideoProject = FreeVideoProject(),
    val targetDurationSeconds: Int = 24,
    val isBusy: Boolean = false,
    val busyMessage: String = "",
    val isImportingImage: Boolean = false,
    val importingSceneIndex: Int = -1,
    val imageImportError: String? = null,
    val renderProgress: Float = 0f,
    val activePickerSceneIndex: Int = -1,
    val previewingSceneIndex: Int = -1,
    val isVoicePreviewPlaying: Boolean = false,
    val generatedVideoPath: String? = null,
    val savedToLibrary: Boolean = false,
    val pendingPaidAction: PendingPaidAction? = null,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null
)

class AllInOneCreatorViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "AllInOneCreatorVM"
    }

    private val aiService = GoogleAiStudioService()
    private val storyGenerator = FreeVideoStoryGenerator()
    private val voiceManager = StoryVoiceManager(application)
    private val audioMixer = StoryAudioMixer(application)
    private val encoder = Mp4SlideshowEncoder(application)
    private val videoService = VideoGenerationService(application)
    private val userPrefs = UserPreferences(application)
    private val videoRepo = VideoRepository(AppDatabase.getDatabase(application).videoJobDao())

    private var exportJob: Job? = null

    private val _uiState = MutableStateFlow(AllInOneCreatorUiState())
    val uiState: StateFlow<AllInOneCreatorUiState> = _uiState.asStateFlow()

    fun goToStep(step: AllInOneStep) {
        _uiState.update { it.copy(currentStep = step, errorMessage = null) }
    }

    fun nextStep() {
        val values = AllInOneStep.entries
        val idx = values.indexOf(_uiState.value.currentStep)
        if (idx < values.lastIndex) {
            goToStep(values[idx + 1])
        }
    }

    fun previousStep() {
        val values = AllInOneStep.entries
        val idx = values.indexOf(_uiState.value.currentStep)
        if (idx > 0) {
            goToStep(values[idx - 1])
        }
    }

    // ---- Step 1: Story Settings ----

    fun updateStoryPrompt(text: String) {
        _uiState.update { it.copy(project = it.project.copy(storyPrompt = text), errorMessage = null) }
    }

    fun selectLanguage(lang: String) {
        _uiState.update { it.copy(project = it.project.copy(language = lang)) }
    }

    fun selectAspectRatio(ratio: String) {
        _uiState.update { it.copy(project = it.project.copy(aspectRatio = ratio)) }
    }

    fun selectVideoStyle(style: VideoStyle) {
        _uiState.update { it.copy(project = it.project.copy(videoStyle = style)) }
    }

    fun selectTargetDuration(seconds: Int) {
        _uiState.update { it.copy(targetDurationSeconds = seconds) }
    }

    fun setSampleStory(text: String, language: String, style: VideoStyle) {
        _uiState.update {
            it.copy(
                project = it.project.copy(
                    storyPrompt = text,
                    language = language,
                    videoStyle = style,
                    emotion = StoryEmotion.detectEmotion(text)
                ),
                errorMessage = null
            )
        }
    }

    // ---- Step 2: Generate & Edit Consistent Characters ----

    fun generateCharactersAndAdvance() {
        val state = _uiState.value
        val story = state.project.storyPrompt.trim()
        if (story.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your story in Step 1 first (कृपया पहले कहानी लिखें).") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyMessage = "Extracting consistent characters (face, outfit & voice)...",
                    errorMessage = null
                )
            }
            val apiKey = userPrefs.getEffectiveGeminiApiKey()
            val result = aiService.generateConsistentCharacters(
                apiKey = apiKey,
                storyText = story,
                style = state.project.videoStyle,
                language = state.project.language
            )

            result.onSuccess { chars ->
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        busyMessage = "",
                        project = it.project.copy(characters = chars),
                        currentStep = AllInOneStep.STEP_2_CHARACTERS,
                        snackbarMessage = "${chars.size} consistent character(s) created!"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(isBusy = false, errorMessage = err.message ?: "Failed to build character sheet.")
                }
            }
        }
    }

    fun updateCharacter(index: Int, updated: StoryCharacter) {
        _uiState.update { state ->
            val mutable = state.project.characters.toMutableList()
            if (index in mutable.indices) {
                mutable[index] = updated
            }
            state.copy(project = state.project.copy(characters = mutable))
        }
    }

    fun addNewCharacter() {
        _uiState.update { state ->
            val num = state.project.characters.size + 1
            val newChar = StoryCharacter(
                name = "Character $num",
                age = "25",
                facialFeatures = "Expressive warm Indian face",
                hairAndStyle = "Neat dark hair",
                clothingAndColors = "Traditional festive kurta in saffron and cream",
                voiceGender = VoiceGender.FEMALE,
                voiceTone = "Clear & Friendly"
            )
            state.copy(project = state.project.copy(characters = state.project.characters + newChar))
        }
    }

    fun deleteCharacter(index: Int) {
        _uiState.update { state ->
            if (state.project.characters.size <= 1) return@update state
            val mutable = state.project.characters.toMutableList().apply { removeAt(index) }
            state.copy(project = state.project.copy(characters = mutable))
        }
    }

    // ---- Step 3: Scene Breakdown & AI/Gallery Images ----

    fun generateScenePromptsAndGoToStep3() {
        val state = _uiState.value
        val story = state.project.storyPrompt.trim()
        if (story.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a story first.") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyMessage = "Creating character-consistent storyboard scenes...",
                    errorMessage = null
                )
            }
            try {
                val proj = storyGenerator.generateStoryboard(
                    storyIdea = story,
                    language = state.project.language,
                    aspectRatio = state.project.aspectRatio,
                    targetDurationSeconds = state.targetDurationSeconds,
                    style = state.project.videoStyle,
                    characters = state.project.characters,
                    apiKeyOverride = userPrefs.getEffectiveGeminiApiKey()
                )
                // Preserve music, subtitle & character preferences from current project
                val merged = proj.copy(
                    characters = state.project.characters,
                    audioUri = state.project.audioUri,
                    bgMusicName = state.project.bgMusicName,
                    isMusicMuted = state.project.isMusicMuted,
                    showSubtitles = state.project.showSubtitles,
                    voiceGender = state.project.voiceGender,
                    speechRate = state.project.speechRate,
                    speechPitch = state.project.speechPitch
                )
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        busyMessage = "",
                        project = merged,
                        currentStep = AllInOneStep.STEP_3_IMAGES,
                        snackbarMessage = "${merged.scenes.size} scenes ready! Pick gallery photos or generate AI images."
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isBusy = false, errorMessage = "Storyboard generation failed: ${e.message}")
                }
            }
        }
    }

    fun setActiveSceneForPicker(sceneIndex: Int) {
        _uiState.update { it.copy(activePickerSceneIndex = sceneIndex) }
    }

    fun onSceneImagePicked(uri: String) {
        val idx = _uiState.value.activePickerSceneIndex
        if (idx < 0) return
        val app = getApplication<Application>()
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isImportingImage = true,
                    importingSceneIndex = idx,
                    imageImportError = null,
                    errorMessage = null
                )
            }
            val result = ImageImportHelper.importImageToLocalStorage(app, uri)
            result.onSuccess { imported ->
                _uiState.update { state ->
                    val scenes = state.project.scenes.toMutableList()
                    if (idx in scenes.indices) {
                        scenes[idx] = scenes[idx].copy(imageUri = imported.localFilePath)
                    }
                    state.copy(
                        project = state.project.copy(scenes = scenes),
                        activePickerSceneIndex = -1,
                        isImportingImage = false,
                        importingSceneIndex = -1,
                        imageImportError = null,
                        generatedVideoPath = null,
                        snackbarMessage = "Scene ${idx + 1} photo loaded: ${imported.displayName} (${imported.width}x${imported.height})"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        activePickerSceneIndex = -1,
                        isImportingImage = false,
                        importingSceneIndex = -1,
                        imageImportError = err.message ?: "Failed to load selected image.",
                        errorMessage = err.message ?: "Failed to load selected image."
                    )
                }
            }
        }
    }

    fun removeSceneImage(sceneIndex: Int) {
        _uiState.update { state ->
            val scenes = state.project.scenes.toMutableList()
            if (sceneIndex in scenes.indices) {
                scenes[sceneIndex] = scenes[sceneIndex].copy(imageUri = null)
            }
            state.copy(project = state.project.copy(scenes = scenes))
        }
    }

    fun requestGenerateAiImageForScene(sceneIndex: Int) {
        val apiKey = userPrefs.getEffectiveGeminiApiKey()
        if (apiKey.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Google AI Image API requires a Gemini API key in Settings (⚙️) or AI Studio Secrets. " +
                        "You can pick photos from your phone gallery completely free right here!"
                )
            }
            return
        }
        _uiState.update {
            it.copy(pendingPaidAction = PendingPaidAction.GenerateSceneImage(sceneIndex))
        }
    }

    // ---- Step 4: Motion & Optional Veo I2V ----

    fun updateSceneMotionEffect(sceneIndex: Int, effect: MotionEffect) {
        _uiState.update { state ->
            val scenes = state.project.scenes.toMutableList()
            if (sceneIndex in scenes.indices) {
                scenes[sceneIndex] = scenes[sceneIndex].copy(motionEffect = effect)
            }
            state.copy(project = state.project.copy(scenes = scenes), generatedVideoPath = null)
        }
    }

    fun updateSceneDuration(sceneIndex: Int, seconds: Int) {
        _uiState.update { state ->
            val scenes = state.project.scenes.toMutableList()
            if (sceneIndex in scenes.indices) {
                scenes[sceneIndex] = scenes[sceneIndex].copy(durationSeconds = seconds.coerceIn(2, 20))
            }
            state.copy(project = state.project.copy(scenes = scenes), generatedVideoPath = null)
        }
    }

    fun requestAnimateSceneWithVeo(sceneIndex: Int) {
        val scene = _uiState.value.project.scenes.getOrNull(sceneIndex) ?: return
        if (scene.imageUri.isNullOrBlank()) {
            _uiState.update { it.copy(errorMessage = "Pick or generate an image for Scene ${scene.sceneNumber} first.") }
            return
        }
        val apiKey = userPrefs.getEffectiveGeminiApiKey().ifBlank { userPrefs.settingsFlow.value.providerApiKey }
        if (apiKey.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Google Veo API key is missing. Add GEMINI_API_KEY in Settings, or use the built-in 100% Free 25fps Motion Effects (Zoom/Pan/Drift) on all scenes!"
                )
            }
            return
        }
        _uiState.update {
            it.copy(pendingPaidAction = PendingPaidAction.AnimateSceneWithVeo(sceneIndex))
        }
    }

    fun dismissPendingPaidAction() {
        _uiState.update { it.copy(pendingPaidAction = null) }
    }

    fun confirmPendingPaidAction() {
        val action = _uiState.value.pendingPaidAction ?: return
        _uiState.update { it.copy(pendingPaidAction = null) }
        when (action) {
            is PendingPaidAction.GenerateSceneImage -> executeGenerateSceneImage(action.sceneIndex)
            is PendingPaidAction.AnimateSceneWithVeo -> executeAnimateSceneWithVeo(action.sceneIndex)
        }
    }

    private fun executeGenerateSceneImage(sceneIndex: Int) {
        val state = _uiState.value
        val scene = state.project.scenes.getOrNull(sceneIndex) ?: return
        val apiKey = userPrefs.getEffectiveGeminiApiKey()

        viewModelScope.launch {
            updateSceneAt(sceneIndex) { it.copy(isGeneratingImage = true) }
            _uiState.update { it.copy(errorMessage = null) }

            val charContext = if (state.project.characters.isNotEmpty()) {
                "Keep character appearance identical: ${state.project.characters.joinToString("; ") { it.toConsistencyPrompt() }}. "
            } else ""

            val fullPrompt = "$charContext${scene.imagePrompt.ifBlank { scene.caption }}"
            val dir = File(getApplication<Application>().filesDir, "studio_scene_images").apply { mkdirs() }
            val outFile = File(dir, "scene_${scene.sceneNumber}_${System.currentTimeMillis()}.png")

            val result = aiService.generateImageWithGoogleAi(
                apiKey = apiKey,
                prompt = fullPrompt,
                style = state.project.videoStyle,
                aspectRatio = state.project.aspectRatio,
                outputFile = outFile
            )

            result.onSuccess { file ->
                updateSceneAt(sceneIndex) {
                    it.copy(isGeneratingImage = false, imageUri = file.absolutePath)
                }
                _uiState.update { it.copy(snackbarMessage = "Scene ${scene.sceneNumber} AI image generated!") }
            }.onFailure { err ->
                updateSceneAt(sceneIndex) { it.copy(isGeneratingImage = false) }
                _uiState.update { it.copy(errorMessage = err.message ?: "Google AI Image failed for Scene ${scene.sceneNumber}.") }
            }
        }
    }

    private fun executeAnimateSceneWithVeo(sceneIndex: Int) {
        val state = _uiState.value
        val scene = state.project.scenes.getOrNull(sceneIndex) ?: return
        val imageUri = scene.imageUri ?: return
        val apiKey = userPrefs.getEffectiveGeminiApiKey().ifBlank { userPrefs.settingsFlow.value.providerApiKey }

        viewModelScope.launch {
            updateSceneAt(sceneIndex) { it.copy(isAnimatingVideo = true) }
            _uiState.update { it.copy(errorMessage = null) }

            val base64 = encodeImageAsJpegBase64(imageUri)
            if (base64 == null) {
                updateSceneAt(sceneIndex) { it.copy(isAnimatingVideo = false) }
                _uiState.update { it.copy(errorMessage = "Could not read image for Veo animation.") }
                return@launch
            }

            val veoSettings = userPrefs.settingsFlow.value.copy(
                providerType = VideoProviderType.GOOGLE_VEO,
                providerApiKey = apiKey
            )
            val prompt = "${scene.imagePrompt.ifBlank { scene.caption }}. Motion: ${scene.motionEffect.promptDescription}."

            val sub = videoService.submitJob(
                prompt = prompt,
                style = state.project.videoStyle.displayName,
                aspectRatio = state.project.aspectRatio,
                duration = "${scene.durationSeconds.coerceIn(5, 8)} sec",
                dialogueLanguage = state.project.language,
                settings = veoSettings,
                imageBase64 = base64,
                imageMimeType = "image/jpeg"
            )

            sub.onFailure { err ->
                updateSceneAt(sceneIndex) { it.copy(isAnimatingVideo = false) }
                _uiState.update { it.copy(errorMessage = err.message ?: "Google Veo API request failed.") }
                return@launch
            }

            val submission = sub.getOrNull() ?: return@launch
            var elapsed = 0
            while (coroutineContext.isActive && elapsed < 180) {
                delay(4000)
                elapsed += 4
                val poll = videoService.pollJobStatus(submission.jobId, veoSettings, elapsed)
                if (poll.status == VideoJobStatus.COMPLETED && !poll.videoUrl.isNullOrBlank()) {
                    val dl = videoService.downloadVideoLocally(poll.videoUrl, submission.jobId, apiKey)
                    val path = dl.getOrNull() ?: poll.videoUrl
                    updateSceneAt(sceneIndex) {
                        it.copy(isAnimatingVideo = false, remoteVideoUrl = path)
                    }
                    _uiState.update { it.copy(snackbarMessage = "Scene ${scene.sceneNumber} animated with Google Veo!") }
                    return@launch
                } else if (poll.status == VideoJobStatus.FAILED) {
                    updateSceneAt(sceneIndex) { it.copy(isAnimatingVideo = false) }
                    _uiState.update { it.copy(errorMessage = poll.errorMessage ?: "Veo scene animation failed.") }
                    return@launch
                }
            }
            updateSceneAt(sceneIndex) { it.copy(isAnimatingVideo = false) }
        }
    }

    // ---- Step 5: Voiceover Synthesis & Sync ----

    fun selectVoiceGender(gender: VoiceGender) {
        _uiState.update { it.copy(project = it.project.copy(voiceGender = gender)) }
    }

    fun selectEmotion(emotion: StoryEmotion) {
        _uiState.update { it.copy(project = it.project.copy(emotion = emotion)) }
    }

    fun updateSpeechRate(rate: Float) {
        _uiState.update { it.copy(project = it.project.copy(speechRate = rate.coerceIn(0.6f, 1.5f))) }
    }

    fun updateSpeechPitch(pitch: Float) {
        _uiState.update { it.copy(project = it.project.copy(speechPitch = pitch.coerceIn(0.6f, 1.5f))) }
    }

    fun updateSceneNarration(sceneIndex: Int, narration: String) {
        updateSceneAt(sceneIndex) { it.copy(narrationText = narration, narrationAudioPath = null) }
    }

    fun generateConsistentHindiVoiceovers() {
        val state = _uiState.value
        if (state.project.scenes.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please create scenes in Step 3 first.") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyMessage = "Synthesizing consistent ${state.project.language} voice across all scenes...",
                    errorMessage = null
                )
            }
            try {
                val ready = voiceManager.awaitInitialization()
                if (!ready) {
                    Log.w(TAG, "TTS fallback synthesis used for AllInOne")
                }
                val voicedProject = voiceManager.synthesizeProjectVoiceover(state.project) { idx, total, msg ->
                    _uiState.update { it.copy(busyMessage = "[$idx/$total] $msg") }
                }

                // Auto-extend scenes if narration is longer than scene duration
                val synced = voicedProject.scenes.map { sc ->
                    val audioPath = sc.narrationAudioPath
                    if (!audioPath.isNullOrBlank()) {
                        val file = File(audioPath)
                        if (file.exists() && file.length() > 44) {
                            val durMs = voiceManager.computeWavDurationMs(file)
                            val neededSec = maxOf(3, Math.ceil((durMs + 350L) / 1000.0).toInt()).coerceIn(3, 30)
                            sc.copy(
                                durationSeconds = neededSec,
                                calculatedAudioDurationMs = durMs
                            )
                        } else sc
                    } else sc
                }

                _uiState.update {
                    it.copy(
                        isBusy = false,
                        busyMessage = "",
                        project = voicedProject.copy(scenes = synced),
                        generatedVideoPath = null,
                        snackbarMessage = "Consistent voiceover generated & synced across ${synced.size} scenes!"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isBusy = false, errorMessage = "Voice synthesis failed: ${e.message}")
                }
            }
        }
    }

    fun previewSceneVoice(sceneIndex: Int) {
        val state = _uiState.value
        val scene = state.project.scenes.getOrNull(sceneIndex) ?: return
        if (state.isVoicePreviewPlaying && state.previewingSceneIndex == sceneIndex) {
            voiceManager.stopPreview()
            _uiState.update { it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = -1) }
            return
        }

        _uiState.update { it.copy(isVoicePreviewPlaying = true, previewingSceneIndex = sceneIndex) }
        val wav = scene.narrationAudioPath
        if (!wav.isNullOrBlank() && File(wav).exists()) {
            voiceManager.playAudioFile(wav) {
                _uiState.update { it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = -1) }
            }
        } else {
            val text = scene.narrationText.ifBlank { scene.caption }.ifBlank { "Scene ${scene.sceneNumber}" }
            voiceManager.previewVoice(
                text = text,
                language = state.project.language,
                gender = state.project.voiceGender,
                emotion = state.project.emotion,
                speedMultiplier = state.project.speechRate,
                pitchMultiplier = state.project.speechPitch
            ) {
                _uiState.update { it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = -1) }
            }
        }
    }

    // ---- Step 6: Background Music & Subtitles ----

    fun toggleSubtitles(enabled: Boolean) {
        _uiState.update { it.copy(project = it.project.copy(showSubtitles = enabled), generatedVideoPath = null) }
    }

    fun setBackgroundMusic(uri: String?, name: String?) {
        _uiState.update {
            it.copy(
                project = it.project.copy(audioUri = uri, bgMusicName = name, isMusicMuted = false),
                generatedVideoPath = null
            )
        }
    }

    fun toggleMusicMute() {
        _uiState.update {
            it.copy(project = it.project.copy(isMusicMuted = !it.project.isMusicMuted), generatedVideoPath = null)
        }
    }

    fun updateSceneCaption(sceneIndex: Int, caption: String) {
        updateSceneAt(sceneIndex) { it.copy(caption = caption) }
    }

    // ---- Step 7 & Step 8: Render Complete Preview & Export MP4 ----

    fun renderCompletePreviewAndExport(moveToExportStep: Boolean = false) {
        val state = _uiState.value
        if (state.project.scenes.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "No scenes created yet. Complete Steps 1 to 3 first.") }
            return
        }

        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    renderProgress = 0.05f,
                    busyMessage = "Preparing complete voiceover & audio sync...",
                    errorMessage = null,
                    savedToLibrary = false
                )
            }

            try {
                // Ensure voiceovers are synthesized if missing
                var activeProject = _uiState.value.project
                if (activeProject.scenes.any { it.narrationAudioPath.isNullOrBlank() && it.narrationText.isNotBlank() }) {
                    _uiState.update { it.copy(busyMessage = "Generating missing scene voiceovers...", renderProgress = 0.12f) }
                    activeProject = voiceManager.synthesizeProjectVoiceover(activeProject) { _, _, msg ->
                        _uiState.update { it.copy(busyMessage = msg) }
                    }
                    _uiState.update { it.copy(project = activeProject) }
                }

                // Mix master audio track
                _uiState.update { it.copy(busyMessage = "Mixing narration & background music...", renderProgress = 0.28f) }
                val audioDir = File(getApplication<Application>().cacheDir, "allinone_audio").apply { mkdirs() }
                val masterWav = File(audioDir, "master_allinone_${System.currentTimeMillis()}.wav")

                val entries = activeProject.scenes.map { sc ->
                    StoryAudioMixer.SceneAudioEntry(
                        sceneNumber = sc.sceneNumber,
                        sceneDurationSeconds = sc.durationSeconds,
                        narrationWavPath = sc.narrationAudioPath
                    )
                }

                val mixOk = audioMixer.createMasterAudioTrack(
                    sceneEntries = entries,
                    bgMusicUri = if (activeProject.isMusicMuted) null else activeProject.audioUri?.let { Uri.parse(it) },
                    isMusicMuted = activeProject.isMusicMuted,
                    outputFile = masterWav
                )

                _uiState.update { it.copy(busyMessage = "Rendering HD 25fps MP4 with motion & subtitles...", renderProgress = 0.42f) }

                val videoDir = File(getApplication<Application>().filesDir, "videos").apply { mkdirs() }
                val outMp4 = File(videoDir, "studio_story_${System.currentTimeMillis()}.mp4")

                val encodeResult = encoder.encodeSlideshow(
                    scenes = activeProject.scenes,
                    aspectRatio = activeProject.aspectRatio,
                    outputFile = outMp4,
                    audioUri = if (activeProject.isMusicMuted) null else activeProject.audioUri?.let { Uri.parse(it) },
                    masterAudioFile = if (mixOk && masterWav.exists()) masterWav else null,
                    showSubtitles = activeProject.showSubtitles,
                    cinematicVignette = true
                ) { prog, msg ->
                    _uiState.update {
                        it.copy(
                            renderProgress = 0.42f + (prog * 0.56f),
                            busyMessage = msg
                        )
                    }
                }

                encodeResult.onSuccess { mp4File ->
                    val totalDur = activeProject.scenes.sumOf { it.durationSeconds }
                    videoRepo.saveVideoJob(
                        VideoJob(
                            jobId = "studio_${UUID.randomUUID().toString().take(8)}",
                            prompt = activeProject.storyPrompt.take(240),
                            style = activeProject.videoStyle.displayName,
                            aspectRatio = activeProject.aspectRatio,
                            duration = "${totalDur}s",
                            dialogueLanguage = activeProject.language,
                            provider = "All-in-One 8-Step Studio",
                            status = VideoJobStatus.COMPLETED,
                            progressPercent = 100,
                            statusMessage = "Complete MP4 Story Ready",
                            localVideoPath = mp4File.absolutePath,
                            isSlideshow = true
                        )
                    )

                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            renderProgress = 1f,
                            busyMessage = "",
                            generatedVideoPath = mp4File.absolutePath,
                            savedToLibrary = true,
                            currentStep = if (moveToExportStep) AllInOneStep.STEP_8_EXPORT else AllInOneStep.STEP_7_PREVIEW,
                            snackbarMessage = "Complete MP4 video rendered and ready!"
                        )
                    }
                }.onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            renderProgress = 0f,
                            errorMessage = "MP4 render failed: ${err.message}"
                        )
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        renderProgress = 0f,
                        errorMessage = "Video creation failed: ${e.message}"
                    )
                }
            }
        }
    }

    fun saveVideoToGallery(context: Context) {
        val path = _uiState.value.generatedVideoPath ?: return
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(context, "Render video in Step 7 first", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            try {
                val fileName = "AIPromptStudio_Story_${System.currentTimeMillis()}.mp4"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIPromptStudio")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(file).use { input -> input.copyTo(out) }
                        }
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                        Toast.makeText(context, "Saved to Movies/AIPromptStudio/$fileName", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "AIPromptStudio").apply { mkdirs() }
                    file.copyTo(File(dir, fileName), overwrite = true)
                    Toast.makeText(context, "Saved to Movies/AIPromptStudio/$fileName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareVideo(context: Context) {
        val path = _uiState.value.generatedVideoPath ?: return
        val file = File(path)
        if (!file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Created with AI Prompt Studio 8-Step Video Creator")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Story Video"))
        } catch (e: Exception) {
            Toast.makeText(context, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateSceneAt(index: Int, transform: (FreeVideoScene) -> FreeVideoScene) {
        _uiState.update { state ->
            val list = state.project.scenes.toMutableList()
            if (index in list.indices) {
                list[index] = transform(list[index])
            }
            state.copy(project = state.project.copy(scenes = list))
        }
    }

    private suspend fun encodeImageAsJpegBase64(uriOrPath: String): String? = withContext(Dispatchers.IO) {
        try {
            val stream = ImageImportHelper.openUriInputStream(getApplication(), uriOrPath)
            val bytes = stream?.use { it.readBytes() } ?: return@withContext null
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            var sample = 1
            while (opts.outWidth / sample > 1280 || opts.outHeight / sample > 1280) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return@withContext null
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, baos)
            bmp.recycle()
            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null, imageImportError = null) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        voiceManager.release()
        super.onCleared()
    }
}
