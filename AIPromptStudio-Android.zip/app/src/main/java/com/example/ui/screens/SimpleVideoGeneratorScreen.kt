package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserSettings
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import com.example.ui.viewmodel.VideoGeneratorUiState
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleVideoGeneratorScreen(
    state: VideoGeneratorUiState,
    settings: UserSettings,
    isProviderConfigured: Boolean,
    onPromptChange: (String) -> Unit,
    onSelectStyle: (VideoStyle) -> Unit,
    onSelectAspectRatio: (VideoAspectRatio) -> Unit,
    onSelectDuration: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSetSample: (String, VideoStyle) -> Unit,
    onGenerateClick: () -> Unit,
    onCancelGeneration: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onDismissSetupPrompt: () -> Unit,
    onNavigateToFreeVideoMaker: (() -> Unit)? = null,
    onConfirmPaidApiCall: (() -> Unit)? = null,
    onDismissPaidApiConfirmation: (() -> Unit)? = null,
    onSwitchToFreeModeAndGenerate: (() -> Unit)? = null,
    onToggleFreeLimitsDialog: ((Boolean) -> Unit)? = null,
    onOpenGoogleFlow: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showAdvancedSettings by remember { mutableStateOf(false) }
    var languageDropdownExpanded by remember { mutableStateOf(false) }

    val languages = listOf("Hindi", "English", "Hinglish", "Marathi", "Bengali", "Tamil", "Telugu", "Gujarati")
    val durations = listOf("5 sec", "10 sec")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VideoCameraBack,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "1. Generate Video",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "सीधे एआई वीडियो क्लिप बनाएं • AI Video Generator",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Free Mode Active Banner
        if (settings.providerType == VideoProviderType.FREE_MODE) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("free_mode_active_banner"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6EE7B7))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF10B981)
                                ) {
                                    Text(
                                        text = "FREE MODE",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "100% Free • No API Key Needed",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF065F46)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Turn your story into an animated MP4 video with synced Hindi voiceover directly on your device.",
                            fontSize = 12.sp,
                            color = Color(0xFF047857),
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onToggleFreeLimitsDialog?.invoke(true) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF047857)),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(30.dp)
                                    .testTag("btn_view_free_limits")
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color(0xFF047857))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Free Limits (सीमाएं)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }

                            if (onOpenGoogleFlow != null) {
                                OutlinedButton(
                                    onClick = onOpenGoogleFlow,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF0284C7)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .height(30.dp)
                                        .testTag("btn_open_google_flow")
                                ) {
                                    Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color(0xFF0284C7))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("Google AI Studio", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Provider Warning Banner if paid provider unconfigured
        if (!isProviderConfigured && settings.providerType != VideoProviderType.FREE_MODE) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Video Engine Credentials Required",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = "To generate actual MP4 videos with ${settings.providerType.displayName}, configure your API key in Settings.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Button(
                            onClick = onNavigateToSettings,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Setup", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Preset Indian Story Ideas
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quick Story Ideas (त्वरित उदाहरण):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SampleIdeaChip(
                        label = "गाँव की रसोई (दादी और पोता)",
                        onClick = {
                            onSetSample(
                                "एक बच्चा अपनी दादी के साथ भारतीय गांव में चूल्हे पर खाना बना रहा है। मिट्टी की दीवारें, सरसों के खेत और शाम की सुनहरी धूप।",
                                VideoStyle.REALISTIC
                            )
                        }
                    )
                    SampleIdeaChip(
                        label = "हवेली में सास–बहू ड्रामा",
                        onClick = {
                            onSetSample(
                                "एक पारंपरिक भारतीय हवेली में पूजा के समय सास और बहू के बीच भावुक संवाद, लाल सिंदूर और पीतल की आरती का थाल।",
                                VideoStyle.CINEMATIC
                            )
                        }
                    )
                    SampleIdeaChip(
                        label = "3D भारतीय बच्चे व मोर",
                        onClick = {
                            onSetSample(
                                "3D कार्टून शैली में एक छोटा भारतीय लड़का और उसकी पालतू गिलहरी बारिश में मोर को नाचते हुए देख रहे हैं।",
                                VideoStyle.CARTOON_3D
                            )
                        }
                    )
                    SampleIdeaChip(
                        label = "रामायण / कृष्ण लीला",
                        onClick = {
                            onSetSample(
                                "वृंदावन के कदंब के पेड़ के नीचे भगवान श्रीकृष्ण दिव्य बांसुरी बजाते हुए, गायें और मयूर मंत्रमुग्ध हैं।",
                                VideoStyle.ANIMATED
                            )
                        }
                    )
                }
            }
        }

        // Main Input Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_generator_input_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // 1. Story / Idea Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Story or Video Idea (वीडियो विचार / कहानी):",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (state.prompt.isNotBlank()) {
                            IconButton(
                                onClick = { onPromptChange("") },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = state.prompt,
                        onValueChange = onPromptChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("video_prompt_input"),
                        placeholder = {
                            Text(
                                text = "एक बच्चा अपनी दादी के साथ भारतीय गांव में खाना बना रहा है...",
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // 2. Video Style Selector
                    Text(
                        text = "Video Style (वीडियो शैली):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoStyle.entries.forEach { style ->
                            FilterChip(
                                selected = state.selectedStyle == style,
                                onClick = { onSelectStyle(style) },
                                label = {
                                    Column {
                                        Text(style.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(style.hindiName, fontSize = 10.sp)
                                    }
                                },
                                modifier = Modifier.testTag("style_chip_${style.name.lowercase()}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3. Aspect Ratio Selector
                    Text(
                        text = "Aspect Ratio (पहलू अनुपात):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoAspectRatio.entries.forEach { ratio ->
                            FilterChip(
                                selected = state.selectedAspectRatio == ratio,
                                onClick = { onSelectAspectRatio(ratio) },
                                label = {
                                    Text(
                                        text = "${ratio.ratio} (${ratio.hindiLabel})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                },
                                modifier = Modifier.testTag("ratio_chip_${ratio.ratio.replace(":", "_")}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4. Duration & Language Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Duration
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Duration (समय):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                durations.forEach { dur ->
                                    FilterChip(
                                        selected = state.selectedDuration == dur,
                                        onClick = { onSelectDuration(dur) },
                                        label = { Text(dur, fontSize = 11.sp) },
                                        modifier = Modifier.testTag("duration_chip_$dur"),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    )
                                }
                            }
                        }

                        // Language Selection
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Dialogue Language:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            ExposedDropdownMenuBox(
                                expanded = languageDropdownExpanded,
                                onExpandedChange = { languageDropdownExpanded = !languageDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = state.dialogueLanguage,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = languageDropdownExpanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    textStyle = MaterialTheme.typography.bodySmall
                                )
                                ExposedDropdownMenu(
                                    expanded = languageDropdownExpanded,
                                    onDismissRequest = { languageDropdownExpanded = false }
                                ) {
                                    languages.forEach { lang ->
                                        DropdownMenuItem(
                                            text = { Text(lang) },
                                            onClick = {
                                                onSelectLanguage(lang)
                                                languageDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Optional Advanced Settings
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { showAdvancedSettings = !showAdvancedSettings },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Advanced Settings (उन्नत विकल्प)", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (showAdvancedSettings) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    AnimatedVisibility(visible = showAdvancedSettings) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Active Video Provider: ${settings.providerType.displayName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Negative Prompt: deformed anatomy, disfigured face, bad hands, plastic skin, low resolution, motion glitch",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Error Message Display
                    if (state.errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = state.errorMessage,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 12.sp
                                )
                                if (onNavigateToFreeVideoMaker != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = onNavigateToFreeVideoMaker,
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("btn_switch_to_free_maker")
                                    ) {
                                        Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "✨ Create Free Animated Video Instead (मुफ़्त बनाएं)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Main Action Button: 🎬 Generate Video
                    Button(
                        onClick = onGenerateClick,
                        enabled = !state.isGenerating,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (settings.providerType == VideoProviderType.FREE_MODE) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("generate_video_main_button")
                    ) {
                        if (state.isGenerating) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Creating Video... (वीडियो बन रहा है)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Text(
                                text = if (settings.providerType == VideoProviderType.FREE_MODE) {
                                    "🎬 Generate Free Video (मुफ़्त वीडियो बनाएं)"
                                } else {
                                    "🎬 Generate Video (Paid API: ${settings.providerType.displayName})"
                                },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (onNavigateToFreeVideoMaker != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = onNavigateToFreeVideoMaker,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_free_animated_video_shortcut")
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF10B981))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "✨ Free Video Maker (No API Key • मुफ़्त एनिमेटेड वीडियो)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }
                    }
                }
            }
        }

        // Active Generation Progress Card (While generating)
        if (state.isGenerating) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generation_progress_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AI Video Generation in Progress",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            CircularProgressIndicator(
                                progress = { state.progressPercent / 100f },
                                modifier = Modifier.size(26.dp),
                                strokeWidth = 3.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = state.statusMessage.ifBlank { "Processing video frames... (फ्रेम तैयार किए जा रहे हैं)" },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LinearProgressIndicator(
                            progress = { state.progressPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Provider: ${settings.providerType.displayName}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            OutlinedButton(
                                onClick = onCancelGeneration,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Cancel (रद्द करें)", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Setup Required Modal Dialog
    if (state.showSetupPrompt) {
        AlertDialog(
            onDismissRequest = onDismissSetupPrompt,
            title = { Text("Video Provider Setup Required") },
            text = {
                Text(
                    text = state.setupMessage
                        ?: "Real video generation requires an API Key (Google Veo, Luma, Runway) or a Custom Server endpoint. Please configure your credentials in Settings."
                )
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (onNavigateToFreeVideoMaker != null) {
                        TextButton(
                            onClick = {
                                onDismissSetupPrompt()
                                onNavigateToFreeVideoMaker()
                            }
                        ) {
                            Text("Free Maker", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }
                    }
                    Button(
                        onClick = {
                            onDismissSetupPrompt()
                            onNavigateToSettings()
                        }
                    ) {
                        Text("Settings")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissSetupPrompt) {
                    Text("Cancel")
                }
            }
        )
    }

    // Explicit Paid API Confirmation Dialog (Requirement 12: Never make paid API calls without confirmation)
    if (state.showPaidApiConfirmDialog) {
        val targetProvider = state.pendingPaidProvider?.displayName ?: settings.providerType.displayName
        AlertDialog(
            onDismissRequest = { onDismissPaidApiConfirmation?.invoke() },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = {
                Text("Confirm Paid API Video Generation", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "You are about to call a paid cloud video API ($targetProvider).",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• This request connects to cloud GPUs and may incur billing charges or consume paid API credits on your account.\n" +
                               "• AI Prompt Studio never triggers paid cloud APIs automatically.\n\n" +
                               "💡 Recommendation: You can switch to 100% Free Mode to create animated multi-scene videos with Hindi voiceover on-device without any API key or billing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { onSwitchToFreeModeAndGenerate?.invoke() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text("Use 100% Free Mode", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { onDismissPaidApiConfirmation?.invoke() }
                    ) {
                        Text("Cancel")
                    }
                    TextButton(
                        onClick = { onConfirmPaidApiCall?.invoke() },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Proceed (Paid)", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        )
    }

    // Free Usage Limits & Quotas Dialog (Requirement 10 & 11)
    if (state.showFreeLimitsDialog) {
        AlertDialog(
            onDismissRequest = { onToggleFreeLimitsDialog?.invoke(false) },
            icon = { Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF10B981)) },
            title = {
                Text("Free Mode Limits & Quotas", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "✨ 100% Free On-Device Video Engine",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color(0xFF047857),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Generations: Unlimited daily story & video creations.\n" +
                               "• No API Keys Required: No Google Veo, Luma, or Runway key needed.\n" +
                               "• Video Duration: 15 to 45 seconds multi-scene MP4.\n" +
                               "• Indian Voiceover: Native Android TTS in Hindi, Gujarati, and English.\n" +
                               "• Visual Styles: 3D Cartoon, Realistic, Cinematic, Animated Indian.\n" +
                               "• Audio Mixing: Story-synchronized voice narration with background music.\n" +
                               "• Export Format: Standard MP4 (H.264 / AAC audio).\n\n" +
                               "ℹ️ Cloud Video Diffusion: Google Veo and Luma Dream Machine run on cloud server clusters and require paid API access. Users with Google AI Studio access can open the web workspace below.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { onToggleFreeLimitsDialog?.invoke(false) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text("Got It (समझ गया)")
                }
            },
            dismissButton = {
                if (onOpenGoogleFlow != null) {
                    TextButton(
                        onClick = {
                            onToggleFreeLimitsDialog?.invoke(false)
                            onOpenGoogleFlow()
                        }
                    ) {
                        Text("Open Google AI Studio", color = Color(0xFF0284C7))
                    }
                }
            }
        )
    }
}

@Composable
private fun SampleIdeaChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
