package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.StoryRepository
import com.example.data.model.SceneItem
import com.example.data.model.StoryPlan
import com.example.data.remote.GeminiStoryGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class StoryUiState(
    val userStory: String = "",
    val storyType: String = "सास–बहू",
    val duration: String = "60 sec",
    val aspectRatio: String = "9:16",
    val generateAllScenes: Boolean = true,
    val isGenerating: Boolean = false,
    val regeneratingSceneNumber: Int? = null,
    val currentPlan: StoryPlan? = null,
    val snackbarMessage: String? = null,
    val isSaved: Boolean = false
)

class StoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StoryRepository
    private val generator = GeminiStoryGenerator()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = StoryRepository(db.storyPlanDao())
    }

    val savedStories: StateFlow<List<StoryPlan>> = repository.allStories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiState = MutableStateFlow(StoryUiState())
    val uiState: StateFlow<StoryUiState> = _uiState.asStateFlow()

    fun updateStoryText(text: String) {
        _uiState.update { it.copy(userStory = text) }
    }

    fun selectStoryType(type: String) {
        _uiState.update { it.copy(storyType = type) }
    }

    fun selectDuration(duration: String) {
        _uiState.update { it.copy(duration = duration) }
    }

    fun selectAspectRatio(ratio: String) {
        _uiState.update { it.copy(aspectRatio = ratio) }
    }

    fun toggleGenerateAllScenes(enabled: Boolean) {
        _uiState.update { it.copy(generateAllScenes = enabled) }
    }

    fun setSamplePrompt(prompt: String, type: String) {
        _uiState.update {
            it.copy(
                userStory = prompt,
                storyType = type
            )
        }
    }

    fun generatePlan() {
        val state = _uiState.value
        val inputPrompt = state.userStory.trim()

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, snackbarMessage = null, isSaved = false) }
            try {
                val plan = generator.generateStoryPlan(
                    userStory = inputPrompt,
                    storyType = state.storyType,
                    duration = state.duration,
                    aspectRatio = state.aspectRatio,
                    generateAllScenes = state.generateAllScenes
                )
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        currentPlan = plan,
                        snackbarMessage = "🎉 Video production plan generated successfully!"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        snackbarMessage = "Failed to generate plan: ${e.message}"
                    )
                }
            }
        }
    }

    fun regenerateScene(sceneNumber: Int) {
        val currentPlan = _uiState.value.currentPlan ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(regeneratingSceneNumber = sceneNumber) }
            try {
                val newScene = generator.regenerateScene(currentPlan, sceneNumber)
                val updatedScenes = currentPlan.scenes.map {
                    if (it.sceneNumber == sceneNumber) newScene else it
                }
                val updatedPlan = currentPlan.copy(scenes = updatedScenes)
                _uiState.update {
                    it.copy(
                        regeneratingSceneNumber = null,
                        currentPlan = updatedPlan,
                        snackbarMessage = "🔄 Scene $sceneNumber regenerated!",
                        isSaved = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        regeneratingSceneNumber = null,
                        snackbarMessage = "Regeneration error: ${e.message}"
                    )
                }
            }
        }
    }

    fun saveCurrentPlan() {
        val plan = _uiState.value.currentPlan ?: return
        viewModelScope.launch {
            try {
                val id = repository.saveStory(plan)
                _uiState.update {
                    it.copy(
                        currentPlan = plan.copy(id = id),
                        isSaved = true,
                        snackbarMessage = "💾 Story saved to History!"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(snackbarMessage = "Error saving story: ${e.message}")
                }
            }
        }
    }

    fun loadStoryFromHistory(plan: StoryPlan) {
        _uiState.update {
            it.copy(
                userStory = plan.originalPrompt,
                storyType = plan.storyType,
                duration = plan.duration,
                aspectRatio = plan.aspectRatio,
                currentPlan = plan,
                isSaved = true,
                snackbarMessage = "📂 Loaded: ${plan.title}"
            )
        }
    }

    fun deleteStory(id: Long) {
        viewModelScope.launch {
            try {
                repository.deleteStory(id)
                _uiState.update { it.copy(snackbarMessage = "Story deleted from history") }
            } catch (e: Exception) {
                _uiState.update { it.copy(snackbarMessage = "Delete failed: ${e.message}") }
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
