package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CinemaGold = Color(0xFFD97706)
val CinemaGoldLight = Color(0xFFFBBF24)
val CinemaGoldDark = Color(0xFFB45309)

val DeepIndigo = Color(0xFF1E1B4B)
val RoyalIndigo = Color(0xFF4338CA)
val IndigoLight = Color(0xFF818CF8)

val EmeraldIndian = Color(0xFF059669)
val SaffronIndian = Color(0xFFEA580C)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)

// Backward compatibility
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

