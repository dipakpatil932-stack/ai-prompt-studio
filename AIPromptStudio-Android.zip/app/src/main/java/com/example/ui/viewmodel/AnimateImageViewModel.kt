package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferences
import com.example.data.local.VideoRepository
import com.example.data.media.ImageImportHelper
import com.example.data.model.FreeVideoScene
import com.example.data.model.MotionEffect
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import com.example.data.remote.video.VideoGenerationService
import com.example.data.video.Mp4SlideshowEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

enum class AnimateEngineMode(val label: String, val isPaid: Boolean) {
    ON_DEVICE_CINEMATIC("On-Device 25fps Motion MP4 (100% Free)", false),
    GOOGLE_VEO_CLOUD("Google Veo Image-to-Video API (Paid Cloud)", true)
}

data class AnimateImageUiState(
    val selectedImageUri: String? = null,
    val motionPrompt: String = "",
    val selectedMotionEffect: MotionEffect = MotionEffect.KEN_BURNS_ZOOM_IN,
    val selectedAspectRatio: VideoAspectRatio = VideoAspectRatio.RATIO_9_16,
    val selectedDurationSec: Int = 6,
    val selectedStyle: VideoStyle = VideoStyle.CINEMATIC,
    val addCinematicVignette: Boolean = true,
    val optionalCaption: String = "",
    val backgroundMusicUri: String? = null,
    val backgroundMusicName: String? = null,
    val engineMode: AnimateEngineMode = AnimateEngineMode.ON_DEVICE_CINEMATIC,
    val showPaidConfirmDialog: Boolean = false,
    val isAnimating: Boolean = false,
    val isImportingImage: Boolean = false,
    val imageImportError: String? = null,
    val progress: Float = 0f,
    val statusMessage: String = "",
    val outputVideoPath: String? = null,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null
)

class AnimateImageViewModel(application: Application) : AndroidViewModel(application) {

    private val encoder = Mp4SlideshowEncoder(application)
    private val videoService = VideoGenerationService(application)
    private val userPrefs = UserPreferences(application)
    private val videoRepo = VideoRepository(AppDatabase.getDatabase(application).videoJobDao())

    private var animationJob: Job? = null

    private val _uiState = MutableStateFlow(AnimateImageUiState())
    val uiState: StateFlow<AnimateImageUiState> = _uiState.asStateFlow()

    fun setSelectedImage(uriOrPath: String) {
        val clean = uriOrPath.trim()
        if (clean.isBlank()) return

        val app = getApplication<Application>()
        val internalFile = File(clean)
        if (clean.startsWith(app.filesDir.absolutePath) && internalFile.exists() && internalFile.length() > 0L) {
            _uiState.update {
                it.copy(
                    selectedImageUri = clean,
                    outputVideoPath = null,
                    isImportingImage = false,
                    imageImportError = null,
                    errorMessage = null
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isImportingImage = true,
                    imageImportError = null,
                    errorMessage = null,
                    outputVideoPath = null
                )
            }
            val result = ImageImportHelper.importImageToLocalStorage(app, clean)
            result.onSuccess { imported ->
                _uiState.update {
                    it.copy(
                        selectedImageUri = imported.localFilePath,
                        isImportingImage = false,
                        imageImportError = null,
                        snackbarMessage = "Photo ready: ${imported.displayName} (${imported.width}x${imported.height})"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isImportingImage = false,
                        imageImportError = err.message ?: "Failed to load selected image."
                    )
                }
            }
        }
    }

    fun updateMotionPrompt(text: String) {
        _uiState.update { it.copy(motionPrompt = text, errorMessage = null) }
    }

    fun selectMotionEffect(effect: MotionEffect) {
        _uiState.update { it.copy(selectedMotionEffect = effect) }
    }

    fun selectAspectRatio(ratio: VideoAspectRatio) {
        _uiState.update { it.copy(selectedAspectRatio = ratio) }
    }

    fun selectDuration(seconds: Int) {
        _uiState.update { it.copy(selectedDurationSec = seconds.coerceIn(4, 15)) }
    }

    fun selectStyle(style: VideoStyle) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun toggleCinematicVignette(enabled: Boolean) {
        _uiState.update { it.copy(addCinematicVignette = enabled) }
    }

    fun updateOptionalCaption(caption: String) {
        _uiState.update { it.copy(optionalCaption = caption) }
    }

    fun setBackgroundMusic(uri: String?, name: String?) {
        _uiState.update { it.copy(backgroundMusicUri = uri, backgroundMusicName = name) }
    }

    fun selectEngineMode(mode: AnimateEngineMode) {
        _uiState.update { it.copy(engineMode = mode, errorMessage = null) }
    }

    fun startAnimateImage() {
        val current = _uiState.value
        if (current.selectedImageUri.isNullOrBlank()) {
            _uiState.update { it.copy(errorMessage = "Please upload or pick an image from your gallery first (कृपया पहले एक चित्र चुनें).") }
            return
        }

        if (current.engineMode.isPaid) {
            _uiState.update { it.copy(showPaidConfirmDialog = true) }
            return
        }

        executeOnDeviceAnimation()
    }

    fun dismissPaidConfirmDialog() {
        _uiState.update { it.copy(showPaidConfirmDialog = false) }
    }

    fun switchToFreeMotionAndAnimate() {
        _uiState.update {
            it.copy(
                showPaidConfirmDialog = false,
                engineMode = AnimateEngineMode.ON_DEVICE_CINEMATIC
            )
        }
        executeOnDeviceAnimation()
    }

    fun confirmPaidVeoImageToVideo() {
        _uiState.update { it.copy(showPaidConfirmDialog = false) }
        executeCloudVeoImageToVideo()
    }

    private fun executeOnDeviceAnimation() {
        val state = _uiState.value
        val imageUri = state.selectedImageUri ?: return

        animationJob?.cancel()
        animationJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAnimating = true,
                    progress = 0.05f,
                    statusMessage = "Initializing 25fps OpenGL motion engine...",
                    errorMessage = null,
                    outputVideoPath = null
                )
            }

            val scene = FreeVideoScene(
                sceneNumber = 1,
                title = "",
                caption = state.optionalCaption.trim(),
                narrationText = "",
                imageUri = imageUri,
                durationSeconds = state.selectedDurationSec,
                videoStyle = state.selectedStyle,
                motionEffect = state.selectedMotionEffect
            )

            val outDir = File(getApplication<Application>().filesDir, "videos").apply { mkdirs() }
            val outFile = File(outDir, "animated_photo_${System.currentTimeMillis()}.mp4")

            val result = encoder.encodeSlideshow(
                scenes = listOf(scene),
                aspectRatio = state.selectedAspectRatio.ratio,
                outputFile = outFile,
                audioUri = state.backgroundMusicUri?.let { Uri.parse(it) },
                masterAudioFile = null,
                showSubtitles = state.optionalCaption.isNotBlank(),
                cinematicVignette = state.addCinematicVignette
            ) { prog, msg ->
                _uiState.update { it.copy(progress = prog, statusMessage = msg) }
            }

            result.onSuccess { file ->
                val job = VideoJob(
                    jobId = "anim_${UUID.randomUUID().toString().take(8)}",
                    prompt = state.motionPrompt.ifBlank { "Image Animation (${state.selectedMotionEffect.displayName})" },
                    style = state.selectedStyle.displayName,
                    aspectRatio = state.selectedAspectRatio.ratio,
                    duration = "${state.selectedDurationSec} sec",
                    dialogueLanguage = "None",
                    provider = AnimateEngineMode.ON_DEVICE_CINEMATIC.label,
                    status = VideoJobStatus.COMPLETED,
                    progressPercent = 100,
                    statusMessage = "Animated MP4 Ready",
                    localVideoPath = file.absolutePath,
                    isSlideshow = false
                )
                videoRepo.saveVideoJob(job)

                _uiState.update {
                    it.copy(
                        isAnimating = false,
                        progress = 1f,
                        statusMessage = "Animated MP4 created!",
                        outputVideoPath = file.absolutePath,
                        snackbarMessage = "Animated MP4 video ready!"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isAnimating = false,
                        progress = 0f,
                        errorMessage = "Animation failed: ${err.message}"
                    )
                }
            }
        }
    }

    private fun executeCloudVeoImageToVideo() {
        val state = _uiState.value
        val imageUri = state.selectedImageUri ?: return
        val apiKey = userPrefs.getEffectiveGeminiApiKey().ifBlank { userPrefs.settingsFlow.value.providerApiKey }

        if (apiKey.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Google Veo API key is missing. Add GEMINI_API_KEY in Settings / Secrets, or use the 100% Free On-Device Motion MP4 mode."
                )
            }
            return
        }

        animationJob?.cancel()
        animationJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAnimating = true,
                    progress = 0.08f,
                    statusMessage = "Encoding image & contacting Google Veo Image-to-Video API...",
                    errorMessage = null,
                    outputVideoPath = null
                )
            }

            val encoded = encodeImageAsJpegBase64(imageUri)
            if (encoded == null) {
                _uiState.update {
                    it.copy(
                        isAnimating = false,
                        errorMessage = "Failed to read the selected image file for Veo API upload."
                    )
                }
                return@launch
            }

            val promptText = buildString {
                append(state.motionPrompt.trim().ifBlank { "Bring this image to life with subtle natural movement" })
                append(". Camera motion: ${state.selectedMotionEffect.promptDescription}.")
            }

            val veoSettings = userPrefs.settingsFlow.value.copy(
                providerType = VideoProviderType.GOOGLE_VEO,
                providerApiKey = apiKey
            )

            val sub = videoService.submitJob(
                prompt = promptText,
                style = state.selectedStyle.displayName,
                aspectRatio = state.selectedAspectRatio.ratio,
                duration = "${state.selectedDurationSec} sec",
                dialogueLanguage = "None",
                settings = veoSettings,
                imageBase64 = encoded,
                imageMimeType = "image/jpeg"
            )

            sub.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isAnimating = false,
                        progress = 0f,
                        errorMessage = err.message ?: "Google Veo Image-to-Video API unavailable."
                    )
                }
                return@launch
            }

            val submission = sub.getOrNull() ?: return@launch
            if (submission.initialStatus == VideoJobStatus.COMPLETED && !submission.directVideoUrl.isNullOrBlank()) {
                val dl = videoService.downloadVideoLocally(submission.directVideoUrl, submission.jobId, apiKey)
                val localPath = dl.getOrNull()
                if (localPath != null) {
                    _uiState.update {
                        it.copy(
                            isAnimating = false,
                            progress = 1f,
                            outputVideoPath = localPath,
                            statusMessage = "Google Veo animated video ready!"
                        )
                    }
                    return@launch
                }
            }

            var elapsed = 0
            while (coroutineContext.isActive && elapsed < 240) {
                delay(4000)
                elapsed += 4
                val poll = videoService.pollJobStatus(submission.jobId, veoSettings, elapsed)
                _uiState.update {
                    it.copy(
                        progress = (poll.progressPercent / 100f).coerceIn(0.1f, 0.95f),
                        statusMessage = poll.statusMessage
                    )
                }
                if (poll.status == VideoJobStatus.COMPLETED && !poll.videoUrl.isNullOrBlank()) {
                    val dl = videoService.downloadVideoLocally(poll.videoUrl, submission.jobId, apiKey)
                    val path = dl.getOrNull()
                    if (path != null) {
                        videoRepo.saveVideoJob(
                            VideoJob(
                                jobId = submission.jobId,
                                prompt = promptText,
                                style = state.selectedStyle.displayName,
                                aspectRatio = state.selectedAspectRatio.ratio,
                                duration = "${state.selectedDurationSec} sec",
                                provider = AnimateEngineMode.GOOGLE_VEO_CLOUD.label,
                                status = VideoJobStatus.COMPLETED,
                                progressPercent = 100,
                                videoUrl = poll.videoUrl,
                                localVideoPath = path,
                                isSlideshow = false
                            )
                        )
                        _uiState.update {
                            it.copy(
                                isAnimating = false,
                                progress = 1f,
                                outputVideoPath = path,
                                statusMessage = "Google Veo video ready!"
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(isAnimating = false, errorMessage = "Veo finished, but video download failed.")
                        }
                    }
                    return@launch
                } else if (poll.status == VideoJobStatus.FAILED) {
                    _uiState.update {
                        it.copy(
                            isAnimating = false,
                            errorMessage = poll.errorMessage ?: "Google Veo Image-to-Video failed."
                        )
                    }
                    return@launch
                }
            }
        }
    }

    private suspend fun encodeImageAsJpegBase64(uriOrPath: String): String? = withContext(Dispatchers.IO) {
        try {
            val stream = ImageImportHelper.openUriInputStream(getApplication(), uriOrPath)
            val bytes = stream?.use { it.readBytes() } ?: return@withContext null
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            var sample = 1
            while (opts.outWidth / sample > 1280 || opts.outHeight / sample > 1280) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return@withContext null
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 90, baos)
            bmp.recycle()
            Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }

    fun cancelAnimation() {
        animationJob?.cancel()
        _uiState.update { it.copy(isAnimating = false, progress = 0f, statusMessage = "Cancelled") }
    }

    fun saveVideoToGallery(context: Context) {
        val path = _uiState.value.outputVideoPath ?: return
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(context, "Video file not found", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            try {
                val fileName = "AIPromptStudio_Anim_${System.currentTimeMillis()}.mp4"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIPromptStudio")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(file).use { input -> input.copyTo(out) }
                        }
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                        Toast.makeText(context, "Saved to Movies/AIPromptStudio/$fileName", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "AIPromptStudio").apply { mkdirs() }
                    file.copyTo(File(dir, fileName), overwrite = true)
                    Toast.makeText(context, "Saved to Movies/AIPromptStudio/$fileName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareVideo(context: Context) {
        val path = _uiState.value.outputVideoPath ?: return
        val file = File(path)
        if (!file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Animated MP4"))
        } catch (e: Exception) {
            Toast.makeText(context, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null, imageImportError = null) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
