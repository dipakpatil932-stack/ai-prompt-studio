package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.data.media.ImageImportHelper
import com.example.data.model.AllInOneStep
import com.example.data.model.MotionEffect
import com.example.data.model.StoryCharacter
import com.example.data.model.StoryEmotion
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoStyle
import com.example.data.model.VoiceGender
import com.example.ui.components.VideoPlayerView
import com.example.ui.components.rememberUnifiedImagePicker
import com.example.ui.viewmodel.AllInOneCreatorUiState
import com.example.ui.viewmodel.PendingPaidAction

@Composable
fun AllInOneCreatorScreen(
    state: AllInOneCreatorUiState,
    onGoToStep: (AllInOneStep) -> Unit,
    onNextStep: () -> Unit,
    onPreviousStep: () -> Unit,
    onStoryChange: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectAspectRatio: (String) -> Unit,
    onSelectStyle: (VideoStyle) -> Unit,
    onSelectDuration: (Int) -> Unit,
    onSetSampleStory: (String, String, VideoStyle) -> Unit,
    onGenerateCharactersAndAdvance: () -> Unit,
    onUpdateCharacter: (Int, StoryCharacter) -> Unit,
    onAddCharacter: () -> Unit,
    onDeleteCharacter: (Int) -> Unit,
    onGenerateScenesAndGoToStep3: () -> Unit,
    onSetActiveScenePicker: (Int) -> Unit,
    onSceneImagePicked: (String) -> Unit,
    onRemoveSceneImage: (Int) -> Unit,
    onRequestGenerateAiImage: (Int) -> Unit,
    onUpdateSceneMotionEffect: (Int, MotionEffect) -> Unit,
    onUpdateSceneDuration: (Int, Int) -> Unit,
    onRequestAnimateSceneVeo: (Int) -> Unit,
    onSelectVoiceGender: (VoiceGender) -> Unit,
    onSelectEmotion: (StoryEmotion) -> Unit,
    onUpdateSpeechRate: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onUpdateSceneNarration: (Int, String) -> Unit,
    onGenerateVoiceovers: () -> Unit,
    onPreviewSceneVoice: (Int) -> Unit,
    onToggleSubtitles: (Boolean) -> Unit,
    onSetBackgroundMusic: (String?, String?) -> Unit,
    onToggleMusicMute: () -> Unit,
    onUpdateSceneCaption: (Int, String) -> Unit,
    onRenderPreviewAndExport: (Boolean) -> Unit,
    onConfirmPaidAction: () -> Unit,
    onDismissPaidAction: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShareVideo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imagePicker = rememberUnifiedImagePicker { uri ->
        onSceneImagePicked(uri.toString())
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            onSetBackgroundMusic(uri.toString(), uri.lastPathSegment ?: "Story Music")
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Horizontal 8-Step Stepper Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AllInOneStep.entries.forEach { step ->
                val active = state.currentStep == step
                val completed = step.stepNumber < state.currentStep.stepNumber
                Surface(
                    onClick = { onGoToStep(step) },
                    shape = RoundedCornerShape(14.dp),
                    color = when {
                        active -> MaterialTheme.colorScheme.primary
                        completed -> Color(0xFFECFDF5)
                        else -> MaterialTheme.colorScheme.surface
                    },
                    border = BorderStroke(
                        1.dp,
                        when {
                            active -> MaterialTheme.colorScheme.primary
                            completed -> Color(0xFF10B981)
                            else -> MaterialTheme.colorScheme.outlineVariant
                        }
                    ),
                    modifier = Modifier.testTag("stepper_step_${step.stepNumber}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        active -> Color.White.copy(alpha = 0.25f)
                                        completed -> Color(0xFF10B981)
                                        else -> MaterialTheme.colorScheme.surfaceVariant
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${step.stepNumber}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (active || completed) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = step.title,
                            fontSize = 11.sp,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                            color = when {
                                active -> Color.White
                                completed -> Color(0xFF065F46)
                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        }

        if (state.isBusy) {
            LinearProgressIndicator(
                progress = { if (state.renderProgress > 0f) state.renderProgress else 0.35f },
                modifier = Modifier.fillMaxWidth().height(4.dp)
            )
            Surface(color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(state.busyMessage.ifBlank { "Working..." }, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        if (state.errorMessage != null) {
            Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), shape = RoundedCornerShape(10.dp)) {
                Text(state.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
            }
        }

        // Active Step Body
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = state.currentStep.hindiTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            when (state.currentStep) {
                AllInOneStep.STEP_1_STORY -> {
                    item {
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Write your Hindi, Gujarati, or English story:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                OutlinedTextField(
                                    value = state.project.storyPrompt,
                                    onValueChange = onStoryChange,
                                    modifier = Modifier.fillMaxWidth().height(130.dp).testTag("allinone_story_input"),
                                    placeholder = { Text("उदा: गाँव की मीरा ने अपनी मेहनत से पूरे गाँव में शिक्षा की रोशनी जलाई...") },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(
                                        Triple("किसान व बेटा (Hindi)", "एक छोटे गाँव के किसान रामू और उसके बेटे आरव ने जैविक खेती से बंजर खेत में सोना उगाया।", VideoStyle.REALISTIC),
                                        Triple("3D Story (Hindi)", "3D कार्टून शैली में नन्हीं अन्या और उसकी दादी सुमित्रा ने बारिश में एक घायल मोर की मदद की।", VideoStyle.CARTOON_3D),
                                        Triple("Solar Village (English)", "Young Meera builds a small solar lamp in her Indian village so every child can study after sunset.", VideoStyle.CINEMATIC)
                                    ).forEach { (label, txt, sty) ->
                                        FilterChip(
                                            selected = false,
                                            onClick = { onSetSampleStory(txt, if (label.contains("English")) "English" else "Hindi", sty) },
                                            label = { Text(label, fontSize = 11.sp) }
                                        )
                                    }
                                }

                                Text("Visual Style:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    VideoStyle.entries.forEach { sty ->
                                        FilterChip(
                                            selected = state.project.videoStyle == sty,
                                            onClick = { onSelectStyle(sty) },
                                            label = { Text("${sty.displayName} (${sty.hindiName})", fontSize = 11.sp) }
                                        )
                                    }
                                }

                                Text("Aspect Ratio:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    VideoAspectRatio.entries.forEach { ar ->
                                        FilterChip(
                                            selected = state.project.aspectRatio == ar.ratio,
                                            onClick = { onSelectAspectRatio(ar.ratio) },
                                            label = { Text("${ar.ratio} (${ar.hindiLabel})", fontSize = 11.sp) }
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Hindi", "English", "Gujarati").forEach { lang ->
                                        FilterChip(
                                            selected = state.project.language == lang,
                                            onClick = { onSelectLanguage(lang) },
                                            label = { Text(lang, fontSize = 11.sp) }
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(15 to "15s", 24 to "24s", 36 to "36s").forEach { (sec, lbl) ->
                                        FilterChip(
                                            selected = state.targetDurationSeconds == sec,
                                            onClick = { onSelectDuration(sec) },
                                            label = { Text(lbl, fontSize = 11.sp) }
                                        )
                                    }
                                }

                                Button(
                                    onClick = onGenerateCharactersAndAdvance,
                                    enabled = !state.isBusy,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_allinone_step1_next")
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate Consistent Characters ->", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                AllInOneStep.STEP_2_CHARACTERS -> {
                    item {
                        Text(
                            text = "Lock exact faces, hairstyles, outfits, and voices across every scene:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    itemsIndexed(state.project.characters) { idx, ch ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Character ${idx + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    if (state.project.characters.size > 1) {
                                        IconButton(onClick = { onDeleteCharacter(idx) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Remove Character")
                                        }
                                    }
                                }
                                OutlinedTextField(
                                    value = ch.name,
                                    onValueChange = { onUpdateCharacter(idx, ch.copy(name = it)) },
                                    label = { Text("Name") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = ch.facialFeatures,
                                    onValueChange = { onUpdateCharacter(idx, ch.copy(facialFeatures = it)) },
                                    label = { Text("Consistent Face & Skin Features") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = ch.clothingAndColors,
                                    onValueChange = { onUpdateCharacter(idx, ch.copy(clothingAndColors = it)) },
                                    label = { Text("Locked Outfit & Colors") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    VoiceGender.entries.forEach { g ->
                                        FilterChip(
                                            selected = ch.voiceGender == g,
                                            onClick = { onUpdateCharacter(idx, ch.copy(voiceGender = g)) },
                                            label = { Text(g.displayName, fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    item {
                        OutlinedButton(onClick = onAddCharacter, modifier = Modifier.fillMaxWidth().height(46.dp)) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Character")
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onGenerateScenesAndGoToStep3,
                            enabled = !state.isBusy,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_allinone_step2_next")
                        ) {
                            Text("Generate Scene Storyboard ->", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                AllInOneStep.STEP_3_IMAGES -> {
                    item {
                        Text(
                            text = "Assign a Gallery Photo (Free) or Generate an AI Image (API key) for each scene:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    itemsIndexed(state.project.scenes) { idx, scene ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Scene ${scene.sceneNumber}: ${scene.title}", fontWeight = FontWeight.Bold)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable(enabled = !(state.isImportingImage && state.importingSceneIndex == idx)) {
                                            onSetActiveScenePicker(idx)
                                            imagePicker.launchGalleryPicker()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (state.isImportingImage && state.importingSceneIndex == idx) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.5.dp)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("Loading image...", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                        }
                                    } else if (!scene.imageUri.isNullOrBlank()) {
                                        val model = ImageImportHelper.toCoilModel(scene.imageUri)
                                        SubcomposeAsyncImage(
                                            model = ImageRequest.Builder(context).data(model).crossfade(true).build(),
                                            contentDescription = "Scene ${scene.sceneNumber} image",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize(),
                                            loading = {
                                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                                                }
                                            },
                                            error = {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
                                                    Text("Preview failed. Try Browse Files.", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                                }
                                            }
                                        )
                                    } else {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                                            Text("Tap to Pick Photo (JPG/PNG/WEBP)", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                                Text(scene.imagePrompt, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 15.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            onSetActiveScenePicker(idx)
                                            imagePicker.launchGalleryPicker()
                                        },
                                        modifier = Modifier.weight(1f).height(48.dp)
                                    ) {
                                        Text("Gallery", fontSize = 11.sp)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            onSetActiveScenePicker(idx)
                                            imagePicker.launchFileBrowser()
                                        },
                                        modifier = Modifier.weight(1f).height(48.dp)
                                    ) {
                                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Files", fontSize = 11.sp)
                                    }
                                    Button(
                                        onClick = { onRequestGenerateAiImage(idx) },
                                        enabled = !scene.isGeneratingImage,
                                        modifier = Modifier.weight(1f).height(48.dp)
                                    ) {
                                        if (scene.isGeneratingImage) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                        } else {
                                            Text("AI Image", fontSize = 11.sp)
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            cm.setPrimaryClip(ClipData.newPlainText("Prompt", scene.imagePrompt))
                                            Toast.makeText(context, "Copied scene prompt", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.height(48.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy prompt", modifier = Modifier.size(15.dp))
                                    }
                                }
                                if (!scene.imageUri.isNullOrBlank()) {
                                    TextButton(onClick = { onRemoveSceneImage(idx) }) { Text("Remove Image", fontSize = 11.sp) }
                                }
                            }
                        }
                    }
                }

                AllInOneStep.STEP_4_ANIMATE -> {
                    item {
                        Text(
                            text = "Choose 25fps camera animation per scene (100% Free) or optional Google Veo Image-to-Video:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    itemsIndexed(state.project.scenes) { idx, scene ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Scene ${scene.sceneNumber} (${scene.durationSeconds}s)", fontWeight = FontWeight.Bold)
                                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    MotionEffect.entries.forEach { effect ->
                                        FilterChip(
                                            selected = scene.motionEffect == effect,
                                            onClick = { onUpdateSceneMotionEffect(idx, effect) },
                                            label = { Text("${effect.displayName} (${effect.hindiName})", fontSize = 11.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                            )
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Duration:", fontSize = 12.sp)
                                    listOf(3, 5, 7, 10).forEach { sec ->
                                        FilterChip(selected = scene.durationSeconds == sec, onClick = { onUpdateSceneDuration(idx, sec) }, label = { Text("${sec}s", fontSize = 11.sp) })
                                    }
                                }
                                if (!scene.imageUri.isNullOrBlank()) {
                                    OutlinedButton(
                                        onClick = { onRequestAnimateSceneVeo(idx) },
                                        enabled = !scene.isAnimatingVideo,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = when {
                                                scene.isAnimatingVideo -> "Animating via Google Veo..."
                                                !scene.remoteVideoUrl.isNullOrBlank() -> "Animated via Google Veo Ready"
                                                else -> "Optional: Animate with Google Veo API (Paid)"
                                            },
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                AllInOneStep.STEP_5_VOICEOVER -> {
                    item {
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Consistent Narrator Voice Settings (सभी दृश्यों के लिए एक जैसी आवाज़):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    VoiceGender.entries.forEach { g ->
                                        FilterChip(selected = state.project.voiceGender == g, onClick = { onSelectVoiceGender(g) }, label = { Text(g.displayName, fontSize = 11.sp) })
                                    }
                                }
                                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StoryEmotion.entries.forEach { e ->
                                        FilterChip(selected = state.project.emotion == e, onClick = { onSelectEmotion(e) }, label = { Text(e.displayName, fontSize = 11.sp) })
                                    }
                                }
                                Text("Speed: ${String.format("%.2fx", state.project.speechRate)}", fontSize = 12.sp)
                                Slider(value = state.project.speechRate, onValueChange = onUpdateSpeechRate, valueRange = 0.6f..1.5f)
                                Text("Pitch: ${String.format("%.2fx", state.project.speechPitch)}", fontSize = 12.sp)
                                Slider(value = state.project.speechPitch, onValueChange = onUpdateSpeechPitch, valueRange = 0.6f..1.5f)

                                Button(
                                    onClick = onGenerateVoiceovers,
                                    enabled = !state.isBusy,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_allinone_generate_voices")
                                ) {
                                    Icon(Icons.Default.Mic, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate & Sync All Scene Voices", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    itemsIndexed(state.project.scenes) { idx, scene ->
                        Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Scene ${scene.sceneNumber} (${scene.durationSeconds}s)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    OutlinedButton(onClick = { onPreviewSceneVoice(idx) }, modifier = Modifier.height(34.dp), contentPadding = PaddingValues(horizontal = 10.dp)) {
                                        val isPlaying = state.isVoicePreviewPlaying && state.previewingSceneIndex == idx
                                        Icon(if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (isPlaying) "Stop" else "Preview", fontSize = 11.sp)
                                    }
                                }
                                OutlinedTextField(
                                    value = scene.narrationText,
                                    onValueChange = { onUpdateSceneNarration(idx, it) },
                                    label = { Text("Spoken Narration") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                AllInOneStep.STEP_6_MUSIC_SUBTITLES -> {
                    item {
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Default.Subtitles, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text("Burn-in Subtitles (सबटाइटल)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("Display scene captions at bottom of video", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Switch(checked = state.project.showSubtitles, onCheckedChange = onToggleSubtitles)
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(if (state.project.isMusicMuted) Icons.Default.MusicOff else Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(state.project.bgMusicName ?: "No custom music (auto ambient)", fontSize = 12.sp)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        IconButton(onClick = onToggleMusicMute) {
                                            Icon(if (state.project.isMusicMuted) Icons.Default.MusicOff else Icons.Default.MusicNote, contentDescription = "Toggle mute")
                                        }
                                        OutlinedButton(onClick = { musicPicker.launch("audio/*") }) {
                                            Text("Select Audio", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    itemsIndexed(state.project.scenes) { idx, scene ->
                        OutlinedTextField(
                            value = scene.caption,
                            onValueChange = { onUpdateSceneCaption(idx, it) },
                            label = { Text("Scene ${scene.sceneNumber} Subtitle Text") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Button(
                            onClick = { onRenderPreviewAndExport(false) },
                            enabled = !state.isBusy,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_allinone_render_preview")
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Render Complete Video Preview ->", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                AllInOneStep.STEP_7_PREVIEW -> {
                    item {
                        if (!state.generatedVideoPath.isNullOrBlank()) {
                            VideoPlayerView(
                                videoPathOrUrl = state.generatedVideoPath,
                                aspectRatio = state.project.aspectRatio
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { onGoToStep(AllInOneStep.STEP_8_EXPORT) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.fillMaxWidth().height(50.dp)
                            ) {
                                Text("Continue to Download & Share (Step 8) ->", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Video preview not rendered yet for current edits.", fontWeight = FontWeight.Medium)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = { onRenderPreviewAndExport(false) },
                                        enabled = !state.isBusy,
                                        modifier = Modifier.fillMaxWidth().height(48.dp)
                                    ) {
                                        Text("Render Complete Preview MP4")
                                    }
                                }
                            }
                        }
                    }
                }

                AllInOneStep.STEP_8_EXPORT -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                            border = BorderStroke(1.dp, Color(0xFF6EE7B7))
                        ) {
                            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(28.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = if (!state.generatedVideoPath.isNullOrBlank()) "Your Complete Story Video is Ready!" else "Ready to Export Final MP4",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = Color(0xFF065F46)
                                    )
                                }
                                Text(
                                    text = "Format: ${state.project.aspectRatio} • Scenes: ${state.project.scenes.size} • Duration: ${state.project.scenes.sumOf { it.durationSeconds }}s • Voice: ${state.project.language}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF047857)
                                )
                                if (state.generatedVideoPath.isNullOrBlank()) {
                                    Button(
                                        onClick = { onRenderPreviewAndExport(true) },
                                        enabled = !state.isBusy,
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        modifier = Modifier.fillMaxWidth().height(50.dp)
                                    ) {
                                        Text("Render Final MP4 Now", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        Button(
                                            onClick = onSaveToGallery,
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                            modifier = Modifier.weight(1f).height(50.dp).testTag("btn_allinone_download_mp4")
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Download MP4", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        OutlinedButton(
                                            onClick = onShareVideo,
                                            modifier = Modifier.weight(1f).height(50.dp).testTag("btn_allinone_share_mp4")
                                        ) {
                                            Icon(Icons.Default.Share, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Share", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Prev / Next Step Bar
        Surface(
            shadowElevation = 6.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onPreviousStep,
                    enabled = state.currentStep != AllInOneStep.STEP_1_STORY && !state.isBusy,
                    modifier = Modifier.height(44.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Prev", fontSize = 12.sp)
                }

                Text(
                    text = "Step ${state.currentStep.stepNumber} / 8",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Button(
                    onClick = onNextStep,
                    enabled = state.currentStep != AllInOneStep.STEP_8_EXPORT && !state.isBusy,
                    modifier = Modifier.height(44.dp)
                ) {
                    Text("Next", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }
    }

    if (state.pendingPaidAction != null) {
        val isVeo = state.pendingPaidAction is PendingPaidAction.AnimateSceneWithVeo
        AlertDialog(
            onDismissRequest = onDismissPaidAction,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text(if (isVeo) "Confirm Google Veo API Call" else "Confirm Google AI Image Call", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    if (isVeo) {
                        "This will send this scene image to Google Veo Image-to-Video API and requires billing/whitelist access."
                    } else {
                        "This will generate an image via Google AI Image API using your configured API key."
                    },
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = onConfirmPaidAction) { Text("Proceed") }
            },
            dismissButton = {
                TextButton(onClick = onDismissPaidAction) { Text("Cancel") }
            }
        )
    }
}
