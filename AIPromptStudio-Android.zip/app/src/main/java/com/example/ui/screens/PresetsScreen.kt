package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PresetsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current

    fun copyPrompt(text: String, label: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("AI Prompt Studio Preset", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied $label", Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Cinematic Studio Presets",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Tested camera angles, lighting cues and video motion prompts for Indian cinema",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            PresetCategoryCard(
                categoryTitle = "Indian Cinematic Visual Styles",
                icon = Icons.Default.VideoCameraBack,
                items = listOf(
                    PresetItem(
                        title = "Photorealistic Bollywood Drama",
                        prompt = "Photorealistic Indian cinematic style, realistic skin texture, natural facial expressions, authentic clothing, cinematic depth of field, realistic lighting, 4K, vertical 9:16."
                    ),
                    PresetItem(
                        title = "Royal Rajasthani Haveli Golden Hour",
                        prompt = "Extravagant Indian heritage haveli courtyard, carved jharokhas, warm golden hour sunbeams, atmospheric dust motes, rich silk saree zari reflections, 35mm anamorphic lens."
                    ),
                    PresetItem(
                        title = "Earthy Indian Rural / Monsoon",
                        prompt = "Indian village monsoon morning, dewy mustard crops, lush green rural soil, soft overcast diffused silver light, droplets on foliage, natural cotton khadi textures."
                    )
                ),
                onCopy = { prompt, title -> copyPrompt(prompt, title) }
            )
        }

        item {
            PresetCategoryCard(
                categoryTitle = "Camera Movement Prompts",
                icon = Icons.Default.CameraAlt,
                items = listOf(
                    PresetItem(
                        title = "Dramatic Push-In (Emotional Tension)",
                        prompt = "Slow cinematic push-in from wide two-shot into eye-level close-up, rack focusing between characters, 24fps cinematic motion blur."
                    ),
                    PresetItem(
                        title = "Low Angle Heroic Tracking",
                        prompt = "Low angle tracking gimbal shot moving parallel to footsteps, dynamic upward tilt revealing majestic horizon, steady smooth motion."
                    ),
                    PresetItem(
                        title = "360-Degree Emotional Arc",
                        prompt = "Continuous smooth orbital 180-degree arc around characters, gentle camera drift capturing soft backlight."
                    )
                ),
                onCopy = { prompt, title -> copyPrompt(prompt, title) }
            )
        }

        item {
            PresetCategoryCard(
                categoryTitle = "Lighting Instructions",
                icon = Icons.Default.Lightbulb,
                items = listOf(
                    PresetItem(
                        title = "Flickering Ghee Diya Warmth",
                        prompt = "Warm amber glow from flickering oil lamps casting dancing soft shadows, warm 2700K color temperature with rich gold highlights."
                    ),
                    PresetItem(
                        title = "Chiaroscuro Night Mystery",
                        prompt = "Deep midnight blue ambient background contrasted with single warm brass lantern casting sharp dramatic rim light."
                    )
                ),
                onCopy = { prompt, title -> copyPrompt(prompt, title) }
            )
        }
    }
}

data class PresetItem(val title: String, val prompt: String)

@Composable
private fun PresetCategoryCard(
    categoryTitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    items: List<PresetItem>,
    onCopy: (String, String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = categoryTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            items.forEach { item ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.prompt,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { onCopy(item.prompt, item.title) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
