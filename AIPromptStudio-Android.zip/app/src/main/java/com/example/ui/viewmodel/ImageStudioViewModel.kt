package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserPreferences
import com.example.data.media.ImageImportHelper
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoStyle
import com.example.data.remote.GoogleAiStudioService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

enum class ImageStudioMode(val label: String) {
    CREATE_IMAGE("Create AI Image (चित्र बनाएं)"),
    EDIT_IMAGE("Edit Uploaded Image (फोटो एडिट करें)")
}

data class ImageStudioUiState(
    val mode: ImageStudioMode = ImageStudioMode.CREATE_IMAGE,
    val prompt: String = "",
    val editInstruction: String = "",
    val uploadedImageUri: String? = null,
    val selectedStyle: VideoStyle = VideoStyle.CARTOON_3D,
    val selectedAspectRatio: VideoAspectRatio = VideoAspectRatio.RATIO_9_16,
    val isGenerating: Boolean = false,
    val isImportingImage: Boolean = false,
    val imageImportError: String? = null,
    val generatedImagePath: String? = null,
    val showPaidConfirmDialog: Boolean = false,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null
)

class ImageStudioViewModel(application: Application) : AndroidViewModel(application) {

    private val aiService = GoogleAiStudioService()
    private val userPrefs = UserPreferences(application)

    private val _uiState = MutableStateFlow(ImageStudioUiState())
    val uiState: StateFlow<ImageStudioUiState> = _uiState.asStateFlow()

    fun selectMode(mode: ImageStudioMode) {
        _uiState.update { it.copy(mode = mode, errorMessage = null) }
    }

    fun updatePrompt(text: String) {
        _uiState.update { it.copy(prompt = text, errorMessage = null) }
    }

    fun updateEditInstruction(text: String) {
        _uiState.update { it.copy(editInstruction = text, errorMessage = null) }
    }

    fun setUploadedImage(uri: String?) {
        if (uri.isNullOrBlank()) {
            _uiState.update {
                it.copy(
                    uploadedImageUri = null,
                    isImportingImage = false,
                    imageImportError = null,
                    errorMessage = null
                )
            }
            return
        }
        val app = getApplication<Application>()
        val clean = uri.trim()
        val existingFile = File(clean)
        if (clean.startsWith(app.filesDir.absolutePath) && existingFile.exists() && existingFile.length() > 0L) {
            _uiState.update {
                it.copy(
                    uploadedImageUri = clean,
                    isImportingImage = false,
                    imageImportError = null,
                    errorMessage = null
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isImportingImage = true,
                    imageImportError = null,
                    errorMessage = null
                )
            }
            val result = ImageImportHelper.importImageToLocalStorage(app, clean)
            result.onSuccess { imported ->
                _uiState.update {
                    it.copy(
                        uploadedImageUri = imported.localFilePath,
                        isImportingImage = false,
                        imageImportError = null,
                        snackbarMessage = "Photo ready: ${imported.displayName} (${imported.width}x${imported.height})"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isImportingImage = false,
                        imageImportError = err.message ?: "Failed to load selected image."
                    )
                }
            }
        }
    }

    fun selectStyle(style: VideoStyle) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun selectAspectRatio(ratio: VideoAspectRatio) {
        _uiState.update { it.copy(selectedAspectRatio = ratio) }
    }

    fun prefillPrompt(promptText: String, aspectRatioStr: String? = null) {
        val ratio = aspectRatioStr?.let { r -> VideoAspectRatio.entries.find { it.ratio == r } }
        _uiState.update {
            it.copy(
                mode = ImageStudioMode.CREATE_IMAGE,
                prompt = promptText,
                selectedAspectRatio = ratio ?: it.selectedAspectRatio,
                errorMessage = null
            )
        }
    }

    fun requestGenerateOrEdit() {
        val state = _uiState.value
        if (state.mode == ImageStudioMode.CREATE_IMAGE && state.prompt.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a prompt to generate an image.") }
            return
        }
        if (state.mode == ImageStudioMode.EDIT_IMAGE) {
            if (state.uploadedImageUri.isNullOrBlank()) {
                _uiState.update { it.copy(errorMessage = "Please upload an image from gallery to edit.") }
                return
            }
            if (state.editInstruction.isBlank()) {
                _uiState.update { it.copy(errorMessage = "Please describe how you want to edit the uploaded image.") }
                return
            }
        }

        val apiKey = userPrefs.getEffectiveGeminiApiKey()
        if (apiKey.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "Google AI Image API requires a valid Gemini API key.\n\n" +
                        "• Enter your key in Settings (⚙️) or AI Studio Secrets (`GEMINI_API_KEY`).\n" +
                        "• Note: Real cloud AI image generation is never faked; you can still upload your own gallery photos in Free Video Maker or Animate Image studio anytime for free."
                )
            }
            return
        }

        _uiState.update { it.copy(showPaidConfirmDialog = true) }
    }

    fun dismissPaidConfirmDialog() {
        _uiState.update { it.copy(showPaidConfirmDialog = false) }
    }

    fun confirmAndExecuteAiImage() {
        _uiState.update { it.copy(showPaidConfirmDialog = false) }
        val state = _uiState.value
        val apiKey = userPrefs.getEffectiveGeminiApiKey()

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, errorMessage = null) }

            val imagesDir = File(getApplication<Application>().filesDir, "generated_images").apply { mkdirs() }
            val outFile = File(imagesDir, "ai_img_${System.currentTimeMillis()}.png")

            val result = if (state.mode == ImageStudioMode.CREATE_IMAGE) {
                aiService.generateImageWithGoogleAi(
                    apiKey = apiKey,
                    prompt = state.prompt,
                    style = state.selectedStyle,
                    aspectRatio = state.selectedAspectRatio.ratio,
                    outputFile = outFile
                )
            } else {
                val uploadedPath = state.uploadedImageUri!!
                val app = getApplication<Application>()
                val bytes = withContext(Dispatchers.IO) {
                    ImageImportHelper.openUriInputStream(app, uploadedPath)?.use { it.readBytes() }
                }
                if (bytes == null || bytes.isEmpty()) {
                    Result.failure(Exception("Could not read uploaded image bytes."))
                } else {
                    val mime = when (ImageImportHelper.inferExtension(null, uploadedPath)) {
                        "png" -> "image/png"
                        "webp" -> "image/webp"
                        else -> "image/jpeg"
                    }
                    aiService.editImageWithGoogleAi(
                        apiKey = apiKey,
                        imageBytes = bytes,
                        mimeType = mime,
                        instruction = state.editInstruction,
                        style = state.selectedStyle,
                        aspectRatio = state.selectedAspectRatio.ratio,
                        outputFile = outFile
                    )
                }
            }

            result.onSuccess { file ->
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        generatedImagePath = file.absolutePath,
                        snackbarMessage = "Image generated successfully!"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        errorMessage = err.message ?: "Google AI Image service unavailable."
                    )
                }
            }
        }
    }

    fun saveImageToGallery(context: Context) {
        val path = _uiState.value.generatedImagePath ?: return
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(context, "Image file not found", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            try {
                val fileName = "AIPromptStudio_${System.currentTimeMillis()}.png"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AIPromptStudio")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(file).use { input -> input.copyTo(out) }
                        }
                        values.clear()
                        values.put(MediaStore.Images.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                        Toast.makeText(context, "Saved to Pictures/AIPromptStudio/$fileName", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "AIPromptStudio").apply { mkdirs() }
                    file.copyTo(File(dir, fileName), overwrite = true)
                    Toast.makeText(context, "Saved to Pictures/AIPromptStudio/$fileName", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Save failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareImage(context: Context) {
        val path = _uiState.value.generatedImagePath ?: return
        val file = File(path)
        if (!file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share AI Image"))
        } catch (e: Exception) {
            Toast.makeText(context, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
