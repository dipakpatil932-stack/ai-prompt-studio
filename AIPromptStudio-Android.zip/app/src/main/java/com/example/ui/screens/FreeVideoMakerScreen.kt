package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.FreeVideoStep
import com.example.ui.components.VideoPlayerView
import com.example.ui.viewmodel.FreeVideoMakerUiState
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreeVideoMakerScreen(
    state: FreeVideoMakerUiState,
    onStoryPromptChange: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectAspectRatio: (String) -> Unit,
    onSelectTargetDuration: (Int) -> Unit,
    onSetSamplePrompt: (String, String) -> Unit,
    onGenerateStoryboard: () -> Unit,
    onCreateScenesManually: () -> Unit,
    onSetActiveSceneForPicker: (Int) -> Unit,
    onImageSelected: (String) -> Unit,
    onRemoveSceneImage: (Int) -> Unit,
    onUpdateSceneCaption: (Int, String) -> Unit,
    onUpdateSceneTitle: (Int, String) -> Unit,
    onUpdateSceneDuration: (Int, Int) -> Unit,
    onMoveSceneUp: (Int) -> Unit,
    onMoveSceneDown: (Int) -> Unit,
    onDeleteScene: (Int) -> Unit,
    onAddNewScene: () -> Unit,
    onStartCreateMp4: () -> Unit,
    onCancelExport: () -> Unit,
    onBackToEditor: () -> Unit,
    onBackToStoryInput: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShareVideo: () -> Unit,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Zero-permission modern Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onImageSelected(uri.toString())
        }
    }

    when (state.currentStep) {
        FreeVideoStep.STORY_INPUT -> {
            StoryInputStep(
                state = state,
                onStoryPromptChange = onStoryPromptChange,
                onSelectLanguage = onSelectLanguage,
                onSelectAspectRatio = onSelectAspectRatio,
                onSelectTargetDuration = onSelectTargetDuration,
                onSetSamplePrompt = onSetSamplePrompt,
                onGenerateStoryboard = onGenerateStoryboard,
                onCreateScenesManually = onCreateScenesManually,
                modifier = modifier
            )
        }
        FreeVideoStep.SCENE_EDITOR -> {
            SceneEditorStep(
                state = state,
                onPickImageForScene = { index ->
                    onSetActiveSceneForPicker(index)
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onRemoveSceneImage = onRemoveSceneImage,
                onUpdateSceneCaption = onUpdateSceneCaption,
                onUpdateSceneTitle = onUpdateSceneTitle,
                onUpdateSceneDuration = onUpdateSceneDuration,
                onMoveSceneUp = onMoveSceneUp,
                onMoveSceneDown = onMoveSceneDown,
                onDeleteScene = onDeleteScene,
                onAddNewScene = onAddNewScene,
                onStartCreateMp4 = onStartCreateMp4,
                onBackToStoryInput = onBackToStoryInput,
                modifier = modifier
            )
        }
        FreeVideoStep.EXPORTING -> {
            ExportingStep(
                progress = state.exportProgress,
                message = state.exportStatusMessage,
                onCancelExport = onCancelExport,
                modifier = modifier
            )
        }
        FreeVideoStep.RESULT -> {
            ResultStep(
                videoPath = state.generatedVideoPath,
                project = state.project,
                onSaveToGallery = onSaveToGallery,
                onShareVideo = onShareVideo,
                onEditAgain = onBackToEditor,
                onBackToHome = onBackToHome,
                modifier = modifier
            )
        }
    }
}

@Composable
private fun StoryInputStep(
    state: FreeVideoMakerUiState,
    onStoryPromptChange: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectAspectRatio: (String) -> Unit,
    onSelectTargetDuration: (Int) -> Unit,
    onSetSamplePrompt: (String, String) -> Unit,
    onGenerateStoryboard: () -> Unit,
    onCreateScenesManually: () -> Unit,
    modifier: Modifier = Modifier
) {
    val languages = listOf("Hindi", "Gujarati", "English")
    val aspectRatios = listOf(
        "9:16" to "9:16 Vertical (रील्स / रील्स)",
        "16:9" to "16:9 Cinema (यूट्यूब)",
        "1:1" to "1:1 Square (पोस्ट)"
    )
    val durations = listOf(
        15 to "15s (4 दृश्य)",
        30 to "30s (6 दृश्य)",
        45 to "45s (8 दृश्य)"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Feature Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.2f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Free Video Maker",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "फ्री वीडियो मेकर • 100% Free On-Device MP4 Creator",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Clear distinction notice card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp).padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "100% Free • No API Key Needed (पूरी तरह निशुल्क)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Creates real MP4 videos using your gallery photos, scene captions, and voiceover on your phone. For realistic AI motion video, use 'AI Video Generation' in the menu.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // Story input field
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Enter Your Story / Video Idea (कहानी दर्ज करें):",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = state.project.storyPrompt,
                        onValueChange = onStoryPromptChange,
                        placeholder = {
                            Text(
                                "उदा: एक गांव का किसान मेहनत से अपने बच्चों के सपने पूरे करता है...\n" +
                                "એક ગામના મહેનતુ ખેડૂતની પ્રેરણાદાયી વાર્તા...\n" +
                                "A farmer working hard in his village to fulfill his family's dreams...",
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("free_video_story_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Sample stories
                    Text(
                        text = "Quick Sample Ideas (नमूना कहानियां):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SampleChip("🌾 Village Farmer (किसान)", "गांव का एक कर्मठ किसान और उसकी हरी-भरी फसल", "Hindi") { p, l -> onSetSamplePrompt(p, l) }
                        SampleChip("🪔 Diwali Festival (दीपावली)", "दीपावली की खुशियां और पूरा परिवार साथ", "Hindi") { p, l -> onSetSamplePrompt(p, l) }
                        SampleChip("🌟 મહેનત અને સફળતા", "ગુજરાતી ગામમાં ખેડૂતની સફળતા અને ઉત્સાહની વાર્તા", "Gujarati") { p, l -> onSetSamplePrompt(p, l) }
                        SampleChip("🏞️ Nature Journey", "A peaceful journey across mist-covered mountains and sunlit rivers", "English") { p, l -> onSetSamplePrompt(p, l) }
                    }
                }
            }
        }

        // Language & Settings Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "1. Story Language (भाषा):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        languages.forEach { lang ->
                            val label = when (lang) {
                                "Hindi" -> "हिंदी (Hindi)"
                                "Gujarati" -> "ગુજરાતી (Gujarati)"
                                else -> "English"
                            }
                            FilterChip(
                                selected = state.project.language.equals(lang, ignoreCase = true),
                                onClick = { onSelectLanguage(lang) },
                                label = { Text(label, fontSize = 13.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "2. Video Format (अनुपात):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        aspectRatios.forEach { (ratio, label) ->
                            FilterChip(
                                selected = state.project.aspectRatio == ratio,
                                onClick = { onSelectAspectRatio(ratio) },
                                label = { Text(label, fontSize = 12.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "3. Video Duration (अवधि):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        durations.forEach { (sec, label) ->
                            FilterChip(
                                selected = state.targetDurationSeconds == sec,
                                onClick = { onSelectTargetDuration(sec) },
                                label = { Text(label, fontSize = 12.sp) }
                            )
                        }
                    }
                }
            }
        }

        // Error message if any
        if (state.errorMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = state.errorMessage,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Action Buttons
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onGenerateStoryboard,
                    enabled = !state.isGeneratingStory,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_generate_storyboard")
                ) {
                    if (state.isGeneratingStory) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Generating Storyboard (स्टोरीबोर्ड तैयार हो रहा है)...")
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "✨ Generate Storyboard (AI से बनाएं)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                OutlinedButton(
                    onClick = onCreateScenesManually,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_create_manual_scenes")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Create Scenes Manually (बिना AI खुद बनाएं)",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun SampleChip(label: String, prompt: String, lang: String, onSelect: (String, String) -> Unit) {
    Surface(
        onClick = { onSelect(prompt, lang) },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun SceneEditorStep(
    state: FreeVideoMakerUiState,
    onPickImageForScene: (Int) -> Unit,
    onRemoveSceneImage: (Int) -> Unit,
    onUpdateSceneCaption: (Int, String) -> Unit,
    onUpdateSceneTitle: (Int, String) -> Unit,
    onUpdateSceneDuration: (Int, Int) -> Unit,
    onMoveSceneUp: (Int) -> Unit,
    onMoveSceneDown: (Int) -> Unit,
    onDeleteScene: (Int) -> Unit,
    onAddNewScene: () -> Unit,
    onStartCreateMp4: () -> Unit,
    onBackToStoryInput: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Navigation & Title Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackToStoryInput) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "Storyboard & Photos",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.project.scenes.size} Scenes • ${state.project.scenes.sumOf { it.durationSeconds }}s total video",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Instructions Banner
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Tap 'Select Photo' to add your gallery images for each scene. You can edit captions, rearrange scenes, and tap 'Create Video' when ready!",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Scene Cards List
        itemsIndexed(state.project.scenes) { index, scene ->
            SceneCardItem(
                scene = scene,
                index = index,
                totalScenes = state.project.scenes.size,
                onPickImage = { onPickImageForScene(index) },
                onRemoveImage = { onRemoveSceneImage(index) },
                onUpdateCaption = { caption -> onUpdateSceneCaption(index, caption) },
                onUpdateTitle = { title -> onUpdateSceneTitle(index, title) },
                onUpdateDuration = { dur -> onUpdateSceneDuration(index, dur) },
                onMoveUp = { onMoveSceneUp(index) },
                onMoveDown = { onMoveSceneDown(index) },
                onDelete = { onDeleteScene(index) }
            )
        }

        // Add New Scene Button
        item {
            OutlinedButton(
                onClick = onAddNewScene,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Another Scene (नया दृश्य जोड़ें)")
            }
        }

        // Error message if any
        if (state.errorMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = state.errorMessage,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Big Primary Button: CREATE MP4 VIDEO
        item {
            Button(
                onClick = onStartCreateMp4,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981) // High-contrast success green
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_create_actual_mp4_video")
            ) {
                Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "🎬 Create MP4 Video (वीडियो बनाएं) ➔",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
private fun SceneCardItem(
    scene: FreeVideoScene,
    index: Int,
    totalScenes: Int,
    onPickImage: () -> Unit,
    onRemoveImage: () -> Unit,
    onUpdateCaption: (String) -> Unit,
    onUpdateTitle: (String) -> Unit,
    onUpdateDuration: (Int) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("scene_card_$index")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Scene Header & Reorder Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "SCENE ${scene.sceneNumber}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onMoveUp,
                        enabled = index > 0,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = onMoveDown,
                        enabled = index < totalScenes - 1,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Scene", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Image Thumbnail / Selection Area
            if (!scene.imageUri.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = scene.imageUri,
                        contentDescription = "Selected Scene Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Replace / Remove buttons overlay
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = onPickImage,
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.75f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Replace", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Surface(
                            onClick = onRemoveImage,
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.75f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Remove", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            } else {
                // Placeholder: tap to pick from phone gallery
                Surface(
                    onClick = onPickImage,
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Select Photo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "📷 Tap to Select Photo from Gallery",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "(गैलरी से फोटो चुनें या ऑटो-बैकड्रॉप का उपयोग करें)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Caption Text Field
            OutlinedTextField(
                value = scene.caption,
                onValueChange = onUpdateCaption,
                label = { Text("Scene Caption / Subtitle (कैप्शन)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Duration selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Duration: ${scene.durationSeconds}s", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(3, 4, 5, 6).forEach { sec ->
                        FilterChip(
                            selected = scene.durationSeconds == sec,
                            onClick = { onUpdateDuration(sec) },
                            label = { Text("${sec}s", fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExportingStep(
    progress: Float,
    message: String,
    onCancelExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    progress = { progress },
                    color = Color(0xFF10B981),
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.size(72.dp),
                    strokeWidth = 6.dp
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Creating MP4 Video...",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${(progress * 100).toInt()}% • $message",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                LinearProgressIndicator(
                    progress = { progress },
                    color = Color(0xFF10B981),
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedButton(
                    onClick = onCancelExport,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancel (रद्द करें)")
                }
            }
        }
    }
}

@Composable
private fun ResultStep(
    videoPath: String?,
    project: FreeVideoProject,
    onSaveToGallery: () -> Unit,
    onShareVideo: () -> Unit,
    onEditAgain: () -> Unit,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Success Header
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF10B981).copy(alpha = 0.2f),
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Video Created Successfully!",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "आपका MP4 वीडियो सफलतापूर्वक तैयार हो चुका है",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF10B981),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Embedded Playable Video Player
        item {
            if (!videoPath.isNullOrBlank()) {
                VideoPlayerView(
                    videoPathOrUrl = videoPath,
                    aspectRatio = project.aspectRatio,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("Video file not found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Video Info Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = project.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    val fileSizeKb = videoPath?.let { File(it).length() / 1024 } ?: 0
                    Text(
                        text = "Format: ${project.aspectRatio} • ${project.scenes.size} Scenes • ${project.scenes.sumOf { it.durationSeconds }}s • ${fileSizeKb} KB",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Action Buttons: Save & Share
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onSaveToGallery,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_save_free_video_gallery")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📥 Save to Phone Gallery (गैलरी में सहेजें)", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onShareVideo,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_share_free_video")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📤 Share Video (WhatsApp / Instagram)", fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onEditAgain,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit Scenes", fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = onBackToHome,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Home", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
