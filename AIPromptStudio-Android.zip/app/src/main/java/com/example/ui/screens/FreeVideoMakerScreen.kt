package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.FreeVideoStep
import com.example.data.model.StoryEmotion
import com.example.data.model.VoiceGender
import com.example.ui.components.VideoPlayerView
import com.example.ui.viewmodel.FreeVideoMakerUiState
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreeVideoMakerScreen(
    state: FreeVideoMakerUiState,
    onStoryPromptChange: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectAspectRatio: (String) -> Unit,
    onSelectTargetDuration: (Int) -> Unit,
    onSelectEmotion: (StoryEmotion) -> Unit,
    onSelectVoiceGender: (VoiceGender) -> Unit,
    onUpdateSpeechRate: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onSetBackgroundMusic: (String?, String?) -> Unit,
    onToggleMusicMute: () -> Unit,
    onSetSamplePrompt: (String, String) -> Unit,
    onGenerateStoryboard: () -> Unit,
    onGenerateAutomaticVoiceover: () -> Unit,
    onPreviewVoiceForScene: (Int) -> Unit,
    onStopVoicePreview: () -> Unit,
    onCreateScenesManually: () -> Unit,
    onSetActiveSceneForPicker: (Int) -> Unit,
    onImageSelected: (String) -> Unit,
    onRemoveSceneImage: (Int) -> Unit,
    onUpdateSceneCaption: (Int, String) -> Unit,
    onUpdateSceneNarration: (Int, String) -> Unit,
    onUpdateSceneTitle: (Int, String) -> Unit,
    onUpdateSceneDuration: (Int, Int) -> Unit,
    onMoveSceneUp: (Int) -> Unit,
    onMoveSceneDown: (Int) -> Unit,
    onDeleteScene: (Int) -> Unit,
    onAddNewScene: () -> Unit,
    onStartCreateMp4: () -> Unit,
    onCancelExport: () -> Unit,
    onBackToEditor: () -> Unit,
    onBackToStoryInput: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShareVideo: () -> Unit,
    onBackToHome: () -> Unit,
    onTestVoice: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Zero-permission modern Android Photo Picker for scene images
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onImageSelected(uri.toString())
        }
    }

    // Audio file picker for custom background music
    val musicPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val displayName = uri.lastPathSegment ?: "Custom Music"
            onSetBackgroundMusic(uri.toString(), displayName)
        }
    }

    when (state.currentStep) {
        FreeVideoStep.STORY_INPUT -> {
            StoryInputStep(
                state = state,
                onStoryPromptChange = onStoryPromptChange,
                onSelectLanguage = onSelectLanguage,
                onSelectAspectRatio = onSelectAspectRatio,
                onSelectTargetDuration = onSelectTargetDuration,
                onSelectEmotion = onSelectEmotion,
                onSelectVoiceGender = onSelectVoiceGender,
                onSetSamplePrompt = onSetSamplePrompt,
                onGenerateStoryboard = onGenerateStoryboard,
                onCreateScenesManually = onCreateScenesManually,
                onTestVoice = onTestVoice,
                modifier = modifier
            )
        }
        FreeVideoStep.SCENE_EDITOR -> {
            SceneEditorStep(
                state = state,
                onPickImageForScene = { index ->
                    onSetActiveSceneForPicker(index)
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onPickBackgroundMusic = {
                    musicPickerLauncher.launch("audio/*")
                },
                onToggleMusicMute = onToggleMusicMute,
                onSelectEmotion = onSelectEmotion,
                onSelectVoiceGender = onSelectVoiceGender,
                onUpdateSpeechRate = onUpdateSpeechRate,
                onUpdateSpeechPitch = onUpdateSpeechPitch,
                onGenerateAutomaticVoiceover = onGenerateAutomaticVoiceover,
                onPreviewVoiceForScene = onPreviewVoiceForScene,
                onStopVoicePreview = onStopVoicePreview,
                onRemoveSceneImage = onRemoveSceneImage,
                onUpdateSceneCaption = onUpdateSceneCaption,
                onUpdateSceneNarration = onUpdateSceneNarration,
                onUpdateSceneTitle = onUpdateSceneTitle,
                onUpdateSceneDuration = onUpdateSceneDuration,
                onMoveSceneUp = onMoveSceneUp,
                onMoveSceneDown = onMoveSceneDown,
                onDeleteScene = onDeleteScene,
                onAddNewScene = onAddNewScene,
                onStartCreateMp4 = onStartCreateMp4,
                onBackToStoryInput = onBackToStoryInput,
                onTestVoice = onTestVoice,
                modifier = modifier
            )
        }
        FreeVideoStep.EXPORTING -> {
            ExportingStep(
                progress = state.exportProgress,
                message = state.exportStatusMessage,
                onCancelExport = onCancelExport,
                modifier = modifier
            )
        }
        FreeVideoStep.RESULT -> {
            ResultStep(
                videoPath = state.generatedVideoPath,
                project = state.project,
                onSaveToGallery = onSaveToGallery,
                onShareVideo = onShareVideo,
                onEditAgain = onBackToEditor,
                onBackToHome = onBackToHome,
                modifier = modifier
            )
        }
    }
}

@Composable
private fun StoryInputStep(
    state: FreeVideoMakerUiState,
    onStoryPromptChange: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectAspectRatio: (String) -> Unit,
    onSelectTargetDuration: (Int) -> Unit,
    onSelectEmotion: (StoryEmotion) -> Unit,
    onSelectVoiceGender: (VoiceGender) -> Unit,
    onSetSamplePrompt: (String, String) -> Unit,
    onGenerateStoryboard: () -> Unit,
    onCreateScenesManually: () -> Unit,
    onTestVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val languages = listOf("Auto (ऑटो डिटेक्ट)", "Hindi (हिंदी)", "Gujarati (ગુજરાતી)", "English")
    val aspectRatios = listOf(
        "9:16" to "9:16 Vertical (रील्स / रील्स)",
        "16:9" to "16:9 Cinema (यूट्यूब)",
        "1:1" to "1:1 Square (पोस्ट)"
    )
    val durations = listOf(
        15 to "15s (4 दृश्य)",
        30 to "30s (6 दृश्य)",
        45 to "45s (8 दृश्य)"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Feature Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.2f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Free Video Maker",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "🎙️ ऑटोमैटिक स्टोरी वॉइसओवर & ऑडियो सिंक • 100% Free",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Voiceover Highlight Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Automated Voiceover & Music Sync",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "कहानी लिखते ही हिंदी, गुजराती और अंग्रेज़ी में प्राकृतिक आवाज़ (पुरुष/महिला), भाव अनुसार गति और बैकग्राउंड म्यूज़िक डकिंग के साथ MP4 वीडियो तैयार होता है।",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Story Input Field
        item {
            Column {
                Text(
                    text = "1. Enter Story or Video Idea (अपनी कहानी दर्ज करें)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = state.project.storyPrompt,
                    onValueChange = onStoryPromptChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .testTag("free_video_story_input"),
                    placeholder = {
                        Text("उदा: गांव के एक परिश्रमी किसान की सफलता की प्रेरणादायक कहानी... (Hindi, Gujarati or English)")
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Story Samples
                Text(
                    text = "💡 Quick Story Ideas (सुझाए गए विचार):",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SampleChip(
                        label = "🌾 किसान की प्रेरणा (Hindi)",
                        prompt = "एक छोटे किसान ने जैविक खेती की तकनीक सीखकर बंजर जमीन पर हरियाली लहराई और पूरे गांव को आत्मनिर्भर बनाया।",
                        lang = "Hindi",
                        onSelect = onSetSamplePrompt
                    )
                    SampleChip(
                        label = "🚀 ગુજરાતી ઉદ્યોગ સાહસિક",
                        prompt = "એક નાનકડા ગામના યુવાને પોતાની મહેનતથી ઓનલાઇન વ્યાપાર શરૂ કરી સમગ્ર ગુજરાતમાં નામ રોશન કર્યું.",
                        lang = "Gujarati",
                        onSelect = onSetSamplePrompt
                    )
                    SampleChip(
                        label = "💡 Solar Innovation (English)",
                        prompt = "A determined girl in a rural school designs an affordable solar lantern that lights up every study table in her village.",
                        lang = "English",
                        onSelect = onSetSamplePrompt
                    )
                    SampleChip(
                        label = "🕉️ भक्ति व शांति (Devotional)",
                        prompt = "प्राचीन मंदिर की सुबह की आरती और घंटी की मधुर गूंज में मन को असीम शांति मिलती है।",
                        lang = "Hindi",
                        onSelect = onSetSamplePrompt
                    )
                }
            }
        }

        // Emotion & Mood Preset Selection
        item {
            Column {
                Text(
                    text = "2. Story Mood & Emotion (कहानी का भाव)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "भाव के आधार पर आवाज की गति, पिच और बैकग्राउंड म्यूज़िक टोन सेट होती है",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StoryEmotion.entries.forEach { emotion ->
                        FilterChip(
                            selected = state.project.emotion == emotion,
                            onClick = { onSelectEmotion(emotion) },
                            label = { Text(emotion.displayName, fontSize = 12.sp) },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }
        }

        // Voice Character / Gender Selection
        item {
            Column {
                Text(
                    text = "3. Voice Choice (आवाज़ का प्रकार)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    VoiceGender.entries.forEach { gender ->
                        FilterChip(
                            selected = state.project.voiceGender == gender,
                            onClick = { onSelectVoiceGender(gender) },
                            label = { Text(gender.displayName, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (gender == VoiceGender.FEMALE) Icons.Default.RecordVoiceOver else Icons.Default.Mic,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onTestVoice,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF10B981)),
                    modifier = Modifier.testTag("btn_test_voice_story_input")
                ) {
                    Icon(
                        imageVector = if (state.isVoicePreviewPlaying && state.previewingSceneIndex == -1) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.isVoicePreviewPlaying && state.previewingSceneIndex == -1) "Stop Voice (आवाज़ रोकें)" else "Test Voice (आवाज़ चलाकर देखें)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Language & Format Selectors
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Language
                Column {
                    Text(
                        text = "4. Language (भाषा)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        languages.forEach { lang ->
                            val cleanLang = lang.substringBefore(" ")
                            FilterChip(
                                selected = state.project.language == cleanLang || (state.project.language == "Auto" && cleanLang == "Auto"),
                                onClick = { onSelectLanguage(cleanLang) },
                                label = { Text(lang, fontSize = 12.sp) },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }

                // Format Aspect Ratio
                Column {
                    Text(
                        text = "5. Video Format (अनुपात)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        aspectRatios.forEach { (ratio, label) ->
                            FilterChip(
                                selected = state.project.aspectRatio == ratio,
                                onClick = { onSelectAspectRatio(ratio) },
                                label = { Text(label, fontSize = 12.sp) },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }

                // Target Duration
                Column {
                    Text(
                        text = "6. Target Duration (लक्षित अवधि)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        durations.forEach { (dur, label) ->
                            FilterChip(
                                selected = state.targetDurationSeconds == dur,
                                onClick = { onSelectTargetDuration(dur) },
                                label = { Text(label, fontSize = 12.sp) },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Error message if any
        if (state.errorMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = state.errorMessage,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Action Buttons: Generate Storyboard or Manual
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onGenerateStoryboard,
                    enabled = !state.isGeneratingStory,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF10B981) // High-contrast green
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btn_generate_free_storyboard")
                ) {
                    if (state.isGeneratingStory) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Understanding Story & Generating Voice...", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Generate Story, Voice & Scenes (कहानी बनाएं) ➔",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                OutlinedButton(
                    onClick = onCreateScenesManually,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_create_scenes_manually")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Or Create Scenes Manually (खुद दृश्य बनाएं)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun SampleChip(label: String, prompt: String, lang: String, onSelect: (String, String) -> Unit) {
    Surface(
        onClick = { onSelect(prompt, lang) },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun SceneEditorStep(
    state: FreeVideoMakerUiState,
    onPickImageForScene: (Int) -> Unit,
    onPickBackgroundMusic: () -> Unit,
    onToggleMusicMute: () -> Unit,
    onSelectEmotion: (StoryEmotion) -> Unit,
    onSelectVoiceGender: (VoiceGender) -> Unit,
    onUpdateSpeechRate: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onGenerateAutomaticVoiceover: () -> Unit,
    onPreviewVoiceForScene: (Int) -> Unit,
    onStopVoicePreview: () -> Unit,
    onRemoveSceneImage: (Int) -> Unit,
    onUpdateSceneCaption: (Int, String) -> Unit,
    onUpdateSceneNarration: (Int, String) -> Unit,
    onUpdateSceneTitle: (Int, String) -> Unit,
    onUpdateSceneDuration: (Int, Int) -> Unit,
    onMoveSceneUp: (Int) -> Unit,
    onMoveSceneDown: (Int) -> Unit,
    onDeleteScene: (Int) -> Unit,
    onAddNewScene: () -> Unit,
    onStartCreateMp4: () -> Unit,
    onBackToStoryInput: () -> Unit,
    onTestVoice: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showVoiceSettingsDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Navigation & Title Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackToStoryInput) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Storyboard & Voiceover",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.project.scenes.size} Scenes • ${state.project.scenes.sumOf { it.durationSeconds }}s video • ${state.project.emotion.displayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Voice controls shortcut
                IconButton(onClick = { showVoiceSettingsDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Voice & Music Settings",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Voiceover & Background Music Toolbar Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Automatic Voiceover (Android TTS)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = onTestVoice,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(32.dp).testTag("btn_test_voice_editor")
                            ) {
                                Icon(
                                    imageVector = if (state.isVoicePreviewPlaying && state.previewingSceneIndex == -1) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = if (state.isVoicePreviewPlaying && state.previewingSceneIndex == -1) MaterialTheme.colorScheme.error else Color(0xFF10B981)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (state.isVoicePreviewPlaying && state.previewingSceneIndex == -1) "Stop" else "Test Voice",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Button(
                                onClick = onGenerateAutomaticVoiceover,
                                enabled = !state.isGeneratingVoiceover,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                if (state.isGeneratingVoiceover) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Syncing...", fontSize = 11.sp)
                                } else {
                                    Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Re-Sync Voice", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Background Music bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (state.project.isMusicMuted) Icons.Default.MusicOff else Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = if (state.project.isMusicMuted) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (state.project.audioUri != null) "Music: ${state.project.bgMusicName ?: "Custom File"}" else "Suggested: ${state.project.emotion.defaultMusicDesc.take(32)}...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (state.project.isMusicMuted) "Muted (म्यूट)" else "Auto-Ducking: Soft during speech, loud during pauses",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = onToggleMusicMute, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = if (state.project.isMusicMuted) Icons.Default.MusicOff else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Mute Music",
                                    tint = if (state.project.isMusicMuted) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            OutlinedButton(
                                onClick = onPickBackgroundMusic,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Select Music", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Scene Cards List
        itemsIndexed(state.project.scenes) { index, scene ->
            SceneCardItem(
                scene = scene,
                index = index,
                totalScenes = state.project.scenes.size,
                isPreviewPlaying = state.isVoicePreviewPlaying && state.previewingSceneIndex == index,
                onPickImage = { onPickImageForScene(index) },
                onRemoveImage = { onRemoveSceneImage(index) },
                onUpdateCaption = { caption -> onUpdateSceneCaption(index, caption) },
                onUpdateNarration = { narration -> onUpdateSceneNarration(index, narration) },
                onPreviewVoice = {
                    if (state.isVoicePreviewPlaying && state.previewingSceneIndex == index) {
                        onStopVoicePreview()
                    } else {
                        onPreviewVoiceForScene(index)
                    }
                },
                onUpdateTitle = { title -> onUpdateSceneTitle(index, title) },
                onUpdateDuration = { dur -> onUpdateSceneDuration(index, dur) },
                onMoveUp = { onMoveSceneUp(index) },
                onMoveDown = { onMoveSceneDown(index) },
                onDelete = { onDeleteScene(index) }
            )
        }

        // Add New Scene Button
        item {
            OutlinedButton(
                onClick = onAddNewScene,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Another Scene (नया दृश्य जोड़ें)")
            }
        }

        // Error message if any
        if (state.errorMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = state.errorMessage,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Big Primary Button: CREATE MP4 VIDEO
        item {
            Button(
                onClick = onStartCreateMp4,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981) // High-contrast success green
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_create_actual_mp4_video")
            ) {
                Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "🎬 Create Final MP4 Video (वीडियो बनाएं) ➔",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        }
    }

    // Voice & Audio Configuration Dialog
    if (showVoiceSettingsDialog) {
        VoiceSettingsDialog(
            project = state.project,
            onDismiss = { showVoiceSettingsDialog = false },
            onSelectEmotion = onSelectEmotion,
            onSelectVoiceGender = onSelectVoiceGender,
            onUpdateSpeechRate = onUpdateSpeechRate,
            onUpdateSpeechPitch = onUpdateSpeechPitch,
            onApplyAndReSync = {
                showVoiceSettingsDialog = false
                onGenerateAutomaticVoiceover()
            }
        )
    }
}

@Composable
private fun SceneCardItem(
    scene: FreeVideoScene,
    index: Int,
    totalScenes: Int,
    isPreviewPlaying: Boolean,
    onPickImage: () -> Unit,
    onRemoveImage: () -> Unit,
    onUpdateCaption: (String) -> Unit,
    onUpdateNarration: (String) -> Unit,
    onPreviewVoice: () -> Unit,
    onUpdateTitle: (String) -> Unit,
    onUpdateDuration: (Int) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("scene_card_$index")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Scene Header & Reorder Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "SCENE ${scene.sceneNumber}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onMoveUp,
                        enabled = index > 0,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = onMoveDown,
                        enabled = index < totalScenes - 1,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Scene", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Image Thumbnail / Selection Area
            if (!scene.imageUri.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = scene.imageUri,
                        contentDescription = "Selected Scene Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Replace / Remove buttons overlay
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            onClick = onPickImage,
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.75f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Replace", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Surface(
                            onClick = onRemoveImage,
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.75f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Remove", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            } else {
                // Placeholder: tap to pick from phone gallery
                Surface(
                    onClick = onPickImage,
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Select Photo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "📷 Tap to Select Photo from Gallery",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "(गैलरी से फोटो चुनें या ऑटो-बैकड्रॉप का उपयोग करें)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Narration Voiceover Script Box
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Voiceover Script (बोली जाने वाली वाणी)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }

                    // Voice preview button
                    TextButton(
                        onClick = onPreviewVoice,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = if (isPreviewPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (isPreviewPlaying) MaterialTheme.colorScheme.error else Color(0xFF10B981),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isPreviewPlaying) "Stop" else "Preview Voice",
                            fontSize = 11.sp,
                            color = if (isPreviewPlaying) MaterialTheme.colorScheme.error else Color(0xFF10B981),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                OutlinedTextField(
                    value = scene.narrationText.ifBlank { scene.caption },
                    onValueChange = onUpdateNarration,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                    ),
                    maxLines = 3
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Caption Text Field (On-screen subtitle)
            OutlinedTextField(
                value = scene.caption,
                onValueChange = onUpdateCaption,
                label = { Text("On-Screen Caption / Subtitle (स्क्रीन कैप्शन)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Synchronized Duration indicator & manual adjuster
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Scene Timing: ${scene.durationSeconds}s", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (scene.calculatedAudioDurationMs > 0) {
                        Text(
                            text = "Audio: ${(scene.calculatedAudioDurationMs / 1000.0).format(1)}s + 0.8s pause",
                            fontSize = 10.sp,
                            color = Color(0xFF10B981)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(3, 4, 5, 6, 8).forEach { sec ->
                        FilterChip(
                            selected = scene.durationSeconds == sec,
                            onClick = { onUpdateDuration(sec) },
                            label = { Text("${sec}s", fontSize = 11.sp) }
                        )
                    }
                }
            }
        }
    }
}

private fun Double.format(digits: Int) = "%.${digits}f".format(this)

@Composable
private fun VoiceSettingsDialog(
    project: FreeVideoProject,
    onDismiss: () -> Unit,
    onSelectEmotion: (StoryEmotion) -> Unit,
    onSelectVoiceGender: (VoiceGender) -> Unit,
    onUpdateSpeechRate: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onApplyAndReSync: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🎙️ Voice & Expression Settings", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Emotion selector
                Column {
                    Text("Story Emotion & Delivery", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StoryEmotion.entries.forEach { emo ->
                            FilterChip(
                                selected = project.emotion == emo,
                                onClick = { onSelectEmotion(emo) },
                                label = { Text(emo.displayName, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                // Gender selector
                Column {
                    Text("Voice Gender", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VoiceGender.entries.forEach { gender ->
                            FilterChip(
                                selected = project.voiceGender == gender,
                                onClick = { onSelectVoiceGender(gender) },
                                label = { Text(gender.displayName, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                // Speech Speed
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Speech Speed: ${"%.2f".format(project.speechRate)}x", fontSize = 12.sp)
                    }
                    Slider(
                        value = project.speechRate,
                        onValueChange = onUpdateSpeechRate,
                        valueRange = 0.7f..1.4f,
                        steps = 6
                    )
                }

                // Speech Pitch
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Voice Pitch: ${"%.2f".format(project.speechPitch)}x", fontSize = 12.sp)
                    }
                    Slider(
                        value = project.speechPitch,
                        onValueChange = onUpdateSpeechPitch,
                        valueRange = 0.7f..1.4f,
                        steps = 6
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onApplyAndReSync) {
                Text("Apply & Re-Sync")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun ExportingStep(
    progress: Float,
    message: String,
    onCancelExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.size(80.dp),
                    color = Color(0xFF10B981),
                    strokeWidth = 6.dp
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF10B981)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Creating Playable MP4 Video",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = message.ifBlank { "Processing video frames and audio..." },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFF10B981)
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedButton(
                    onClick = onCancelExport,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Cancel (रद्द करें)", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun ResultStep(
    videoPath: String?,
    project: FreeVideoProject,
    onSaveToGallery: () -> Unit,
    onShareVideo: () -> Unit,
    onEditAgain: () -> Unit,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Success Header
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF10B981).copy(alpha = 0.2f),
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "MP4 Video Created With Voiceover! 🎬",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "आपका MP4 वीडियो वॉइसओवर और बैकग्राउंड म्यूज़िक के साथ तैयार है",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF10B981),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Embedded Playable Video Player
        item {
            if (!videoPath.isNullOrBlank()) {
                VideoPlayerView(
                    videoPathOrUrl = videoPath,
                    aspectRatio = project.aspectRatio,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("Video file not found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Video Info Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = project.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    val fileSizeKb = videoPath?.let { File(it).length() / 1024 } ?: 0
                    Text(
                        text = "Format: ${project.aspectRatio} • ${project.scenes.size} Scenes • ${project.scenes.sumOf { it.durationSeconds }}s • ${project.emotion.displayName} • ${fileSizeKb} KB",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Action Buttons: Save & Share
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onSaveToGallery,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_save_free_video_gallery")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📥 Save to Phone Gallery (गैलरी में सहेजें)", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onShareVideo,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_share_free_video")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📤 Share Video (शेयर करें)", fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onEditAgain,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit Story", fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = onBackToHome,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Home", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
