package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SceneItem

@Composable
fun SceneCard(
    scene: SceneItem,
    isRegenerating: Boolean = false,
    onCopy: (String) -> Unit,
    onRegenerate: () -> Unit,
    onSave: () -> Unit,
    onShare: (String) -> Unit,
    onGenerateVideo: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    val formattedSceneText = remember(scene) {
        buildString {
            appendLine("🎬 SCENE ${String.format("%02d", scene.sceneNumber)}")
            appendLine("Duration: ${scene.duration}")
            appendLine()
            appendLine("VISUAL PROMPT:")
            appendLine(scene.visualPrompt)
            appendLine()
            appendLine("DIALOGUE:")
            appendLine(scene.dialogue)
            appendLine()
            appendLine("CAMERA:")
            appendLine(scene.camera)
            appendLine()
            appendLine("LIGHTING:")
            appendLine(scene.lighting)
            appendLine()
            appendLine("AUDIO:")
            appendLine(scene.audio)
            appendLine()
            appendLine("CONTINUITY:")
            appendLine(scene.continuity)
            if (scene.imagePrompt.isNotBlank()) {
                appendLine()
                appendLine("IMAGE PROMPT:")
                appendLine(scene.imagePrompt)
            }
            if (scene.videoPrompt.isNotBlank()) {
                appendLine()
                appendLine("VIDEO PROMPT:")
                appendLine(scene.videoPrompt)
            }
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("scene_card_${scene.sceneNumber}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Scene Number & Duration badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Text(
                            text = "Scene ${String.format("%02d", scene.sceneNumber)}",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Text(
                            text = "⏱ ${scene.duration}",
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }

                if (isRegenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // VISUAL PROMPT
            SectionBlock(
                title = "VISUAL PROMPT",
                badgeEmoji = "🎥",
                content = scene.visualPrompt,
                contentColor = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(12.dp))

            // DIALOGUE
            SectionBlock(
                title = "DIALOGUE",
                badgeEmoji = "💬",
                content = scene.dialogue,
                contentColor = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // CAMERA
            SectionBlock(
                title = "CAMERA",
                badgeEmoji = "📹",
                content = scene.camera,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // LIGHTING
            SectionBlock(
                title = "LIGHTING",
                badgeEmoji = "💡",
                content = scene.lighting,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // AUDIO
            SectionBlock(
                title = "AUDIO",
                badgeEmoji = "🔊",
                content = scene.audio,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // CONTINUITY
            SectionBlock(
                title = "CONTINUITY",
                badgeEmoji = "🔄",
                content = scene.continuity,
                contentColor = MaterialTheme.colorScheme.tertiary
            )

            // Optional expanded details (Image prompt, Video prompt, Facial expression, Voice)
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    if (scene.facialExpression.isNotBlank()) {
                        SectionBlock(
                            title = "FACIAL EXPRESSIONS",
                            badgeEmoji = "🎭",
                            content = scene.facialExpression,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (scene.voiceInstruction.isNotBlank()) {
                        SectionBlock(
                            title = "VOICE INSTRUCTIONS",
                            badgeEmoji = "🎙️",
                            content = scene.voiceInstruction,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (scene.imagePrompt.isNotBlank()) {
                        SectionBlock(
                            title = "IMAGE PROMPT (Midjourney / Flux)",
                            badgeEmoji = "🖼️",
                            content = scene.imagePrompt,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (scene.videoPrompt.isNotBlank()) {
                        SectionBlock(
                            title = "VIDEO PROMPT (Runway / Luma / Kling)",
                            badgeEmoji = "🎞️",
                            content = scene.videoPrompt,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Expand/collapse button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                OutlinedButton(
                    onClick = { isExpanded = !isExpanded },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("expand_scene_${scene.sceneNumber}")
                ) {
                    Text(
                        text = if (isExpanded) "Less Details" else "AI Tool Prompts & Expressions",
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: 📋 Copy, 🔄 Regenerate, 💾 Save, 📤 Share
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ActionButtonItem(
                    icon = Icons.Default.ContentCopy,
                    label = "Copy",
                    tag = "copy_scene_${scene.sceneNumber}",
                    onClick = { onCopy(formattedSceneText) }
                )

                ActionButtonItem(
                    icon = Icons.Default.Refresh,
                    label = "Regenerate",
                    tag = "regen_scene_${scene.sceneNumber}",
                    onClick = onRegenerate
                )

                ActionButtonItem(
                    icon = Icons.Default.Bookmark,
                    label = "Save",
                    tag = "save_scene_${scene.sceneNumber}",
                    onClick = onSave
                )

                ActionButtonItem(
                    icon = Icons.Default.Share,
                    label = "Share",
                    tag = "share_scene_${scene.sceneNumber}",
                    onClick = { onShare(formattedSceneText) }
                )
            }

            if (onGenerateVideo != null) {
                Spacer(modifier = Modifier.height(10.dp))
                androidx.compose.material3.FilledTonalButton(
                    onClick = {
                        val prompt = "${scene.visualPrompt}. Dialogue: ${scene.dialogue}"
                        onGenerateVideo(prompt)
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("scene_generate_video_button_${scene.sceneNumber}")
                ) {
                    Text(
                        text = "🎬 Generate Actual Video Clip (यह सीन बनाएं)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionBlock(
    title: String,
    badgeEmoji: String,
    content: String,
    contentColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = badgeEmoji, fontSize = 14.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.5.sp
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = content,
            style = MaterialTheme.typography.bodyMedium,
            color = contentColor,
            lineHeight = 20.sp
        )
    }
}

@Composable
private fun ActionButtonItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tag: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp),
        modifier = Modifier
            .testTag(tag)
            .height(36.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
