package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.media.ImageImportHelper
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoStyle
import com.example.ui.components.SelectedImagePreviewBox
import com.example.ui.components.rememberUnifiedImagePicker
import com.example.ui.viewmodel.ImageStudioMode
import com.example.ui.viewmodel.ImageStudioUiState

@Composable
fun ImageStudioScreen(
    state: ImageStudioUiState,
    onSelectMode: (ImageStudioMode) -> Unit,
    onPromptChange: (String) -> Unit,
    onEditInstructionChange: (String) -> Unit,
    onUploadedImageSelected: (String?) -> Unit,
    onSelectStyle: (VideoStyle) -> Unit,
    onSelectAspectRatio: (VideoAspectRatio) -> Unit,
    onRequestGenerate: () -> Unit,
    onConfirmPaidImage: () -> Unit,
    onDismissPaidDialog: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShareImage: () -> Unit,
    onAnimateThisImage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val imagePicker = rememberUnifiedImagePicker { uri ->
        onUploadedImageSelected(uri.toString())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Brush, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Image Creator & Editor",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "3D कार्टून व रियलिस्टिक इमेज बनाएं या फोटो एडिट करें • Gemini Flash Image & Imagen 3",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Mode Tabs (Create vs Edit)
        item {
            val selectedIdx = if (state.mode == ImageStudioMode.CREATE_IMAGE) 0 else 1
            TabRow(
                selectedTabIndex = selectedIdx,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedIdx == 0,
                    onClick = { onSelectMode(ImageStudioMode.CREATE_IMAGE) },
                    text = { Text("Create AI Image", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("tab_create_ai_image")
                )
                Tab(
                    selected = selectedIdx == 1,
                    onClick = { onSelectMode(ImageStudioMode.EDIT_IMAGE) },
                    text = { Text("Edit Photo", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("tab_edit_ai_image")
                )
            }
        }

        // Main Input Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (state.mode == ImageStudioMode.CREATE_IMAGE) {
                        Text("Describe Image (चित्र का विवरण):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        OutlinedTextField(
                            value = state.prompt,
                            onValueChange = onPromptChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp)
                                .testTag("image_studio_prompt_input"),
                            placeholder = {
                                Text("e.g., Cute 3D Pixar Indian boy and his grandmother lighting Diwali diyas in a cozy village courtyard")
                            },
                            shape = RoundedCornerShape(12.dp)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "3D Cartoon Village Boy" to "Adorable 3D animated Indian boy in orange kurta smiling near emerald mustard field, golden sunlight",
                                "Realistic Haveli Queen" to "Photorealistic royal Indian princess looking out of carved sandstone haveli window at sunset, crimson silk",
                                "Krishna Flute Art" to "Vibrant 3D animated young Krishna playing bamboo flute under sacred kadamba tree beside glowing peacock"
                            ).forEach { (chipLabel, samplePrompt) ->
                                Surface(
                                    onClick = { onPromptChange(samplePrompt) },
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Text(chipLabel, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                }
                            }
                        }
                    } else {
                        Text("1. Upload Photo to Edit (फोटो चुनें):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        SelectedImagePreviewBox(
                            imageUriOrPath = state.uploadedImageUri,
                            isImporting = state.isImportingImage,
                            errorMessage = state.imageImportError,
                            pickerHandle = imagePicker,
                            height = 190.dp,
                            emptyTitle = "Tap to Pick Photo from Gallery",
                            emptySubtitle = "Supports JPG, JPEG, PNG, WEBP • Gallery or Files",
                            testTagPrefix = "image_studio_edit"
                        )

                        Text("2. Edit Instructions (क्या बदलना है?):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        OutlinedTextField(
                            value = state.editInstruction,
                            onValueChange = onEditInstructionChange,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .testTag("image_studio_edit_instruction"),
                            placeholder = {
                                Text("e.g., Transform into 3D Pixar cartoon style and change background to glowing Diwali courtyard")
                            },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    Text("Visual Style (शैली):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoStyle.entries.forEach { style ->
                            FilterChip(
                                selected = state.selectedStyle == style,
                                onClick = { onSelectStyle(style) },
                                label = { Text("${style.displayName} (${style.hindiName})", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Text("Aspect Ratio (अनुपात):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoAspectRatio.entries.forEach { ratio ->
                            FilterChip(
                                selected = state.selectedAspectRatio == ratio,
                                onClick = { onSelectAspectRatio(ratio) },
                                label = { Text("${ratio.ratio} (${ratio.hindiLabel})", fontSize = 11.sp) }
                            )
                        }
                    }

                    Button(
                        onClick = onRequestGenerate,
                        enabled = !state.isGenerating,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_generate_or_edit_image")
                    ) {
                        if (state.isGenerating) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Processing via Google AI...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (state.mode == ImageStudioMode.CREATE_IMAGE) "Generate AI Image (चित्र बनाएं)" else "Edit Image with AI (एडिट करें)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Honest API Error / Billing Status Box
        if (state.errorMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(state.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp, lineHeight = 18.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = onRequestGenerate, modifier = Modifier.height(38.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Retry", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Generated / Edited Image Preview + Save / Share / Animate Handoff
        if (!state.generatedImagePath.isNullOrBlank()) {
            val imgPath = state.generatedImagePath
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("image_studio_result_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("AI Generated Image", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF059669))

                        AsyncImage(
                            model = ImageImportHelper.toCoilModel(imgPath),
                            contentDescription = "AI Generated Image Result",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.Black.copy(alpha = 0.05f))
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onSaveToGallery,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_save_ai_image")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save Photo", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            OutlinedButton(
                                onClick = onShareImage,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_share_ai_image")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Button(
                            onClick = { onAnimateThisImage(imgPath) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_animate_generated_image")
                        ) {
                            Icon(Icons.Default.Animation, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Animate This Image into Video ->", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }

    if (state.showPaidConfirmDialog) {
        AlertDialog(
            onDismissRequest = onDismissPaidDialog,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Confirm Google AI Image Request", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "This action calls Google Gemini / Imagen 3 Image API using your configured API key and may consume quota or cloud credits.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = onConfirmPaidImage) { Text("Generate Image") }
            },
            dismissButton = {
                TextButton(onClick = onDismissPaidDialog) { Text("Cancel") }
            }
        )
    }
}
