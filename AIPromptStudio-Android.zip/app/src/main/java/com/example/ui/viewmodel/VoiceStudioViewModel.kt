package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.AudioDownloadExporter
import com.example.data.audio.AudioExportResult
import com.example.data.audio.StoryVoiceManager
import com.example.data.local.UserPreferences
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.StoryEmotion
import com.example.data.model.VoiceGender
import com.example.data.remote.GoogleAiStudioService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class VoiceEngineOption(val label: String, val isCloudPaid: Boolean) {
    FREE_DEVICE_TTS("Free AI Voice (Android Offline TTS • No API Key)", false),
    CLOUD_GEMINI_TTS("Google Gemini Cloud Voice (API Key Required)", true)
}

data class CloudVoicePreset(
    val id: String,
    val label: String,
    val gender: VoiceGender
)

data class VoiceStudioUiState(
    val scriptText: String = "",
    val language: String = "Hindi",
    val voiceGender: VoiceGender = VoiceGender.FEMALE,
    val emotion: StoryEmotion = StoryEmotion.MOTIVATIONAL,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val engineOption: VoiceEngineOption = VoiceEngineOption.FREE_DEVICE_TTS,
    val selectedCloudVoice: String = "Kore",
    val lockVoiceAcrossScenes: Boolean = true,
    val isSynthesizing: Boolean = false,
    val isPlayingPreview: Boolean = false,
    val generatedWavPath: String? = null,
    val generatedDurationMs: Long = 0L,
    val lastExportResult: AudioExportResult? = null,
    val showPaidConfirmDialog: Boolean = false,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null
)

class VoiceStudioViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        val CLOUD_VOICES = listOf(
            CloudVoicePreset("Kore", "Kore — Clear Studio Female", VoiceGender.FEMALE),
            CloudVoicePreset("Aoede", "Aoede — Warm Story Female", VoiceGender.FEMALE),
            CloudVoicePreset("Puck", "Puck — Friendly Narrative Male", VoiceGender.MALE),
            CloudVoicePreset("Charon", "Charon — Deep Cinematic Male", VoiceGender.MALE)
        )
    }

    private val voiceManager = StoryVoiceManager(application)
    private val audioExporter = AudioDownloadExporter(application)
    private val aiService = GoogleAiStudioService()
    private val userPrefs = UserPreferences(application)

    private val _uiState = MutableStateFlow(VoiceStudioUiState())
    val uiState: StateFlow<VoiceStudioUiState> = _uiState.asStateFlow()

    fun updateScriptText(text: String) {
        _uiState.update { it.copy(scriptText = text, errorMessage = null) }
    }

    fun selectLanguage(lang: String) {
        _uiState.update { it.copy(language = lang, errorMessage = null) }
    }

    fun selectGender(gender: VoiceGender) {
        val suggestedCloud = if (gender == VoiceGender.FEMALE) "Kore" else "Puck"
        _uiState.update {
            it.copy(
                voiceGender = gender,
                selectedCloudVoice = if (CLOUD_VOICES.firstOrNull { v -> v.id == it.selectedCloudVoice }?.gender == gender) {
                    it.selectedCloudVoice
                } else {
                    suggestedCloud
                }
            )
        }
    }

    fun selectEmotion(emotion: StoryEmotion) {
        _uiState.update { it.copy(emotion = emotion) }
    }

    fun updateSpeechRate(rate: Float) {
        _uiState.update { it.copy(speechRate = rate.coerceIn(0.5f, 2.0f)) }
    }

    fun updateSpeechPitch(pitch: Float) {
        _uiState.update { it.copy(speechPitch = pitch.coerceIn(0.5f, 2.0f)) }
    }

    fun selectEngine(option: VoiceEngineOption) {
        _uiState.update { it.copy(engineOption = option, errorMessage = null) }
    }

    fun selectCloudVoice(voiceId: String) {
        val preset = CLOUD_VOICES.find { it.id == voiceId }
        _uiState.update {
            it.copy(
                selectedCloudVoice = voiceId,
                voiceGender = preset?.gender ?: it.voiceGender
            )
        }
    }

    fun toggleLockVoiceAcrossScenes(locked: Boolean) {
        _uiState.update { it.copy(lockVoiceAcrossScenes = locked) }
    }

    fun setSampleScript(text: String, language: String) {
        _uiState.update {
            it.copy(
                scriptText = text,
                language = language,
                generatedWavPath = null,
                lastExportResult = null,
                errorMessage = null
            )
        }
    }

    fun previewOrStopVoice() {
        val state = _uiState.value
        if (state.isPlayingPreview) {
            voiceManager.stopPreview()
            _uiState.update { it.copy(isPlayingPreview = false) }
            return
        }

        val existingPath = state.generatedWavPath
        if (!existingPath.isNullOrBlank() && File(existingPath).exists()) {
            _uiState.update { it.copy(isPlayingPreview = true, errorMessage = null) }
            voiceManager.playAudioFile(existingPath) {
                _uiState.update { it.copy(isPlayingPreview = false) }
            }
            return
        }

        val textToSpeak = state.scriptText.trim().ifBlank {
            when (state.language) {
                "Gujarati" -> "નમસ્તે, એઆઈ પ્રોમ્પ્ટ સ્ટુડિયોમાં આપનું સ્વાગત છે."
                "English" -> "Hello, welcome to AI Prompt Studio voiceover studio."
                else -> "नमस्ते, एआई प्रॉम्प्ट स्टूडियो में आपका स्वागत है। यह आपकी कहानी की आवाज़ है।"
            }
        }

        _uiState.update { it.copy(isPlayingPreview = true, errorMessage = null) }
        voiceManager.previewVoice(
            text = textToSpeak,
            language = state.language,
            gender = state.voiceGender,
            emotion = state.emotion,
            speedMultiplier = state.speechRate,
            pitchMultiplier = state.speechPitch
        ) {
            _uiState.update { it.copy(isPlayingPreview = false) }
        }
    }

    fun requestGenerateAudio() {
        val state = _uiState.value
        if (state.scriptText.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter Hindi, English, or Gujarati text first.") }
            return
        }

        if (state.engineOption.isCloudPaid) {
            val apiKey = userPrefs.getEffectiveGeminiApiKey()
            if (apiKey.isBlank()) {
                _uiState.update {
                    it.copy(
                        errorMessage = "Google Gemini Cloud Voice requires an API key in Settings (⚙️) or AI Studio Secrets. Or select Free AI Voice (no API key needed)."
                    )
                }
                return
            }
            _uiState.update { it.copy(showPaidConfirmDialog = true) }
            return
        }

        synthesizeFreeDeviceVoice()
    }

    fun dismissPaidConfirmDialog() {
        _uiState.update { it.copy(showPaidConfirmDialog = false) }
    }

    fun switchToFreeTtsAndGenerate() {
        _uiState.update {
            it.copy(
                showPaidConfirmDialog = false,
                engineOption = VoiceEngineOption.FREE_DEVICE_TTS
            )
        }
        synthesizeFreeDeviceVoice()
    }

    fun confirmAndGenerateCloudVoice() {
        _uiState.update { it.copy(showPaidConfirmDialog = false) }
        synthesizeCloudGeminiVoice()
    }

    private fun synthesizeFreeDeviceVoice() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSynthesizing = true,
                    errorMessage = null,
                    lastExportResult = null
                )
            }
            try {
                val singleScene = FreeVideoScene(
                    sceneNumber = 1,
                    title = "Voiceover",
                    caption = state.scriptText.trim().take(60),
                    narrationText = state.scriptText.trim(),
                    durationSeconds = 5
                )
                val dummyProject = FreeVideoProject(
                    title = "VoiceStudio",
                    storyPrompt = state.scriptText.trim(),
                    language = state.language,
                    scenes = listOf(singleScene),
                    emotion = state.emotion,
                    voiceGender = state.voiceGender,
                    speechRate = state.speechRate,
                    speechPitch = state.speechPitch
                )

                val resultProj = voiceManager.synthesizeProjectVoiceover(dummyProject) { _, _, _ -> }
                val wavPath = resultProj.scenes.firstOrNull()?.narrationAudioPath
                val wavFile = wavPath?.let { File(it) }

                if (wavFile != null && wavFile.exists() && wavFile.length() > 44) {
                    val durMs = voiceManager.computeWavDurationMs(wavFile)
                    _uiState.update {
                        it.copy(
                            isSynthesizing = false,
                            generatedWavPath = wavFile.absolutePath,
                            generatedDurationMs = durMs,
                            snackbarMessage = "Voice audio generated (${String.format("%.1f", durMs / 1000f)}s)!"
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isSynthesizing = false,
                            errorMessage = "Could not synthesize audio on device TTS engine. Check TTS language pack or retry."
                        )
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isSynthesizing = false,
                        errorMessage = "Voice synthesis failed: ${e.message}"
                    )
                }
            }
        }
    }

    private fun synthesizeCloudGeminiVoice() {
        val state = _uiState.value
        val apiKey = userPrefs.getEffectiveGeminiApiKey()
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSynthesizing = true,
                    errorMessage = null,
                    lastExportResult = null
                )
            }

            val outDir = File(getApplication<Application>().cacheDir, "cloud_tts").apply { mkdirs() }
            val outWav = File(outDir, "gemini_tts_${System.currentTimeMillis()}.wav")
            val result = aiService.synthesizeCloudVoiceWithGemini(
                apiKey = apiKey,
                text = state.scriptText.trim(),
                voiceName = state.selectedCloudVoice,
                language = state.language,
                outputWavFile = outWav
            )

            result.onSuccess { file ->
                val durMs = voiceManager.computeWavDurationMs(file)
                _uiState.update {
                    it.copy(
                        isSynthesizing = false,
                        generatedWavPath = file.absolutePath,
                        generatedDurationMs = durMs,
                        snackbarMessage = "Cloud AI voice ready (${state.selectedCloudVoice})!"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isSynthesizing = false,
                        errorMessage = err.message ?: "Cloud Gemini TTS unavailable."
                    )
                }
            }
        }
    }

    fun downloadAudio(context: Context) {
        val wavPath = _uiState.value.generatedWavPath ?: return
        val file = File(wavPath)
        if (!file.exists()) {
            Toast.makeText(context, "Generate voice audio first", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            val titleHint = "AI_Voice_${_uiState.value.language}"
            val result = withContext(Dispatchers.IO) {
                audioExporter.exportVoiceAudio(file, titleHint)
            }
            result.onSuccess { export ->
                _uiState.update {
                    it.copy(
                        lastExportResult = export,
                        snackbarMessage = export.note
                    )
                }
                Toast.makeText(context, export.note, Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                _uiState.update { it.copy(errorMessage = "Audio export failed: ${err.message}") }
            }
        }
    }

    fun shareAudio(context: Context) {
        val exported = _uiState.value.lastExportResult
        val filePath = exported?.filePath ?: _uiState.value.generatedWavPath ?: return
        val mime = exported?.mimeType ?: "audio/wav"
        val file = File(filePath)
        if (!file.exists()) return
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share AI Voiceover Audio"))
        } catch (e: Exception) {
            Toast.makeText(context, "Share error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        voiceManager.release()
        super.onCleared()
    }
}
