package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StoryPlan
import com.example.ui.components.ProductionPlanHeader
import com.example.ui.components.SceneCard
import com.example.ui.viewmodel.StoryUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryToVideoScreen(
    state: StoryUiState,
    onStoryTextChange: (String) -> Unit,
    onStoryTypeSelect: (String) -> Unit,
    onDurationSelect: (String) -> Unit,
    onAspectRatioSelect: (String) -> Unit,
    onGenerateAllScenesToggle: (Boolean) -> Unit,
    onGenerateClick: () -> Unit,
    onRegenerateScene: (Int) -> Unit,
    onSaveCurrentPlan: () -> Unit,
    onSetSample: (String, String) -> Unit,
    onGenerateActualVideo: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val storyTypes = listOf(
        "सास–बहू",
        "Emotional Family",
        "Mythological",
        "Kids",
        "Horror",
        "Village Life",
        "Custom"
    )

    val durations = listOf("30 sec", "60 sec", "2 min", "5 min")
    val aspectRatios = listOf("9:16", "16:9", "1:1")

    var dropdownExpanded by remember { mutableStateOf(false) }

    fun copyToClipboard(text: String, label: String = "Copied") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("AI Prompt Studio", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label to clipboard", Toast.LENGTH_SHORT).show()
    }

    fun shareText(text: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "AI Story Video Production Plan")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "Share Production Plan"))
    }

    fun formatEntirePlan(plan: StoryPlan): String {
        return buildString {
            appendLine("🎬 ${plan.title}")
            appendLine("Genre: ${plan.storyType} | Duration: ${plan.duration} | Aspect Ratio: ${plan.aspectRatio}")
            appendLine("Visual Style: ${plan.visualStyle}")
            appendLine()
            appendLine("CHARACTER PROMPTS:")
            appendLine(plan.characterPrompts)
            appendLine()
            appendLine("CHARACTER CONSISTENCY:")
            appendLine(plan.characterConsistency)
            appendLine()
            appendLine("NEGATIVE PROMPT:")
            appendLine(plan.negativePrompt)
            appendLine()
            appendLine("════════════════════════════════════")
            appendLine("SCENE-BY-SCENE PRODUCTION BREAKDOWN")
            appendLine("════════════════════════════════════")
            appendLine()
            plan.scenes.forEach { sc ->
                appendLine("SCENE ${String.format("%02d", sc.sceneNumber)} (${sc.duration})")
                appendLine("VISUAL PROMPT: ${sc.visualPrompt}")
                appendLine("DIALOGUE: ${sc.dialogue}")
                appendLine("CAMERA: ${sc.camera}")
                appendLine("LIGHTING: ${sc.lighting}")
                appendLine("AUDIO: ${sc.audio}")
                appendLine("CONTINUITY: ${sc.continuity}")
                if (sc.imagePrompt.isNotBlank()) appendLine("IMAGE PROMPT: ${sc.imagePrompt}")
                if (sc.videoPrompt.isNotBlank()) appendLine("VIDEO PROMPT: ${sc.videoPrompt}")
                appendLine()
            }
            if (plan.finalMessage.isNotBlank()) {
                appendLine("FINAL SCENE / MESSAGE:")
                appendLine(plan.finalMessage)
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SmartDisplay,
                        contentDescription = "Studio",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Story to Video",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "AI Story to Video Prompt Generator • Hindi Story & Master Prompt",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Quick Preset Hindi Stories
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quick Story Ideas (त्वरित उदाहरण):",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SampleChip(
                        label = "सास–बहू हवेली ड्रामा",
                        onClick = {
                            onSetSample(
                                "एक पुरानी राजस्थानी हवेली में कठोर सास सुमित्रा देवी अपनी आधुनिक बहू प्रिया की निष्ठा की परीक्षा लेती हैं, जहाँ पूजा की थाली और पारिवारिक मान-सम्मान को लेकर भावनात्मक मोड़ आता है।",
                                "सास–बहू"
                            )
                        }
                    )
                    SampleChip(
                        label = "गाँव की सुबह व किसान",
                        onClick = {
                            onSetSample(
                                "एक छोटे से भारतीय गाँव में किसान रामेश्वर अपने 10 साल के बेटे के साथ भोर के समय सरसों के खेतों में पानी लगाने जाता है। पिता-पुत्र के बीच माटी के रिश्ते और आत्मसम्मान की मार्मिक बातचीत।",
                                "Village Life"
                            )
                        }
                    )
                    SampleChip(
                        label = "महाभारत अर्जुन-कृष्ण संवाद",
                        onClick = {
                            onSetSample(
                                "कुरुक्षेत्र के रणक्षेत्र में धनुर्धर अर्जुन विषाद में गांडीव रख देते हैं और भगवान श्रीकृष्ण दिव्य मुस्कुराते हुए कर्म और आत्मा का अमर उपदेश देते हैं।",
                                "Mythological"
                            )
                        }
                    )
                    SampleChip(
                        label = "पुरानी हवेली का रहस्यमयी साया",
                        onClick = {
                            onSetSample(
                                "शिमला की बर्फीली रात में एक बंद पड़ी सौ साल पुरानी ब्रिटिश हवेली में युवा पत्रकार अमन जलती लालटेन लेकर दाखिल होता है और उसे अचानक घुंघरुओं की झंकार सुनाई देती है।",
                                "Horror"
                            )
                        }
                    )
                }
            }
        }

        // Input Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("story_input_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // 1. Large Multiline Text Box
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "कहानी / Master Prompt",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (state.userStory.isNotBlank()) {
                            IconButton(
                                onClick = { onStoryTextChange("") },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = state.userStory,
                        onValueChange = onStoryTextChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .testTag("story_prompt_input"),
                        placeholder = {
                            Text(
                                text = "अपनी कहानी या Master Prompt यहाँ लिखें...",
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                fontSize = 14.sp
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // 2. Story Type Dropdown
                    Text(
                        text = "Story Type (कहानी का प्रकार):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = !dropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = state.storyType,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                                .testTag("story_type_dropdown"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors()
                        )

                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            storyTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        onStoryTypeSelect(type)
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3. Duration Options
                    Text(
                        text = "Duration (समय सीमा):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        durations.forEach { dur ->
                            FilterChip(
                                selected = state.duration == dur,
                                onClick = { onDurationSelect(dur) },
                                label = { Text(dur, fontSize = 12.sp) },
                                modifier = Modifier.testTag("duration_chip_$dur"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4. Aspect Ratio Options
                    Text(
                        text = "Aspect Ratio (पहलू अनुपात):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        aspectRatios.forEach { ratio ->
                            val ratioLabel = when (ratio) {
                                "9:16" -> "9:16 (Reels/Shorts)"
                                "16:9" -> "16:9 (Cinema/YT)"
                                else -> "1:1 (Square)"
                            }
                            FilterChip(
                                selected = state.aspectRatio == ratio,
                                onClick = { onAspectRatioSelect(ratio) },
                                label = { Text(ratioLabel, fontSize = 12.sp) },
                                modifier = Modifier.testTag("aspect_ratio_chip_$ratio"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generate All Scenes Toggle Option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Generate All Scenes",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Generate full scene coverage for selected duration",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = state.generateAllScenes,
                            onCheckedChange = onGenerateAllScenesToggle,
                            modifier = Modifier.testTag("generate_all_scenes_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Dual Actions: A. Generate Video Prompts & B. Generate Actual Video
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onGenerateClick,
                            enabled = !state.isGenerating,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("generate_prompts_button")
                        ) {
                            if (state.isGenerating) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generating...", fontSize = 12.sp)
                            } else {
                                Text("A. Script Prompts\n(प्रॉम्प्ट बनाएं)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (onGenerateActualVideo != null) {
                            Button(
                                onClick = {
                                    val prompt = state.userStory.trim().ifBlank { "Indian Haveli story" }
                                    onGenerateActualVideo(prompt)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("generate_actual_video_button")
                            ) {
                                Text("B. Actual Video\n(सीधा वीडियो बनाएं)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Generated Results
        if (state.currentPlan != null) {
            val plan = state.currentPlan

            // Production Plan Header (Title, Consistency, Negative Prompt, Master actions)
            item {
                ProductionPlanHeader(
                    plan = plan,
                    isSaved = state.isSaved,
                    onCopyAll = {
                        copyToClipboard(formatEntirePlan(plan), "Complete Production Plan")
                    },
                    onSave = onSaveCurrentPlan,
                    onShareAll = {
                        shareText(formatEntirePlan(plan))
                    },
                    onRegenerateAll = onGenerateClick,
                    onGenerateActualVideo = onGenerateActualVideo
                )
            }

            // Scenes Header Banner
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Scene-by-Scene Breakdown (${plan.scenes.size} Scenes)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "8–10 sec each",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Individual Scene Cards
            items(plan.scenes, key = { it.sceneNumber }) { scene ->
                SceneCard(
                    scene = scene,
                    isRegenerating = state.regeneratingSceneNumber == scene.sceneNumber,
                    onCopy = { text -> copyToClipboard(text, "Scene ${scene.sceneNumber}") },
                    onRegenerate = { onRegenerateScene(scene.sceneNumber) },
                    onSave = onSaveCurrentPlan,
                    onShare = { text -> shareText(text) },
                    onGenerateVideo = onGenerateActualVideo
                )
            }
        }
    }
}

@Composable
private fun SampleChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
