package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.VideoRepository
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.FreeVideoStep
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.remote.FreeVideoStoryGenerator
import com.example.data.video.Mp4SlideshowEncoder
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

data class FreeVideoMakerUiState(
    val project: FreeVideoProject = FreeVideoProject(),
    val currentStep: FreeVideoStep = FreeVideoStep.STORY_INPUT,
    val isGeneratingStory: Boolean = false,
    val isExportingVideo: Boolean = false,
    val exportProgress: Float = 0f,
    val exportStatusMessage: String = "",
    val generatedVideoPath: String? = null,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null,
    val targetDurationSeconds: Int = 20,
    val activeSceneIndexForPicker: Int? = null
)

class FreeVideoMakerViewModel(application: Application) : AndroidViewModel(application) {

    private val storyGenerator = FreeVideoStoryGenerator()
    private val encoder = Mp4SlideshowEncoder(application)
    private val videoRepo: VideoRepository

    private var exportJob: Job? = null

    init {
        val db = AppDatabase.getDatabase(application)
        videoRepo = VideoRepository(db.videoJobDao())
    }

    private val _uiState = MutableStateFlow(
        FreeVideoMakerUiState(
            project = FreeVideoProject(
                title = "मेरी कहानी (My Story)",
                storyPrompt = "",
                language = "Hindi",
                aspectRatio = "9:16",
                scenes = emptyList()
            )
        )
    )
    val uiState: StateFlow<FreeVideoMakerUiState> = _uiState.asStateFlow()

    fun updateStoryPrompt(text: String) {
        _uiState.update {
            it.copy(
                project = it.project.copy(storyPrompt = text),
                errorMessage = null
            )
        }
    }

    fun selectLanguage(language: String) {
        _uiState.update {
            it.copy(project = it.project.copy(language = language))
        }
    }

    fun selectAspectRatio(ratio: String) {
        _uiState.update {
            it.copy(project = it.project.copy(aspectRatio = ratio))
        }
    }

    fun selectTargetDuration(durationSeconds: Int) {
        _uiState.update {
            it.copy(targetDurationSeconds = durationSeconds)
        }
    }

    fun setSamplePrompt(prompt: String, language: String = "Hindi") {
        _uiState.update {
            it.copy(
                project = it.project.copy(
                    storyPrompt = prompt,
                    language = language
                ),
                errorMessage = null
            )
        }
    }

    fun generateStoryboard() {
        val prompt = _uiState.value.project.storyPrompt.trim()
        if (prompt.isBlank()) {
            _uiState.update {
                it.copy(errorMessage = "Please enter your story idea (कृपया अपनी कहानी या विचार दर्ज करें).")
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(isGeneratingStory = true, errorMessage = null)
            }

            try {
                val current = _uiState.value.project
                val project = storyGenerator.generateStoryboard(
                    storyIdea = prompt,
                    language = current.language,
                    aspectRatio = current.aspectRatio,
                    targetDurationSeconds = _uiState.value.targetDurationSeconds
                )

                _uiState.update {
                    it.copy(
                        project = project,
                        currentStep = FreeVideoStep.SCENE_EDITOR,
                        isGeneratingStory = false,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                Log.e("FreeVideoMakerVM", "Storyboard generation failed", e)
                _uiState.update {
                    it.copy(
                        isGeneratingStory = false,
                        errorMessage = "Failed to generate storyboard: ${e.message}"
                    )
                }
            }
        }
    }

    fun createScenesManually() {
        val current = _uiState.value.project
        val lang = current.language
        val defaultScenes = listOf(
            FreeVideoScene(
                sceneNumber = 1,
                title = if (lang == "Gujarati") "દ્રશ્ય ૧: શરૂઆત" else if (lang == "English") "Scene 1: Introduction" else "दृश्य १: आरंभ",
                caption = if (lang == "Gujarati") "અહીં તમારી પ્રથમ ક્ષણની વાર્તા લખો." else if (lang == "English") "Write the opening line of your video here." else "यहां अपनी कहानी की शुरुआती पंक्ति लिखें।",
                durationSeconds = 4
            ),
            FreeVideoScene(
                sceneNumber = 2,
                title = if (lang == "Gujarati") "દ્રશ્ય ૨: પ્રવાસ" else if (lang == "English") "Scene 2: Journey" else "दृश्य २: यात्रा व प्रयास",
                caption = if (lang == "Gujarati") "વાર્તાનો આગળનો મુખ્ય ભાગ વર્ણવો." else if (lang == "English") "Describe the main journey or action." else "कहानी का मुख्य हिस्सा और भावनाएं यहां जोड़ें।",
                durationSeconds = 4
            ),
            FreeVideoScene(
                sceneNumber = 3,
                title = if (lang == "Gujarati") "દ્રશ્ય ૩: વળાંક" else if (lang == "English") "Scene 3: Climax" else "दृश्य ३: महत्वपूर्ण मोड़",
                caption = if (lang == "Gujarati") "સૌથી રોમાંચક ક્ષણ અને શીખ." else if (lang == "English") "The key turning point or message." else "कहानी का सबसे भावुक और यादगार पल।",
                durationSeconds = 4
            ),
            FreeVideoScene(
                sceneNumber = 4,
                title = if (lang == "Gujarati") "દ્રશ્ય ૪: સુંદર અંત" else if (lang == "English") "Scene 4: Conclusion" else "दृश्य ४: सुंदर समापन",
                caption = if (lang == "Gujarati") "જીવનનો સુંદર સંદેશ અને સમાપન." else if (lang == "English") "Final inspirational takeaway." else "सुंदर अंत और दर्शकों के लिए संदेश।",
                durationSeconds = 4
            )
        )

        _uiState.update {
            it.copy(
                project = current.copy(
                    title = if (lang == "Gujarati") "મારી વીડિયો વાર્તા" else if (lang == "English") "My Video Story" else "मेरी नई वीडियो कहानी",
                    scenes = defaultScenes
                ),
                currentStep = FreeVideoStep.SCENE_EDITOR,
                errorMessage = null
            )
        }
    }

    fun setActiveSceneForPicker(sceneIndex: Int) {
        _uiState.update { it.copy(activeSceneIndexForPicker = sceneIndex) }
    }

    fun onImageSelectedForActiveScene(uriString: String) {
        val activeIndex = _uiState.value.activeSceneIndexForPicker ?: return
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (activeIndex in currentScenes.indices) {
            currentScenes[activeIndex] = currentScenes[activeIndex].copy(imageUri = uriString)
            _uiState.update {
                it.copy(
                    project = it.project.copy(scenes = currentScenes),
                    activeSceneIndexForPicker = null
                )
            }
        }
    }

    fun removeSceneImage(sceneIndex: Int) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(imageUri = null)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneCaption(sceneIndex: Int, caption: String) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(caption = caption)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneTitle(sceneIndex: Int, title: String) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(title = title)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneDuration(sceneIndex: Int, durationSeconds: Int) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(durationSeconds = durationSeconds)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun moveSceneUp(index: Int) {
        if (index <= 0) return
        val list = _uiState.value.project.scenes.toMutableList()
        val item = list.removeAt(index)
        list.add(index - 1, item)
        val renumbered = list.mapIndexed { idx, sc -> sc.copy(sceneNumber = idx + 1) }
        _uiState.update { it.copy(project = it.project.copy(scenes = renumbered)) }
    }

    fun moveSceneDown(index: Int) {
        val list = _uiState.value.project.scenes.toMutableList()
        if (index >= list.size - 1) return
        val item = list.removeAt(index)
        list.add(index + 1, item)
        val renumbered = list.mapIndexed { idx, sc -> sc.copy(sceneNumber = idx + 1) }
        _uiState.update { it.copy(project = it.project.copy(scenes = renumbered)) }
    }

    fun deleteScene(index: Int) {
        val list = _uiState.value.project.scenes.toMutableList()
        if (list.size <= 1) {
            _uiState.update { it.copy(snackbarMessage = "At least one scene is required (कम से कम एक दृश्य आवश्यक है).") }
            return
        }
        if (index in list.indices) {
            list.removeAt(index)
            val renumbered = list.mapIndexed { idx, sc -> sc.copy(sceneNumber = idx + 1) }
            _uiState.update { it.copy(project = it.project.copy(scenes = renumbered)) }
        }
    }

    fun addNewScene() {
        val list = _uiState.value.project.scenes.toMutableList()
        val newNumber = list.size + 1
        list.add(
            FreeVideoScene(
                sceneNumber = newNumber,
                title = "Scene $newNumber",
                caption = "New scene caption (नया दृश्य)",
                durationSeconds = 4
            )
        )
        _uiState.update { it.copy(project = it.project.copy(scenes = list)) }
    }

    fun startCreateMp4Video() {
        val project = _uiState.value.project
        if (project.scenes.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please add at least one scene before creating video.") }
            return
        }

        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExportingVideo = true,
                    currentStep = FreeVideoStep.EXPORTING,
                    exportProgress = 0.05f,
                    exportStatusMessage = "Starting video engine...",
                    errorMessage = null
                )
            }

            try {
                val videosDir = File(getApplication<Application>().filesDir, "videos").apply { mkdirs() }
                val targetFile = File(videosDir, "free_video_${System.currentTimeMillis()}.mp4")

                val result = encoder.encodeSlideshow(
                    scenes = project.scenes,
                    aspectRatio = project.aspectRatio,
                    outputFile = targetFile,
                    audioUri = project.audioUri?.let { Uri.parse(it) }
                ) { progress, message ->
                    _uiState.update {
                        it.copy(
                            exportProgress = progress,
                            exportStatusMessage = message
                        )
                    }
                }

                result.onSuccess { file ->
                    // Save reference to local database so it shows up in "My Videos / History"
                    val videoJob = VideoJob(
                        jobId = "free_${UUID.randomUUID().toString().take(8)}",
                        prompt = project.storyPrompt.ifBlank { project.title },
                        style = "Free Video Slideshow",
                        aspectRatio = project.aspectRatio,
                        duration = "${project.scenes.sumOf { it.durationSeconds }} sec",
                        dialogueLanguage = project.language,
                        provider = "Free Video Maker (On-Device)",
                        status = VideoJobStatus.COMPLETED,
                        progressPercent = 100,
                        statusMessage = "Created via Free Video Maker",
                        videoUrl = file.absolutePath,
                        localVideoPath = file.absolutePath
                    )
                    videoRepo.saveVideoJob(videoJob)

                    _uiState.update {
                        it.copy(
                            isExportingVideo = false,
                            currentStep = FreeVideoStep.RESULT,
                            generatedVideoPath = file.absolutePath,
                            exportProgress = 1.0f,
                            exportStatusMessage = "Video Created!"
                        )
                    }
                }.onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isExportingVideo = false,
                            currentStep = FreeVideoStep.SCENE_EDITOR,
                            errorMessage = "Video creation failed: ${err.message}"
                        )
                    }
                }

            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isExportingVideo = false,
                        currentStep = FreeVideoStep.SCENE_EDITOR,
                        errorMessage = "Error during export: ${e.message}"
                    )
                }
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        _uiState.update {
            it.copy(
                isExportingVideo = false,
                currentStep = FreeVideoStep.SCENE_EDITOR,
                exportProgress = 0f,
                errorMessage = "Video creation cancelled (वीडियो निर्माण रद्द किया गया)."
            )
        }
    }

    fun backToEditor() {
        _uiState.update { it.copy(currentStep = FreeVideoStep.SCENE_EDITOR) }
    }

    fun backToStoryInput() {
        _uiState.update { it.copy(currentStep = FreeVideoStep.STORY_INPUT) }
    }

    fun saveVideoToGallery(context: Context) {
        val videoPath = _uiState.value.generatedVideoPath
        if (videoPath == null) {
            Toast.makeText(context, "No video file found", Toast.LENGTH_SHORT).show()
            return
        }

        val videoFile = File(videoPath)
        if (!videoFile.exists()) {
            Toast.makeText(context, "Video file not found", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            try {
                val fileName = "AIPromptStudio_${System.currentTimeMillis()}.mp4"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIPromptStudio")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(videoFile).use { input -> input.copyTo(out) }
                        }
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                        Toast.makeText(context, "✅ Video saved to Movies/AIPromptStudio!", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                    val appDir = File(moviesDir, "AIPromptStudio").apply { mkdirs() }
                    val destFile = File(appDir, fileName)
                    FileInputStream(videoFile).use { input ->
                        FileOutputStream(destFile).use { output -> input.copyTo(output) }
                    }
                    Toast.makeText(context, "✅ Video saved to Movies/AIPromptStudio!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to save: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareVideo(context: Context) {
        val path = _uiState.value.generatedVideoPath ?: return
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(context, "Video file not found", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Video (वीडियो शेयर करें)"))
        } catch (e: Exception) {
            Toast.makeText(context, "Share failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun onImageSelected(uriString: String) {
        onImageSelectedForActiveScene(uriString)
    }

    fun startCreateMp4() {
        startCreateMp4Video()
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
