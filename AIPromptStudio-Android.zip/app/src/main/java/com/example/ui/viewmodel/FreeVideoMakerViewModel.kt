package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.audio.StoryAudioMixer
import com.example.data.audio.StoryVoiceManager
import com.example.data.local.AppDatabase
import com.example.data.local.VideoRepository
import com.example.data.model.FreeVideoProject
import com.example.data.model.FreeVideoScene
import com.example.data.model.FreeVideoStep
import com.example.data.model.StoryEmotion
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.model.VoiceGender
import com.example.data.remote.FreeVideoStoryGenerator
import com.example.data.video.Mp4SlideshowEncoder
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

data class FreeVideoMakerUiState(
    val project: FreeVideoProject = FreeVideoProject(),
    val currentStep: FreeVideoStep = FreeVideoStep.STORY_INPUT,
    val isGeneratingStory: Boolean = false,
    val isGeneratingVoiceover: Boolean = false,
    val isExportingVideo: Boolean = false,
    val isVoicePreviewPlaying: Boolean = false,
    val previewingSceneIndex: Int? = null,
    val exportProgress: Float = 0f,
    val exportStatusMessage: String = "",
    val generatedVideoPath: String? = null,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null,
    val targetDurationSeconds: Int = 20,
    val activeSceneIndexForPicker: Int? = null
)

class FreeVideoMakerViewModel(application: Application) : AndroidViewModel(application) {

    private val storyGenerator = FreeVideoStoryGenerator()
    private val voiceManager = StoryVoiceManager(application)
    private val audioMixer = StoryAudioMixer(application)
    private val encoder = Mp4SlideshowEncoder(application)
    private val videoRepo: VideoRepository

    private var exportJob: Job? = null
    private var voiceGenJob: Job? = null

    init {
        val db = AppDatabase.getDatabase(application)
        videoRepo = VideoRepository(db.videoJobDao())
    }

    private val _uiState = MutableStateFlow(
        FreeVideoMakerUiState(
            project = FreeVideoProject(
                title = "मेरी कहानी (My Story)",
                storyPrompt = "",
                language = "Auto",
                aspectRatio = "9:16",
                emotion = StoryEmotion.MOTIVATIONAL,
                voiceGender = VoiceGender.FEMALE,
                scenes = emptyList()
            )
        )
    )
    val uiState: StateFlow<FreeVideoMakerUiState> = _uiState.asStateFlow()

    fun updateStoryPrompt(text: String) {
        _uiState.update {
            it.copy(
                project = it.project.copy(storyPrompt = text),
                errorMessage = null
            )
        }
    }

    fun selectLanguage(language: String) {
        _uiState.update {
            it.copy(project = it.project.copy(language = language))
        }
    }

    fun selectAspectRatio(ratio: String) {
        _uiState.update {
            it.copy(project = it.project.copy(aspectRatio = ratio))
        }
    }

    fun selectTargetDuration(durationSeconds: Int) {
        _uiState.update {
            it.copy(targetDurationSeconds = durationSeconds)
        }
    }

    fun selectEmotion(emotion: StoryEmotion) {
        _uiState.update {
            it.copy(project = it.project.copy(emotion = emotion))
        }
    }

    fun selectVoiceGender(gender: VoiceGender) {
        _uiState.update {
            it.copy(project = it.project.copy(voiceGender = gender))
        }
    }

    fun updateSpeechRate(rate: Float) {
        _uiState.update {
            it.copy(project = it.project.copy(speechRate = rate))
        }
    }

    fun updateSpeechPitch(pitch: Float) {
        _uiState.update {
            it.copy(project = it.project.copy(speechPitch = pitch))
        }
    }

    fun setSamplePrompt(prompt: String, language: String = "Hindi") {
        val emotion = StoryEmotion.detectEmotion(prompt)
        _uiState.update {
            it.copy(
                project = it.project.copy(
                    storyPrompt = prompt,
                    language = language,
                    emotion = emotion
                ),
                errorMessage = null
            )
        }
    }

    fun setBackgroundMusic(uri: String?, name: String?) {
        _uiState.update {
            it.copy(
                project = it.project.copy(
                    audioUri = uri,
                    bgMusicName = name,
                    isMusicMuted = false
                )
            )
        }
    }

    fun toggleMusicMute() {
        _uiState.update {
            it.copy(project = it.project.copy(isMusicMuted = !it.project.isMusicMuted))
        }
    }

    fun generateStoryboard() {
        val prompt = _uiState.value.project.storyPrompt.trim()
        if (prompt.isBlank()) {
            _uiState.update {
                it.copy(errorMessage = "Please enter your story idea (कृपया अपनी कहानी या विचार दर्ज करें).")
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(isGeneratingStory = true, errorMessage = null)
            }

            try {
                val current = _uiState.value.project
                val project = storyGenerator.generateStoryboard(
                    storyIdea = prompt,
                    language = current.language,
                    aspectRatio = current.aspectRatio,
                    targetDurationSeconds = _uiState.value.targetDurationSeconds
                )

                _uiState.update {
                    it.copy(
                        project = project,
                        currentStep = FreeVideoStep.SCENE_EDITOR,
                        isGeneratingStory = false,
                        errorMessage = null
                    )
                }

                // Automatically generate voiceover and synchronize scene timings
                generateAutomaticVoiceover()

            } catch (e: Exception) {
                Log.e("FreeVideoMakerVM", "Storyboard generation failed", e)
                _uiState.update {
                    it.copy(
                        isGeneratingStory = false,
                        errorMessage = "Failed to generate storyboard: ${e.message}"
                    )
                }
            }
        }
    }

    fun generateAutomaticVoiceover() {
        val project = _uiState.value.project
        if (project.scenes.isEmpty()) return

        voiceGenJob?.cancel()
        voiceGenJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGeneratingVoiceover = true,
                    exportStatusMessage = "Synthesizing voiceover narration (वॉइसओवर तैयार हो रहा है)..."
                )
            }

            try {
                val updatedProject = voiceManager.synthesizeProjectVoiceover(project) { current, total, msg ->
                    _uiState.update {
                        it.copy(exportStatusMessage = msg)
                    }
                }

                _uiState.update {
                    it.copy(
                        project = updatedProject,
                        isGeneratingVoiceover = false,
                        snackbarMessage = "🎙️ Voiceover generated & synchronized (${updatedProject.scenes.sumOf { s -> s.durationSeconds }}s total)"
                    )
                }
            } catch (e: Exception) {
                Log.e("FreeVideoMakerVM", "Voiceover synthesis error", e)
                _uiState.update {
                    it.copy(
                        isGeneratingVoiceover = false,
                        errorMessage = "Voiceover error: ${e.message}"
                    )
                }
            }
        }
    }

    fun previewVoiceForScene(sceneIndex: Int) {
        val scene = _uiState.value.project.scenes.getOrNull(sceneIndex) ?: return
        val text = scene.narrationText.ifBlank { scene.caption }
        if (text.isBlank()) return

        _uiState.update {
            it.copy(isVoicePreviewPlaying = true, previewingSceneIndex = sceneIndex)
        }

        // If audio file already synthesized, play it directly
        val audioPath = scene.narrationAudioPath
        if (!audioPath.isNullOrBlank() && File(audioPath).exists()) {
            voiceManager.playAudioFile(audioPath) {
                _uiState.update {
                    it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = null)
                }
            }
        } else {
            val project = _uiState.value.project
            voiceManager.previewVoice(
                text = text,
                language = project.language,
                gender = project.voiceGender,
                emotion = project.emotion,
                speedMultiplier = project.speechRate,
                pitchMultiplier = project.speechPitch,
                onDone = {
                    _uiState.update {
                        it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = null)
                    }
                }
            )
        }
    }

    fun stopVoicePreview() {
        voiceManager.stopPreview()
        _uiState.update {
            it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = null)
        }
    }

    /**
     * Dedicated Test Voice action for testing TTS speech in the selected language and voice style.
     */
    fun testVoice(customText: String? = null) {
        if (_uiState.value.isVoicePreviewPlaying) {
            stopVoicePreview()
            return
        }

        val project = _uiState.value.project
        val textToSpeak = customText?.ifBlank { null } ?: when {
            project.language.contains("Gujarati", ignoreCase = true) || project.language.equals("gu", ignoreCase = true) ->
                "નમસ્તે! આ તમારી વિડિઓ વાર્તા માટે ઓટોમેટિક વૉઇસઓવરનું પરીક્ષણ છે."
            project.language.contains("English", ignoreCase = true) || project.language.equals("en", ignoreCase = true) ->
                "Hello! This is a test of your automated story voiceover."
            else ->
                "नमस्ते! यह आपकी वीडियो कहानी के लिए ऑटोमैटिक वॉइसओवर का परीक्षण है।"
        }

        Log.i("FreeVideoMakerVM", "Testing voice with text: '$textToSpeak' in ${project.language}")

        _uiState.update {
            it.copy(
                isVoicePreviewPlaying = true,
                previewingSceneIndex = -1,
                snackbarMessage = "Testing voice (${project.voiceGender.displayName}, ${project.language})..."
            )
        }

        voiceManager.previewVoice(
            text = textToSpeak,
            language = project.language,
            gender = project.voiceGender,
            emotion = project.emotion,
            speedMultiplier = project.speechRate,
            pitchMultiplier = project.speechPitch,
            onDone = {
                _uiState.update {
                    it.copy(isVoicePreviewPlaying = false, previewingSceneIndex = null)
                }
            }
        )
    }

    fun createScenesManually() {
        val current = _uiState.value.project
        val lang = current.language
        val defaultScenes = listOf(
            FreeVideoScene(
                sceneNumber = 1,
                title = if (lang == "Gujarati") "દ્રશ્ય ૧: શરૂઆત" else if (lang == "English") "Scene 1: Introduction" else "दृश्य १: आरंभ",
                caption = if (lang == "Gujarati") "અહીં તમારી પ્રથમ ક્ષણની વાર્તા લખો." else if (lang == "English") "Write the opening line of your video here." else "यहां अपनी कहानी की शुरुआती पंक्ति लिखें।",
                narrationText = if (lang == "Gujarati") "અહીં તમારી પ્રથમ ક્ષણની વાર્તા લખો." else if (lang == "English") "Write the opening line of your video here." else "यहां अपनी कहानी की शुरुआती पंक्ति लिखें।",
                durationSeconds = 4
            ),
            FreeVideoScene(
                sceneNumber = 2,
                title = if (lang == "Gujarati") "દ્રશ્ય ૨: પ્રવાસ" else if (lang == "English") "Scene 2: Journey" else "दृश्य २: यात्रा व प्रयास",
                caption = if (lang == "Gujarati") "વાર્તાનો આગળનો મુખ્ય ભાગ વર્ણવો." else if (lang == "English") "Describe the main journey or action." else "कहानी का मुख्य हिस्सा और भावनाएं यहां जोड़ें।",
                narrationText = if (lang == "Gujarati") "વાર્તાનો આગળનો મુખ્ય ભાગ વર્ણવો." else if (lang == "English") "Describe the main journey or action." else "कहानी का मुख्य हिस्सा और भावनाएं यहां जोड़ें।",
                durationSeconds = 4
            ),
            FreeVideoScene(
                sceneNumber = 3,
                title = if (lang == "Gujarati") "દ્રશ્ય ૩: વળાંક" else if (lang == "English") "Scene 3: Climax" else "दृश्य ३: महत्वपूर्ण मोड़",
                caption = if (lang == "Gujarati") "સૌથી રોમાંચક ક્ષણ અને શીખ." else if (lang == "English") "The key turning point or message." else "कहानी का सबसे भावुक और यादगार पल।",
                narrationText = if (lang == "Gujarati") "સૌથી રોમાંચક ક્ષણ અને શીખ." else if (lang == "English") "The key turning point or message." else "कहानी का सबसे भावुक और यादगार पल।",
                durationSeconds = 4
            ),
            FreeVideoScene(
                sceneNumber = 4,
                title = if (lang == "Gujarati") "દ્રશ્ય ૪: સુંદર અંત" else if (lang == "English") "Scene 4: Conclusion" else "दृश्य ४: सुंदर समापन",
                caption = if (lang == "Gujarati") "જીવનનો સુંદર સંદેશ અને સમાપન." else if (lang == "English") "Final inspirational takeaway." else "सुंदर अंत और दर्शकों के लिए संदेश।",
                narrationText = if (lang == "Gujarati") "જીવનનો સુંદર સંદેશ અને સમાપન." else if (lang == "English") "Final inspirational takeaway." else "सुंदर अंत और दर्शकों के लिए संदेश।",
                durationSeconds = 4
            )
        )

        _uiState.update {
            it.copy(
                project = current.copy(
                    title = if (lang == "Gujarati") "મારી વીડિયો વાર્તા" else if (lang == "English") "My Video Story" else "मेरी नई वीडियो कहानी",
                    scenes = defaultScenes
                ),
                currentStep = FreeVideoStep.SCENE_EDITOR,
                errorMessage = null
            )
        }
    }

    fun setActiveSceneForPicker(sceneIndex: Int) {
        _uiState.update { it.copy(activeSceneIndexForPicker = sceneIndex) }
    }

    fun onImageSelectedForActiveScene(uriString: String) {
        val activeIndex = _uiState.value.activeSceneIndexForPicker ?: return
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (activeIndex in currentScenes.indices) {
            currentScenes[activeIndex] = currentScenes[activeIndex].copy(imageUri = uriString)
            _uiState.update {
                it.copy(
                    project = it.project.copy(scenes = currentScenes),
                    activeSceneIndexForPicker = null
                )
            }
        }
    }

    fun removeSceneImage(sceneIndex: Int) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(imageUri = null)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneCaption(sceneIndex: Int, caption: String) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(caption = caption)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneNarration(sceneIndex: Int, narration: String) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(
                narrationText = narration,
                narrationAudioPath = null // Reset so it regenerates
            )
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneTitle(sceneIndex: Int, title: String) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(title = title)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun updateSceneDuration(sceneIndex: Int, durationSeconds: Int) {
        val currentScenes = _uiState.value.project.scenes.toMutableList()
        if (sceneIndex in currentScenes.indices) {
            currentScenes[sceneIndex] = currentScenes[sceneIndex].copy(durationSeconds = durationSeconds)
            _uiState.update { it.copy(project = it.project.copy(scenes = currentScenes)) }
        }
    }

    fun moveSceneUp(index: Int) {
        if (index <= 0) return
        val list = _uiState.value.project.scenes.toMutableList()
        val item = list.removeAt(index)
        list.add(index - 1, item)
        val renumbered = list.mapIndexed { idx, sc -> sc.copy(sceneNumber = idx + 1) }
        _uiState.update { it.copy(project = it.project.copy(scenes = renumbered)) }
    }

    fun moveSceneDown(index: Int) {
        val list = _uiState.value.project.scenes.toMutableList()
        if (index >= list.size - 1) return
        val item = list.removeAt(index)
        list.add(index + 1, item)
        val renumbered = list.mapIndexed { idx, sc -> sc.copy(sceneNumber = idx + 1) }
        _uiState.update { it.copy(project = it.project.copy(scenes = renumbered)) }
    }

    fun deleteScene(index: Int) {
        val list = _uiState.value.project.scenes.toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            val renumbered = list.mapIndexed { idx, sc -> sc.copy(sceneNumber = idx + 1) }
            _uiState.update { it.copy(project = it.project.copy(scenes = renumbered)) }
        }
    }

    fun addNewScene() {
        val list = _uiState.value.project.scenes.toMutableList()
        val newNumber = list.size + 1
        list.add(
            FreeVideoScene(
                sceneNumber = newNumber,
                title = "Scene $newNumber",
                caption = "New scene caption (नया दृश्य)",
                narrationText = "New scene narration (नया दृश्य वॉइसओवर)",
                durationSeconds = 4
            )
        )
        _uiState.update { it.copy(project = it.project.copy(scenes = list)) }
    }

    fun startCreateMp4Video() {
        val project = _uiState.value.project
        if (project.scenes.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please add at least one scene before creating video.") }
            return
        }

        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExportingVideo = true,
                    currentStep = FreeVideoStep.EXPORTING,
                    exportProgress = 0.05f,
                    exportStatusMessage = "Preparing audio and voiceover...",
                    errorMessage = null
                )
            }

            try {
                // 1. Ensure all scenes with narration text have valid, non-empty synthesized audio
                val scenesNeedingVoice = project.scenes.filter { sc ->
                    val hasText = sc.narrationText.isNotBlank() || sc.caption.isNotBlank()
                    val hasValidAudio = sc.narrationAudioPath != null &&
                            File(sc.narrationAudioPath).exists() &&
                            File(sc.narrationAudioPath).length() > 44
                    hasText && !hasValidAudio
                }

                val finalizedProject = if (scenesNeedingVoice.isNotEmpty()) {
                    _uiState.update { it.copy(exportStatusMessage = "Synthesizing voiceover narrations (वॉइसओवर तैयार हो रहा है)...") }
                    voiceManager.synthesizeProjectVoiceover(project) { _, _, msg ->
                        _uiState.update { it.copy(exportStatusMessage = msg) }
                    }
                } else {
                    project
                }

                // Verify every scene with text has a valid audio file
                for (sc in finalizedProject.scenes) {
                    val text = sc.narrationText.ifBlank { sc.caption }.trim()
                    if (text.isNotBlank()) {
                        val path = sc.narrationAudioPath
                        if (path.isNullOrBlank() || !File(path).exists() || File(path).length() <= 44) {
                            _uiState.update {
                                it.copy(
                                    isExportingVideo = false,
                                    currentStep = FreeVideoStep.SCENE_EDITOR,
                                    errorMessage = "Scene ${sc.sceneNumber} narration audio is missing or failed to synthesize. Please test voice or retry export."
                                )
                            }
                            return@launch
                        }
                    }
                }

                // 2. Synchronize scene durations tightly with spoken audio to eliminate silent gaps and avoid clipping
                val syncedScenes = finalizedProject.scenes.map { sc ->
                    val path = sc.narrationAudioPath
                    if (!path.isNullOrBlank()) {
                        val audioFile = File(path)
                        if (audioFile.exists() && audioFile.length() > 44) {
                            val audioDurationMs = voiceManager.computeWavDurationMs(audioFile)
                            val snugSec = maxOf(3, Math.ceil((audioDurationMs + 350L) / 1000.0).toInt()).coerceIn(3, 30)
                            // If scene duration is shorter than spoken narration, extend it
                            // If scene duration is longer than spoken narration + 1s, tighten it to eliminate silent gap
                            val adjustedSec = if (sc.durationSeconds < snugSec || sc.durationSeconds > snugSec + 1) snugSec else sc.durationSeconds
                            sc.copy(durationSeconds = adjustedSec, calculatedAudioDurationMs = audioDurationMs)
                        } else sc
                    } else sc
                }
                val syncedProject = finalizedProject.copy(scenes = syncedScenes)
                _uiState.update { it.copy(project = syncedProject) }

                // 3. Mix scene narration WAV files with background music and automatic ducking
                val audioDir = File(getApplication<Application>().cacheDir, "master_audio").apply { mkdirs() }
                val masterWavFile = File(audioDir, "master_${System.currentTimeMillis()}.wav")

                val sceneEntries = syncedScenes.map { sc ->
                    StoryAudioMixer.SceneAudioEntry(
                        sceneNumber = sc.sceneNumber,
                        sceneDurationSeconds = sc.durationSeconds,
                        narrationWavPath = sc.narrationAudioPath
                    )
                }

                val hasNarrationOrMusic = sceneEntries.any { it.narrationWavPath != null } || (syncedProject.audioUri != null && !syncedProject.isMusicMuted)
                val masterAudioCreated = if (hasNarrationOrMusic) {
                    _uiState.update { it.copy(exportProgress = 0.12f, exportStatusMessage = "Mixing voiceover & background music (डकिंग व ऑडियो सिंक)...") }
                    val mixSuccess = audioMixer.createMasterAudioTrack(
                        sceneEntries = sceneEntries,
                        bgMusicUri = syncedProject.audioUri?.let { Uri.parse(it) },
                        isMusicMuted = syncedProject.isMusicMuted,
                        outputFile = masterWavFile
                    )

                    val validation = audioMixer.getLastValidation()
                    if (!mixSuccess || (validation != null && !validation.isValid)) {
                        val errMsg = validation?.errorMessage ?: "Master audio track creation failed."
                        _uiState.update {
                            it.copy(
                                isExportingVideo = false,
                                currentStep = FreeVideoStep.SCENE_EDITOR,
                                errorMessage = "Audio timeline error: $errMsg"
                            )
                        }
                        return@launch
                    }
                    true
                } else false

                // 4. Encode Video Frames and Mux Master Audio
                val videosDir = File(getApplication<Application>().filesDir, "videos").apply { mkdirs() }
                val targetFile = File(videosDir, "free_video_${System.currentTimeMillis()}.mp4")

                val result = encoder.encodeSlideshow(
                    scenes = syncedScenes,
                    aspectRatio = syncedProject.aspectRatio,
                    outputFile = targetFile,
                    audioUri = syncedProject.audioUri?.let { Uri.parse(it) },
                    masterAudioFile = if (masterAudioCreated) masterWavFile else null
                ) { progress, message ->
                    _uiState.update {
                        it.copy(
                            exportProgress = progress,
                            exportStatusMessage = message
                        )
                    }
                }

                result.onSuccess { file ->
                    // Save reference to local database so it shows up in "My Videos / History"
                    val totalDurationSec = syncedScenes.sumOf { it.durationSeconds }
                    val videoJob = VideoJob(
                        jobId = "free_${UUID.randomUUID().toString().take(8)}",
                        prompt = finalizedProject.storyPrompt.ifBlank { finalizedProject.title },
                        style = "Free Video Slideshow (${finalizedProject.emotion.displayName})",
                        aspectRatio = finalizedProject.aspectRatio,
                        duration = "$totalDurationSec sec",
                        dialogueLanguage = finalizedProject.language,
                        provider = "Free Video Maker (On-Device + Voiceover)",
                        status = VideoJobStatus.COMPLETED,
                        progressPercent = 100,
                        statusMessage = "Created via Free Video Maker with Voiceover",
                        videoUrl = file.absolutePath,
                        localVideoPath = file.absolutePath
                    )
                    videoRepo.saveVideoJob(videoJob)

                    _uiState.update {
                        it.copy(
                            isExportingVideo = false,
                            currentStep = FreeVideoStep.RESULT,
                            generatedVideoPath = file.absolutePath,
                            exportProgress = 1.0f,
                            exportStatusMessage = "Video Created!"
                        )
                    }
                }.onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isExportingVideo = false,
                            currentStep = FreeVideoStep.SCENE_EDITOR,
                            errorMessage = "Video creation failed: ${err.message}"
                        )
                    }
                }

            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isExportingVideo = false,
                        currentStep = FreeVideoStep.SCENE_EDITOR,
                        errorMessage = "Error during export: ${e.message}"
                    )
                }
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        _uiState.update {
            it.copy(
                isExportingVideo = false,
                currentStep = FreeVideoStep.SCENE_EDITOR,
                exportProgress = 0f,
                errorMessage = "Video creation cancelled (वीडियो निर्माण रद्द किया गया)."
            )
        }
    }

    fun backToEditor() {
        _uiState.update { it.copy(currentStep = FreeVideoStep.SCENE_EDITOR) }
    }

    fun backToStoryInput() {
        _uiState.update { it.copy(currentStep = FreeVideoStep.STORY_INPUT) }
    }

    fun saveVideoToGallery(context: Context) {
        val videoPath = _uiState.value.generatedVideoPath
        if (videoPath == null) {
            Toast.makeText(context, "No video file found", Toast.LENGTH_SHORT).show()
            return
        }

        val videoFile = File(videoPath)
        if (!videoFile.exists()) {
            Toast.makeText(context, "Video file not found", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            try {
                val fileName = "AIPromptStudio_${System.currentTimeMillis()}.mp4"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIPromptStudio")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(videoFile).use { input -> input.copyTo(out) }
                        }
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        context.contentResolver.update(uri, values, null, null)
                        Toast.makeText(context, "✅ Video saved to Movies/AIPromptStudio!", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                    val appDir = File(moviesDir, "AIPromptStudio").apply { mkdirs() }
                    val destFile = File(appDir, fileName)
                    FileInputStream(videoFile).use { input ->
                        FileOutputStream(destFile).use { output -> input.copyTo(output) }
                    }
                    Toast.makeText(context, "✅ Video saved to Movies/AIPromptStudio!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to save: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareVideo(context: Context) {
        val path = _uiState.value.generatedVideoPath ?: return
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(context, "Video file not found", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Video (वीडियो शेयर करें)"))
        } catch (e: Exception) {
            Toast.makeText(context, "Share failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun onImageSelected(uriString: String) {
        onImageSelectedForActiveScene(uriString)
    }

    fun startCreateMp4() {
        startCreateMp4Video()
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}
