package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StoryEmotion
import com.example.data.model.VoiceGender
import com.example.ui.viewmodel.VoiceEngineOption
import com.example.ui.viewmodel.VoiceStudioUiState
import com.example.ui.viewmodel.VoiceStudioViewModel
import java.io.File

@Composable
fun VoiceStudioScreen(
    state: VoiceStudioUiState,
    onScriptChange: (String) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onSelectGender: (VoiceGender) -> Unit,
    onSelectEmotion: (StoryEmotion) -> Unit,
    onUpdateSpeechRate: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onSelectEngine: (VoiceEngineOption) -> Unit,
    onSelectCloudVoice: (String) -> Unit,
    onToggleLockVoice: (Boolean) -> Unit,
    onSetSampleScript: (String, String) -> Unit,
    onPreviewOrStop: () -> Unit,
    onRequestGenerate: () -> Unit,
    onConfirmCloudVoice: () -> Unit,
    onDismissPaidDialog: () -> Unit,
    onSwitchToFreeTts: () -> Unit,
    onDownloadAudio: () -> Unit,
    onShareAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Voice & Text-to-Speech",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "हिंदी, गुजराती व अंग्रेज़ी वॉइस जनरेशन • Male/Female Voice, Speed Controls & Download",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Script Input Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. Enter Voice Script (स्क्रिप्ट लिखें):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    OutlinedTextField(
                        value = state.scriptText,
                        onValueChange = onScriptChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("voice_studio_script_input"),
                        placeholder = {
                            Text("यहाँ हिंदी, गुजराती या अंग्रेज़ी में डायलॉग या कहानी लिखें...")
                        },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("Hindi Story", "एक छोटे से गाँव में एक परिश्रमी किसान रहता था। सुबह की सुनहरी धूप में वह हर दिन नई उम्मीद के साथ काम करता था।", "Hindi"),
                            Triple("English Narration", "In the quiet golden dawn of an Indian village, hope shines brighter than ever before.", "English"),
                            Triple("Gujarati Voice", "સવારના સોનેરી પ્રકાશમાં ગામના ખેડૂતે નવી આશા સાથે પોતાના સપનાની શરૂઆત કરી.", "Gujarati")
                        ).forEach { (label, sample, lang) ->
                            Surface(
                                onClick = { onSetSampleScript(sample, lang) },
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Text(label, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                        }
                    }
                }
            }
        }

        // Language, Gender, Mood & Speed/Pitch Controls
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("2. Language & Speaker (भाषा व आवाज़):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Hindi", "English", "Gujarati").forEach { lang ->
                            FilterChip(
                                selected = state.language == lang,
                                onClick = { onSelectLanguage(lang) },
                                label = { Text(lang, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        VoiceGender.entries.forEach { gender ->
                            FilterChip(
                                selected = state.voiceGender == gender,
                                onClick = { onSelectGender(gender) },
                                label = { Text(gender.displayName, fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (gender == VoiceGender.FEMALE) Icons.Default.RecordVoiceOver else Icons.Default.Mic,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                        }
                    }

                    Text("Mood Preset (भाव):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StoryEmotion.entries.forEach { emotion ->
                            FilterChip(
                                selected = state.emotion == emotion,
                                onClick = { onSelectEmotion(emotion) },
                                label = { Text(emotion.displayName, fontSize = 11.sp) }
                            )
                        }
                    }

                    Column {
                        Text(
                            text = "Speed (गति): ${String.format("%.2fx", state.speechRate)}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Slider(
                            value = state.speechRate,
                            onValueChange = onUpdateSpeechRate,
                            valueRange = 0.5f..2.0f,
                            modifier = Modifier.testTag("voice_speed_slider")
                        )
                    }

                    Column {
                        Text(
                            text = "Voice Pitch (पिच): ${String.format("%.2fx", state.speechPitch)}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Slider(
                            value = state.speechPitch,
                            onValueChange = onUpdateSpeechPitch,
                            valueRange = 0.5f..2.0f,
                            modifier = Modifier.testTag("voice_pitch_slider")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Keep Same Voice Across All Scenes", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Locks voice character profile for consistent storytelling", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = state.lockVoiceAcrossScenes, onCheckedChange = onToggleLockVoice)
                    }
                }
            }
        }

        // Engine Choice (Free On-Device TTS vs Google Cloud Gemini TTS)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Voice Engine (वॉइस इंजन):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    VoiceEngineOption.entries.forEach { option ->
                        val selected = state.engineOption == option
                        Surface(
                            onClick = { onSelectEngine(option) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) {
                                if (!option.isCloudPaid) Color(0xFFECFDF5) else MaterialTheme.colorScheme.primaryContainer
                            } else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) {
                                    if (!option.isCloudPaid) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                                } else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = option.label,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected && !option.isCloudPaid) Color(0xFF065F46) else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (state.engineOption == VoiceEngineOption.CLOUD_GEMINI_TTS) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Cloud AI Speaker Preset:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            VoiceStudioViewModel.CLOUD_VOICES.forEach { preset ->
                                FilterChip(
                                    selected = state.selectedCloudVoice == preset.id,
                                    onClick = { onSelectCloudVoice(preset.id) },
                                    label = { Text(preset.label, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (state.errorMessage != null) {
            item {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                    Text(
                        text = state.errorMessage,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Preview & Synthesize Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onPreviewOrStop,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("btn_preview_voice_studio")
                ) {
                    Icon(
                        imageVector = if (state.isPlayingPreview) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (state.isPlayingPreview) "Stop" else "Preview Voice", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                    onClick = onRequestGenerate,
                    enabled = !state.isSynthesizing,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!state.engineOption.isCloudPaid) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(52.dp)
                        .testTag("btn_generate_voice_audio")
                ) {
                    if (state.isSynthesizing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.5.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generating...")
                    } else {
                        Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Generate Audio", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Generated Audio Download & Share Card
        if (!state.generatedWavPath.isNullOrBlank() && File(state.generatedWavPath).exists()) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                    border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_result_download_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Voiceover Ready (${String.format("%.1f", state.generatedDurationMs / 1000f)} sec)",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF065F46)
                                )
                                Text(
                                    text = state.lastExportResult?.note ?: "Tap Download Audio to save MP3/M4A directly to Music/AIPromptStudio.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF047857)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onDownloadAudio,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_download_voice_mp3")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Download Audio", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            OutlinedButton(
                                onClick = onShareAudio,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_share_voice_audio")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share Audio", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (state.showPaidConfirmDialog) {
        AlertDialog(
            onDismissRequest = onDismissPaidDialog,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Confirm Cloud Gemini Voiceover", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Synthesizing studio audio via Gemini Cloud TTS uses your API key quota. Or use Free Offline Android TTS completely free.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = onConfirmCloudVoice) { Text("Use Cloud AI Voice") }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = onSwitchToFreeTts) {
                        Text("Use Free Voice", color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = onDismissPaidDialog) { Text("Cancel") }
                }
            }
        )
    }
}
