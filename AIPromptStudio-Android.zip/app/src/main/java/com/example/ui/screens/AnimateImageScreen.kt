package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MotionEffect
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoStyle
import com.example.ui.components.SelectedImagePreviewBox
import com.example.ui.components.VideoPlayerView
import com.example.ui.components.rememberUnifiedImagePicker
import com.example.ui.viewmodel.AnimateEngineMode
import com.example.ui.viewmodel.AnimateImageUiState

@Composable
fun AnimateImageScreen(
    state: AnimateImageUiState,
    onImageSelected: (String) -> Unit,
    onMotionPromptChange: (String) -> Unit,
    onSelectMotionEffect: (MotionEffect) -> Unit,
    onSelectAspectRatio: (VideoAspectRatio) -> Unit,
    onSelectDuration: (Int) -> Unit,
    onSelectStyle: (VideoStyle) -> Unit,
    onToggleVignette: (Boolean) -> Unit,
    onCaptionChange: (String) -> Unit,
    onSetBackgroundMusic: (String?, String?) -> Unit,
    onSelectEngineMode: (AnimateEngineMode) -> Unit,
    onStartAnimate: () -> Unit,
    onCancelAnimate: () -> Unit,
    onConfirmPaidVeo: () -> Unit,
    onDismissPaidDialog: () -> Unit,
    onSwitchToFreeMotion: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShareVideo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val imagePicker = rememberUnifiedImagePicker { uri ->
        onImageSelected(uri.toString())
    }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            onSetBackgroundMusic(uri.toString(), uri.lastPathSegment ?: "Background Music")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Animation,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Animate Image to Video",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "फोटो से एनिमेटेड MP4 वीडियो बनाएं • Smooth Camera Motion & Cinematic FX",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Upload Photo Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "1. Select Photo from Gallery (फोटो चुनें):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SelectedImagePreviewBox(
                        imageUriOrPath = state.selectedImageUri,
                        isImporting = state.isImportingImage,
                        errorMessage = state.imageImportError,
                        pickerHandle = imagePicker,
                        height = 210.dp,
                        emptyTitle = "Tap to Upload Photo from Gallery",
                        emptySubtitle = "Supports JPG, JPEG, PNG, WEBP • Gallery or Browse Files",
                        testTagPrefix = "animate_image"
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = state.motionPrompt,
                        onValueChange = onMotionPromptChange,
                        label = { Text("Motion Instruction (optional for Free Mode / used for Veo AI)") },
                        placeholder = { Text("e.g., Gentle wind in hair, warm golden sunlight, slow cinematic zoom in...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("animate_motion_prompt_input"),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = state.optionalCaption,
                        onValueChange = onCaptionChange,
                        label = { Text("Subtitle / Overlay Text (Optional)") },
                        placeholder = { Text("e.g., जीवन की नई सुबह • New Beginning") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("animate_caption_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }
            }
        }

        // Camera Motion, Aspect Ratio, Duration & Style
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "2. Camera Motion Effect (कैमरा मोशन):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MotionEffect.entries.forEach { effect ->
                            FilterChip(
                                selected = state.selectedMotionEffect == effect,
                                onClick = { onSelectMotionEffect(effect) },
                                label = {
                                    Column {
                                        Text(effect.displayName, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        Text(effect.hindiName, fontSize = 10.sp)
                                    }
                                },
                                modifier = Modifier.testTag("motion_chip_${effect.name.lowercase()}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Text(
                        text = "3. Video Aspect Ratio (अनुपात):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoAspectRatio.entries.forEach { ratio ->
                            FilterChip(
                                selected = state.selectedAspectRatio == ratio,
                                onClick = { onSelectAspectRatio(ratio) },
                                label = { Text("${ratio.ratio} (${ratio.hindiLabel})", fontSize = 11.sp) },
                                modifier = Modifier.testTag("animate_ratio_${ratio.ratio.replace(":", "_")}"),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Text(
                        text = "4. Duration & Visual Polish:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 6, 8, 10).forEach { sec ->
                            FilterChip(
                                selected = state.selectedDurationSec == sec,
                                onClick = { onSelectDuration(sec) },
                                label = { Text("${sec}s", fontSize = 12.sp) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoStyle.entries.forEach { style ->
                            FilterChip(
                                selected = state.selectedStyle == style,
                                onClick = { onSelectStyle(style) },
                                label = { Text("${style.displayName} (${style.hindiName})", fontSize = 11.sp) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Cinematic Vignette Glow", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Warm edges and subtle film polish", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = state.addCinematicVignette,
                            onCheckedChange = onToggleVignette
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = state.backgroundMusicName ?: "Optional Background Music",
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                        OutlinedButton(
                            onClick = { musicPicker.launch("audio/*") },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text(if (state.backgroundMusicUri == null) "Add Music" else "Change", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Engine Selector (Free On-Device vs Google Veo I2V)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Animation Engine (इंजन चुनें):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    AnimateEngineMode.entries.forEach { mode ->
                        val selected = state.engineMode == mode
                        Surface(
                            onClick = { onSelectEngineMode(mode) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) {
                                if (!mode.isPaid) Color(0xFFECFDF5) else MaterialTheme.colorScheme.primaryContainer
                            } else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) {
                                    if (!mode.isPaid) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                                } else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = mode.label,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected && !mode.isPaid) Color(0xFF065F46) else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // Error Box
        if (state.errorMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(state.errorMessage, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(onClick = onStartAnimate, modifier = Modifier.height(36.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Retry", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Action Button / Progress
        item {
            if (state.isAnimating) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = state.statusMessage.ifBlank { "Animating image..." },
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { state.progress.coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(6.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(onClick = onCancelAnimate, modifier = Modifier.fillMaxWidth()) {
                            Text("Cancel")
                        }
                    }
                }
            } else {
                Button(
                    onClick = onStartAnimate,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!state.engineMode.isPaid) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btn_animate_image_go")
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (!state.engineMode.isPaid) {
                            "Animate Photo to MP4 (मुफ़्त वीडियो बनाएं)"
                        } else {
                            "Animate with Google Veo (Cloud API)"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }

        // Result Video Player + Download / Share
        if (!state.outputVideoPath.isNullOrBlank()) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("animate_result_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Animated Video Ready!",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF059669)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        VideoPlayerView(
                            videoPathOrUrl = state.outputVideoPath,
                            aspectRatio = state.selectedAspectRatio.ratio
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onSaveToGallery,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_download_animated_mp4")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save MP4", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            OutlinedButton(
                                onClick = onShareVideo,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("btn_share_animated_mp4")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (state.showPaidConfirmDialog) {
        AlertDialog(
            onDismissRequest = onDismissPaidDialog,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Confirm Paid Veo Cloud Call", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Google Veo Image-to-Video sends your photo and prompt to Google Cloud GPUs and may require paid billing/whitelist access.\n\n" +
                        "You can also switch to 100% Free On-Device 25fps Motion MP4 with zero cost.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = onConfirmPaidVeo) { Text("Proceed with Veo") }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = onSwitchToFreeMotion) {
                        Text("Use Free MP4", color = Color(0xFF059669), fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = onDismissPaidDialog) { Text("Cancel") }
                }
            }
        )
    }
}
