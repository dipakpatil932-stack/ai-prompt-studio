package com.example

import androidx.test.core.app.ApplicationProvider
import com.example.data.local.UserSettings
import com.example.data.local.VideoJobEntity
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import com.example.data.remote.video.VideoConfigException
import com.example.data.remote.video.VideoGenerationService
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class VideoGenerationServiceTest {

    @Test
    fun testInputValidationForBlankPrompt() = runTest {
        val service = VideoGenerationService(ApplicationProvider.getApplicationContext())
        val settings = UserSettings(
            providerType = VideoProviderType.GOOGLE_VEO,
            providerApiKey = "test_key"
        )

        val result = service.submitJob(
            prompt = "   ",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "9:16",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            settings = settings
        )

        assertTrue(result.isFailure)
        val error = result.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
        assertTrue(error?.message?.contains("Please enter a story") == true)
    }

    @Test
    fun testMissingCustomBackendFailsWithConfigException() = runTest {
        val service = VideoGenerationService(ApplicationProvider.getApplicationContext())
        val settings = UserSettings(
            providerType = VideoProviderType.CUSTOM_BACKEND,
            customBackendUrl = ""
        )

        val result = service.submitJob(
            prompt = "एक बच्चा गांव में खेल रहा है",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "9:16",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            settings = settings
        )

        assertTrue(result.isFailure)
        val error = result.exceptionOrNull()
        assertTrue(error is VideoConfigException)
        assertTrue(error?.message?.contains("Custom Video Server URL is not configured") == true)
    }

    @Test
    fun testMissingApiKeyFailsCleanly() = runTest {
        val service = VideoGenerationService(ApplicationProvider.getApplicationContext())
        val settings = UserSettings(
            providerType = VideoProviderType.LUMA_DREAM_MACHINE,
            providerApiKey = ""
        )

        val result = service.submitJob(
            prompt = "Indian village festival celebration",
            style = VideoStyle.CINEMATIC.displayName,
            aspectRatio = "16:9",
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            settings = settings
        )

        assertTrue(result.isFailure)
        val error = result.exceptionOrNull()
        assertTrue(error is VideoConfigException)
        assertTrue(error?.message?.contains("Luma Dream Machine API API key is not configured") == true)
    }

    @Test
    fun testVideoJobEntityConversion() {
        val job = VideoJob(
            id = 42L,
            jobId = "veo_test_123",
            prompt = "दादी और पोता चूल्हे पर खाना बना रहे हैं",
            style = VideoStyle.REALISTIC.displayName,
            aspectRatio = VideoAspectRatio.RATIO_9_16.ratio,
            duration = "5 sec",
            dialogueLanguage = "Hindi",
            provider = VideoProviderType.GOOGLE_VEO.displayName,
            status = VideoJobStatus.COMPLETED,
            progressPercent = 100,
            statusMessage = "Video Ready",
            videoUrl = "https://example.com/test.mp4",
            localVideoPath = "/data/user/0/com.example/files/videos/video_123.mp4"
        )

        val entity = VideoJobEntity.fromDomain(job)
        assertEquals(42L, entity.id)
        assertEquals("veo_test_123", entity.jobId)
        assertEquals(VideoJobStatus.COMPLETED.name, entity.status)
        assertEquals("https://example.com/test.mp4", entity.videoUrl)

        val convertedBack = entity.toDomain()
        assertEquals(job.id, convertedBack.id)
        assertEquals(job.jobId, convertedBack.jobId)
        assertEquals(job.prompt, convertedBack.prompt)
        assertEquals(VideoJobStatus.COMPLETED, convertedBack.status)
        assertEquals(job.localVideoPath, convertedBack.localVideoPath)
    }
}
