package com.example.ui.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.UserPreferences
import com.example.data.local.UserSettings
import com.example.data.local.VideoRepository
import com.example.data.model.VideoAspectRatio
import com.example.data.model.VideoJob
import com.example.data.model.VideoJobStatus
import com.example.data.model.VideoProviderType
import com.example.data.model.VideoStyle
import com.example.data.remote.video.VideoGenerationService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

data class VideoGeneratorUiState(
    val prompt: String = "",
    val selectedStyle: VideoStyle = VideoStyle.CINEMATIC,
    val selectedAspectRatio: VideoAspectRatio = VideoAspectRatio.RATIO_9_16,
    val selectedDuration: String = "5 sec",
    val dialogueLanguage: String = "Hindi",
    val activeJob: VideoJob? = null,
    val currentStatus: VideoJobStatus = VideoJobStatus.IDLE,
    val progressPercent: Int = 0,
    val statusMessage: String = "",
    val errorMessage: String? = null,
    val isGenerating: Boolean = false,
    val showSetupPrompt: Boolean = false,
    val setupMessage: String? = null,
    val connectionTestResult: String? = null,
    val isTestingConnection: Boolean = false
)

class VideoGeneratorViewModel(application: Application) : AndroidViewModel(application) {

    private val userPrefs = UserPreferences(application)
    private val videoRepo: VideoRepository
    private val videoService = VideoGenerationService(application)

    private var activePollingJob: Job? = null

    init {
        val db = AppDatabase.getDatabase(application)
        videoRepo = VideoRepository(db.videoJobDao())
    }

    val settings: StateFlow<UserSettings> = userPrefs.settingsFlow
    val savedVideos: StateFlow<List<VideoJob>> = videoRepo.allVideoJobs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiState = MutableStateFlow(VideoGeneratorUiState())
    val uiState: StateFlow<VideoGeneratorUiState> = _uiState.asStateFlow()

    fun updatePrompt(text: String) {
        _uiState.update { it.copy(prompt = text, errorMessage = null) }
    }

    fun selectStyle(style: VideoStyle) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun selectAspectRatio(ratio: VideoAspectRatio) {
        _uiState.update { it.copy(selectedAspectRatio = ratio) }
    }

    fun selectDuration(duration: String) {
        _uiState.update { it.copy(selectedDuration = duration) }
    }

    fun selectDialogueLanguage(language: String) {
        _uiState.update { it.copy(dialogueLanguage = language) }
    }

    fun setSamplePrompt(prompt: String, style: VideoStyle = VideoStyle.CINEMATIC) {
        _uiState.update {
            it.copy(
                prompt = prompt,
                selectedStyle = style,
                errorMessage = null
            )
        }
    }

    fun dismissSetupPrompt() {
        _uiState.update { it.copy(showSetupPrompt = false, setupMessage = null) }
    }

    fun updateProvider(type: VideoProviderType) {
        userPrefs.updateProvider(type)
    }

    fun updateApiKey(key: String) {
        userPrefs.updateApiKey(key)
    }

    fun updateBackendUrl(url: String) {
        userPrefs.updateCustomBackendUrl(url)
    }

    fun updateGeminiApiKeyOverride(key: String) {
        userPrefs.updateGeminiApiKeyOverride(key)
    }

    fun testConnection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingConnection = true, connectionTestResult = null) }
            val currentSettings = settings.value
            val result = videoService.testConnection(currentSettings)
            result.onSuccess { msg ->
                _uiState.update { it.copy(isTestingConnection = false, connectionTestResult = "✅ $msg") }
            }.onFailure { err ->
                _uiState.update { it.copy(isTestingConnection = false, connectionTestResult = "❌ ${err.message}") }
            }
        }
    }

    fun clearConnectionTestResult() {
        _uiState.update { it.copy(connectionTestResult = null) }
    }

    fun generateVideo() {
        val promptText = _uiState.value.prompt.trim()
        if (promptText.isBlank()) {
            _uiState.update {
                it.copy(errorMessage = "Please enter your video idea or story (कृपया वीडियो विचार दर्ज करें).")
            }
            return
        }

        val currentSettings = settings.value

        // Check if provider is configured
        if (!userPrefs.isConfigured()) {
            val providerName = currentSettings.providerType.displayName
            val help = if (currentSettings.providerType == VideoProviderType.CUSTOM_BACKEND) {
                "Custom Video Backend URL is missing. Please configure your server URL in Settings."
            } else {
                "$providerName requires an API key. You can enter your API credentials in Settings (⚙️)."
            }
            _uiState.update {
                it.copy(
                    showSetupPrompt = true,
                    setupMessage = "$help\n(वीडियो जनरेटर कॉन्फ़िगर करने के लिए सेटिंग्स में जाएं।)"
                )
            }
            return
        }

        activePollingJob?.cancel()

        activePollingJob = viewModelScope.launch {
            val style = _uiState.value.selectedStyle
            val ratio = _uiState.value.selectedAspectRatio
            val duration = _uiState.value.selectedDuration
            val language = _uiState.value.dialogueLanguage

            _uiState.update {
                it.copy(
                    isGenerating = true,
                    currentStatus = VideoJobStatus.SUBMITTING,
                    progressPercent = 5,
                    statusMessage = "Submitting video request to server... (सर्वर पर अनुरोध भेजा जा रहा है)",
                    errorMessage = null
                )
            }

            val submissionResult = videoService.submitJob(
                prompt = promptText,
                style = style.displayName,
                aspectRatio = ratio.ratio,
                duration = duration,
                dialogueLanguage = language,
                settings = currentSettings
            )

            submissionResult.onFailure { error ->
                Log.e("VideoGeneratorViewModel", "Submission failed", error)
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        currentStatus = VideoJobStatus.FAILED,
                        progressPercent = 0,
                        statusMessage = "Submission failed",
                        errorMessage = error.message ?: "Failed to initiate video generation."
                    )
                }
            }

            submissionResult.onSuccess { submission ->
                val newJob = VideoJob(
                    jobId = submission.jobId,
                    prompt = promptText,
                    style = style.displayName,
                    aspectRatio = ratio.ratio,
                    duration = duration,
                    dialogueLanguage = language,
                    provider = currentSettings.providerType.displayName,
                    status = submission.initialStatus,
                    progressPercent = if (submission.initialStatus == VideoJobStatus.COMPLETED) 100 else 10,
                    statusMessage = submission.initialMessage,
                    videoUrl = submission.directVideoUrl
                )

                val dbId = videoRepo.saveVideoJob(newJob)
                val currentJob = newJob.copy(id = dbId)

                _uiState.update {
                    it.copy(
                        activeJob = currentJob,
                        currentStatus = submission.initialStatus,
                        statusMessage = submission.initialMessage
                    )
                }

                if (submission.initialStatus == VideoJobStatus.COMPLETED && submission.directVideoUrl != null) {
                    handleCompletedVideo(currentJob, submission.directVideoUrl)
                } else {
                    pollJobProgress(currentJob)
                }
            }
        }
    }

    private suspend fun pollJobProgress(initialJob: VideoJob) {
        var currentJob = initialJob
        var elapsed = 0
        val maxWaitSeconds = 300 // 5 minutes max polling

        while (viewModelScope.isActive && elapsed < maxWaitSeconds) {
            delay(4000)
            elapsed += 4

            val currentSettings = settings.value
            val pollResult = videoService.pollJobStatus(currentJob.jobId, currentSettings, elapsed)

            _uiState.update {
                it.copy(
                    currentStatus = pollResult.status,
                    progressPercent = pollResult.progressPercent,
                    statusMessage = pollResult.statusMessage,
                    errorMessage = pollResult.errorMessage
                )
            }

            currentJob = currentJob.copy(
                status = pollResult.status,
                progressPercent = pollResult.progressPercent,
                statusMessage = pollResult.statusMessage,
                videoUrl = pollResult.videoUrl ?: currentJob.videoUrl,
                errorMessage = pollResult.errorMessage,
                updatedAt = System.currentTimeMillis()
            )
            videoRepo.updateVideoJob(currentJob)

            if (pollResult.status == VideoJobStatus.COMPLETED) {
                val videoUrl = pollResult.videoUrl ?: currentJob.videoUrl
                if (!videoUrl.isNullOrBlank()) {
                    handleCompletedVideo(currentJob, videoUrl)
                } else {
                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            currentStatus = VideoJobStatus.COMPLETED,
                            activeJob = currentJob
                        )
                    }
                }
                return
            } else if (pollResult.status == VideoJobStatus.FAILED) {
                _uiState.update {
                    it.copy(
                        isGenerating = false,
                        currentStatus = VideoJobStatus.FAILED,
                        errorMessage = pollResult.errorMessage ?: "Video generation failed at provider."
                    )
                }
                return
            }
        }

        if (elapsed >= maxWaitSeconds) {
            val timeoutError = "Generation timed out. You can check status later in My Videos.\n(समय सीमा समाप्त, बाद में इतिहास में जांचें।)"
            val timedOutJob = currentJob.copy(
                status = VideoJobStatus.FAILED,
                errorMessage = timeoutError
            )
            videoRepo.updateVideoJob(timedOutJob)
            _uiState.update {
                it.copy(
                    isGenerating = false,
                    currentStatus = VideoJobStatus.FAILED,
                    errorMessage = timeoutError
                )
            }
        }
    }

    private suspend fun handleCompletedVideo(job: VideoJob, videoUrl: String) {
        _uiState.update {
            it.copy(
                statusMessage = "Downloading video for offline preview... (वीडियो डाउनलोड हो रहा है...)",
                progressPercent = 95
            )
        }

        val downloadResult = videoService.downloadVideoLocally(videoUrl, job.jobId)
        val localPath = downloadResult.getOrNull()

        val updatedJob = job.copy(
            status = VideoJobStatus.COMPLETED,
            progressPercent = 100,
            statusMessage = "Video Ready (वीडियो तैयार है)",
            videoUrl = videoUrl,
            localVideoPath = localPath,
            updatedAt = System.currentTimeMillis()
        )

        videoRepo.updateVideoJob(updatedJob)

        _uiState.update {
            it.copy(
                isGenerating = false,
                currentStatus = VideoJobStatus.COMPLETED,
                progressPercent = 100,
                statusMessage = "Video ready!",
                activeJob = updatedJob
            )
        }
    }

    fun cancelGeneration() {
        activePollingJob?.cancel()
        val current = _uiState.value.activeJob
        if (current != null) {
            val cancelledJob = current.copy(
                status = VideoJobStatus.CANCELLED,
                statusMessage = "Cancelled by user (उपयोगकर्ता द्वारा रद्द किया गया)"
            )
            viewModelScope.launch { videoRepo.updateVideoJob(cancelledJob) }
        }
        _uiState.update {
            it.copy(
                isGenerating = false,
                currentStatus = VideoJobStatus.CANCELLED,
                statusMessage = "Generation cancelled"
            )
        }
    }

    fun retryJob(job: VideoJob) {
        _uiState.update {
            it.copy(
                prompt = job.prompt,
                selectedStyle = VideoStyle.entries.find { s -> s.displayName == job.style } ?: VideoStyle.CINEMATIC,
                selectedAspectRatio = VideoAspectRatio.entries.find { r -> r.ratio == job.aspectRatio } ?: VideoAspectRatio.RATIO_9_16,
                selectedDuration = job.duration,
                dialogueLanguage = job.dialogueLanguage,
                activeJob = null,
                currentStatus = VideoJobStatus.IDLE,
                errorMessage = null
            )
        }
        generateVideo()
    }

    fun openVideoJob(job: VideoJob) {
        _uiState.update {
            it.copy(
                activeJob = job,
                currentStatus = job.status,
                progressPercent = job.progressPercent,
                statusMessage = job.statusMessage,
                errorMessage = job.errorMessage
            )
        }
    }

    fun deleteVideoJob(id: Long) {
        viewModelScope.launch {
            videoRepo.deleteVideoJob(id)
            if (_uiState.value.activeJob?.id == id) {
                _uiState.update { it.copy(activeJob = null, currentStatus = VideoJobStatus.IDLE) }
            }
        }
    }

    fun saveVideoToGallery(context: Context, videoPath: String) {
        val file = File(videoPath)
        if (!file.exists()) {
            Toast.makeText(context, "Video file not found locally (वीडियो फ़ाइल नहीं मिली)", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIPromptStudio")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val uri = context.contentResolver.insert(collection, values)

                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { outStream ->
                        FileInputStream(file).use { inStream ->
                            inStream.copyTo(outStream)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                    Toast.makeText(context, "Saved to Movies folder! (गैलरी में सहेजा गया)", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Could not create gallery entry", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Video saved at: ${file.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Log.e("VideoGeneratorViewModel", "Failed to save video to gallery", e)
            Toast.makeText(context, "Save error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareVideo(context: Context, videoJob: VideoJob) {
        val localPath = videoJob.localVideoPath
        if (localPath != null && File(localPath).exists()) {
            try {
                val file = File(localPath)
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, "🎬 Created with AI Prompt Studio: ${videoJob.prompt}")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share Generated Video"))
            } catch (e: Exception) {
                Log.e("VideoGeneratorViewModel", "Share file error", e)
                fallbackShareText(context, videoJob)
            }
        } else if (!videoJob.videoUrl.isNullOrBlank()) {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "AI Video: ${videoJob.prompt}")
                putExtra(Intent.EXTRA_TEXT, "🎬 Generated Video: ${videoJob.videoUrl}\n\nPrompt: ${videoJob.prompt}")
            }
            context.startActivity(Intent.createChooser(intent, "Share Video Link"))
        } else {
            Toast.makeText(context, "Video file not ready yet for sharing", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fallbackShareText(context: Context, videoJob: VideoJob) {
        val text = "🎬 AI Video Generation Plan\nIdea: ${videoJob.prompt}\nStyle: ${videoJob.style}\nRatio: ${videoJob.aspectRatio}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "Share"))
    }
}
