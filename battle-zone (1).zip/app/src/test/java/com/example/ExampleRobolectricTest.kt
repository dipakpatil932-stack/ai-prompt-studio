package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.engine.CombatEngine
import com.example.game.engine.TacticalIslandMap
import com.example.game.model.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun testAppNameString() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Battle Zone", appName)
  }

  @Test
  fun testWeaponCatalogIntegrity() {
    assertTrue(WeaponCatalog.ALL_WEAPONS.isNotEmpty())
    val ar = WeaponCatalog.VX9_TEMPEST
    assertEquals("VX-9 Tempest", ar.name)
    assertEquals(WeaponCategory.ASSAULT_RIFLE, ar.category)
    assertTrue(ar.baseDamage > 0f)
    assertTrue(ar.magCapacity > 0)
  }

  @Test
  fun testMapPointsOfInterest() {
    assertEquals(12, TacticalIslandMap.POIs.size)
    assertFalse(TacticalIslandMap.BUILDINGS.isEmpty())
  }

  @Test
  fun testCombatDamageAbsorption() {
    val player = PlayerState(health = 100f, armor = 100f)
    CombatEngine.applyDamageToPlayer(player, 40f)
    // 55% of 40 = 22 absorbed by armor, 18 applied to health
    assertEquals(82f, player.health, 0.01f)
    assertEquals(78f, player.armor, 0.01f)
    assertTrue(player.isAlive)
  }

  @Test
  fun testMainActivityLaunch() {
    val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
    assertNotNull(controller.get())
  }

  @Test
  fun testGameEngineMatchLifecycle() {
    val engine = com.example.game.engine.GameEngine()
    engine.initializeMatch(MatchMode.SOLO)
    assertNotNull(engine.playerState.value)
    assertTrue(engine.bots.value.isNotEmpty())
    assertTrue(engine.vehicles.value.isNotEmpty())
    assertTrue(engine.lootItems.value.isNotEmpty())
    assertEquals(MatchPhase.LOBBY, engine.matchPhase.value)

    // Run game engine updates
    engine.update(0.016f)
    assertTrue(engine.playerState.value.isAlive)

    // Squad mode test
    engine.initializeMatch(MatchMode.SQUAD)
    assertEquals(3, engine.squad.value.size)
  }
}
