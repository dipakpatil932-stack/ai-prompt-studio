package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Battle Royale Palette
val TacticalAmber = Color(0xFFFFB300)
val TacticalAmberLight = Color(0xFFFFD54F)
val TacticalCyan = Color(0xFF00E5FF)
val TacticalGreen = Color(0xFF00E676)
val TacticalRed = Color(0xFFFF334B)
val TacticalOrange = Color(0xFFFF7043)
val TacticalPurple = Color(0xFFAB47BC)

val CarbonDark = Color(0xFF0A0E14)
val SlateNavy = Color(0xFF121924)
val SlateSurface = Color(0xFF1A2332)
val SlateBorder = Color(0xFF28384D)
val SlateHighlight = Color(0xFF384F6C)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF9BAAC0)
val TextMuted = Color(0xFF62738B)

// Rarity Colors
val RarityCommon = Color(0xFF9E9E9E)
val RarityUncommon = Color(0xFF4CAF50)
val RarityRare = Color(0xFF2196F3)
val RarityEpic = Color(0xFF9C27B0)
val RarityLegendary = Color(0xFFFF9800)
