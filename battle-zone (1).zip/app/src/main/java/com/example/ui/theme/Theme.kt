package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = TacticalAmber,
    onPrimary = Color.Black,
    primaryContainer = SlateHighlight,
    onPrimaryContainer = TacticalAmberLight,
    secondary = TacticalCyan,
    onSecondary = Color.Black,
    secondaryContainer = SlateSurface,
    onSecondaryContainer = TacticalCyan,
    tertiary = TacticalGreen,
    background = CarbonDark,
    surface = SlateNavy,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurface,
    onSurfaceVariant = TextSecondary,
    outline = SlateBorder,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(colorScheme = DarkColorScheme, typography = Typography, content = content)
}
