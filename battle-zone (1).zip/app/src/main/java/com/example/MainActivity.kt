package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.game.audio.GameSoundEngine
import com.example.game.engine.GameEngine
import com.example.game.model.MatchMode
import com.example.game.model.MatchPhase
import com.example.game.repository.GameRepository
import com.example.game.ui.*
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay

enum class CurrentAppScreen {
  MAIN_MENU,
  TRAINING_GROUND,
  IN_GAME,
  MATCH_SUMMARY
}

class MainActivity : ComponentActivity() {

  private lateinit var gameRepository: GameRepository
  private lateinit var gameEngine: GameEngine

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    gameRepository = GameRepository(applicationContext)
    gameEngine = GameEngine()

    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = CarbonDark,
          contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { _ ->
          BattleZoneApp(
            gameRepository = gameRepository,
            gameEngine = gameEngine
          )
        }
      }
    }
  }

  override fun onDestroy() {
    super.onDestroy()
  }
}

@Composable
fun BattleZoneApp(
  gameRepository: GameRepository,
  gameEngine: GameEngine
) {
  var appScreen by remember { mutableStateOf(CurrentAppScreen.MAIN_MENU) }

  val player by gameEngine.playerState.collectAsState()
  val matchPhase by gameEngine.matchPhase.collectAsState()
  val safeZone by gameEngine.safeZone.collectAsState()
  val bots by gameEngine.bots.collectAsState()
  val vehicles by gameEngine.vehicles.collectAsState()
  val lootItems by gameEngine.lootItems.collectAsState()
  val tracers by gameEngine.bulletTracers.collectAsState()
  val particles by gameEngine.combatParticles.collectAsState()
  val killFeed by gameEngine.killFeed.collectAsState()
  val nearbyLoot by gameEngine.nearbyLoot.collectAsState()
  val nearbyVehicle by gameEngine.nearbyVehicle.collectAsState()
  val squad by gameEngine.squad.collectAsState()
  val matchSummary by gameEngine.matchSummary.collectAsState()
  val damagePopups by gameEngine.damagePopups.collectAsState()

  // Match state loop: run 60 ticks/second while on IN_GAME screen
  LaunchedEffect(appScreen) {
    if (appScreen == CurrentAppScreen.IN_GAME) {
      while (true) {
        delay(16)
        gameEngine.update(0.016f)
      }
    }
  }

  // Detect match conclusion and show summary
  LaunchedEffect(matchSummary) {
    val summary = matchSummary
    if (summary != null && appScreen == CurrentAppScreen.IN_GAME) {
      gameRepository.recordMatchResult(summary)
      delay(1500) // Brief dramatic pause for victory/defeat banner
      if (appScreen == CurrentAppScreen.IN_GAME) {
        appScreen = CurrentAppScreen.MATCH_SUMMARY
      }
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonDark)
  ) {
    when (appScreen) {
      CurrentAppScreen.MAIN_MENU -> {
        MainMenuScreen(
          repository = gameRepository,
          onStartMatch = { mode ->
            gameEngine.initializeMatch(mode)
            appScreen = CurrentAppScreen.IN_GAME
            GameSoundEngine.playUiTap()
          },
          onOpenTraining = {
            appScreen = CurrentAppScreen.TRAINING_GROUND
            GameSoundEngine.playUiTap()
          }
        )
      }

      CurrentAppScreen.TRAINING_GROUND -> {
        TrainingGroundScreen(
          onBackToMenu = {
            appScreen = CurrentAppScreen.MAIN_MENU
            GameSoundEngine.playUiTap()
          }
        )
      }

      CurrentAppScreen.IN_GAME -> {
        Box(modifier = Modifier.fillMaxSize()) {
          // 3D Perspective Graphic Renderer
          GameRenderer(
            player = player,
            phase = matchPhase,
            safeZone = safeZone,
            bots = bots,
            vehicles = vehicles,
            lootItems = lootItems,
            tracers = tracers,
            particles = particles,
            damagePopups = damagePopups,
            camX = gameEngine.smoothedCamX,
            camY = gameEngine.smoothedCamY
          )

          // Tactical HUD & Controls
          GameHud(
            gameEngine = gameEngine,
            player = player,
            phase = matchPhase,
            safeZone = safeZone,
            aliveCount = bots.count { it.isAlive } + (if (player.isAlive) 1 else 0),
            killFeed = killFeed,
            nearbyLoot = nearbyLoot,
            nearbyVehicle = nearbyVehicle,
            squad = squad,
            onReturnToLobby = {
              appScreen = CurrentAppScreen.MAIN_MENU
            }
          )
        }
      }

      CurrentAppScreen.MATCH_SUMMARY -> {
        val summary = matchSummary
        if (summary != null) {
          MatchResultScreen(
            summary = summary,
            onPlayAgain = {
              gameEngine.initializeMatch(gameEngine.selectedMatchMode)
              appScreen = CurrentAppScreen.IN_GAME
              GameSoundEngine.playUiTap()
            },
            onReturnToLobby = {
              appScreen = CurrentAppScreen.MAIN_MENU
              GameSoundEngine.playUiTap()
            }
          )
        } else {
          appScreen = CurrentAppScreen.MAIN_MENU
        }
      }
    }
  }
}
