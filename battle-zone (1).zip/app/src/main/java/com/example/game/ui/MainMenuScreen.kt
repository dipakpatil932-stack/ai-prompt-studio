package com.example.game.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.audio.GameSoundEngine
import com.example.game.model.*
import com.example.game.repository.*
import com.example.ui.theme.*

enum class MenuTab {
  LOBBY,
  WEAPONS,
  CHARACTERS,
  MISSIONS,
  LEADERBOARD,
  PROFILE
}

@Composable
fun MainMenuScreen(
  repository: GameRepository,
  onStartMatch: (MatchMode) -> Unit,
  onOpenTraining: () -> Unit,
  modifier: Modifier = Modifier
) {
  val profile by repository.profileState.collectAsState()
  val settings by repository.settingsState.collectAsState()
  val missions by repository.missionsState.collectAsState()

  var currentTab by remember { mutableStateOf(MenuTab.LOBBY) }
  var selectedMode by remember { mutableStateOf(MatchMode.SOLO) }
  var showSettingsDialog by remember { mutableStateOf(false) }
  var showMatchmakingModal by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(Color(0xFF101720), CarbonDark, Color(0xFF0D1219))
        )
      )
  ) {
    Column(modifier = Modifier.fillMaxSize()) {

      // 1. TOP HEADER (Avatar, Level, XP bar, Coins, Training Ground, Settings)
      TopHeaderBar(
        profile = profile,
        onOpenTraining = onOpenTraining,
        onOpenSettings = { showSettingsDialog = true }
      )

      // 2. MAIN CONTENT AREA BASED ON TAB
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
      ) {
        when (currentTab) {
          MenuTab.LOBBY -> LobbyHomeScreen(
            profile = profile,
            selectedMode = selectedMode,
            onSelectMode = { selectedMode = it },
            onStartMatch = { showMatchmakingModal = true },
            onOpenTraining = onOpenTraining
          )
          MenuTab.WEAPONS -> WeaponsArmoryScreen()
          MenuTab.CHARACTERS -> CharacterCustomizationScreen(
            profile = profile,
            onSelectOutfit = { repository.selectOutfit(it) }
          )
          MenuTab.MISSIONS -> MissionsScreen(
            missions = missions,
            onClaim = { repository.claimMissionReward(it) }
          )
          MenuTab.LEADERBOARD -> LeaderboardScreen(repository = repository)
          MenuTab.PROFILE -> ProfileStatsScreen(profile = profile)
        }
      }

      // 3. BOTTOM NAVIGATION DOCK
      BottomNavigationDock(
        activeTab = currentTab,
        onTabSelected = {
          currentTab = it
          GameSoundEngine.playUiTap()
        }
      )
    }

    // Matchmaking Flow Modal Dialog
    if (showMatchmakingModal) {
      MatchmakingDialog(
        mode = selectedMode,
        onLaunchMatch = {
          showMatchmakingModal = false
          onStartMatch(selectedMode)
        },
        onCancel = {
          showMatchmakingModal = false
          GameSoundEngine.playUiTap()
        }
      )
    }

    // Settings Modal Dialog
    if (showSettingsDialog) {
      SettingsDialog(
        settings = settings,
        onSaveSettings = { repository.updateSettings(it) },
        onDismiss = { showSettingsDialog = false }
      )
    }
  }
}

// -------------------------------------------------------------
// TOP HEADER BAR
// -------------------------------------------------------------

@Composable
fun TopHeaderBar(
  profile: PlayerProfile,
  onOpenTraining: () -> Unit,
  onOpenSettings: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(SlateNavy)
      .padding(horizontal = 16.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    // User Profile Pill
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(TacticalAmber)
          .border(2.dp, TacticalAmberLight, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text("LV${profile.level}", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black)
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column {
        Text(profile.username, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        // XP Bar
        Box(
          modifier = Modifier
            .width(100.dp)
            .height(4.dp)
            .background(Color(0xFF263238), RoundedCornerShape(2.dp))
        ) {
          Box(
            modifier = Modifier
              .fillMaxHeight()
              .fillMaxWidth((profile.xp.toFloat() / profile.xpNextLevel.coerceAtLeast(1)).coerceIn(0f, 1f))
              .background(TacticalAmber, RoundedCornerShape(2.dp))
          )
        }
      }
    }

    // Right Controls: Currency, Training, Settings
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
      // Coins Pill
      Row(
        modifier = Modifier
          .background(SlateSurface, RoundedCornerShape(16.dp))
          .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TacticalAmber, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("${profile.coins}", color = TacticalAmberLight, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }

      // Training Ground Shortcut
      OutlinedButton(
        onClick = onOpenTraining,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TacticalCyan),
        border = BorderStroke(1.dp, TacticalCyan),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
        modifier = Modifier
          .height(32.dp)
          .testTag("training_ground_menu_button")
      ) {
        Icon(Icons.Default.Adjust, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("TRAINING GROUND", fontSize = 10.sp, fontWeight = FontWeight.Bold)
      }

      // Settings Button
      IconButton(
        onClick = onOpenSettings,
        modifier = Modifier
          .size(32.dp)
          .testTag("settings_button")
      ) {
        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
      }
    }
  }
}

// -------------------------------------------------------------
// LOBBY HOME SCREEN
// -------------------------------------------------------------

@Composable
fun LobbyHomeScreen(
  profile: PlayerProfile,
  selectedMode: MatchMode,
  onSelectMode: (MatchMode) -> Unit,
  onStartMatch: () -> Unit,
  onOpenTraining: () -> Unit
) {
  BoxWithConstraints(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    val isLandscape = maxWidth >= 540.dp
    if (isLandscape) {
      Row(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Box(
          modifier = Modifier
            .weight(1.2f)
            .fillMaxHeight(),
          contentAlignment = Alignment.Center
        ) {
          LobbyCharacterDisplay(profile)
        }

        Column(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight(),
          verticalArrangement = Arrangement.Center,
          horizontalAlignment = Alignment.End
        ) {
          LobbyDeployControls(
            selectedMode = selectedMode,
            onSelectMode = onSelectMode,
            onStartMatch = onStartMatch,
            isCentered = false
          )
        }
      }
    } else {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1.1f),
          contentAlignment = Alignment.Center
        ) {
          LobbyCharacterDisplay(profile)
        }
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .weight(0.9f),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          LobbyDeployControls(
            selectedMode = selectedMode,
            onSelectMode = onSelectMode,
            onStartMatch = onStartMatch,
            isCentered = true
          )
        }
      }
    }
  }
}

@Composable
private fun LobbyCharacterDisplay(profile: PlayerProfile) {
  Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val cx = size.width / 2f
      val cy = size.height / 2f

      // Glowing tactical platform
      drawOval(
        color = Color(0x33FFB300),
        topLeft = Offset(cx - 100f, cy + 80f),
        size = androidx.compose.ui.geometry.Size(200f, 40f)
      )
      drawOval(
        color = TacticalAmber,
        topLeft = Offset(cx - 70f, cy + 90f),
        size = androidx.compose.ui.geometry.Size(140f, 20f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
      )

      // Stylized 3D Character Figurine
      val outfit = OutfitCatalog.OUTFITS[profile.selectedOutfitIndex % OutfitCatalog.OUTFITS.size]
      // Shadow
      drawCircle(Color(0x66000000), radius = 28f, center = Offset(cx + 4f, cy + 80f))
      // Body
      drawRoundRect(
        color = Color(outfit.primaryColorHex),
        topLeft = Offset(cx - 24f, cy - 30f),
        size = androidx.compose.ui.geometry.Size(48f, 75f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
      )
      // Armor Vest
      drawRoundRect(
        color = Color(0xFF263238),
        topLeft = Offset(cx - 20f, cy - 20f),
        size = androidx.compose.ui.geometry.Size(40f, 45f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
      )
      // Helmet
      drawCircle(Color(0xFF37474F), radius = 22f, center = Offset(cx, cy - 45f))
      // Glowing Visor
      drawRoundRect(
        color = Color(outfit.accentColorHex),
        topLeft = Offset(cx - 14f, cy - 48f),
        size = androidx.compose.ui.geometry.Size(28f, 8f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
      )
      // Weapon in hands
      drawRect(
        color = Color(0xFF212121),
        topLeft = Offset(cx + 12f, cy - 5f),
        size = androidx.compose.ui.geometry.Size(55f, 14f)
      )
    }

    // Equipped Outfit Label
    Surface(
      color = Color(0xCC101720),
      shape = RoundedCornerShape(6.dp),
      border = BorderStroke(1.dp, SlateBorder),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 8.dp)
    ) {
      val outfit = OutfitCatalog.OUTFITS[profile.selectedOutfitIndex % OutfitCatalog.OUTFITS.size]
      Text(
        text = "${outfit.name} // LOADOUT READY",
        color = TacticalAmber,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
      )
    }
  }
}

@Composable
private fun LobbyDeployControls(
  selectedMode: MatchMode,
  onSelectMode: (MatchMode) -> Unit,
  onStartMatch: () -> Unit,
  isCentered: Boolean = false
) {
  Column(
    horizontalAlignment = if (isCentered) Alignment.CenterHorizontally else Alignment.End,
    verticalArrangement = Arrangement.Center
  ) {
    Text(
      text = "BATTLE ZONE: SURVIVAL",
      color = Color.White,
      fontSize = 20.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.SansSerif
    )
    Text(
      text = "MAP: ISLA PERDIDA // 24 CONTESTANTS",
      color = TacticalCyan,
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold
    )

    Spacer(modifier = Modifier.height(14.dp))

    // Mode Selector Pills (Solo, Duo, Squad)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      MatchMode.values().forEach { mode ->
        val isSel = mode == selectedMode
        Surface(
          color = if (isSel) TacticalAmber else SlateSurface,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, if (isSel) TacticalAmberLight else SlateBorder),
          modifier = Modifier
            .clickable {
              onSelectMode(mode)
              GameSoundEngine.playUiTap()
            }
            .testTag("mode_${mode.name.lowercase()}")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              when (mode) {
                MatchMode.SOLO -> Icons.Default.Person
                MatchMode.DUO -> Icons.Default.People
                MatchMode.SQUAD -> Icons.Default.Groups
              },
              contentDescription = null,
              tint = if (isSel) Color.Black else Color.White,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = mode.displayName,
              color = if (isSel) Color.Black else Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Giant START MATCH Button
    Button(
      onClick = onStartMatch,
      colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .width(240.dp)
        .height(52.dp)
        .testTag("start_match_button")
    ) {
      Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(24.dp))
      Spacer(modifier = Modifier.width(10.dp))
      Text("DEPLOY MATCH", fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
  }
}

// -------------------------------------------------------------
// WEAPONS ARMORY SCREEN
// -------------------------------------------------------------

@Composable
fun WeaponsArmoryScreen() {
  var selectedWeapon by remember { mutableStateOf(WeaponCatalog.VX9_TEMPEST) }

  Row(
    modifier = Modifier
      .fillMaxSize()
      .padding(20.dp),
    horizontalArrangement = Arrangement.spacedBy(20.dp)
  ) {
    // Left: Weapon List
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(WeaponCatalog.ALL_WEAPONS) { wp ->
        val isSel = wp.id == selectedWeapon.id
        Surface(
          color = if (isSel) SlateSurface else SlateNavy,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) TacticalAmber else SlateBorder),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              selectedWeapon = wp
              GameSoundEngine.playUiTap()
            }
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(wp.name, color = if (isSel) TacticalAmberLight else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
              Text(wp.category.displayName, color = TextMuted, fontSize = 10.sp)
            }
            Text(wp.ammoType.caliber, color = wp.ammoType.color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Right: Selected Weapon Detailed Stats
    Card(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight(),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, SlateBorder)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(18.dp)
      ) {
        Text(selectedWeapon.name, color = TacticalAmber, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text(selectedWeapon.category.displayName, color = TacticalCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Text(selectedWeapon.description, color = TextSecondary, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        // Weapon Stat Bars
        StatProgressRow("DAMAGE", selectedWeapon.baseDamage, 120f, TacticalRed)
        StatProgressRow("RATE OF FIRE", selectedWeapon.fireRateRps * 60f, 900f, TacticalCyan)
        StatProgressRow("EFFECTIVE RANGE", selectedWeapon.rangeMeters, 600f, TacticalGreen)
        StatProgressRow("MAG CAPACITY", selectedWeapon.magCapacity.toFloat(), 40f, TacticalAmber)
        StatProgressRow("RECOIL CONTROL", 5f - selectedWeapon.recoilVertical, 5f, TacticalPurple)
      }
    }
  }
}

@Composable
fun StatProgressRow(label: String, value: Float, max: Float, color: Color) {
  Column(modifier = Modifier.padding(vertical = 4.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(label, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
      Text("${value.toInt()}", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
    Spacer(modifier = Modifier.height(2.dp))
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(5.dp)
        .background(Color(0xFF263238), RoundedCornerShape(2.dp))
    ) {
      Box(
        modifier = Modifier
          .fillMaxHeight()
          .fillMaxWidth((value / max).coerceIn(0f, 1f))
          .background(color, RoundedCornerShape(2.dp))
      )
    }
  }
}

// -------------------------------------------------------------
// CHARACTER CUSTOMIZATION SCREEN
// -------------------------------------------------------------
// CHARACTER CUSTOMIZATION SCREEN (OUTFITS, HEADGEAR, EMOTES)
// -------------------------------------------------------------

@Composable
fun CharacterCustomizationScreen(
  profile: PlayerProfile,
  onSelectOutfit: (Int) -> Unit
) {
  var activeCategory by remember { mutableStateOf("Outfits") }
  var selectedHeadgear by remember { mutableStateOf(0) }
  var selectedEmote by remember { mutableStateOf(0) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Customization category tabs
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 12.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("Outfits", "Headgear", "Emotes").forEach { cat ->
        val isSel = cat == activeCategory
        Button(
          onClick = {
            activeCategory = cat
            GameSoundEngine.playUiTap()
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isSel) TacticalAmber else SlateSurface,
            contentColor = if (isSel) Color.Black else Color.White
          ),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp)
        ) {
          Text(cat.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    when (activeCategory) {
      "Outfits" -> {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(OutfitCatalog.OUTFITS.indices.toList()) { index ->
            val outfit = OutfitCatalog.OUTFITS[index]
            val isEquipped = profile.selectedOutfitIndex == index

            Surface(
              color = if (isEquipped) SlateSurface else SlateNavy,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(if (isEquipped) 1.5.dp else 1.dp, if (isEquipped) TacticalAmber else SlateBorder),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onSelectOutfit(index)
                  GameSoundEngine.playUiTap()
                }
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(18.dp)
                      .clip(CircleShape)
                      .background(Color(outfit.accentColorHex))
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(outfit.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(outfit.description, color = TextMuted, fontSize = 10.sp)
                  }
                }

                if (isEquipped) {
                  Text("EQUIPPED", color = TacticalAmber, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                } else {
                  Button(
                    onClick = {
                      onSelectOutfit(index)
                      GameSoundEngine.playUiTap()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SlateHighlight, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                  ) {
                    Text("EQUIP", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }

      "Headgear" -> {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(CustomizationCatalog.HEADGEARS.indices.toList()) { index ->
            val hg = CustomizationCatalog.HEADGEARS[index]
            val isEquipped = selectedHeadgear == index

            Surface(
              color = if (isEquipped) SlateSurface else SlateNavy,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(if (isEquipped) 1.5.dp else 1.dp, if (isEquipped) TacticalCyan else SlateBorder),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  selectedHeadgear = index
                  GameSoundEngine.playUiTap()
                }
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(18.dp)
                      .clip(CircleShape)
                      .background(Color(hg.colorHex))
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(hg.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(hg.description, color = TextMuted, fontSize = 10.sp)
                  }
                }

                if (isEquipped) {
                  Text("EQUIPPED", color = TacticalCyan, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                } else {
                  Button(
                    onClick = {
                      selectedHeadgear = index
                      GameSoundEngine.playUiTap()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SlateHighlight, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                  ) {
                    Text("EQUIP", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }

      "Emotes" -> {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(CustomizationCatalog.EMOTES.indices.toList()) { index ->
            val emote = CustomizationCatalog.EMOTES[index]
            val isEquipped = selectedEmote == index

            Surface(
              color = if (isEquipped) SlateSurface else SlateNavy,
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(if (isEquipped) 1.5.dp else 1.dp, if (isEquipped) TacticalGreen else SlateBorder),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  selectedEmote = index
                  GameSoundEngine.playUiTap()
                }
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Celebration, contentDescription = null, tint = TacticalGreen, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(emote.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(emote.prompt, color = TextMuted, fontSize = 10.sp)
                  }
                }

                if (isEquipped) {
                  Text("ACTIVE", color = TacticalGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                } else {
                  Button(
                    onClick = {
                      selectedEmote = index
                      GameSoundEngine.playUiTap()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SlateHighlight, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                  ) {
                    Text("SELECT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// MISSIONS SCREEN
// -------------------------------------------------------------

@Composable
fun MissionsScreen(
  missions: List<GameMission>,
  onClaim: (String) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(20.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    items(missions) { m ->
      Surface(
        color = SlateNavy,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (m.isCompleted && !m.isClaimed) TacticalAmber else SlateBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(m.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(m.description, color = TextSecondary, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(6.dp))

            // Progress Bar
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .width(180.dp)
                  .height(6.dp)
                  .background(Color(0xFF263238), RoundedCornerShape(3.dp))
              ) {
                Box(
                  modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth((m.currentCount.toFloat() / m.targetCount).coerceIn(0f, 1f))
                    .background(TacticalGreen, RoundedCornerShape(3.dp))
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text("${m.currentCount}/${m.targetCount}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
          }

          // Rewards & Claim Button
          Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TacticalAmber, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(2.dp))
              Text("+${m.rewardCoins}", color = TacticalAmberLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)

              Spacer(modifier = Modifier.width(8.dp))

              Icon(Icons.Default.Star, contentDescription = null, tint = TacticalCyan, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(2.dp))
              Text("+${m.rewardXp} XP", color = TacticalCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (m.isClaimed) {
              Text("CLAIMED", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            } else if (m.isCompleted) {
              Button(
                onClick = { onClaim(m.id) },
                colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                modifier = Modifier.height(30.dp)
              ) {
                Text("CLAIM REWARD", fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            } else {
              Text("IN PROGRESS", color = TacticalCyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// LEADERBOARD SCREEN
// -------------------------------------------------------------

@Composable
fun LeaderboardScreen(repository: GameRepository) {
  var selectedType by remember { mutableStateOf("Global") }
  val board = repository.getLeaderboard(selectedType)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(20.dp)
  ) {
    // Toggle type
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("Global", "Friends", "Season").forEach { type ->
        val isSel = type == selectedType
        Button(
          onClick = {
            selectedType = type
            GameSoundEngine.playUiTap()
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isSel) TacticalAmber else SlateSurface,
            contentColor = if (isSel) Color.Black else Color.White
          ),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp)
        ) {
          Text(type, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      items(board) { item ->
        Surface(
          color = SlateNavy,
          shape = RoundedCornerShape(6.dp),
          border = BorderStroke(1.dp, if (item.rank == 1) TacticalAmber else SlateBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                "#${item.rank}",
                color = if (item.rank <= 3) TacticalAmber else TextMuted,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                modifier = Modifier.width(36.dp)
              )
              Text(item.username, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
              Spacer(modifier = Modifier.width(8.dp))
              Text("[${item.badge}]", color = TacticalCyan, fontSize = 10.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
              Text("WINS: ${item.wins}", color = TacticalGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text("KILLS: ${item.eliminations}", color = TacticalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text("RATING: ${item.rating}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// PROFILE & STATS SCREEN
// -------------------------------------------------------------

@Composable
fun ProfileStatsScreen(profile: PlayerProfile) {
  Row(
    modifier = Modifier
      .fillMaxSize()
      .padding(20.dp),
    horizontalArrangement = Arrangement.spacedBy(20.dp)
  ) {
    // Left: Identity Card
    Card(
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight(),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, SlateBorder)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Box(
          modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(TacticalAmber)
            .border(3.dp, Color.White, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Shield, contentDescription = null, tint = Color.Black, modifier = Modifier.size(40.dp))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(profile.username, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text(profile.rankTitle, color = TacticalCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("Level ${profile.level} (XP: ${profile.xp}/${profile.xpNextLevel})", color = TextSecondary, fontSize = 11.sp)
      }
    }

    // Right: Lifetime Combat Statistics
    Card(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight(),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, SlateBorder)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(18.dp)
      ) {
        Text("LIFETIME COMBAT RECORD", color = TacticalAmber, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Spacer(modifier = Modifier.height(14.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          StatBox("MATCHES", "${profile.matchesPlayed}", TacticalCyan)
          StatBox("VICTORIES", "${profile.wins}", TacticalAmber)
          StatBox("TOP 10", "${profile.topTen}", TacticalGreen)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          StatBox("TOTAL KILLS", "${profile.totalKills}", TacticalRed)
          StatBox("MAX KILLS", "${profile.highestKills}", TacticalPurple)
          val kd = if (profile.matchesPlayed > 0) String.format("%.2f", profile.totalKills.toFloat() / profile.matchesPlayed) else "0.00"
          StatBox("AVG K/D", kd, TacticalAmberLight)
        }
      }
    }
  }
}

// -------------------------------------------------------------
// SETTINGS MODAL DIALOG
// -------------------------------------------------------------

@Composable
fun SettingsDialog(
  settings: GameSettingsConfig,
  onSaveSettings: (GameSettingsConfig) -> Unit,
  onDismiss: () -> Unit
) {
  var gfxQuality by remember { mutableStateOf(settings.graphicsQuality) }
  var targetFps by remember { mutableStateOf(settings.targetFps) }
  var masterVol by remember { mutableStateOf(settings.masterVolume) }
  var sfxVol by remember { mutableStateOf(settings.sfxVolume) }
  var sens by remember { mutableStateOf(settings.cameraSensitivity) }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xCC000000))
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.75f)
        .wrapContentHeight(),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, SlateBorder)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("SETTINGS // SYSTEM & COMBAT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Graphics preset (Low, Med, High, Ultra)
        Text("GRAPHICS PRESET", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("Low", "Medium", "High", "Ultra").forEach { q ->
            val isSel = q == gfxQuality
            OutlinedButton(
              onClick = { gfxQuality = q },
              border = BorderStroke(1.dp, if (isSel) TacticalAmber else SlateBorder),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSel) TacticalAmber.copy(alpha = 0.2f) else Color.Transparent,
                contentColor = if (isSel) TacticalAmber else Color.White
              ),
              modifier = Modifier.height(30.dp)
            ) {
              Text(q, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Target FPS (30, 60, 90)
        Text("FRAME RATE TARGET", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(30, 60, 90).forEach { fps ->
            val isSel = fps == targetFps
            OutlinedButton(
              onClick = { targetFps = fps },
              border = BorderStroke(1.dp, if (isSel) TacticalCyan else SlateBorder),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSel) TacticalCyan.copy(alpha = 0.2f) else Color.Transparent,
                contentColor = if (isSel) TacticalCyan else Color.White
              ),
              modifier = Modifier.height(30.dp)
            ) {
              Text("${fps} FPS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bot AI Difficulty
        var botDiff by remember { mutableStateOf(BotDifficulty.NORMAL) }
        Text("AI DIFFICULTY", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          BotDifficulty.values().forEach { diff ->
            val isSel = diff == botDiff
            OutlinedButton(
              onClick = { botDiff = diff },
              border = BorderStroke(1.dp, if (isSel) TacticalAmber else SlateBorder),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = if (isSel) TacticalAmber.copy(alpha = 0.2f) else Color.Transparent,
                contentColor = if (isSel) TacticalAmber else Color.White
              ),
              modifier = Modifier.height(30.dp)
            ) {
              Text(diff.displayName.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Controls Quick Guide Expandable
        var showControlsGuide by remember { mutableStateOf(false) }
        OutlinedButton(
          onClick = { showControlsGuide = !showControlsGuide },
          border = BorderStroke(1.dp, TacticalCyan),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TacticalCyan),
          modifier = Modifier.fillMaxWidth().height(32.dp)
        ) {
          Icon(Icons.AutoMirrored.Filled.HelpOutline, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (showControlsGuide) "HIDE CONTROLS GUIDE" else "VIEW COMBAT CONTROLS GUIDE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        if (showControlsGuide) {
          Surface(
            color = Color(0x33000000),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
          ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("• Left Thumb: Move & Sprint lock", color = Color.White, fontSize = 9.sp)
              Text("• Right Thumb: Look & Aim camera", color = Color.White, fontSize = 9.sp)
              Text("• Fire Button: Primary weapon discharge with recoil", color = Color.White, fontSize = 9.sp)
              Text("• ADS Scope: Accurate precision targeting", color = Color.White, fontSize = 9.sp)
              Text("• Jump / Crouch / Prone: Tactical stances", color = Color.White, fontSize = 9.sp)
              Text("• Vehicle: Drive, throttle, reset if stuck", color = Color.White, fontSize = 9.sp)
              Text("• Squad: Approach knocked teammates to revive", color = Color.White, fontSize = 9.sp)
              Text("• Map: Tap anywhere on map to drop waypoint beacon", color = Color.White, fontSize = 9.sp)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Audio Sliders
        Text("MASTER VOLUME: ${(masterVol * 100).toInt()}%", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Slider(
          value = masterVol,
          onValueChange = { masterVol = it },
          colors = SliderDefaults.colors(thumbColor = TacticalAmber, activeTrackColor = TacticalAmber)
        )

        Text("AIM SENSITIVITY: ${(sens * 100).toInt()}%", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Slider(
          value = sens,
          onValueChange = { sens = it },
          valueRange = 0.5f..2.0f,
          colors = SliderDefaults.colors(thumbColor = TacticalCyan, activeTrackColor = TacticalCyan)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = {
            onSaveSettings(
              settings.copy(
                graphicsQuality = gfxQuality,
                targetFps = targetFps,
                masterVolume = masterVol,
                cameraSensitivity = sens
              )
            )
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("APPLY SETTINGS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }
    }
  }
}

// -------------------------------------------------------------
// BOTTOM NAVIGATION DOCK
// -------------------------------------------------------------

@Composable
fun BottomNavigationDock(
  activeTab: MenuTab,
  onTabSelected: (MenuTab) -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(SlateNavy)
      .padding(horizontal = 16.dp, vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceAround,
    verticalAlignment = Alignment.CenterVertically
  ) {
    MenuTab.values().forEach { tab ->
      val isSel = tab == activeTab
      Column(
        modifier = Modifier
          .clickable { onTabSelected(tab) }
          .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(
          when (tab) {
            MenuTab.LOBBY -> Icons.Default.Home
            MenuTab.WEAPONS -> Icons.Default.Security
            MenuTab.CHARACTERS -> Icons.Default.AccessibilityNew
            MenuTab.MISSIONS -> Icons.AutoMirrored.Filled.Assignment
            MenuTab.LEADERBOARD -> Icons.Default.Leaderboard
            MenuTab.PROFILE -> Icons.Default.AccountCircle
          },
          contentDescription = tab.name,
          tint = if (isSel) TacticalAmber else TextMuted,
          modifier = Modifier.size(18.dp)
        )
        Text(
          text = tab.name,
          color = if (isSel) TacticalAmber else TextMuted,
          fontSize = 9.sp,
          fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
        )
      }
    }
  }
}

// -------------------------------------------------------------
// MATCHMAKING MODAL DIALOG (STEP 13)
// -------------------------------------------------------------

@Composable
fun MatchmakingDialog(
  mode: MatchMode,
  onLaunchMatch: () -> Unit,
  onCancel: () -> Unit
) {
  var playersFound by remember { mutableStateOf(1) }
  var countdown by remember { mutableStateOf(3) }
  var isMatchFound by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    while (playersFound < 24) {
      kotlinx.coroutines.delay(100)
      playersFound = (playersFound + (2..4).random()).coerceAtMost(24)
      if (playersFound >= 24) {
        isMatchFound = true
      }
    }
    // Match countdown
    while (countdown > 0) {
      kotlinx.coroutines.delay(800)
      countdown -= 1
    }
    onLaunchMatch()
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xD90A0E14))
      .padding(32.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier.width(440.dp),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(1.5.dp, TacticalAmber)
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Mode badge & Disclaimer
        Surface(
          color = Color(0x3300E5FF),
          shape = RoundedCornerShape(4.dp),
          border = BorderStroke(1.dp, TacticalCyan)
        ) {
          Text(
            text = "LOCAL MATCHMAKING SIMULATION (OFFLINE MODE)",
            color = TacticalCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Radar search pulse
        Box(
          modifier = Modifier
            .size(70.dp)
            .clip(CircleShape)
            .background(Color(0x22FFB300))
            .border(2.dp, if (isMatchFound) TacticalGreen else TacticalAmber, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            if (isMatchFound) Icons.Default.CheckCircle else Icons.Default.Sensors,
            contentDescription = null,
            tint = if (isMatchFound) TacticalGreen else TacticalAmber,
            modifier = Modifier.size(36.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = if (isMatchFound) "MATCH FOUND // ROOM #ISLA-ALPHA-77" else "SEARCHING FOR CONTESTANTS...",
          color = Color.White,
          fontWeight = FontWeight.Black,
          fontSize = 14.sp
        )

        Text(
          text = "MODE: ${mode.displayName.uppercase()} // MAP: ISLA PERDIDA",
          color = TextSecondary,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Players progress bar
        LinearProgressIndicator(
          progress = { playersFound / 24f },
          modifier = Modifier.fillMaxWidth().height(6.dp),
          color = if (isMatchFound) TacticalGreen else TacticalAmber,
          trackColor = SlateBorder
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Players: $playersFound / 24", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          if (isMatchFound) {
            Text("Launching in ${countdown}s...", color = TacticalGreen, fontSize = 10.sp, fontWeight = FontWeight.Black)
          } else {
            Text("Estimating wait: < 3s", color = TextMuted, fontSize = 10.sp)
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = onCancel,
            border = BorderStroke(1.dp, SlateBorder),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
            modifier = Modifier.weight(1f)
          ) {
            Text("CANCEL SEARCH", fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onLaunchMatch,
            colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
            modifier = Modifier.weight(1f)
          ) {
            Text("DEPLOY NOW", fontSize = 11.sp, fontWeight = FontWeight.Black)
          }
        }
      }
    }
  }
}
