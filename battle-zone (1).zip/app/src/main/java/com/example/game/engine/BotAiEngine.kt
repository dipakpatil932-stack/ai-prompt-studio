package com.example.game.engine

import androidx.compose.ui.geometry.Offset
import com.example.game.audio.GameSoundEngine
import com.example.game.model.*
import kotlin.math.*
import kotlin.random.Random

class BotAiEngine {

  var difficulty: BotDifficulty = BotDifficulty.NORMAL

  fun updateBots(
    dt: Float,
    bots: List<BotEntity>,
    player: PlayerState,
    safeZone: SafeZoneState,
    lootItems: MutableList<LootItem>,
    vehicles: List<VehicleInstance> = emptyList(),
    tracers: MutableList<BulletTracer>,
    particles: MutableList<CombatParticle>,
    killFeed: MutableList<KillFeedEntry>
  ) {
    val livingBots = bots.filter { it.isAlive }

    for (bot in livingBots) {
      // 1. Zone check: Is bot outside safe zone?
      val distToZoneCenter = hypot(bot.posX - safeZone.currentCenterX, bot.posY - safeZone.currentCenterY)
      if (distToZoneCenter > safeZone.currentRadius) {
        // Outside safe zone -> take ring tick damage
        bot.health -= safeZone.dpsOutside * dt
        if (bot.health <= 0f) {
          bot.isAlive = false
          bot.health = 0f
          killFeed.add(KillFeedEntry("Zone Boundary", bot.name, "Energy Ring", false))
          continue
        }
        // Force state to rush toward safe zone
        bot.state = BotBehaviorState.RUSHING_ZONE
        bot.targetX = safeZone.targetCenterX + (Random.nextFloat() * 100f - 50f)
        bot.targetY = safeZone.targetCenterY + (Random.nextFloat() * 100f - 50f)
      }

      // 2. Cooldown tickers
      if (bot.reloadTimer > 0f) {
        bot.reloadTimer -= dt
        if (bot.reloadTimer <= 0f) {
          bot.ammoInMag = bot.activeWeapon.magCapacity
        }
      }
      if (bot.attackCooldown > 0f) {
        bot.attackCooldown -= dt
      }

      // 3. Perception: Player detection adjusted for difficulty
      val distToPlayer = hypot(player.posX - bot.posX, player.posY - bot.posY)
      val detectionRange = when (difficulty) {
        BotDifficulty.EASY -> 180f
        BotDifficulty.NORMAL -> 240f
        BotDifficulty.HARD -> 320f
      }
      val playerInSight = distToPlayer < detectionRange && player.isAlive

      // 4. Decision State Machine
      when (bot.state) {
        BotBehaviorState.RUSHING_ZONE -> {
          // Check for nearby vehicle to board if far away
          if (distToZoneCenter > 350f) {
            val nearVeh = vehicles.firstOrNull { !it.isOccupied && hypot(it.posX - bot.posX, it.posY - bot.posY) < 60f }
            if (nearVeh != null) {
              moveBotTowards(bot, nearVeh.posX, nearVeh.posY, speed = 50f, dt = dt)
              if (hypot(nearVeh.posX - bot.posX, nearVeh.posY - bot.posY) < 15f) {
                // Board and propel vehicle towards zone center
                nearVeh.isOccupied = true
                nearVeh.currentSpeed = 80f
                bot.posX = nearVeh.posX
                bot.posY = nearVeh.posY
              }
            } else {
              moveBotTowards(bot, bot.targetX, bot.targetY, speed = 46f, dt = dt)
            }
          } else {
            moveBotTowards(bot, bot.targetX, bot.targetY, speed = 42f, dt = dt)
          }

          if (playerInSight && distToPlayer < 120f) {
            bot.state = BotBehaviorState.ENGAGING_ENEMY
          }
        }

        BotBehaviorState.PATROL -> {
          if (playerInSight) {
            bot.state = BotBehaviorState.ENGAGING_ENEMY
          } else if (distToZoneCenter > safeZone.currentRadius * 0.85f) {
            bot.state = BotBehaviorState.RUSHING_ZONE
            bot.targetX = safeZone.targetCenterX
            bot.targetY = safeZone.targetCenterY
          } else {
            // Intelligent Loot Search: Find nearby rare/epic ground loot within 60 units
            val nearbyLoot = lootItems.firstOrNull {
              hypot(it.posX - bot.posX, it.posY - bot.posY) < 60f &&
              (it.type == LootType.WEAPON || it.type == LootType.ARMOR_VEST || it.type == LootType.HEALTH_KIT)
            }

            if (nearbyLoot != null && Random.nextFloat() < 0.25f) {
              bot.state = BotBehaviorState.LOOTING
              bot.targetX = nearbyLoot.posX
              bot.targetY = nearbyLoot.posY
            } else {
              // Pick a random waypoint if near target
              val distToTgt = hypot(bot.posX - bot.targetX, bot.posY - bot.targetY)
              if (distToTgt < 25f || bot.targetX == 0f) {
                val angle = Random.nextFloat() * (Math.PI.toFloat() * 2f)
                val dist = Random.nextFloat() * 150f + 50f
                bot.targetX = (bot.posX + cos(angle) * dist).coerceIn(150f, TacticalIslandMap.WORLD_SIZE - 150f)
                bot.targetY = (bot.posY + sin(angle) * dist).coerceIn(150f, TacticalIslandMap.WORLD_SIZE - 150f)
              }
              moveBotTowards(bot, bot.targetX, bot.targetY, speed = 26f, dt = dt)
            }
          }
        }

        BotBehaviorState.LOOTING -> {
          moveBotTowards(bot, bot.targetX, bot.targetY, speed = 36f, dt = dt)
          val distToLoot = hypot(bot.posX - bot.targetX, bot.posY - bot.targetY)
          if (distToLoot < 12f) {
            // Pickup loot item
            val item = lootItems.firstOrNull { hypot(it.posX - bot.posX, it.posY - bot.posY) < 16f }
            if (item != null) {
              if (item.type == LootType.WEAPON && item.weaponRef != null) {
                bot.activeWeapon = item.weaponRef
                bot.ammoInMag = item.weaponRef.magCapacity
              } else if (item.type == LootType.ARMOR_VEST) {
                bot.armor = 100f
              } else if (item.type == LootType.HEALTH_KIT) {
                bot.health = (bot.health + 40f).coerceAtMost(100f)
              }
              lootItems.remove(item)
            }
            bot.state = BotBehaviorState.PATROL
          } else if (playerInSight) {
            bot.state = BotBehaviorState.ENGAGING_ENEMY
          }
        }

        BotBehaviorState.TAKING_COVER -> {
          // Find nearest cover obstacle
          val nearestCover = TacticalIslandMap.COVER_OBJECTS.minByOrNull { hypot(it.x - bot.posX, it.y - bot.posY) }
          if (nearestCover != null) {
            moveBotTowards(bot, nearestCover.x, nearestCover.y, speed = 40f, dt = dt)
            val distToCover = hypot(bot.posX - nearestCover.x, bot.posY - nearestCover.y)
            if (distToCover < 15f) {
              bot.state = BotBehaviorState.HEALING
            }
          } else {
            bot.state = BotBehaviorState.HEALING
          }
        }

        BotBehaviorState.ENGAGING_ENEMY -> {
          if (!playerInSight) {
            bot.state = BotBehaviorState.PATROL
          } else {
            // Face the player
            val targetAngle = Math.toDegrees(atan2((player.posY - bot.posY).toDouble(), (player.posX - bot.posX).toDouble())).toFloat()
            bot.rotationDeg = targetAngle

            // Tactical strafe / approach with difficulty speed modifier
            val baseSpeed = when (difficulty) {
              BotDifficulty.EASY -> 22f
              BotDifficulty.NORMAL -> 30f
              BotDifficulty.HARD -> 42f
            }

            if (distToPlayer > 75f) {
              moveBotTowards(bot, player.posX, player.posY, speed = baseSpeed, dt = dt)
            } else if (distToPlayer < 30f) {
              // Back up / tactical reposition
              moveBotTowards(bot, bot.posX - cos(Math.toRadians(targetAngle.toDouble())).toFloat() * 20f,
                             bot.posY - sin(Math.toRadians(targetAngle.toDouble())).toFloat() * 20f, speed = baseSpeed * 0.8f, dt = dt)
            }

            // Attack if ready
            if (bot.attackCooldown <= 0f && bot.reloadTimer <= 0f) {
              if (bot.ammoInMag > 0) {
                bot.ammoInMag -= 1
                val reactionFactor = difficulty.reactionTimeSec
                bot.attackCooldown = (1f / bot.activeWeapon.fireRateRps) * reactionFactor.coerceAtLeast(0.8f)
                val hit = CombatEngine.fireBotAtPlayer(bot, player, tracers, particles)
                GameSoundEngine.playGunshot(bot.activeWeapon.category.name)
              } else {
                bot.reloadTimer = bot.activeWeapon.reloadTimeSec
                // Intelligent secondary weapon switch if available
                if (bot.activeWeapon.category == WeaponCategory.SNIPER || bot.activeWeapon.category == WeaponCategory.SHOTGUN) {
                  bot.activeWeapon = WeaponCatalog.P9_SPECTRE
                  bot.ammoInMag = WeaponCatalog.P9_SPECTRE.magCapacity
                }
              }
            }

            // Low health retreat to cover or heal
            if (bot.health < 35f && Random.nextFloat() < 0.12f) {
              bot.state = BotBehaviorState.TAKING_COVER
            }
          }
        }

        BotBehaviorState.HEALING -> {
          // Heal over time
          bot.health = (bot.health + 30f * dt).coerceAtMost(100f)
          if (bot.health >= 85f || (playerInSight && distToPlayer < 50f)) {
            bot.state = if (playerInSight) BotBehaviorState.ENGAGING_ENEMY else BotBehaviorState.PATROL
          }
        }
      }
    }

    // Bot vs Bot ambient skirmishes across the island (keeps match dynamic)
    if (livingBots.size > 3 && Random.nextFloat() < 0.018f) {
      val b1 = livingBots.random()
      val b2 = livingBots.filter { it.id != b1.id }.randomOrNull()
      if (b2 != null) {
        val distBetween = hypot(b1.posX - b2.posX, b1.posY - b2.posY)
        if (distBetween < 250f) {
          b2.health -= Random.nextFloat() * 45f + 15f
          if (b2.health <= 0f) {
            b2.isAlive = false
            b2.health = 0f
            killFeed.add(KillFeedEntry(b1.name, b2.name, b1.activeWeapon.name, false))
          }
        }
      }
    }
  }

  private fun moveBotTowards(bot: BotEntity, targetX: Float, targetY: Float, speed: Float, dt: Float) {
    val dx = targetX - bot.posX
    val dy = targetY - bot.posY
    val dist = hypot(dx, dy)
    if (dist > 1.5f) {
      val dirX = dx / dist
      val dirY = dy / dist
      val nextX = bot.posX + dirX * speed * dt
      val nextY = bot.posY + dirY * speed * dt

      if (!TacticalIslandMap.checkCollision(nextX, nextY, 15f)) {
        bot.posX = nextX
        bot.posY = nextY
      }
      bot.rotationDeg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    }
  }
}
