package com.example.game.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.audio.GameSoundEngine
import com.example.game.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

data class PracticeTarget(
  val id: Int,
  val distanceMeters: Int,
  var posX: Float,
  var speed: Float,
  var isHit: Boolean = false,
  var hitMessage: String = ""
)

@Composable
fun TrainingGroundScreen(
  onBackToMenu: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedWeapon by remember { mutableStateOf(WeaponCatalog.VX9_TEMPEST) }
  var currentAmmo by remember { mutableStateOf(selectedWeapon.magCapacity) }
  var totalScore by remember { mutableStateOf(0) }
  var targetList by remember {
    mutableStateOf(
      listOf(
        PracticeTarget(1, 25, 0.3f, 0.4f),
        PracticeTarget(2, 50, 0.6f, -0.6f),
        PracticeTarget(3, 100, 0.5f, 0.8f)
      )
    )
  }
  var lastHitFeedback by remember { mutableStateOf("READY ON FIRING LINE") }

  // Target animation loop
  LaunchedEffect(Unit) {
    while (true) {
      delay(30)
      targetList = targetList.map { tgt ->
        var nextX = tgt.posX + (tgt.speed * 0.012f)
        var nextSpeed = tgt.speed
        if (nextX > 0.85f || nextX < 0.15f) {
          nextSpeed = -nextSpeed
          nextX = nextX.coerceIn(0.15f, 0.85f)
        }
        tgt.copy(posX = nextX, speed = nextSpeed)
      }
    }
  }

  fun fireAtTarget() {
    if (currentAmmo <= 0) {
      currentAmmo = selectedWeapon.magCapacity
      GameSoundEngine.playReload()
      return
    }
    currentAmmo -= 1
    GameSoundEngine.playGunshot(selectedWeapon.category.name)

    // Simulate ballistics hit against target
    val target = targetList.random()
    val isHeadshot = Random.nextFloat() < 0.35f
    val hitScore = if (isHeadshot) 100 else 50
    totalScore += hitScore
    lastHitFeedback = "${if (isHeadshot) "HEADSHOT!" else "BODY HIT"} (${target.distanceMeters}M) +$hitScore PTS"
    GameSoundEngine.playHitmarker(isHeadshot)
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(CarbonDark)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {

      // Top Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(SlateNavy)
          .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onBackToMenu, modifier = Modifier.testTag("training_back_button")) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text("TACTICAL TRAINING GROUNDS // OFFLINE FIRING RANGE", color = TacticalAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text("SCORE: ", color = TextSecondary, fontSize = 11.sp)
          Text("$totalScore", color = TacticalCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          Spacer(modifier = Modifier.width(16.dp))
          Text(lastHitFeedback, color = TacticalAmberLight, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
      }

      // Middle Range Visualization
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .background(Color(0xFF141C22))
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Range dirt & perspective lines
          drawLine(Color(0x33FFFFFF), start = Offset(w * 0.1f, h), end = Offset(w * 0.3f, 0f), strokeWidth = 1f)
          drawLine(Color(0x33FFFFFF), start = Offset(w * 0.9f, h), end = Offset(w * 0.7f, 0f), strokeWidth = 1f)

          // Distance berms
          val y25 = h * 0.72f
          val y50 = h * 0.48f
          val y100 = h * 0.24f

          drawLine(Color(0xFF37474F), start = Offset(0f, y25), end = Offset(w, y25), strokeWidth = 2f)
          drawLine(Color(0xFF37474F), start = Offset(0f, y50), end = Offset(w, y50), strokeWidth = 2f)
          drawLine(Color(0xFF37474F), start = Offset(0f, y100), end = Offset(w, y100), strokeWidth = 2f)

          // Draw targets
          targetList.forEach { tgt ->
            val ty = when (tgt.distanceMeters) {
              25 -> y25
              50 -> y50
              else -> y100
            }
            val tx = tgt.posX * w
            val scale = when (tgt.distanceMeters) {
              25 -> 1.0f
              50 -> 0.75f
              else -> 0.5f
            }

            // Target silhouette
            drawRect(Color(0xFFFFB300), topLeft = Offset(tx - 14f * scale, ty - 40f * scale), size = androidx.compose.ui.geometry.Size(28f * scale, 40f * scale))
            drawCircle(Color(0xFFFF334B), radius = 6f * scale, center = Offset(tx, ty - 20f * scale))
            drawCircle(Color.White, radius = 2.5f * scale, center = Offset(tx, ty - 20f * scale))
          }

          // Center Crosshair reticle
          drawCircle(Color(0xAA00E5FF), radius = 18f, center = Offset(w / 2f, h * 0.55f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
          drawLine(Color(0xAA00E5FF), start = Offset(w / 2f - 26f, h * 0.55f), end = Offset(w / 2f + 26f, h * 0.55f), strokeWidth = 1.5f)
          drawLine(Color(0xAA00E5FF), start = Offset(w / 2f, h * 0.55f - 26f), end = Offset(w / 2f, h * 0.55f + 26f), strokeWidth = 1.5f)
        }

        // Action Fire Button
        Box(
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(24.dp)
            .size(72.dp)
            .clip(CircleShape)
            .background(TacticalRed)
            .border(2.dp, Color.White, CircleShape)
            .clickable { fireAtTarget() }
            .testTag("training_fire_button"),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.GpsFixed, contentDescription = "Fire", tint = Color.White, modifier = Modifier.size(30.dp))
            Text("FIRE ($currentAmmo)", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      // Bottom Weapon Rack Selector
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(SlateNavy)
          .padding(horizontal = 16.dp, vertical = 10.dp)
      ) {
        Text("ARSENAL WEAPON TESTING RACK", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(WeaponCatalog.ALL_WEAPONS) { wp ->
            val isSel = wp.id == selectedWeapon.id
            Surface(
              color = if (isSel) SlateSurface else Color(0xFF141C26),
              shape = RoundedCornerShape(6.dp),
              border = BorderStroke(if (isSel) 1.5.dp else 1.dp, if (isSel) TacticalAmber else SlateBorder),
              modifier = Modifier
                .width(130.dp)
                .clickable {
                  selectedWeapon = wp
                  currentAmmo = wp.magCapacity
                  GameSoundEngine.playUiTap()
                }
            ) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text(wp.name, color = if (isSel) TacticalAmberLight else Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text(wp.category.displayName, color = TextMuted, fontSize = 9.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("DMG: ${wp.baseDamage.toInt()}", color = TacticalGreen, fontSize = 8.sp)
                  Text("RPM: ${(wp.fireRateRps * 60).toInt()}", color = TacticalCyan, fontSize = 8.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}
