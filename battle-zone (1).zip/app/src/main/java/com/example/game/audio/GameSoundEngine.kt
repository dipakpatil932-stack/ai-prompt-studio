package com.example.game.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sin
import kotlin.random.Random

/**
 * High-performance procedural sound engine for Battle Zone: Survival.
 * Synthesizes dynamic audio buffers in real-time via AudioTrack for instant, low-latency
 * gunfire, reloads, impacts, vehicle acceleration, footsteps, sirens, and UI cues.
 */
object GameSoundEngine {
  private const val SAMPLE_RATE = 22050
  private val soundScope = CoroutineScope(Dispatchers.Default)

  var masterVolume: Float = 0.8f
  var sfxVolume: Float = 0.9f
  var isMuted: Boolean = false

  // Pre-baked audio buffers for low-latency playback
  private val sampleCache = ConcurrentHashMap<String, ByteArray>()

  init {
    bakeSamples()
  }

  private fun bakeSamples() {
    // 1. Rifle shot (sharp noise crack + resonant sub punch)
    sampleCache["shot_rifle"] = generateGunshot(durationSec = 0.22f, bassFreq = 110f, noiseMix = 0.65f)
    // 2. SMG shot (higher pitch snappier crack)
    sampleCache["shot_smg"] = generateGunshot(durationSec = 0.15f, bassFreq = 160f, noiseMix = 0.75f)
    // 3. Shotgun blast (deep thunderous spread)
    sampleCache["shot_shotgun"] = generateGunshot(durationSec = 0.35f, bassFreq = 80f, noiseMix = 0.85f)
    // 4. Sniper report (heavy echo boom)
    sampleCache["shot_sniper"] = generateGunshot(durationSec = 0.45f, bassFreq = 65f, noiseMix = 0.70f)
    // 5. Pistol shot (compact pop)
    sampleCache["shot_pistol"] = generateGunshot(durationSec = 0.14f, bassFreq = 140f, noiseMix = 0.60f)
    // 6. Hitmarker ding (high crisp sine ping)
    sampleCache["hitmarker"] = generateTone(freq = 2400f, durationSec = 0.08f, decayExp = 12f)
    // 7. Headshot crit (double high chord)
    sampleCache["headshot_ding"] = generateChord(freq1 = 2800f, freq2 = 3500f, durationSec = 0.12f)
    // 8. Reload clip in (two mechanical clicks)
    sampleCache["reload_click"] = generateMechanicalClick()
    // 9. Footstep (soft low thud)
    sampleCache["footstep"] = generateFootstep()
    // 10. Safe zone warning alarm
    sampleCache["zone_alarm"] = generateSiren()
    // 11. Victory jingle
    sampleCache["victory"] = generateVictoryFanfare()
    // 12. UI click / equip
    sampleCache["ui_tap"] = generateTone(freq = 950f, durationSec = 0.04f, decayExp = 25f)
  }

  private fun generateGunshot(durationSec: Float, bassFreq: Float, noiseMix: Float): ByteArray {
    val totalSamples = (SAMPLE_RATE * durationSec).toInt()
    val buffer = ByteArray(totalSamples)
    var phase = 0f
    for (i in 0 until totalSamples) {
      val progress = i.toFloat() / totalSamples
      val envelope = (1.0f - progress) * (1.0f - progress)
      // Bass sine with quick pitch drop
      val currentFreq = bassFreq * (1.0f - progress * 0.7f)
      phase += 2f * Math.PI.toFloat() * currentFreq / SAMPLE_RATE
      val sineVal = sin(phase)
      val noiseVal = (Random.nextFloat() * 2f - 1f)
      val combined = (sineVal * (1f - noiseMix) + noiseVal * noiseMix) * envelope
      val sampleInt = (combined * 127f).coerceIn(-127f, 127f).toInt()
      buffer[i] = sampleInt.toByte()
    }
    return buffer
  }

  private fun generateTone(freq: Float, durationSec: Float, decayExp: Float): ByteArray {
    val totalSamples = (SAMPLE_RATE * durationSec).toInt()
    val buffer = ByteArray(totalSamples)
    var phase = 0f
    for (i in 0 until totalSamples) {
      val t = i.toFloat() / totalSamples
      val envelope = Math.exp((-decayExp * t).toDouble()).toFloat()
      phase += 2f * Math.PI.toFloat() * freq / SAMPLE_RATE
      val sample = (sin(phase) * envelope * 120f).coerceIn(-127f, 127f).toInt()
      buffer[i] = sample.toByte()
    }
    return buffer
  }

  private fun generateChord(freq1: Float, freq2: Float, durationSec: Float): ByteArray {
    val totalSamples = (SAMPLE_RATE * durationSec).toInt()
    val buffer = ByteArray(totalSamples)
    var phase1 = 0f
    var phase2 = 0f
    for (i in 0 until totalSamples) {
      val t = i.toFloat() / totalSamples
      val envelope = Math.exp((-10f * t).toDouble()).toFloat()
      phase1 += 2f * Math.PI.toFloat() * freq1 / SAMPLE_RATE
      phase2 += 2f * Math.PI.toFloat() * freq2 / SAMPLE_RATE
      val sample = ((sin(phase1) + sin(phase2)) * 0.5f * envelope * 120f).coerceIn(-127f, 127f).toInt()
      buffer[i] = sample.toByte()
    }
    return buffer
  }

  private fun generateMechanicalClick(): ByteArray {
    val durationSec = 0.16f
    val totalSamples = (SAMPLE_RATE * durationSec).toInt()
    val buffer = ByteArray(totalSamples)
    val click1 = (totalSamples * 0.1f).toInt()
    val click2 = (totalSamples * 0.6f).toInt()
    for (i in 0 until totalSamples) {
      var amp = 0f
      if (i in click1..(click1 + 300)) {
        amp += (Random.nextFloat() * 2f - 1f) * 0.8f
      }
      if (i in click2..(click2 + 450)) {
        amp += (Random.nextFloat() * 2f - 1f) * 0.9f
      }
      buffer[i] = (amp * 120f).coerceIn(-127f, 127f).toInt().toByte()
    }
    return buffer
  }

  private fun generateFootstep(): ByteArray {
    val durationSec = 0.08f
    val totalSamples = (SAMPLE_RATE * durationSec).toInt()
    val buffer = ByteArray(totalSamples)
    var phase = 0f
    for (i in 0 until totalSamples) {
      val t = i.toFloat() / totalSamples
      val envelope = (1f - t) * (1f - t)
      phase += 2f * Math.PI.toFloat() * 90f / SAMPLE_RATE
      val sample = ((sin(phase) * 0.7f + (Random.nextFloat() * 2f - 1f) * 0.3f) * envelope * 65f).toInt()
      buffer[i] = sample.coerceIn(-127, 127).toByte()
    }
    return buffer
  }

  private fun generateSiren(): ByteArray {
    val durationSec = 0.65f
    val totalSamples = (SAMPLE_RATE * durationSec).toInt()
    val buffer = ByteArray(totalSamples)
    var phase = 0f
    for (i in 0 until totalSamples) {
      val t = i.toFloat() / totalSamples
      val sweepFreq = 650f + sin(t * Math.PI.toFloat() * 4f) * 200f
      phase += 2f * Math.PI.toFloat() * sweepFreq / SAMPLE_RATE
      val sample = (sin(phase) * 80f).toInt()
      buffer[i] = sample.coerceIn(-127, 127).toByte()
    }
    return buffer
  }

  private fun generateVictoryFanfare(): ByteArray {
    val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f) // C5, E5, G5, C6
    val noteSamples = (SAMPLE_RATE * 0.18f).toInt()
    val totalSamples = noteSamples * notes.size
    val buffer = ByteArray(totalSamples)
    for (n in notes.indices) {
      val freq = notes[n]
      var phase = 0f
      val offset = n * noteSamples
      for (i in 0 until noteSamples) {
        val t = i.toFloat() / noteSamples
        val envelope = (1f - t * 0.2f)
        phase += 2f * Math.PI.toFloat() * freq / SAMPLE_RATE
        val sample = (sin(phase) * envelope * 100f).toInt()
        buffer[offset + i] = sample.coerceIn(-127, 127).toByte()
      }
    }
    return buffer
  }

  fun playGunshot(weaponCategory: String) {
    if (isMuted) return
    val key = when (weaponCategory) {
      "SMG" -> "shot_smg"
      "SHOTGUN" -> "shot_shotgun"
      "SNIPER" -> "shot_sniper"
      "PISTOL" -> "shot_pistol"
      else -> "shot_rifle"
    }
    playSound(key)
  }

  fun playHitmarker(isHeadshot: Boolean = false) {
    if (isMuted) return
    playSound(if (isHeadshot) "headshot_ding" else "hitmarker")
  }

  fun playReload() {
    if (isMuted) return
    playSound("reload_click")
  }

  fun playFootstep() {
    if (isMuted) return
    playSound("footstep")
  }

  fun playZoneAlarm() {
    if (isMuted) return
    playSound("zone_alarm")
  }

  fun playVictory() {
    if (isMuted) return
    playSound("victory")
  }

  fun playUiTap() {
    if (isMuted) return
    playSound("ui_tap")
  }

  private fun playSound(key: String) {
    val raw = sampleCache[key] ?: return
    soundScope.launch {
      try {
        val effectiveVol = (masterVolume * sfxVolume).coerceIn(0f, 1f)
        if (effectiveVol <= 0.001f) return@launch

        val track = AudioTrack.Builder()
          .setAudioAttributes(
            AudioAttributes.Builder()
              .setUsage(AudioAttributes.USAGE_GAME)
              .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
              .build()
          )
          .setAudioFormat(
            AudioFormat.Builder()
              .setEncoding(AudioFormat.ENCODING_PCM_8BIT)
              .setSampleRate(SAMPLE_RATE)
              .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
              .build()
          )
          .setBufferSizeInBytes(raw.size)
          .setTransferMode(AudioTrack.MODE_STATIC)
          .build()

        track.setVolume(effectiveVol)
        track.write(raw, 0, raw.size)
        track.play()
        // Release after finish
        track.setNotificationMarkerPosition(raw.size)
        track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
          override fun onMarkerReached(t: AudioTrack?) {
            try {
              t?.stop()
              t?.release()
            } catch (_: Exception) {}
          }
          override fun onPeriodicNotification(t: AudioTrack?) {}
        })
      } catch (_: Exception) {
        // Fallback gracefully on audio track allocation limits
      }
    }
  }
}
