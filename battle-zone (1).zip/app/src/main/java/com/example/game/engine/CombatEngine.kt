package com.example.game.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.game.audio.GameSoundEngine
import com.example.game.model.*
import kotlin.math.*
import kotlin.random.Random

data class HitResult(
  val didHit: Boolean,
  val isHeadshot: Boolean,
  val damageDealt: Float,
  val hitBotId: String? = null,
  val isElimination: Boolean = false
)

object CombatEngine {

  /**
   * Process a weapon fire event from the player.
   */
  fun firePlayerWeapon(
    player: PlayerState,
    weapon: Weapon,
    bots: List<BotEntity>,
    tracers: MutableList<BulletTracer>,
    particles: MutableList<CombatParticle>,
    damagePopups: MutableList<DamageNumberPopup>? = null
  ): HitResult {
    // Calculate spread based on stance and aiming
    var spreadFactor = weapon.accuracySpread
    if (player.isAimingDownSights) spreadFactor *= 0.35f
    when (player.stance) {
      PlayerStance.CROUCH -> spreadFactor *= 0.65f
      PlayerStance.PRONE -> spreadFactor *= 0.35f
      else -> {}
    }

    val angleSpread = (Random.nextFloat() * 2f - 1f) * spreadFactor
    val firingAngleRad = Math.toRadians((player.rotationDeg + angleSpread).toDouble())

    val originX = player.posX
    val originY = player.posY
    val maxDist = weapon.rangeMeters

    var closestHitDist = maxDist
    var hitBot: BotEntity? = null
    var isHeadshot = false

    val dirX = cos(firingAngleRad).toFloat()
    val dirY = sin(firingAngleRad).toFloat()

    // Raycast against living bots
    for (bot in bots) {
      if (!bot.isAlive) continue

      val toBotX = bot.posX - originX
      val toBotY = bot.posY - originY
      val distAlongRay = toBotX * dirX + toBotY * dirY

      if (distAlongRay in 10f..maxDist) {
        val perpDist = abs(toBotX * dirY - toBotY * dirX)
        val hitRadius = 22f // Bot body collider radius
        if (perpDist <= hitRadius && distAlongRay < closestHitDist) {
          closestHitDist = distAlongRay
          hitBot = bot
          // Random chance for headshot (18% probability or precision sniper)
          isHeadshot = (weapon.category == WeaponCategory.SNIPER) || (Random.nextFloat() < 0.22f)
        }
      }
    }

    // Also check collision with map buildings or obstacles
    var obstacleDist = maxDist
    for (b in TacticalIslandMap.BUILDINGS) {
      val centerDx = b.rect.center.x - originX
      val centerDy = b.rect.center.y - originY
      val distAlong = centerDx * dirX + centerDy * dirY
      if (distAlong in 10f..maxDist) {
        val perp = abs(centerDx * dirY - centerDy * dirX)
        if (perp < b.rect.width / 2f && distAlong < obstacleDist) {
          obstacleDist = distAlong
        }
      }
    }

    val finalHitDist = minOf(closestHitDist, obstacleDist)
    val impactX = originX + dirX * finalHitDist
    val impactY = originY + dirY * finalHitDist

    // Add visual bullet tracer
    tracers.add(
      BulletTracer(
        startX = originX + dirX * 15f,
        startY = originY + dirY * 15f,
        endX = impactX,
        endY = impactY,
        isCritHeadshot = isHeadshot
      )
    )

    // Add impact particles
    spawnImpactSparks(impactX, impactY, particles, if (hitBot != null) Color(0xFFFFB300) else Color(0xFFCFD8DC))

    // Handle bot damage if bot was struck before obstacle
    if (hitBot != null && closestHitDist <= obstacleDist) {
      var rawDamage = weapon.baseDamage
      if (isHeadshot) rawDamage *= 1.85f

      // Apply bot armor absorption
      var appliedDamage = rawDamage
      if (hitBot.armor > 0) {
        val armorAbsorb = rawDamage * 0.5f
        if (hitBot.armor >= armorAbsorb) {
          hitBot.armor -= armorAbsorb
          appliedDamage = rawDamage * 0.5f
        } else {
          val remainingDamage = rawDamage - (hitBot.armor * 2f)
          hitBot.armor = 0f
          appliedDamage = remainingDamage
        }
      }

      hitBot.health -= appliedDamage
      player.damageDealt += appliedDamage
      val eliminated = hitBot.health <= 0f

      if (eliminated) {
        hitBot.isAlive = false
        hitBot.health = 0f
        player.kills += 1
      }

      // Audio feedback
      GameSoundEngine.playHitmarker(isHeadshot)

      // Spawn floating tactical damage indicator
      damagePopups?.add(
        DamageNumberPopup(
          id = System.nanoTime(),
          posX = hitBot.posX + (Random.nextFloat() * 10f - 5f),
          posY = hitBot.posY - 15f,
          damage = appliedDamage.toInt(),
          isHeadshot = isHeadshot
        )
      )

      return HitResult(
        didHit = true,
        isHeadshot = isHeadshot,
        damageDealt = appliedDamage,
        hitBotId = hitBot.id,
        isElimination = eliminated
      )
    }

    return HitResult(didHit = false, isHeadshot = false, damageDealt = 0f)
  }

  /**
   * Process bot firing at player
   */
  fun fireBotAtPlayer(
    bot: BotEntity,
    player: PlayerState,
    tracers: MutableList<BulletTracer>,
    particles: MutableList<CombatParticle>
  ): Boolean {
    val dx = player.posX - bot.posX
    val dy = player.posY - bot.posY
    val dist = hypot(dx, dy)
    if (dist > bot.activeWeapon.rangeMeters) return false

    // Bot accuracy spread based on distance
    val baseAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    val inaccuracy = (Random.nextFloat() * 2f - 1f) * 12f
    val shotAngle = Math.toRadians((baseAngle + inaccuracy).toDouble())

    val dirX = cos(shotAngle).toFloat()
    val dirY = sin(shotAngle).toFloat()

    val impactDist = minOf(dist, bot.activeWeapon.rangeMeters)
    val impactX = bot.posX + dirX * impactDist
    val impactY = bot.posY + dirY * impactDist

    tracers.add(
      BulletTracer(
        startX = bot.posX,
        startY = bot.posY,
        endX = impactX,
        endY = impactY,
        isCritHeadshot = false
      )
    )

    // Check if within player collider
    val hitDist = hypot(impactX - player.posX, impactY - player.posY)
    if (hitDist < 25f) {
      val rawDamage = bot.activeWeapon.baseDamage * 0.65f // Balanced bot damage
      applyDamageToPlayer(player, rawDamage)
      spawnImpactSparks(player.posX, player.posY, particles, Color(0xFFFF334B))
      return true
    }
    return false
  }

  fun applyDamageToPlayer(player: PlayerState, rawDamage: Float) {
    var dmg = rawDamage
    if (player.armor > 0) {
      val absorbRatio = 0.55f
      val absorbed = dmg * absorbRatio
      if (player.armor >= absorbed) {
        player.armor -= absorbed
        dmg *= (1f - absorbRatio)
      } else {
        val excess = absorbed - player.armor
        player.armor = 0f
        dmg = (dmg * (1f - absorbRatio)) + excess
      }
    }
    player.health = (player.health - dmg).coerceAtLeast(0f)
    if (player.health <= 0f) {
      player.isAlive = false
    }
  }

  private fun spawnImpactSparks(
    x: Float,
    y: Float,
    particles: MutableList<CombatParticle>,
    color: Color
  ) {
    for (i in 0..7) {
      val angle = Random.nextFloat() * (Math.PI.toFloat() * 2f)
      val speed = Random.nextFloat() * 45f + 15f
      particles.add(
        CombatParticle(
          x = x,
          y = y,
          velX = cos(angle) * speed,
          velY = sin(angle) * speed,
          color = color,
          life = 1.0f,
          maxLife = 0.35f
        )
      )
    }
  }
}
