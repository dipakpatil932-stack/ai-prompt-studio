package com.example.game.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.audio.GameSoundEngine
import com.example.game.engine.*
import com.example.game.model.*
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun GameHud(
  gameEngine: GameEngine,
  player: PlayerState,
  phase: MatchPhase,
  safeZone: SafeZoneState,
  aliveCount: Int,
  killFeed: List<KillFeedEntry>,
  nearbyLoot: List<LootItem>,
  nearbyVehicle: VehicleInstance?,
  squad: List<SquadTeammate>,
  onReturnToLobby: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showFullMapDialog by remember { mutableStateOf(false) }
  var showInventoryDialog by remember { mutableStateOf(false) }

  Box(modifier = modifier.fillMaxSize()) {

    // 1. TOP STATUS BAR (Alive, Kills, Compass, Zone Timer)
    TopStatusBar(
      player = player,
      phase = phase,
      aliveCount = aliveCount,
      safeZone = safeZone,
      onOpenMap = { showFullMapDialog = true }
    )

    // 2. KILL FEED (Top Left beneath bar)
    KillFeedWidget(
      killFeed = killFeed,
      modifier = Modifier
        .align(Alignment.TopStart)
        .padding(start = 16.dp, top = 62.dp)
    )

    // 3. SQUAD HUD (Top Left, under Kill Feed)
    if (squad.isNotEmpty()) {
      SquadListWidget(
        squad = squad,
        modifier = Modifier
          .align(Alignment.TopStart)
          .padding(start = 16.dp, top = 140.dp)
      )
    }

    // 4. DROPSHIP / PARACHUTE PROMPT OVERLAY
    if (phase == MatchPhase.DROPSHIP_FLIGHT) {
      DropshipOverlay(
        onJump = { gameEngine.executeJumpFromPlane() },
        modifier = Modifier.align(Alignment.Center)
      )
    } else if (phase == MatchPhase.PARACHUTING) {
      ParachutingOverlay(
        altitude = player.posZ,
        modifier = Modifier.align(Alignment.Center)
      )
    }

    // 5. IN-GAME CONTROLS (Only during combat or lobby)
    if (phase == MatchPhase.GROUND_COMBAT || phase == MatchPhase.LOBBY) {
      // Aim Drag Pad covering right half of screen
      Box(
        modifier = Modifier
          .fillMaxHeight()
          .fillMaxWidth(0.65f)
          .align(Alignment.CenterEnd)
          .pointerInput(Unit) {
            detectDragGestures { change, dragAmount ->
              change.consume()
              val sens = if (player.isAimingDownSights) 0.15f else 0.28f
              gameEngine.updateCamera(dragAmount.x * sens, dragAmount.y * sens)
            }
          }
      )

      // Left Movement Analog Stick & Stances
      MovementControls(
        gameEngine = gameEngine,
        stance = player.stance,
        isVehicleDriving = player.currentVehicle != null,
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(start = 24.dp, bottom = 24.dp)
      )

      // Center Status: Health, Armor, Weapon Slots, Reload, Backpack
      CenterStatusWidget(
        player = player,
        activeWeapon = gameEngine.getActiveWeapon(),
        onSwitchSlot = { gameEngine.switchWeaponSlot(it) },
        onReload = { gameEngine.startReload() },
        onHeal = { gameEngine.startHealing() },
        onEnergyDrink = { gameEngine.useEnergyDrink() },
        onOpenInventory = { showInventoryDialog = true },
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .padding(bottom = 12.dp)
      )

      // Right Action Buttons (Fire, ADS, Jump, Interact, Revive, Vehicle controls)
      ActionControls(
        gameEngine = gameEngine,
        player = player,
        nearbyLoot = nearbyLoot,
        nearbyVehicle = nearbyVehicle,
        squad = squad,
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(end = 24.dp, bottom = 24.dp)
      )
    }

    // 6. FULLSCREEN TACTICAL MAP DIALOG
    if (showFullMapDialog) {
      FullscreenTacticalMap(
        player = player,
        safeZone = safeZone,
        squad = squad,
        gameEngine = gameEngine,
        onClose = { showFullMapDialog = false }
      )
    }

    // 7. BACKPACK INVENTORY DIALOG
    if (showInventoryDialog) {
      BackpackInventoryModal(
        player = player,
        gameEngine = gameEngine,
        onClose = { showInventoryDialog = false }
      )
    }

    // 7. LOBBY COUNTDOWN BANNER
    if (phase == MatchPhase.LOBBY) {
      Surface(
        color = Color(0xCC000000),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(top = 70.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = TacticalAmber, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("PRE-MATCH LOBBY: DEPLOYING IN AIR DROP", color = TacticalAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
      }
    }

    // 8. VICTORY / DEFEAT BANNER OVERLAY
    if (phase == MatchPhase.VICTORY || phase == MatchPhase.DEFEATED) {
      val isVictory = phase == MatchPhase.VICTORY
      Surface(
        color = Color(0xEE0A0E14),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(2.dp, if (isVictory) TacticalAmber else TacticalRed),
        modifier = Modifier
          .align(Alignment.Center)
          .padding(24.dp)
      ) {
        Column(
          modifier = Modifier.padding(horizontal = 32.dp, vertical = 20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = if (isVictory) "#1 / VICTORY ROYALE!" else "ELIMINATED",
            color = if (isVictory) TacticalAmber else TacticalRed,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = if (isVictory) "CHAMPION OF ISLA PERDIDA" else "BETTER LUCK NEXT MATCH",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(14.dp))
          Button(
            onClick = onReturnToLobby,
            colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("return_to_lobby_button")
          ) {
            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("RETURN TO LOBBY", fontWeight = FontWeight.Bold, fontSize = 11.sp)
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TOP STATUS BAR & COMPASS
// -------------------------------------------------------------

@Composable
fun TopStatusBar(
  player: PlayerState,
  phase: MatchPhase,
  aliveCount: Int,
  safeZone: SafeZoneState,
  onOpenMap: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(
        Brush.verticalGradient(
          colors = listOf(Color(0xEE0A0E14), Color(0x990A0E14), Color.Transparent)
        )
      )
      .padding(horizontal = 16.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // Alive & Kills
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier
        .background(Color(0x88121924), RoundedCornerShape(6.dp))
        .border(1.dp, SlateBorder, RoundedCornerShape(6.dp))
        .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
      Icon(Icons.Default.People, contentDescription = "Alive", tint = TacticalCyan, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(4.dp))
      Text("ALIVE: ", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
      Text("$aliveCount", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)

      Spacer(modifier = Modifier.width(12.dp))
      Icon(Icons.Default.SportsMartialArts, contentDescription = "Eliminations", tint = TacticalRed, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(4.dp))
      Text("KILLS: ", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
      Text("${player.kills}", color = TacticalAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }

    // Tactical Compass Ribbon (Bearing 0-360)
    CompassRibbon(
      bearing = player.rotationDeg,
      modifier = Modifier
        .width(240.dp)
        .height(28.dp)
    )

    // Zone timer & Interactive Minimap
    Row(verticalAlignment = Alignment.CenterVertically) {
      val zoneSec = safeZone.secondsUntilShrink.toInt()
      val timerText = if (safeZone.isShrinking) "ZONE SHRINKING!" else "SAFE ZONE: %02d:%02d".format(zoneSec / 60, zoneSec % 60)
      val timerColor = if (safeZone.isShrinking) TacticalRed else TacticalAmber

      Text(
        text = timerText,
        color = timerColor,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        modifier = Modifier.padding(end = 10.dp)
      )

      // Minimap preview icon button
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(Color(0xDD1A2332))
          .border(2.dp, TacticalCyan, CircleShape)
          .clickable { onOpenMap() }
          .testTag("minimap_button"),
        contentAlignment = Alignment.Center
      ) {
        Canvas(modifier = Modifier.size(34.dp)) {
          // Minimap circle
          drawCircle(Color(0xFF2E7D32), radius = size.minDimension / 2f)
          drawCircle(Color(0xFF00E5FF), radius = size.minDimension * 0.4f, style = Stroke(width = 2f))
          // Player dot with orientation pointer
          drawCircle(Color.White, radius = 4f, center = center)
          val rad = Math.toRadians(player.rotationDeg.toDouble())
          drawLine(
            color = Color(0xFFFFB300),
            start = center,
            end = center + Offset(cos(rad).toFloat() * 12f, sin(rad).toFloat() * 12f),
            strokeWidth = 2.5f,
            cap = StrokeCap.Round
          )
        }
      }
    }
  }
}

@Composable
fun CompassRibbon(bearing: Float, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .background(Color(0x66000000), RoundedCornerShape(4.dp))
      .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(4.dp)),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val centerDeg = bearing

      for (d in -60..60 step 15) {
        val deg = (centerDeg + d + 360) % 360
        val x = (w / 2f) + (d / 60f) * (w / 2f)
        val isMajor = deg.toInt() % 90 == 0
        drawLine(
          color = if (isMajor) TacticalAmber else Color(0x88FFFFFF),
          start = Offset(x, h * 0.6f),
          end = Offset(x, h),
          strokeWidth = if (isMajor) 2f else 1f
        )
      }
      // Center reticle
      drawLine(
        color = TacticalCyan,
        start = Offset(w / 2f, 0f),
        end = Offset(w / 2f, h),
        strokeWidth = 2f
      )
    }

    val dirName = when {
      bearing in 338f..360f || bearing in 0f..22f -> "N"
      bearing in 23f..67f -> "NE"
      bearing in 68f..112f -> "E"
      bearing in 113f..157f -> "SE"
      bearing in 158f..202f -> "S"
      bearing in 203f..247f -> "SW"
      bearing in 248f..292f -> "W"
      else -> "NW"
    }
    Text(
      text = "$dirName ${bearing.toInt()}°",
      color = Color.White,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace
    )
  }
}

// -------------------------------------------------------------
// KILL FEED & SQUAD
// -------------------------------------------------------------

@Composable
fun KillFeedWidget(killFeed: List<KillFeedEntry>, modifier: Modifier = Modifier) {
  Column(modifier = modifier.width(220.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
    killFeed.take(3).forEach { entry ->
      Surface(
        color = Color(0xAA0A0E14),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.5.dp, if (entry.isPlayerKiller) TacticalAmber else Color(0x33FFFFFF))
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = entry.killerName,
            color = if (entry.isPlayerKiller) TacticalAmber else Color(0xFF90CAF9),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "[${entry.weaponName}]",
            color = Color(0xFFB0BEC5),
            fontSize = 9.sp
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = entry.victimName,
            color = TacticalRed,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}

@Composable
fun SquadListWidget(squad: List<SquadTeammate>, modifier: Modifier = Modifier) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
    squad.forEach { member ->
      Row(
        modifier = Modifier
          .background(Color(0x9910171E), RoundedCornerShape(4.dp))
          .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .background(if (member.isAlive) TacticalGreen else Color.Gray, CircleShape)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(member.name, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.width(8.dp))
        // Mini health bar
        Box(
          modifier = Modifier
            .width(36.dp)
            .height(4.dp)
            .background(Color(0xFF37474F), RoundedCornerShape(2.dp))
        ) {
          Box(
            modifier = Modifier
              .fillMaxHeight()
              .fillMaxWidth((member.health / 100f).coerceIn(0f, 1f))
              .background(TacticalGreen, RoundedCornerShape(2.dp))
          )
        }
      }
    }
  }
}

// -------------------------------------------------------------
// DROPSHIP & PARACHUTE OVERLAYS
// -------------------------------------------------------------

@Composable
fun DropshipOverlay(onJump: () -> Unit, modifier: Modifier = Modifier) {
  Column(
    modifier = modifier
      .background(Color(0xCC000000), RoundedCornerShape(12.dp))
      .border(2.dp, TacticalAmber, RoundedCornerShape(12.dp))
      .padding(horizontal = 28.dp, vertical = 18.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text("AIR INFILTRATION // ISLA PERDIDA", color = TacticalAmber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Text("Select landing zone and deploy parachute", color = TextSecondary, fontSize = 11.sp)
    Spacer(modifier = Modifier.height(14.dp))
    Button(
      onClick = onJump,
      colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
      modifier = Modifier
        .height(44.dp)
        .testTag("dropship_jump_button")
    ) {
      Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text("JUMP & FREEFALL", fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
  }
}

@Composable
fun ParachutingOverlay(altitude: Float, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .background(Color(0xAA0A0E14), RoundedCornerShape(8.dp))
      .padding(horizontal = 20.dp, vertical = 8.dp)
  ) {
    Text(
      text = "ALTITUDE: ${altitude.toInt()}M // GLIDING TO SURFACE",
      color = TacticalCyan,
      fontWeight = FontWeight.Bold,
      fontSize = 12.sp,
      fontFamily = FontFamily.Monospace
    )
  }
}

// -------------------------------------------------------------
// MOVEMENT CONTROLS (ANALOG JOYSTICK & STANCES)
// -------------------------------------------------------------

@Composable
fun MovementControls(
  gameEngine: GameEngine,
  stance: PlayerStance,
  isVehicleDriving: Boolean,
  modifier: Modifier = Modifier
) {
  var stickOffset by remember { mutableStateOf(Offset.Zero) }

  Row(modifier = modifier, verticalAlignment = Alignment.Bottom) {
    // Virtual Analog Joystick
    Box(
      modifier = Modifier
        .size(120.dp)
        .clip(CircleShape)
        .background(Color(0x44FFFFFF))
        .border(2.dp, Color(0x66FFFFFF), CircleShape)
        .pointerInput(Unit) {
          detectDragGestures(
            onDragEnd = {
              stickOffset = Offset.Zero
              gameEngine.moveStickX = 0f
              gameEngine.moveStickY = 0f
            },
            onDragCancel = {
              stickOffset = Offset.Zero
              gameEngine.moveStickX = 0f
              gameEngine.moveStickY = 0f
            }
          ) { change, dragAmount ->
            change.consume()
            val maxRadius = 45f
            val newOffset = stickOffset + dragAmount
            val dist = hypot(newOffset.x, newOffset.y)
            stickOffset = if (dist > maxRadius) {
              Offset(newOffset.x / dist * maxRadius, newOffset.y / dist * maxRadius)
            } else {
              newOffset
            }
            gameEngine.moveStickX = stickOffset.x / maxRadius
            gameEngine.moveStickY = stickOffset.y / maxRadius
          }
        },
      contentAlignment = Alignment.Center
    ) {
      // Moving knob
      Box(
        modifier = Modifier
          .offset(x = stickOffset.x.dp, y = stickOffset.y.dp)
          .size(46.dp)
          .clip(CircleShape)
          .background(Color(0xCCFFB300))
          .border(2.dp, Color.White, CircleShape)
      )
    }

    Spacer(modifier = Modifier.width(14.dp))

    // Stance Buttons (Sprint, Crouch, Prone)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      // Sprint / Run Button
      IconButton(
        onClick = { gameEngine.toggleSprint() },
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(if (gameEngine.isSprintLocked) TacticalAmber else Color(0x661A2332))
          .border(1.5.dp, if (gameEngine.isSprintLocked) TacticalAmber else Color(0x88FFFFFF), CircleShape)
          .testTag("sprint_button")
      ) {
        Icon(
          Icons.AutoMirrored.Filled.DirectionsRun,
          contentDescription = "Sprint",
          tint = if (gameEngine.isSprintLocked) Color.Black else Color.White,
          modifier = Modifier.size(22.dp)
        )
      }

      // Crouch Button
      IconButton(
        onClick = { gameEngine.toggleStance(PlayerStance.CROUCH) },
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(if (stance == PlayerStance.CROUCH) TacticalAmber else Color(0x661A2332))
          .border(1.5.dp, Color(0x88FFFFFF), CircleShape)
          .testTag("crouch_button")
      ) {
        Icon(
          Icons.Default.AccessibilityNew,
          contentDescription = "Crouch",
          tint = if (stance == PlayerStance.CROUCH) Color.Black else Color.White,
          modifier = Modifier.size(20.dp)
        )
      }

      // Prone Button
      IconButton(
        onClick = { gameEngine.toggleStance(PlayerStance.PRONE) },
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(if (stance == PlayerStance.PRONE) TacticalAmber else Color(0x661A2332))
          .border(1.5.dp, Color(0x88FFFFFF), CircleShape)
          .testTag("prone_button")
      ) {
        Icon(
          Icons.Default.AirlineSeatFlat,
          contentDescription = "Prone",
          tint = if (stance == PlayerStance.PRONE) Color.Black else Color.White,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

// -------------------------------------------------------------
// CENTER STATUS (HEALTH, ARMOR, WEAPONS, HEAL)
// -------------------------------------------------------------

@Composable
fun CenterStatusWidget(
  player: PlayerState,
  activeWeapon: Weapon?,
  onSwitchSlot: (Int) -> Unit,
  onReload: () -> Unit,
  onHeal: () -> Unit,
  onEnergyDrink: () -> Unit,
  onOpenInventory: () -> Unit,
  modifier: Modifier = Modifier
) {
  fun getReserve(w: Weapon?): Int {
    if (w == null) return 0
    return when {
      w.ammoType.caliber.contains("45") -> player.reserve45Ammo
      w.ammoType.caliber.contains("12") -> player.reserve12GAmmo
      w.ammoType.caliber.contains("300") -> player.reserve300Ammo
      w.ammoType.caliber.contains("9mm") -> player.reserve9MMAmmo
      else -> player.reserve556Ammo
    }
  }

  Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {

    // Health, Armor, Quick Consumables, and Backpack
    Row(
      modifier = Modifier
        .background(Color(0xDD0A0E14), RoundedCornerShape(8.dp))
        .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
        .padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Quick Heal Medkit Button
      IconButton(
        onClick = onHeal,
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(TacticalGreen.copy(alpha = 0.2f))
          .border(1.dp, TacticalGreen, RoundedCornerShape(6.dp))
          .testTag("heal_button")
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.LocalHospital, contentDescription = "Heal", tint = TacticalGreen, modifier = Modifier.size(16.dp))
          Text("${player.medKitCount}", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
      }

      // Energy Drink Quick Boost Button
      IconButton(
        onClick = onEnergyDrink,
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(TacticalCyan.copy(alpha = 0.2f))
          .border(1.dp, TacticalCyan, RoundedCornerShape(6.dp))
          .testTag("energy_drink_button")
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.LocalDrink, contentDescription = "Drink", tint = TacticalCyan, modifier = Modifier.size(16.dp))
          Text("${player.energyDrinkCount}", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
      }

      Column(modifier = Modifier.width(170.dp)) {
        // Armor bar (Cyan) + Vest/Helmet level badges
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text("AP", color = TacticalCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.width(4.dp))
          Box(
            modifier = Modifier
              .weight(1f)
              .height(5.dp)
              .background(Color(0xFF263238), RoundedCornerShape(2.dp))
          ) {
            Box(
              modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth((player.armor / player.maxArmor).coerceIn(0f, 1f))
                .background(TacticalCyan, RoundedCornerShape(2.dp))
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text("V${player.vestLevel} H${player.helmetLevel}", color = TacticalCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Health bar (Green)
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text("HP", color = TacticalGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.width(4.dp))
          Box(
            modifier = Modifier
              .weight(1f)
              .height(6.dp)
              .background(Color(0xFF263238), RoundedCornerShape(3.dp))
          ) {
            Box(
              modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth((player.health / player.maxHealth).coerceIn(0f, 1f))
                .background(if (player.health < 30f) TacticalRed else TacticalGreen, RoundedCornerShape(3.dp))
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text("${player.health.toInt()}", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
      }

      // Backpack / Inventory Modal Trigger
      IconButton(
        onClick = onOpenInventory,
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(TacticalAmber.copy(alpha = 0.2f))
          .border(1.dp, TacticalAmber, RoundedCornerShape(6.dp))
          .testTag("backpack_button")
      ) {
        Icon(Icons.Default.ShoppingBag, contentDescription = "Backpack", tint = TacticalAmber, modifier = Modifier.size(18.dp))
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Weapon slots selector
    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      WeaponSlotCard(
        weapon = player.primaryWeapon1,
        slotNumber = 1,
        isSelected = player.activeSlot == 0,
        ammoCount = if (player.activeSlot == 0) player.ammoInMag else player.primaryWeapon1?.magCapacity ?: 0,
        reserveAmmo = getReserve(player.primaryWeapon1),
        onClick = { onSwitchSlot(0) }
      )
      WeaponSlotCard(
        weapon = player.primaryWeapon2,
        slotNumber = 2,
        isSelected = player.activeSlot == 1,
        ammoCount = if (player.activeSlot == 1) player.ammoInMag else player.primaryWeapon2?.magCapacity ?: 0,
        reserveAmmo = getReserve(player.primaryWeapon2),
        onClick = { onSwitchSlot(1) }
      )
      WeaponSlotCard(
        weapon = player.sidearmWeapon,
        slotNumber = 3,
        isSelected = player.activeSlot == 2,
        ammoCount = if (player.activeSlot == 2) player.ammoInMag else player.sidearmWeapon?.magCapacity ?: 0,
        reserveAmmo = getReserve(player.sidearmWeapon),
        onClick = { onSwitchSlot(2) }
      )

      // Reload Button
      IconButton(
        onClick = onReload,
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(Color(0xCC1A2332))
          .border(1.5.dp, TacticalAmber, CircleShape)
          .testTag("reload_button")
      ) {
        Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = TacticalAmber, modifier = Modifier.size(22.dp))
      }
    }
  }
}

@Composable
fun WeaponSlotCard(
  weapon: Weapon?,
  slotNumber: Int,
  isSelected: Boolean,
  ammoCount: Int,
  reserveAmmo: Int = 0,
  onClick: () -> Unit
) {
  val borderColor = if (isSelected) TacticalAmber else SlateBorder
  val bgColor = if (isSelected) Color(0xEE1E2833) else Color(0xAA121924)

  Surface(
    color = bgColor,
    shape = RoundedCornerShape(6.dp),
    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
    modifier = Modifier
      .width(108.dp)
      .height(44.dp)
      .clickable { onClick() }
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 6.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = weapon?.name ?: "Empty Slot",
          color = if (isSelected) TacticalAmberLight else Color.White,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1
        )
        Text(
          text = weapon?.ammoType?.caliber ?: "---",
          color = TextMuted,
          fontSize = 8.sp
        )
      }
      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "$ammoCount",
          color = Color.White,
          fontSize = 12.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
        if (weapon != null) {
          Text(
            text = "/ $reserveAmmo",
            color = TextMuted,
            fontSize = 8.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}

// -------------------------------------------------------------
// RIGHT ACTION BUTTONS (FIRE, ADS, JUMP, INTERACT)
// -------------------------------------------------------------

@Composable
fun ActionControls(
  gameEngine: GameEngine,
  player: PlayerState,
  nearbyLoot: List<LootItem>,
  nearbyVehicle: VehicleInstance?,
  squad: List<SquadTeammate> = emptyList(),
  modifier: Modifier = Modifier
) {
  val hasNearbyLoot = nearbyLoot.isNotEmpty()
  val hasNearbyVehicle = nearbyVehicle != null || player.currentVehicle != null

  Column(modifier = modifier, horizontalAlignment = Alignment.End) {

    // Revive Teammate Button (if close to a knocked squad mate)
    val knockedTeammate = squad.firstOrNull {
      it.isKnockedDown && it.isAlive && hypot(it.posX - player.posX, it.posY - player.posY) < 45f
    }
    if (knockedTeammate != null) {
      Button(
        onClick = { gameEngine.reviveTeammate(knockedTeammate.id) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676), contentColor = Color.Black),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .padding(bottom = 8.dp)
          .height(36.dp)
          .testTag("revive_teammate_button")
      ) {
        Icon(Icons.Default.Healing, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("REVIVE ${knockedTeammate.name.uppercase()}", fontWeight = FontWeight.Black, fontSize = 10.sp)
      }
    }

    // Vehicle Unstuck Reset Button
    if (player.currentVehicle != null) {
      Button(
        onClick = { gameEngine.resetVehicle() },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9100), contentColor = Color.Black),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .padding(bottom = 8.dp)
          .height(34.dp)
          .testTag("reset_vehicle_button")
      ) {
        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("UNSTUCK VEHICLE", fontWeight = FontWeight.Bold, fontSize = 9.sp)
      }
    }

    // Quick Interact Button (Pickup loot or Drive vehicle)
    if (hasNearbyLoot || hasNearbyVehicle) {
      Button(
        onClick = { gameEngine.interactAction() },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (hasNearbyVehicle) TacticalCyan else TacticalAmber,
          contentColor = Color.Black
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .padding(bottom = 12.dp)
          .height(38.dp)
          .testTag("interact_button")
      ) {
        val label = when {
          player.currentVehicle != null -> "EXIT VEHICLE"
          hasNearbyVehicle -> "ENTER ${nearbyVehicle?.type?.displayName}"
          else -> "LOOT: ${nearbyLoot.firstOrNull()?.name}"
        }
        Icon(
          if (hasNearbyVehicle) Icons.Default.DirectionsCar else Icons.Default.GetApp,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, fontWeight = FontWeight.Bold, fontSize = 10.sp)
      }
    }

    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(14.dp)) {

      // Secondary column: Aim ADS & Jump
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Aim Down Sights (ADS)
        IconButton(
          onClick = { gameEngine.toggleAds() },
          modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (player.isAimingDownSights) TacticalCyan else Color(0x661A2332))
            .border(2.dp, TacticalCyan, CircleShape)
            .testTag("ads_button")
        ) {
          Icon(
            Icons.Default.FilterCenterFocus,
            contentDescription = "Aim ADS",
            tint = if (player.isAimingDownSights) Color.Black else Color.White,
            modifier = Modifier.size(26.dp)
          )
        }

        // Jump button
        IconButton(
          onClick = {
            gameEngine.triggerJump()
          },
          modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(Color(0x661A2332))
            .border(2.dp, Color(0x88FFFFFF), CircleShape)
            .testTag("jump_button")
        ) {
          Icon(Icons.Default.ArrowUpward, contentDescription = "Jump", tint = Color.White, modifier = Modifier.size(24.dp))
        }
      }

      // Massive Main FIRE Button
      Box(
        modifier = Modifier
          .size(78.dp)
          .clip(CircleShape)
          .background(Color(0xDDF44336))
          .border(3.dp, Color.White, CircleShape)
          .pointerInput(Unit) {
            detectDragGestures(
              onDragStart = { gameEngine.isFiringHeld = true },
              onDragEnd = { gameEngine.isFiringHeld = false },
              onDragCancel = { gameEngine.isFiringHeld = false }
            ) { change, _ ->
              change.consume()
              gameEngine.isFiringHeld = true
            }
          }
          .clickable {
            gameEngine.triggerFireWeapon()
          }
          .testTag("fire_button"),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.GpsFixed, contentDescription = "Fire", tint = Color.White, modifier = Modifier.size(34.dp))
          Text("FIRE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
      }
    }
  }
}

// -------------------------------------------------------------
// FULLSCREEN TACTICAL MAP DIALOG
// -------------------------------------------------------------

@Composable
fun FullscreenTacticalMap(
  player: PlayerState,
  safeZone: SafeZoneState,
  squad: List<SquadTeammate> = emptyList(),
  gameEngine: GameEngine? = null,
  onClose: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xEE0A0E14))
      .padding(24.dp)
  ) {
    Card(
      modifier = Modifier.fillMaxSize(),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, SlateBorder)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Map Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(SlateSurface)
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Map, contentDescription = null, tint = TacticalAmber)
            Spacer(modifier = Modifier.width(8.dp))
            Text("TACTICAL MAP // TAP ANYWHERE TO DROP BEACON", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }

          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (player.waypoint != null) {
              OutlinedButton(
                onClick = { gameEngine?.clearWaypoint() },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TacticalRed),
                border = BorderStroke(1.dp, TacticalRed),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
              ) {
                Text("CLEAR BEACON", fontSize = 9.sp, fontWeight = FontWeight.Bold)
              }
            }

            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }
          }
        }

        // Full Island Map Canvas
        var mapSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .onSizeChanged { mapSize = it }
            .pointerInput(mapSize) {
              detectTapGestures { tapOffset ->
                if (mapSize.width > 0 && mapSize.height > 0) {
                  val worldX = (tapOffset.x / mapSize.width) * TacticalIslandMap.WORLD_SIZE
                  val worldY = (tapOffset.y / mapSize.height) * TacticalIslandMap.WORLD_SIZE
                  gameEngine?.setWaypoint(worldX, worldY)
                }
              }
            }
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val scaleX = size.width / TacticalIslandMap.WORLD_SIZE
            val scaleY = size.height / TacticalIslandMap.WORLD_SIZE

            // Island background
            drawRect(Color(0xFF1E281F))

            // River
            for (i in 0 until TacticalIslandMap.RIVER_POINTS.size - 1) {
              val p1 = TacticalIslandMap.RIVER_POINTS[i]
              val p2 = TacticalIslandMap.RIVER_POINTS[i + 1]
              drawLine(
                color = Color(0xFF1976D2),
                start = Offset(p1.x * scaleX, p1.y * scaleY),
                end = Offset(p2.x * scaleX, p2.y * scaleY),
                strokeWidth = 8f
              )
            }

            // Bridges
            for (bridge in TacticalIslandMap.BRIDGES) {
              drawRect(
                color = Color(0xFF78909C),
                topLeft = Offset(bridge.rect.left * scaleX, bridge.rect.top * scaleY),
                size = Size(bridge.rect.width * scaleX, bridge.rect.height * scaleY)
              )
            }

            // Roads
            for (road in TacticalIslandMap.ROADS) {
              drawLine(
                color = Color(0xFF455A64),
                start = Offset(road.start.x * scaleX, road.start.y * scaleY),
                end = Offset(road.end.x * scaleX, road.end.y * scaleY),
                strokeWidth = 3f
              )
            }

            // Current Safe Zone (Cyan)
            drawCircle(
              color = Color(0xFF00E5FF),
              radius = safeZone.currentRadius * scaleX,
              center = Offset(safeZone.currentCenterX * scaleX, safeZone.currentCenterY * scaleY),
              style = Stroke(width = 2.5f)
            )

            // Target Safe Zone (White dashed)
            drawCircle(
              color = Color.White,
              radius = safeZone.targetRadius * scaleX,
              center = Offset(safeZone.targetCenterX * scaleX, safeZone.targetCenterY * scaleY),
              style = Stroke(width = 2f)
            )

            // POIs
            for (poi in TacticalIslandMap.POIs) {
              val c = Offset(poi.position.x * scaleX, poi.position.y * scaleY)
              drawCircle(poi.color, radius = 6f, center = c)
            }

            // Squad Teammates
            for (mate in squad) {
              if (mate.isAlive) {
                val matePos = Offset(mate.posX * scaleX, mate.posY * scaleY)
                drawCircle(if (mate.isKnockedDown) Color(0xFFFF1744) else Color(0xFF00E676), radius = 6f, center = matePos)
                drawCircle(Color.White, radius = 2.5f, center = matePos)
              }
            }

            // Player Marker
            val playerPos = Offset(player.posX * scaleX, player.posY * scaleY)
            drawCircle(TacticalAmber, radius = 8f, center = playerPos)
            drawCircle(Color.White, radius = 4f, center = playerPos)

            // Waypoint Beacon
            player.waypoint?.let { wp ->
              val wpPos = Offset(wp.posX * scaleX, wp.posY * scaleY)
              drawCircle(Color(0xFFFF0055), radius = 8f, center = wpPos)
              drawCircle(Color.White, radius = 3.5f, center = wpPos)
              drawLine(Color(0xAAFF0055), start = playerPos, end = wpPos, strokeWidth = 2.5f)
            }
          }
        }
      }
    }
  }
}

// -------------------------------------------------------------
// TACTICAL BACKPACK INVENTORY MODAL
// -------------------------------------------------------------

@Composable
fun BackpackInventoryModal(
  player: PlayerState,
  gameEngine: GameEngine,
  onClose: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xCC000000))
      .padding(horizontal = 32.dp, vertical = 20.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.9f)
        .fillMaxHeight(0.9f),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.5.dp, TacticalAmber)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(SlateSurface)
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = TacticalAmber)
            Spacer(modifier = Modifier.width(8.dp))
            Text("TACTICAL BACKPACK // GEAR & LOADOUT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
          }
          IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
          }
        }

        // Inventory content columns
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // Column 1: Equipped Weapons & Drop Controls
          Column(
            modifier = Modifier
              .weight(1.3f)
              .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Text("EQUIPPED WEAPONS", color = TacticalCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            // Primary 1
            InventoryWeaponRow(
              title = "PRIMARY 1",
              weapon = player.primaryWeapon1,
              isActive = player.activeSlot == 0,
              onEquip = { gameEngine.switchWeaponSlot(0) },
              onDrop = { gameEngine.dropWeapon(0) }
            )

            // Primary 2
            InventoryWeaponRow(
              title = "PRIMARY 2",
              weapon = player.primaryWeapon2,
              isActive = player.activeSlot == 1,
              onEquip = { gameEngine.switchWeaponSlot(1) },
              onDrop = { gameEngine.dropWeapon(1) }
            )

            // Sidearm
            InventoryWeaponRow(
              title = "SIDEARM",
              weapon = player.sidearmWeapon,
              isActive = player.activeSlot == 2,
              onEquip = { gameEngine.switchWeaponSlot(2) },
              onDrop = null
            )
          }

          // Column 2: Medical & Armor Supplies
          Column(
            modifier = Modifier
              .weight(1f)
              .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Text("SURVIVAL CONSUMABLES", color = TacticalGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            // Trauma Kit
            Surface(
              color = Color(0x661A2332),
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, SlateBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.LocalHospital, contentDescription = null, tint = TacticalGreen, modifier = Modifier.size(22.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text("Trauma Medkit", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("+50 HP // Qty: ${player.medKitCount}", color = TextMuted, fontSize = 9.sp)
                  }
                }
                Button(
                  onClick = { gameEngine.useMedKit() },
                  enabled = player.medKitCount > 0 && player.health < player.maxHealth,
                  colors = ButtonDefaults.buttonColors(containerColor = TacticalGreen, contentColor = Color.Black),
                  shape = RoundedCornerShape(6.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(28.dp)
                ) {
                  Text("USE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            // Energy Drink
            Surface(
              color = Color(0x661A2332),
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, SlateBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.LocalDrink, contentDescription = null, tint = TacticalCyan, modifier = Modifier.size(22.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text("Adrenaline Drink", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("+35 HP +25 AP // Qty: ${player.energyDrinkCount}", color = TextMuted, fontSize = 9.sp)
                  }
                }
                Button(
                  onClick = { gameEngine.useEnergyDrink() },
                  enabled = player.energyDrinkCount > 0,
                  colors = ButtonDefaults.buttonColors(containerColor = TacticalCyan, contentColor = Color.Black),
                  shape = RoundedCornerShape(6.dp),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(28.dp)
                ) {
                  Text("DRINK", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            // Armor & Helmet Status
            Surface(
              color = Color(0x661A2332),
              shape = RoundedCornerShape(8.dp),
              border = BorderStroke(1.dp, SlateBorder),
              modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text("PROTECTIVE GEAR", color = TacticalAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Vest: Level ${player.vestLevel}", color = Color.White, fontSize = 10.sp)
                  Text("${player.armor.toInt()} / 100 AP", color = TacticalCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Helmet: Level ${player.helmetLevel}", color = Color.White, fontSize = 10.sp)
                  Text("Damage Reduction: ${(player.helmetLevel * 20)}%", color = TacticalAmber, fontSize = 10.sp)
                }
              }
            }
          }

          // Column 3: Ammunition Reserves
          Column(
            modifier = Modifier
              .weight(0.9f)
              .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Text("AMMO CACHES", color = TacticalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)

            AmmoStockRow(label = "5.56mm NATO", count = player.reserve556Ammo)
            AmmoStockRow(label = ".45 ACP Heavy", count = player.reserve45Ammo)
            AmmoStockRow(label = "12 Gauge Shotgun", count = player.reserve12GAmmo)
            AmmoStockRow(label = ".300 Magnum", count = player.reserve300Ammo)
            AmmoStockRow(label = "9mm Tactical", count = player.reserve9MMAmmo)
          }
        }
      }
    }
  }
}

@Composable
fun InventoryWeaponRow(
  title: String,
  weapon: Weapon?,
  isActive: Boolean,
  onEquip: () -> Unit,
  onDrop: (() -> Unit)?
) {
  Surface(
    color = if (isActive) Color(0x882A3A4C) else Color(0x661A2332),
    shape = RoundedCornerShape(8.dp),
    border = BorderStroke(1.dp, if (isActive) TacticalAmber else SlateBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(title, color = if (isActive) TacticalAmberLight else TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(weapon?.name ?: "Empty Slot", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        if (weapon != null) {
          Text(
            "Dmg: ${weapon.baseDamage.toInt()} // Rate: ${weapon.fireRateRps.toInt()} rps // Mag: ${weapon.magCapacity}",
            color = TextMuted,
            fontSize = 9.sp
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (!isActive && weapon != null) {
          Button(
            onClick = onEquip,
            colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text("EQUIP", fontSize = 9.sp, fontWeight = FontWeight.Bold)
          }
        }
        if (onDrop != null && weapon != null) {
          OutlinedButton(
            onClick = onDrop,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TacticalRed),
            border = BorderStroke(1.dp, TacticalRed.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text("DROP", fontSize = 9.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun AmmoStockRow(label: String, count: Int) {
  Surface(
    color = Color(0x661A2332),
    shape = RoundedCornerShape(6.dp),
    border = BorderStroke(1.dp, SlateBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(label, color = Color.White, fontSize = 10.sp)
      Text("$count", color = TacticalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
  }
}
