package com.example.game.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.game.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlayerProfile(
  val username: String = "Survivor-Delta",
  val level: Int = 12,
  val xp: Int = 4350,
  val xpNextLevel: Int = 5000,
  val coins: Int = 2850,
  val rankTitle: String = "Platinum Tier III",
  val matchesPlayed: Int = 48,
  val wins: Int = 11,
  val topTen: Int = 32,
  val totalKills: Int = 184,
  val highestKills: Int = 14,
  val headshots: Int = 67,
  val selectedOutfitIndex: Int = 0,
  val selectedWeaponSkin: String = "Desert Viper"
)

data class GameSettingsConfig(
  val graphicsQuality: String = "High", // Low, Medium, High, Ultra
  val targetFps: Int = 60,
  val shadowQuality: String = "Medium",
  val viewDistance: String = "Far",
  val antiAliasing: Boolean = true,
  val masterVolume: Float = 0.85f,
  val sfxVolume: Float = 0.90f,
  val cameraSensitivity: Float = 1.0f,
  val adsSensitivity: Float = 0.8f,
  val hapticFeedback: Boolean = true
)

class GameRepository(context: Context) {
  private val prefs: SharedPreferences = context.getSharedPreferences("battlezone_prefs", Context.MODE_PRIVATE)

  private val _profileState = MutableStateFlow(loadProfile())
  val profileState = _profileState.asStateFlow()

  private val _settingsState = MutableStateFlow(loadSettings())
  val settingsState = _settingsState.asStateFlow()

  private val _missionsState = MutableStateFlow(getInitialMissions())
  val missionsState = _missionsState.asStateFlow()

  private fun loadProfile(): PlayerProfile {
    return PlayerProfile(
      username = prefs.getString("username", "ApexSurvivor") ?: "ApexSurvivor",
      level = prefs.getInt("level", 8),
      xp = prefs.getInt("xp", 2800),
      coins = prefs.getInt("coins", 3400),
      matchesPlayed = prefs.getInt("matches_played", 35),
      wins = prefs.getInt("wins", 7),
      topTen = prefs.getInt("top_ten", 24),
      totalKills = prefs.getInt("total_kills", 142),
      highestKills = prefs.getInt("highest_kills", 11),
      headshots = prefs.getInt("headshots", 51),
      selectedOutfitIndex = prefs.getInt("outfit_idx", 0)
    )
  }

  private fun loadSettings(): GameSettingsConfig {
    return GameSettingsConfig(
      graphicsQuality = prefs.getString("gfx_quality", "High") ?: "High",
      targetFps = prefs.getInt("target_fps", 60),
      masterVolume = prefs.getFloat("master_vol", 0.85f),
      sfxVolume = prefs.getFloat("sfx_vol", 0.90f),
      cameraSensitivity = prefs.getFloat("cam_sens", 1.0f),
      adsSensitivity = prefs.getFloat("ads_sens", 0.8f),
      hapticFeedback = prefs.getBoolean("haptics", true)
    )
  }

  fun updateSettings(newSettings: GameSettingsConfig) {
    _settingsState.value = newSettings
    prefs.edit()
      .putString("gfx_quality", newSettings.graphicsQuality)
      .putInt("target_fps", newSettings.targetFps)
      .putFloat("master_vol", newSettings.masterVolume)
      .putFloat("sfx_vol", newSettings.sfxVolume)
      .putFloat("cam_sens", newSettings.cameraSensitivity)
      .putFloat("ads_sens", newSettings.adsSensitivity)
      .putBoolean("haptics", newSettings.hapticFeedback)
      .apply()
  }

  fun selectOutfit(index: Int) {
    val current = _profileState.value
    _profileState.value = current.copy(selectedOutfitIndex = index)
    prefs.edit().putInt("outfit_idx", index).apply()
  }

  fun recordMatchResult(summary: MatchSummary) {
    val cur = _profileState.value
    val newXp = cur.xp + summary.xpEarned
    val leveledUp = newXp >= cur.xpNextLevel
    val updatedLevel = if (leveledUp) cur.level + 1 else cur.level
    val remainingXp = if (leveledUp) newXp - cur.xpNextLevel else newXp

    val updatedProfile = cur.copy(
      level = updatedLevel,
      xp = remainingXp,
      coins = cur.coins + summary.coinsEarned,
      matchesPlayed = cur.matchesPlayed + 1,
      wins = if (summary.isVictory) cur.wins + 1 else cur.wins,
      topTen = if (summary.place <= 10) cur.topTen + 1 else cur.topTen,
      totalKills = cur.totalKills + summary.kills,
      highestKills = maxOf(cur.highestKills, summary.kills),
      headshots = cur.headshots + summary.headshots
    )
    _profileState.value = updatedProfile

    prefs.edit()
      .putInt("level", updatedProfile.level)
      .putInt("xp", updatedProfile.xp)
      .putInt("coins", updatedProfile.coins)
      .putInt("matches_played", updatedProfile.matchesPlayed)
      .putInt("wins", updatedProfile.wins)
      .putInt("top_ten", updatedProfile.topTen)
      .putInt("total_kills", updatedProfile.totalKills)
      .putInt("highest_kills", updatedProfile.highestKills)
      .putInt("headshots", updatedProfile.headshots)
      .apply()

    // Update mission progress
    val currentMissions = _missionsState.value.toMutableList()
    var updated = false
    currentMissions.forEachIndexed { i, m ->
      if (!m.isCompleted) {
        if (m.id == "daily_kills") {
          val count = (m.currentCount + summary.kills).coerceAtMost(m.targetCount)
          currentMissions[i] = m.copy(currentCount = count, isCompleted = count >= m.targetCount)
          updated = true
        } else if (m.id == "daily_survive") {
          val mins = (summary.survivalTimeSec / 60).coerceAtLeast(1)
          val count = (m.currentCount + mins).coerceAtMost(m.targetCount)
          currentMissions[i] = m.copy(currentCount = count, isCompleted = count >= m.targetCount)
          updated = true
        } else if (m.id == "daily_match") {
          val count = (m.currentCount + 1).coerceAtMost(m.targetCount)
          currentMissions[i] = m.copy(currentCount = count, isCompleted = count >= m.targetCount)
          updated = true
        }
      }
    }
    if (updated) {
      _missionsState.value = currentMissions
    }
  }

  fun claimMissionReward(missionId: String) {
    val missions = _missionsState.value.toMutableList()
    val index = missions.indexOfFirst { it.id == missionId }
    if (index != -1 && missions[index].isCompleted && !missions[index].isClaimed) {
      val m = missions[index]
      missions[index] = m.copy(isClaimed = true)
      _missionsState.value = missions

      val cur = _profileState.value
      _profileState.value = cur.copy(
        coins = cur.coins + m.rewardCoins,
        xp = cur.xp + m.rewardXp
      )
      prefs.edit().putInt("coins", _profileState.value.coins).putInt("xp", _profileState.value.xp).apply()
    }
  }

  private fun getInitialMissions(): List<GameMission> {
    return listOf(
      GameMission("daily_kills", "Hunter's Mark", "Eliminate 5 opponents in any battle royale match", 5, 2, 500, 300),
      GameMission("daily_survive", "Iron Endurance", "Survive for a total of 15 minutes across matches", 15, 8, 400, 250),
      GameMission("daily_match", "Deploy & Conquer", "Complete 3 battle royale drops on Isla Perdida", 3, 1, 350, 200),
      GameMission("weekly_top3", "Apex Survivor", "Finish in Top 3 in Squad or Solo match", 2, 1, 1200, 800),
      GameMission("weekly_sniper", "Long Distance Strike", "Score 3 eliminations with Sniper or DMR", 3, 0, 900, 600)
    )
  }

  fun getLeaderboard(type: String): List<LeaderboardItem> {
    return when (type) {
      "Friends" -> listOf(
        LeaderboardItem(1, "ShadowBlade_99", 42, 290, 4820, "Apex Master"),
        LeaderboardItem(2, "Survivor-Delta (You)", 11, 184, 3450, "Platinum III"),
        LeaderboardItem(3, "GhostSniper_X", 9, 132, 3120, "Platinum II"),
        LeaderboardItem(4, "VortexRider", 6, 88, 2640, "Gold I"),
        LeaderboardItem(5, "CipherWolf", 4, 61, 2190, "Gold III")
      )
      "Season" -> listOf(
        LeaderboardItem(1, "Kraken_Titan", 128, 890, 8420, "Apex Grandmaster"),
        LeaderboardItem(2, "Valkyrie_One", 114, 762, 7950, "Apex Grandmaster"),
        LeaderboardItem(3, "Ronin_Echo", 98, 640, 7120, "Grandmaster"),
        LeaderboardItem(4, "StrikeHazard", 82, 590, 6890, "Master"),
        LeaderboardItem(5, "PhantomOperator", 76, 520, 6410, "Master")
      )
      else -> listOf(
        LeaderboardItem(1, "OmegaPredator", 210, 1420, 9890, "#1 Worldwide"),
        LeaderboardItem(2, "StormBreaker", 195, 1290, 9420, "Grandmaster"),
        LeaderboardItem(3, "NightFang_9", 182, 1180, 9150, "Grandmaster"),
        LeaderboardItem(4, "DeltaForce_Alpha", 168, 1050, 8800, "Apex Master"),
        LeaderboardItem(5, "CyberWolf_01", 154, 980, 8420, "Apex Master"),
        LeaderboardItem(6, "ViperStrike", 140, 910, 8100, "Master I"),
        LeaderboardItem(7, "ReconFalcon", 129, 845, 7820, "Master II")
      )
    }
  }
}
