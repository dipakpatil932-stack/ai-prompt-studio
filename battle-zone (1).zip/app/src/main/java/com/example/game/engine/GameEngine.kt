package com.example.game.engine

import androidx.compose.ui.geometry.Offset
import com.example.game.audio.GameSoundEngine
import com.example.game.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*
import kotlin.random.Random

class GameEngine {

  private val botAi = BotAiEngine()

  // Match State Flows
  private val _matchPhase = MutableStateFlow(MatchPhase.LOBBY)
  val matchPhase = _matchPhase.asStateFlow()

  private val _playerState = MutableStateFlow(PlayerState())
  val playerState = _playerState.asStateFlow()

  private val _safeZone = MutableStateFlow(SafeZoneState())
  val safeZone = _safeZone.asStateFlow()

  private val _bots = MutableStateFlow<List<BotEntity>>(emptyList())
  val bots = _bots.asStateFlow()

  private val _squad = MutableStateFlow<List<SquadTeammate>>(emptyList())
  val squad = _squad.asStateFlow()

  private val _lootItems = MutableStateFlow<List<LootItem>>(emptyList())
  val lootItems = _lootItems.asStateFlow()

  private val _vehicles = MutableStateFlow<List<VehicleInstance>>(emptyList())
  val vehicles = _vehicles.asStateFlow()

  private val _bulletTracers = MutableStateFlow<List<BulletTracer>>(emptyList())
  val bulletTracers = _bulletTracers.asStateFlow()

  private val _combatParticles = MutableStateFlow<List<CombatParticle>>(emptyList())
  val combatParticles = _combatParticles.asStateFlow()

  private val _killFeed = MutableStateFlow<List<KillFeedEntry>>(emptyList())
  val killFeed = _killFeed.asStateFlow()

  private val _nearbyLoot = MutableStateFlow<List<LootItem>>(emptyList())
  val nearbyLoot = _nearbyLoot.asStateFlow()

  private val _nearbyVehicle = MutableStateFlow<VehicleInstance?>(null)
  val nearbyVehicle = _nearbyVehicle.asStateFlow()

  private val _matchSummary = MutableStateFlow<MatchSummary?>(null)
  val matchSummary = _matchSummary.asStateFlow()

  private val _damagePopups = MutableStateFlow<List<DamageNumberPopup>>(emptyList())
  val damagePopups = _damagePopups.asStateFlow()

  // Smooth camera follow coordinates
  var smoothedCamX: Float = 1500f
  var smoothedCamY: Float = 1500f

  // Dropship flight path
  var dropshipStartX = 200f
  var dropshipStartY = 200f
  var dropshipEndX = 2800f
  var dropshipEndY = 2800f
  var dropshipProgress = 0f

  // Input states updated by HUD touch events
  var moveStickX: Float = 0f
  var moveStickY: Float = 0f
  var isSprintLocked: Boolean = false
  var isFiringHeld: Boolean = false
  var vehicleThrottle: Float = 0f
  var vehicleSteer: Float = 0f

  private var fireCooldown: Float = 0f
  private var footstepTimer: Float = 0f
  private var lobbyCountdown: Float = 8f
  private var matchTimerSec: Float = 0f
  var selectedMatchMode: MatchMode = MatchMode.SOLO

  init {
    initializeMatch(MatchMode.SOLO)
  }

  fun initializeMatch(mode: MatchMode) {
    selectedMatchMode = mode
    _matchPhase.value = MatchPhase.LOBBY
    lobbyCountdown = 7f
    matchTimerSec = 0f
    dropshipProgress = 0f

    // Pick random flight path across island
    val side = Random.nextInt(4)
    when (side) {
      0 -> { dropshipStartX = 200f; dropshipStartY = 200f; dropshipEndX = 2800f; dropshipEndY = 2800f }
      1 -> { dropshipStartX = 200f; dropshipStartY = 2800f; dropshipEndX = 2800f; dropshipEndY = 200f }
      2 -> { dropshipStartX = 1500f; dropshipStartY = 100f; dropshipEndX = 1500f; dropshipEndY = 2900f }
      else -> { dropshipStartX = 100f; dropshipStartY = 1500f; dropshipEndX = 2900f; dropshipEndY = 1500f }
    }

    // Initialize player
    _playerState.value = PlayerState(
      posX = TacticalIslandMap.POIs[8].position.x + 20f,
      posY = TacticalIslandMap.POIs[8].position.y + 20f,
      posZ = 0f,
      rotationDeg = 90f,
      health = 100f,
      armor = 100f,
      primaryWeapon1 = WeaponCatalog.VX9_TEMPEST,
      primaryWeapon2 = WeaponCatalog.BULLDOG12,
      sidearmWeapon = WeaponCatalog.P9_SPECTRE,
      ammoInMag = WeaponCatalog.VX9_TEMPEST.magCapacity
    )

    // Spawn 13 tactical AI opponents (10-15 target range)
    val botList = mutableListOf<BotEntity>()
    val callsigns = listOf(
      "ApexViper", "GhostRecon", "SteelWolf", "PhantomZero", "IronClaw", "ShadowRaven",
      "VortexRider", "CyberNinja", "TitanStrike", "SpectreOne", "FrostBite", "StormSurge",
      "RogueAgent"
    )

    callsigns.forEachIndexed { index, name ->
      val poi = TacticalIslandMap.POIs[index % TacticalIslandMap.POIs.size]
      val offsetX = (Random.nextFloat() * 120f - 60f)
      val offsetY = (Random.nextFloat() * 120f - 60f)
      val weapon = WeaponCatalog.ALL_WEAPONS[index % (WeaponCatalog.ALL_WEAPONS.size - 1)]
      botList.add(
        BotEntity(
          id = "bot_$index",
          name = name,
          posX = (poi.position.x + offsetX).coerceIn(150f, TacticalIslandMap.WORLD_SIZE - 150f),
          posY = (poi.position.y + offsetY).coerceIn(150f, TacticalIslandMap.WORLD_SIZE - 150f),
          rotationDeg = Random.nextFloat() * 360f,
          health = 100f,
          armor = if (Random.nextBoolean()) 50f else 25f,
          activeWeapon = weapon,
          ammoInMag = weapon.magCapacity,
          outfitIndex = index % OutfitCatalog.OUTFITS.size
        )
      )
    }
    _bots.value = botList

    smoothedCamX = _playerState.value.posX
    smoothedCamY = _playerState.value.posY
    _damagePopups.value = emptyList()

    // Squad members if Duo or Squad
    if (mode != MatchMode.SOLO) {
      val squadCount = if (mode == MatchMode.DUO) 1 else 3
      val squadNames = listOf("Bravo-2 (Hawk)", "Charlie-3 (Shield)", "Delta-4 (Medic)")
      val team = mutableListOf<SquadTeammate>()
      for (i in 0 until squadCount) {
        team.add(
          SquadTeammate(
            id = "squad_$i",
            name = squadNames[i],
            health = 100f,
            armor = 100f,
            posX = _playerState.value.posX + (i + 1) * 15f,
            posY = _playerState.value.posY + (i + 1) * 15f
          )
        )
      }
      _squad.value = team
    } else {
      _squad.value = emptyList()
    }

    // Generate ground loot across island
    generateIslandLoot()

    // Vehicles
    _vehicles.value = VehicleEngine.spawnInitialVehicles()

    // Initial safe zone
    _safeZone.value = SafeZoneState(
      currentCenterX = 1500f,
      currentCenterY = 1500f,
      currentRadius = 1450f,
      targetCenterX = 1450f,
      targetCenterY = 1450f,
      targetRadius = 900f,
      phaseNumber = 1,
      secondsUntilShrink = 60f,
      isShrinking = false,
      dpsOutside = 1.5f
    )

    _bulletTracers.value = emptyList()
    _combatParticles.value = emptyList()
    _killFeed.value = listOf(
      KillFeedEntry("HQ Command", "Isla Perdida", "Match Countdown Started", false)
    )
    _matchSummary.value = null
  }

  private fun generateIslandLoot() {
    val items = mutableListOf<LootItem>()
    var idCounter = 0

    // Distribute loot in buildings
    for (b in TacticalIslandMap.BUILDINGS) {
      // 3 items per building
      for (i in 0..2) {
        val lx = b.rect.left + 15f + i * 25f
        val ly = b.rect.top + 15f + (i % 2) * 25f
        val r = Random.nextFloat()
        val loot = when {
          r < 0.32f -> {
            val w = WeaponCatalog.ALL_WEAPONS.random()
            LootItem("loot_${idCounter++}", w.name, LootType.WEAPON, ItemRarity.RARE, lx, ly, weaponRef = w)
          }
          r < 0.52f -> {
            val ammoCal = listOf("5.56mm Ammo Box", ".45 ACP Box", "12-Gauge Shells", ".300 Mag Ammo").random()
            LootItem("loot_${idCounter++}", ammoCal, LootType.AMMO, ItemRarity.COMMON, lx, ly, quantity = 45)
          }
          r < 0.72f -> LootItem("loot_${idCounter++}", "Tactical Kevlar Vest (Lvl 2)", LootType.ARMOR_VEST, ItemRarity.RARE, lx, ly, armorValue = 75f)
          r < 0.88f -> LootItem("loot_${idCounter++}", "Trauma Medkit", LootType.HEALTH_KIT, ItemRarity.EPIC, lx, ly, healValue = 100f)
          else -> LootItem("loot_${idCounter++}", "Tactical Combat Helmet (Lvl 2)", LootType.HELMET, ItemRarity.RARE, lx, ly, armorValue = 50f)
        }
        items.add(loot)
      }
    }

    // High-Value Tactical Military Supply Crates at Major POIs
    val crateLocations = listOf(
      Offset(TacticalIslandMap.POIs[0].position.x + 35f, TacticalIslandMap.POIs[0].position.y - 20f),
      Offset(TacticalIslandMap.POIs[2].position.x - 30f, TacticalIslandMap.POIs[2].position.y + 40f),
      Offset(TacticalIslandMap.POIs[6].position.x + 25f, TacticalIslandMap.POIs[6].position.y + 25f),
      Offset(1500f, 1500f) // Center island drop
    )
    crateLocations.forEach { loc ->
      items.add(
        LootItem(
          id = "crate_${idCounter++}",
          name = "Tactical Airdrop Crate",
          type = LootType.SUPPLY_CRATE,
          rarity = ItemRarity.LEGENDARY,
          posX = loc.x,
          posY = loc.y,
          quantity = 1,
          weaponRef = WeaponCatalog.APEX_STRIKER,
          armorValue = 100f,
          healValue = 100f
        )
      )
    }

    // Additional outdoor field drops
    for (poi in TacticalIslandMap.POIs) {
      for (j in 0..1) {
        val angle = Random.nextFloat() * (Math.PI.toFloat() * 2f)
        val dist = Random.nextFloat() * 60f + 20f
        val lx = poi.position.x + cos(angle) * dist
        val ly = poi.position.y + sin(angle) * dist
        items.add(
          LootItem(
            "loot_${idCounter++}",
            "Combat Stim / Energy Drink",
            LootType.ENERGY_DRINK,
            ItemRarity.UNCOMMON,
            lx, ly,
            healValue = 40f
          )
        )
      }
    }

    _lootItems.value = items
  }

  /**
   * Main game tick called 60 times per second.
   */
  fun update(dt: Float) {
    val phase = _matchPhase.value
    matchTimerSec += dt

    when (phase) {
      MatchPhase.LOBBY -> {
        lobbyCountdown -= dt
        updatePlayerMovement(dt, isLobby = true)
        if (lobbyCountdown <= 0f) {
          _matchPhase.value = MatchPhase.DROPSHIP_FLIGHT
          dropshipProgress = 0f
          GameSoundEngine.playZoneAlarm()
        }
      }

      MatchPhase.DROPSHIP_FLIGHT -> {
        dropshipProgress += (dt / 14f) // 14 seconds flight across island
        val planeX = dropshipStartX + (dropshipEndX - dropshipStartX) * dropshipProgress
        val planeY = dropshipStartY + (dropshipEndY - dropshipStartY) * dropshipProgress

        val p = _playerState.value
        p.posX = planeX
        p.posY = planeY
        p.posZ = 800f // In dropship altitude

        if (dropshipProgress >= 0.95f) {
          // Auto jump at end of island
          executeJumpFromPlane()
        }
      }

      MatchPhase.PARACHUTING -> {
        val p = _playerState.value
        // Glide forward along look angle
        val rad = Math.toRadians(p.rotationDeg.toDouble())
        val glideSpeed = 38f
        p.posX += cos(rad).toFloat() * glideSpeed * dt
        p.posY += sin(rad).toFloat() * glideSpeed * dt
        p.posZ -= 65f * dt // Descend

        if (p.posZ <= 0f) {
          p.posZ = 0f
          _matchPhase.value = MatchPhase.GROUND_COMBAT
          GameSoundEngine.playFootstep()
        }
      }

      MatchPhase.GROUND_COMBAT -> {
        updateCombatMatch(dt)
      }

      MatchPhase.VICTORY, MatchPhase.DEFEATED -> {
        // Match ended
      }
    }

    // Update tracers & particles in all phases
    updateVisualFX(dt)
  }

  fun executeJumpFromPlane() {
    if (_matchPhase.value == MatchPhase.DROPSHIP_FLIGHT) {
      _matchPhase.value = MatchPhase.PARACHUTING
      _playerState.value.posZ = 700f
    }
  }

  private fun updateCombatMatch(dt: Float) {
    val player = _playerState.value
    val botsList = _bots.value
    val safe = _safeZone.value

    // 1. Player movement & vehicle handling
    if (player.isAlive) {
      if (player.currentVehicle != null) {
        val veh = player.currentVehicle!!
        VehicleEngine.updateVehicle(
          vehicle = veh,
          dt = dt,
          throttleInput = vehicleThrottle,
          steerInput = vehicleSteer,
          bots = botsList,
          killFeed = _killFeed.value.toMutableList()
        )
        player.posX = veh.posX
        player.posY = veh.posY
        player.rotationDeg = veh.rotationDeg
      } else {
        updatePlayerMovement(dt, isLobby = false)
      }

      // Reload timer
      if (player.isReloading) {
        val activeWp = getActiveWeapon()
        val reloadTotal = activeWp?.reloadTimeSec ?: 2f
        player.reloadProgress += dt / reloadTotal
        if (player.reloadProgress >= 1f) {
          player.isReloading = false
          player.reloadProgress = 0f
          player.ammoInMag = activeWp?.magCapacity ?: 30
        }
      }

      // Healing timer
      if (player.isHealing) {
        player.healProgress += dt / 3.0f
        if (player.healProgress >= 1f) {
          player.isHealing = false
          player.healProgress = 0f
          player.health = (player.health + 50f).coerceAtMost(player.maxHealth)
        }
      }

      // Automatic firing
      if (isFiringHeld && fireCooldown <= 0f && !player.isReloading && player.currentVehicle == null) {
        val activeWp = getActiveWeapon()
        if (activeWp != null) {
          if (player.ammoInMag > 0) {
            triggerFireWeapon()
          } else {
            // Auto reload on empty
            startReload()
          }
        }
      }
      if (fireCooldown > 0f) {
        fireCooldown -= dt
      }

      // Safe zone ring damage to player
      val distToSafeCenter = hypot(player.posX - safe.currentCenterX, player.posY - safe.currentCenterY)
      if (distToSafeCenter > safe.currentRadius) {
        CombatEngine.applyDamageToPlayer(player, safe.dpsOutside * dt)
        if (!player.isAlive) {
          onPlayerEliminated("Energy Ring Zone")
        }
      }
    }

    // 2. Safe zone update
    updateSafeZone(dt)

    // 3. Bot AI update
    val tracers = _bulletTracers.value.toMutableList()
    val particles = _combatParticles.value.toMutableList()
    val kFeed = _killFeed.value.toMutableList()
    val lootList = _lootItems.value.toMutableList()

    botAi.updateBots(
      dt = dt,
      bots = botsList,
      player = player,
      safeZone = safe,
      lootItems = lootList,
      vehicles = _vehicles.value,
      tracers = tracers,
      particles = particles,
      killFeed = kFeed
    )

    // 3b. Squad AI & Revive handling
    updateSquadTeammates(dt, botsList, safe, tracers, particles, kFeed)

    _bulletTracers.value = tracers
    _combatParticles.value = particles
    _killFeed.value = kFeed
    _lootItems.value = lootList

    // 4. Update nearby loot & vehicle affordances for interact button
    detectNearbyObjects()

    // 5. Check victory / match conclusion
    val aliveBotsCount = botsList.count { it.isAlive }
    val squadAlive = _squad.value.any { it.isAlive && !it.isKnockedDown }
    if (aliveBotsCount == 0 && (player.isAlive || squadAlive) && _matchPhase.value == MatchPhase.GROUND_COMBAT) {
      _matchPhase.value = MatchPhase.VICTORY
      GameSoundEngine.playVictory()
      concludeMatch(isVictory = true, place = 1)
    } else if (!player.isAlive && !squadAlive && _matchPhase.value == MatchPhase.GROUND_COMBAT) {
      _matchPhase.value = MatchPhase.DEFEATED
      concludeMatch(isVictory = false, place = aliveBotsCount + 1)
    }
  }

  private fun updateSquadTeammates(
    dt: Float,
    botsList: List<BotEntity>,
    safe: SafeZoneState,
    tracers: MutableList<BulletTracer>,
    particles: MutableList<CombatParticle>,
    kFeed: MutableList<KillFeedEntry>
  ) {
    val squadList = _squad.value.toMutableList()
    val player = _playerState.value
    var updated = false

    squadList.forEachIndexed { i, mate ->
      if (!mate.isAlive) return@forEachIndexed

      if (mate.isKnockedDown) {
        mate.bleedoutTimer -= dt
        if (mate.bleedoutTimer <= 0f) {
          mate.isAlive = false
          mate.isKnockedDown = false
          kFeed.add(KillFeedEntry("Bleedout", mate.name, "Eliminated", false))
        }
        updated = true
        return@forEachIndexed
      }

      // Move toward player formation position
      val targetFormationX = player.posX + cos((i * 120.0).toFloat()) * 25f
      val targetFormationY = player.posY + sin((i * 120.0).toFloat()) * 25f
      val distToFormation = hypot(targetFormationX - mate.posX, targetFormationY - mate.posY)

      if (distToFormation > 20f) {
        val angle = atan2(targetFormationY - mate.posY, targetFormationX - mate.posX)
        val moveSpeed = if (distToFormation > 60f) 52f else 32f
        mate.posX += cos(angle) * moveSpeed * dt
        mate.posY += sin(angle) * moveSpeed * dt
        updated = true
      }

      // Safe zone ring damage for teammate
      val distToZoneCenter = hypot(mate.posX - safe.currentCenterX, mate.posY - safe.currentCenterY)
      if (distToZoneCenter > safe.currentRadius) {
        mate.health -= safe.dpsOutside * dt
        if (mate.health <= 0f) {
          mate.health = 0f
          mate.isKnockedDown = true
          mate.bleedoutTimer = 30f
        }
        updated = true
      }

      // Teammate auto-revive if player or fellow teammate is down
      val knockedMate = squadList.firstOrNull { it.id != mate.id && it.isKnockedDown && it.isAlive }
      if (knockedMate != null && hypot(knockedMate.posX - mate.posX, knockedMate.posY - mate.posY) < 30f) {
        knockedMate.reviveProgress += dt / 4f
        if (knockedMate.reviveProgress >= 1f) {
          knockedMate.isKnockedDown = false
          knockedMate.health = 50f
          knockedMate.bleedoutTimer = 30f
          knockedMate.reviveProgress = 0f
          GameSoundEngine.playReload()
        }
        updated = true
      }
    }

    if (updated) {
      _squad.value = squadList
    }
  }

  fun resetVehicle() {
    val p = _playerState.value
    val v = p.currentVehicle ?: return
    v.currentSpeed = 0f
    v.posX = (v.posX + 15f).coerceIn(120f, TacticalIslandMap.WORLD_SIZE - 120f)
    v.posY = (v.posY + 15f).coerceIn(120f, TacticalIslandMap.WORLD_SIZE - 120f)
    p.posX = v.posX
    p.posY = v.posY
    GameSoundEngine.playUiTap()
  }

  fun reviveTeammate(teammateId: String) {
    val squadList = _squad.value.toMutableList()
    val idx = squadList.indexOfFirst { it.id == teammateId }
    if (idx != -1) {
      val mate = squadList[idx]
      if (mate.isKnockedDown && mate.isAlive) {
        mate.isKnockedDown = false
        mate.health = 50f
        mate.bleedoutTimer = 30f
        mate.isBeingRevived = false
        mate.reviveProgress = 0f
        _squad.value = squadList
        GameSoundEngine.playReload()
      }
    }
  }

  fun setWaypoint(x: Float, y: Float) {
    _playerState.value.waypoint = MapWaypoint(x, y)
    GameSoundEngine.playUiTap()
  }

  fun clearWaypoint() {
    _playerState.value.waypoint = null
  }

  private fun updateSafeZone(dt: Float) {
    val safe = _safeZone.value
    if (!safe.isShrinking) {
      safe.secondsUntilShrink -= dt
      if (safe.secondsUntilShrink <= 0f) {
        safe.isShrinking = true
        GameSoundEngine.playZoneAlarm()
      }
    } else {
      // Shrink towards target
      val shrinkSpeed = 12f * dt
      safe.currentRadius = (safe.currentRadius - shrinkSpeed).coerceAtLeast(safe.targetRadius)
      val dx = safe.targetCenterX - safe.currentCenterX
      val dy = safe.targetCenterY - safe.currentCenterY
      safe.currentCenterX += dx * 0.005f
      safe.currentCenterY += dy * 0.005f

      if (abs(safe.currentRadius - safe.targetRadius) < 1.0f) {
        // Next phase
        safe.isShrinking = false
        safe.phaseNumber += 1
        safe.secondsUntilShrink = 45f
        safe.dpsOutside += 1.5f

        // Calculate next tighter target
        val nextRadius = (safe.targetRadius * 0.55f).coerceAtLeast(80f)
        val maxShift = (safe.targetRadius - nextRadius) * 0.7f
        val shiftAngle = Random.nextFloat() * (Math.PI.toFloat() * 2f)
        safe.targetCenterX = (safe.currentCenterX + cos(shiftAngle) * maxShift).coerceIn(400f, 2600f)
        safe.targetCenterY = (safe.currentCenterY + sin(shiftAngle) * maxShift).coerceIn(400f, 2600f)
        safe.targetRadius = nextRadius
      }
    }
  }

  private fun updatePlayerMovement(dt: Float, isLobby: Boolean) {
    val p = _playerState.value

    // Jumping physics update
    if (p.isJumping) {
      p.jumpYOffset += p.jumpVelocity * dt
      p.jumpVelocity -= 340f * dt
      if (p.jumpYOffset <= 0f) {
        p.jumpYOffset = 0f
        p.jumpVelocity = 0f
        p.isJumping = false
        GameSoundEngine.playFootstep()
      }
    }

    val stickMag = hypot(moveStickX, moveStickY)

    if (stickMag > 0.08f) {
      var baseSpeed = when (p.stance) {
        PlayerStance.PRONE -> 14f
        PlayerStance.CROUCH -> 28f
        else -> 48f
      }
      val isSprintingNow = (isSprintLocked || p.isSprinting) && p.stance == PlayerStance.STAND
      p.isSprinting = isSprintingNow
      if (isSprintingNow) {
        baseSpeed = 75f // Fast sprint speed
      }

      // Animate walking / running cycle
      val animSpeed = if (isSprintingNow) 20f else 11f
      p.walkCycle = (p.walkCycle + dt * animSpeed) % (Math.PI.toFloat() * 2f)

      val stickAngle = atan2(moveStickY.toDouble(), moveStickX.toDouble())
      val moveDirRad = Math.toRadians(p.rotationDeg.toDouble()) + stickAngle - (Math.PI / 2.0)

      val moveX = cos(moveDirRad).toFloat() * baseSpeed * dt * stickMag
      val moveY = sin(moveDirRad).toFloat() * baseSpeed * dt * stickMag

      val nextX = p.posX + moveX
      val nextY = p.posY + moveY

      // Collision detection against map
      if (!TacticalIslandMap.checkCollision(nextX, p.posY, 16f)) {
        p.posX = nextX
      }
      if (!TacticalIslandMap.checkCollision(p.posX, nextY, 16f)) {
        p.posY = nextY
      }

      // Procedural footstep audio cadence
      footstepTimer += dt
      val stepInterval = if (isSprintingNow) 0.30f else 0.46f
      if (footstepTimer >= stepInterval) {
        footstepTimer = 0f
        GameSoundEngine.playFootstep()
      }
    } else {
      p.walkCycle = 0f
      if (!isSprintLocked) {
        p.isSprinting = false
      }
    }

    // Smooth camera lerp tracking behind player
    smoothedCamX += (p.posX - smoothedCamX) * min(1f, dt * 14f)
    smoothedCamY += (p.posY - smoothedCamY) * min(1f, dt * 14f)
  }

  fun triggerJump() {
    val p = _playerState.value
    if (!p.isJumping && p.stance == PlayerStance.STAND && p.currentVehicle == null) {
      p.isJumping = true
      p.jumpVelocity = 115f
      GameSoundEngine.playFootstep()
    }
  }

  fun toggleSprint() {
    val p = _playerState.value
    isSprintLocked = !isSprintLocked
    p.isSprinting = isSprintLocked
    GameSoundEngine.playUiTap()
  }

  fun triggerFireWeapon() {
    val p = _playerState.value
    val weapon = getActiveWeapon() ?: return
    if (p.isReloading || p.ammoInMag <= 0) return

    p.ammoInMag -= 1
    fireCooldown = 1f / weapon.fireRateRps

    // Audio
    GameSoundEngine.playGunshot(weapon.category.name)

    // Recoil kick on pitch
    p.pitchDeg = (p.pitchDeg - weapon.recoilVertical).coerceIn(-18f, 18f)

    // Fire combat raycast
    val tracers = _bulletTracers.value.toMutableList()
    val particles = _combatParticles.value.toMutableList()
    val popups = _damagePopups.value.toMutableList()

    val result = CombatEngine.firePlayerWeapon(
      player = p,
      weapon = weapon,
      bots = _bots.value,
      tracers = tracers,
      particles = particles,
      damagePopups = popups
    )

    if (result.isElimination && result.hitBotId != null) {
      val bot = _bots.value.find { it.id == result.hitBotId }
      val kFeed = _killFeed.value.toMutableList()
      kFeed.add(0, KillFeedEntry("You", bot?.name ?: "Opponent", weapon.name, true))
      _killFeed.value = kFeed
    }

    _bulletTracers.value = tracers
    _combatParticles.value = particles
    _damagePopups.value = popups
  }

  fun startReload() {
    val p = _playerState.value
    val weapon = getActiveWeapon() ?: return
    if (!p.isReloading && p.ammoInMag < weapon.magCapacity) {
      p.isReloading = true
      p.reloadProgress = 0f
      GameSoundEngine.playReload()
    }
  }

  fun startHealing() {
    val p = _playerState.value
    if (!p.isHealing && p.health < p.maxHealth && p.medKitCount > 0) {
      p.isHealing = true
      p.healProgress = 0f
      p.medKitCount -= 1
      GameSoundEngine.playUiTap()
    }
  }

  fun switchWeaponSlot(slotIndex: Int) {
    val p = _playerState.value
    if (p.activeSlot != slotIndex) {
      p.activeSlot = slotIndex
      p.isReloading = false
      p.ammoInMag = getActiveWeapon()?.magCapacity ?: 30
      GameSoundEngine.playUiTap()
    }
  }

  fun toggleStance(targetStance: PlayerStance) {
    val p = _playerState.value
    p.stance = if (p.stance == targetStance) PlayerStance.STAND else targetStance
    GameSoundEngine.playUiTap()
  }

  fun toggleAds() {
    val p = _playerState.value
    p.isAimingDownSights = !p.isAimingDownSights
    GameSoundEngine.playUiTap()
  }

  fun interactAction() {
    val p = _playerState.value

    // 1. Vehicle interact
    if (p.currentVehicle != null) {
      // Exit vehicle
      val v = p.currentVehicle!!
      v.isOccupied = false
      p.posX = v.posX + 35f
      p.posY = v.posY + 35f
      p.currentVehicle = null
      GameSoundEngine.playUiTap()
      return
    } else {
      val nearbyVeh = _nearbyVehicle.value
      if (nearbyVeh != null) {
        nearbyVeh.isOccupied = true
        p.currentVehicle = nearbyVeh
        GameSoundEngine.playUiTap()
        return
      }
    }

    // 2. Loot interact (pickup closest item)
    val lootList = _lootItems.value.toMutableList()
    val closest = _nearbyLoot.value.firstOrNull()
    if (closest != null) {
      lootList.remove(closest)

      when (closest.type) {
        LootType.SUPPLY_CRATE -> {
          // Open tactical airdrop supply crate
          p.armor = p.maxArmor
          p.health = p.maxHealth
          p.vestLevel = 3
          p.helmetLevel = 3
          p.medKitCount += 2
          p.energyDrinkCount += 2
          p.reserve556Ammo += 90
          p.reserve300Ammo += 20
          if (closest.weaponRef != null) {
            val oldWp = if (p.activeSlot == 1) p.primaryWeapon2 else p.primaryWeapon1
            if (oldWp != null) {
              lootList.add(
                LootItem(
                  id = "drop_${System.nanoTime()}",
                  name = oldWp.name,
                  type = LootType.WEAPON,
                  rarity = ItemRarity.RARE,
                  posX = p.posX + 15f,
                  posY = p.posY + 15f,
                  weaponRef = oldWp
                )
              )
            }
            if (p.activeSlot == 1) p.primaryWeapon2 = closest.weaponRef
            else p.primaryWeapon1 = closest.weaponRef
            p.ammoInMag = closest.weaponRef.magCapacity
          }
          GameSoundEngine.playReload()
        }

        LootType.WEAPON -> {
          if (closest.weaponRef != null) {
            val oldWeapon = when (p.activeSlot) {
              0 -> p.primaryWeapon1
              1 -> p.primaryWeapon2
              else -> p.primaryWeapon1
            }
            // Drop old weapon on ground
            if (oldWeapon != null) {
              lootList.add(
                LootItem(
                  id = "drop_${System.nanoTime()}",
                  name = oldWeapon.name,
                  type = LootType.WEAPON,
                  rarity = ItemRarity.RARE,
                  posX = p.posX + 15f,
                  posY = p.posY + 15f,
                  weaponRef = oldWeapon
                )
              )
            }

            // Equip new weapon
            if (p.activeSlot == 1) {
              p.primaryWeapon2 = closest.weaponRef
            } else {
              p.primaryWeapon1 = closest.weaponRef
              p.activeSlot = 0
            }
            p.ammoInMag = closest.weaponRef.magCapacity
          }
        }

        LootType.AMMO -> {
          when {
            closest.name.contains("45") -> p.reserve45Ammo += closest.quantity
            closest.name.contains("12") -> p.reserve12GAmmo += closest.quantity
            closest.name.contains("300") -> p.reserve300Ammo += closest.quantity
            closest.name.contains("9mm") -> p.reserve9MMAmmo += closest.quantity
            else -> p.reserve556Ammo += closest.quantity
          }
        }

        LootType.ARMOR_VEST -> {
          p.armor = (p.armor + closest.armorValue).coerceAtMost(p.maxArmor)
          p.vestLevel = maxOf(p.vestLevel, 2)
        }

        LootType.HELMET -> {
          p.armor = (p.armor + closest.armorValue).coerceAtMost(p.maxArmor)
          p.helmetLevel = maxOf(p.helmetLevel, 2)
        }

        LootType.HEALTH_KIT -> {
          p.medKitCount += 1
        }

        LootType.ENERGY_DRINK -> {
          p.energyDrinkCount += 1
        }

        else -> {}
      }

      _lootItems.value = lootList
      GameSoundEngine.playUiTap()
    }
  }

  fun useMedKit() {
    val p = _playerState.value
    if (p.medKitCount > 0 && p.health < p.maxHealth && !p.isHealing) {
      p.medKitCount -= 1
      p.isHealing = true
      p.healProgress = 0f
      GameSoundEngine.playUiTap()
    }
  }

  fun useEnergyDrink() {
    val p = _playerState.value
    if (p.energyDrinkCount > 0) {
      p.energyDrinkCount -= 1
      p.health = (p.health + 35f).coerceAtMost(p.maxHealth)
      p.armor = (p.armor + 25f).coerceAtMost(p.maxArmor)
      GameSoundEngine.playUiTap()
    }
  }

  fun dropWeapon(slot: Int) {
    val p = _playerState.value
    val dropped: Weapon? = when (slot) {
      0 -> {
        val w = p.primaryWeapon1
        p.primaryWeapon1 = null
        w
      }
      1 -> {
        val w = p.primaryWeapon2
        p.primaryWeapon2 = null
        w
      }
      else -> null
    }

    if (dropped != null) {
      val list = _lootItems.value.toMutableList()
      list.add(
        LootItem(
          id = "drop_${System.nanoTime()}",
          name = dropped.name,
          type = LootType.WEAPON,
          rarity = ItemRarity.RARE,
          posX = p.posX + 15f,
          posY = p.posY + 15f,
          weaponRef = dropped
        )
      )
      _lootItems.value = list
      if (p.activeSlot == slot) {
        p.activeSlot = if (p.primaryWeapon1 != null) 0 else if (p.primaryWeapon2 != null) 1 else 2
        p.ammoInMag = getActiveWeapon()?.magCapacity ?: 30
      }
      GameSoundEngine.playUiTap()
    }
  }

  private fun detectNearbyObjects() {
    val p = _playerState.value
    val items = _lootItems.value
    val vehs = _vehicles.value

    val closeLoot = items.filter { hypot(it.posX - p.posX, it.posY - p.posY) < 45f }
    _nearbyLoot.value = closeLoot

    val closeVeh = vehs.firstOrNull { hypot(it.posX - p.posX, it.posY - p.posY) < 55f && !it.isOccupied }
    _nearbyVehicle.value = closeVeh
  }

  private fun onPlayerEliminated(cause: String) {
    _playerState.value.isAlive = false
    val kFeed = _killFeed.value.toMutableList()
    kFeed.add(0, KillFeedEntry(cause, "You", "Eliminated", false))
    _killFeed.value = kFeed
  }

  private fun concludeMatch(isVictory: Boolean, place: Int) {
    val p = _playerState.value
    val totalContestants = _bots.value.size + 1
    val survivalSec = matchTimerSec.toInt()

    val xp = (p.kills * 120) + (survivalSec * 1.5f).toInt() + (if (isVictory) 800 else 150)
    val coins = (p.kills * 75) + (if (isVictory) 500 else 100)

    _matchSummary.value = MatchSummary(
      place = place,
      totalPlayers = totalContestants,
      kills = p.kills,
      damageDealt = p.damageDealt.toInt(),
      survivalTimeSec = survivalSec,
      headshots = (p.kills * 0.35f).toInt(),
      xpEarned = xp,
      coinsEarned = coins,
      isVictory = isVictory
    )
  }

  private fun updateVisualFX(dt: Float) {
    val p = _playerState.value

    // Smooth recoil recovery
    if (abs(p.pitchDeg) > 0.05f) {
      p.pitchDeg *= (1f - dt * 6f)
    }

    // Tracers decay
    val tracers = _bulletTracers.value.toMutableList()
    val trIt = tracers.iterator()
    while (trIt.hasNext()) {
      val t = trIt.next()
      t.lifeTimeRemaining -= dt
      if (t.lifeTimeRemaining <= 0f) trIt.remove()
    }
    _bulletTracers.value = tracers

    // Particles decay
    val particles = _combatParticles.value.toMutableList()
    val partIt = particles.iterator()
    while (partIt.hasNext()) {
      val pt = partIt.next()
      pt.x += pt.velX * dt
      pt.y += pt.velY * dt
      pt.life -= dt / pt.maxLife
      if (pt.life <= 0f) partIt.remove()
    }
    _combatParticles.value = particles

    // Damage number popups decay and rise
    val popups = _damagePopups.value.toMutableList()
    val popIt = popups.iterator()
    while (popIt.hasNext()) {
      val pop = popIt.next()
      pop.posY -= 24f * dt
      pop.lifeTime -= dt
      if (pop.lifeTime <= 0f) popIt.remove()
    }
    _damagePopups.value = popups
  }

  fun getActiveWeapon(): Weapon? {
    val p = _playerState.value
    return when (p.activeSlot) {
      0 -> p.primaryWeapon1
      1 -> p.primaryWeapon2
      2 -> p.sidearmWeapon
      else -> WeaponCatalog.COMBAT_CLEAVER
    }
  }

  fun updateCamera(deltaYaw: Float, deltaPitch: Float) {
    val p = _playerState.value
    p.rotationDeg = (p.rotationDeg + deltaYaw) % 360f
    if (p.rotationDeg < 0f) p.rotationDeg += 360f
    p.pitchDeg = (p.pitchDeg + deltaPitch).coerceIn(-35f, 35f)
  }
}
