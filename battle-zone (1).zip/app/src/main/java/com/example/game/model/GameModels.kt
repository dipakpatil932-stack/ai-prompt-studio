package com.example.game.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

// -------------------------------------------------------------
// WEAPONS & AMMO
// -------------------------------------------------------------

enum class WeaponCategory(val displayName: String) {
  ASSAULT_RIFLE("Assault Rifle"),
  SMG("Submachine Gun"),
  SHOTGUN("Shotgun"),
  SNIPER("Sniper Rifle"),
  DMR("Marksman Rifle"),
  PISTOL("Sidearm"),
  MELEE("Melee")
}

enum class AmmoType(val caliber: String, val color: Color) {
  CAL_556("5.56mm", TacticalGreen),
  CAL_9MM("9mm", TacticalCyan),
  CAL_12G("12-Gauge", TacticalOrange),
  CAL_300(".300 Mag", TacticalAmber),
  CAL_45(".45 ACP", TacticalPurple),
  NONE("None", Color.Gray)
}

data class Weapon(
  val id: String,
  val name: String,
  val category: WeaponCategory,
  val ammoType: AmmoType,
  val baseDamage: Float,
  val fireRateRps: Float, // Rounds per second
  val magCapacity: Int,
  val reloadTimeSec: Float,
  val rangeMeters: Float,
  val accuracySpread: Float, // Lower is more accurate
  val recoilVertical: Float,
  val bulletSpeed: Float,
  val isAutomatic: Boolean = true,
  val description: String = ""
)

object WeaponCatalog {
  val VX9_TEMPEST = Weapon(
    id = "vx9_tempest",
    name = "VX-9 Tempest",
    category = WeaponCategory.ASSAULT_RIFLE,
    ammoType = AmmoType.CAL_556,
    baseDamage = 34f,
    fireRateRps = 11f,
    magCapacity = 30,
    reloadTimeSec = 2.2f,
    rangeMeters = 300f,
    accuracySpread = 0.035f,
    recoilVertical = 1.6f,
    bulletSpeed = 820f,
    description = "Military-grade assault rifle with high muzzle velocity and balanced burst control."
  )

  val KESTREL45 = Weapon(
    id = "kestrel45",
    name = "Kestrel-45",
    category = WeaponCategory.SMG,
    ammoType = AmmoType.CAL_45,
    baseDamage = 26f,
    fireRateRps = 15f,
    magCapacity = 32,
    reloadTimeSec = 1.8f,
    rangeMeters = 150f,
    accuracySpread = 0.055f,
    recoilVertical = 1.2f,
    bulletSpeed = 420f,
    description = "Ultra-rapid compact SMG engineered for devastating close-quarters room clearing."
  )

  val BULLDOG12 = Weapon(
    id = "bulldog12",
    name = "Bulldog-12",
    category = WeaponCategory.SHOTGUN,
    ammoType = AmmoType.CAL_12G,
    baseDamage = 95f,
    fireRateRps = 1.5f,
    magCapacity = 8,
    reloadTimeSec = 2.8f,
    rangeMeters = 50f,
    accuracySpread = 0.12f,
    recoilVertical = 3.5f,
    bulletSpeed = 360f,
    isAutomatic = false,
    description = "Heavy tactical pump shotgun delivering massive stopping power at point-blank."
  )

  val APEX_STRIKER = Weapon(
    id = "apex_striker",
    name = "Apex Striker",
    category = WeaponCategory.SNIPER,
    ammoType = AmmoType.CAL_300,
    baseDamage = 110f,
    fireRateRps = 0.8f,
    magCapacity = 5,
    reloadTimeSec = 3.2f,
    rangeMeters = 600f,
    accuracySpread = 0.005f,
    recoilVertical = 4.2f,
    bulletSpeed = 980f,
    isAutomatic = false,
    description = "High-caliber precision bolt sniper rifle with deadly single-shot headshot lethality."
  )

  val COBALT_DMR = Weapon(
    id = "cobalt_dmr",
    name = "Cobalt DMR",
    category = WeaponCategory.DMR,
    ammoType = AmmoType.CAL_556,
    baseDamage = 52f,
    fireRateRps = 5f,
    magCapacity = 20,
    reloadTimeSec = 2.4f,
    rangeMeters = 450f,
    accuracySpread = 0.015f,
    recoilVertical = 2.1f,
    bulletSpeed = 880f,
    isAutomatic = false,
    description = "Semi-automatic designated marksman rifle offering rapid follow-up precision shots."
  )

  val P9_SPECTRE = Weapon(
    id = "p9_spectre",
    name = "P9 Spectre",
    category = WeaponCategory.PISTOL,
    ammoType = AmmoType.CAL_9MM,
    baseDamage = 24f,
    fireRateRps = 6f,
    magCapacity = 15,
    reloadTimeSec = 1.4f,
    rangeMeters = 100f,
    accuracySpread = 0.04f,
    recoilVertical = 1.0f,
    bulletSpeed = 380f,
    isAutomatic = false,
    description = "Lightweight tactical sidearm with crisp trigger pull and fast holster draw."
  )

  val COMBAT_CLEAVER = Weapon(
    id = "combat_cleaver",
    name = "Kevlar Cleaver",
    category = WeaponCategory.MELEE,
    ammoType = AmmoType.NONE,
    baseDamage = 45f,
    fireRateRps = 1.8f,
    magCapacity = 0,
    reloadTimeSec = 0f,
    rangeMeters = 2.5f,
    accuracySpread = 0.0f,
    recoilVertical = 0.0f,
    bulletSpeed = 0f,
    isAutomatic = false,
    description = "Carbon-reinforced titanium edge tactical blade for silent close-range strikes."
  )

  val ALL_WEAPONS = listOf(
    VX9_TEMPEST,
    KESTREL45,
    BULLDOG12,
    APEX_STRIKER,
    COBALT_DMR,
    P9_SPECTRE,
    COMBAT_CLEAVER
  )
}

// -------------------------------------------------------------
// LOOT & RARITY
// -------------------------------------------------------------

enum class ItemRarity(val label: String, val color: Color) {
  COMMON("Common", RarityCommon),
  UNCOMMON("Uncommon", RarityUncommon),
  RARE("Rare", RarityRare),
  EPIC("Epic", RarityEpic),
  LEGENDARY("Legendary", RarityLegendary)
}

enum class LootType {
  WEAPON,
  AMMO,
  ARMOR_VEST,
  HELMET,
  HEALTH_KIT,
  ENERGY_DRINK,
  BACKPACK,
  ATTACHMENT_SCOPE,
  SUPPLY_CRATE
}

data class LootItem(
  val id: String,
  val name: String,
  val type: LootType,
  val rarity: ItemRarity,
  val posX: Float,
  val posY: Float,
  val quantity: Int = 1,
  val weaponRef: Weapon? = null,
  val armorValue: Float = 0f,
  val healValue: Float = 0f,
  val isCrateOpened: Boolean = false
)

// -------------------------------------------------------------
// PLAYER STANCES & MOVEMENT
// -------------------------------------------------------------

enum class PlayerStance {
  STAND,
  CROUCH,
  PRONE,
  SWIM,
  CLIMB
}

enum class MatchMode(val displayName: String, val teamSize: Int) {
  SOLO("Solo", 1),
  DUO("Duo", 2),
  SQUAD("Squad", 4)
}

data class CharacterOutfit(
  val id: String,
  val name: String,
  val primaryColorHex: Long,
  val accentColorHex: Long,
  val description: String,
  val unlocked: Boolean = true
)

data class CharacterHeadgear(
  val id: String,
  val name: String,
  val description: String,
  val colorHex: Long
)

data class CharacterEmote(
  val id: String,
  val name: String,
  val iconName: String,
  val prompt: String
)

object CustomizationCatalog {
  val HEADGEARS = listOf(
    CharacterHeadgear("hg_beret", "Command Beret", "Crimson special forces beret.", 0xFFB71C1C),
    CharacterHeadgear("hg_helmet", "Ballistic Spec-Ops Helmet", "Carbon-reinforced helmet with NVG mount.", 0xFF263238),
    CharacterHeadgear("hg_visor", "Cyber Pulse Visor", "Augmented tactical targeting HUD visor.", 0xFF00E5FF),
    CharacterHeadgear("hg_cowl", "Shadow Phantom Cowl", "Sound and thermal-dampening stealth cowl.", 0xFF212121)
  )

  val EMOTES = listOf(
    CharacterEmote("em_salute", "Military Salute", "Salute", "Crisp tactical salute"),
    CharacterEmote("em_wave", "Tactical Signal", "Signal", "Hand gesture ordering forward advance"),
    CharacterEmote("em_victory", "Champion Flex", "Victory", "Pumps combat fist in celebration"),
    CharacterEmote("em_ready", "Battle Stance", "Stance", "Takes combat ready position")
  )
}

enum class BotDifficulty(val displayName: String, val accuracyMultiplier: Float, val reactionTimeSec: Float) {
  EASY("Easy", 0.6f, 1.2f),
  NORMAL("Normal", 1.0f, 0.7f),
  HARD("Hard", 1.4f, 0.35f)
}

enum class AttachmentType(val displayName: String) {
  SCOPE_RED_DOT("Red Dot Sight"),
  SCOPE_4X("4x Tactical Scope"),
  EXTENDED_MAG("Extended Mag"),
  COMPENSATOR("Recoil Compensator")
}

data class WeaponAttachment(
  val type: AttachmentType,
  val accuracyBonus: Float = 0f,
  val recoilReduction: Float = 0f,
  val extraCapacity: Int = 0
)

data class MapWaypoint(
  val posX: Float,
  val posY: Float,
  val label: String = "Tactical Beacon"
)

object OutfitCatalog {
  val OUTFITS = listOf(
    CharacterOutfit("specops", "Vanguard Spec-Ops", 0xFF1C2833, 0xFFFFB300, "Standard issue tactical urban camo gear with Kevlar accents."),
    CharacterOutfit("desert", "Desert Phantom", 0xFF8D6E63, 0xFFFFD54F, "Treated sandstorm combat fatigues with infrared-absorbing hood."),
    CharacterOutfit("cyber", "Cyber Ronin", 0xFF0D1B2A, 0xFF00E5FF, "Futuristic carbon chassis with luminous neon targeting trim."),
    CharacterOutfit("arctic", "Frost Hunter", 0xFFCFD8DC, 0xFF00B0FF, "Insulated sub-zero tactical parka with alpine camouflage."),
    CharacterOutfit("stalker", "Shadow Stalker", 0xFF121212, 0xFFFF334B, "High-density matte black stealth infiltration uniform.")
  )
}

// -------------------------------------------------------------
// VEHICLES
// -------------------------------------------------------------

enum class VehicleType(val displayName: String, val maxSpeed: Float, val maxHealth: Float) {
  DUNE_BUGGY("Viper Dune Buggy", 34f, 400f),
  OFF_ROAD_4X4("Mammoth 4x4", 28f, 650f),
  TACTICAL_QUAD("Shadow Quad", 38f, 300f)
}

data class VehicleInstance(
  val id: String,
  val type: VehicleType,
  var posX: Float,
  var posY: Float,
  var rotationDeg: Float,
  var currentSpeed: Float = 0f,
  var health: Float = 400f,
  var fuel: Float = 100f,
  var isOccupied: Boolean = false
)

// -------------------------------------------------------------
// SAFE ZONE & PHASES
// -------------------------------------------------------------

enum class MatchPhase {
  LOBBY,
  DROPSHIP_FLIGHT,
  PARACHUTING,
  GROUND_COMBAT,
  VICTORY,
  DEFEATED
}

data class SafeZoneState(
  var currentCenterX: Float = 1500f,
  var currentCenterY: Float = 1500f,
  var currentRadius: Float = 1400f,
  var targetCenterX: Float = 1500f,
  var targetCenterY: Float = 1500f,
  var targetRadius: Float = 1000f,
  var phaseNumber: Int = 1,
  var secondsUntilShrink: Float = 60f,
  var isShrinking: Boolean = false,
  var dpsOutside: Float = 2.0f
)

// -------------------------------------------------------------
// PARTICLES & BULLETS
// -------------------------------------------------------------

data class BulletTracer(
  val startX: Float,
  val startY: Float,
  val endX: Float,
  val endY: Float,
  val isCritHeadshot: Boolean = false,
  var lifeTimeRemaining: Float = 0.12f
)

data class CombatParticle(
  var x: Float,
  var y: Float,
  var velX: Float,
  var velY: Float,
  var color: Color,
  var life: Float = 1.0f,
  val maxLife: Float = 1.0f
)

data class KillFeedEntry(
  val killerName: String,
  val victimName: String,
  val weaponName: String,
  val isPlayerKiller: Boolean,
  val timestampMs: Long = System.currentTimeMillis()
)

data class DamageNumberPopup(
  val id: Long,
  var posX: Float,
  var posY: Float,
  val damage: Int,
  val isHeadshot: Boolean,
  var lifeTime: Float = 0.85f
)

// -------------------------------------------------------------
// BOT ENEMY
// -------------------------------------------------------------

enum class BotBehaviorState {
  PATROL,
  LOOTING,
  ENGAGING_ENEMY,
  TAKING_COVER,
  RUSHING_ZONE,
  HEALING
}

data class BotEntity(
  val id: String,
  val name: String,
  var posX: Float,
  var posY: Float,
  var rotationDeg: Float,
  var health: Float = 100f,
  var armor: Float = 50f,
  var activeWeapon: Weapon = WeaponCatalog.VX9_TEMPEST,
  var ammoInMag: Int = 30,
  var state: BotBehaviorState = BotBehaviorState.PATROL,
  var targetX: Float = 0f,
  var targetY: Float = 0f,
  var reloadTimer: Float = 0f,
  var attackCooldown: Float = 0f,
  var isAlive: Boolean = true,
  val outfitIndex: Int = 0
)

// -------------------------------------------------------------
// PLAYER & SQUAD
// -------------------------------------------------------------

data class PlayerState(
  var posX: Float = 1500f,
  var posY: Float = 1500f,
  var posZ: Float = 0f, // Altitude for dropship/parachuting
  var rotationDeg: Float = 0f,
  var pitchDeg: Float = 0f,
  var health: Float = 100f,
  var maxHealth: Float = 100f,
  var armor: Float = 100f,
  var maxArmor: Float = 100f,
  var helmetLevel: Int = 1,
  var vestLevel: Int = 2,
  var stance: PlayerStance = PlayerStance.STAND,
  var primaryWeapon1: Weapon? = WeaponCatalog.VX9_TEMPEST,
  var primaryWeapon2: Weapon? = WeaponCatalog.BULLDOG12,
  var sidearmWeapon: Weapon? = WeaponCatalog.P9_SPECTRE,
  var activeSlot: Int = 0, // 0: Prim1, 1: Prim2, 2: Sidearm, 3: Melee
  var ammoInMag: Int = 30,
  var reserve556Ammo: Int = 120,
  var reserve45Ammo: Int = 90,
  var reserve12GAmmo: Int = 24,
  var reserve300Ammo: Int = 15,
  var reserve9MMAmmo: Int = 60,
  var medKitCount: Int = 3,
  var energyDrinkCount: Int = 4,
  var kills: Int = 0,
  var damageDealt: Float = 0f,
  var isReloading: Boolean = false,
  var reloadProgress: Float = 0f,
  var isHealing: Boolean = false,
  var healProgress: Float = 0f,
  var isAimingDownSights: Boolean = false,
  var isSprinting: Boolean = false,
  var isJumping: Boolean = false,
  var jumpYOffset: Float = 0f,
  var jumpVelocity: Float = 0f,
  var walkCycle: Float = 0f,
  var currentVehicle: VehicleInstance? = null,
  var isAlive: Boolean = true,
  var isKnockedDown: Boolean = false,
  var bleedoutTimer: Float = 30f,
  var backpackLevel: Int = 1,
  var maxBackpackCapacity: Int = 200,
  var waypoint: MapWaypoint? = null
)

data class SquadTeammate(
  val id: String,
  val name: String,
  var health: Float = 100f,
  var armor: Float = 100f,
  var isAlive: Boolean = true,
  var isKnockedDown: Boolean = false,
  var bleedoutTimer: Float = 30f,
  var isBeingRevived: Boolean = false,
  var reviveProgress: Float = 0f,
  var kills: Int = 0,
  var posX: Float = 1500f,
  var posY: Float = 1500f
)

// -------------------------------------------------------------
// MISSIONS, REWARDS & PROGRESS
// -------------------------------------------------------------

data class GameMission(
  val id: String,
  val title: String,
  val description: String,
  val targetCount: Int,
  var currentCount: Int,
  val rewardCoins: Int,
  val rewardXp: Int,
  var isCompleted: Boolean = false,
  var isClaimed: Boolean = false
)

data class LeaderboardItem(
  val rank: Int,
  val username: String,
  val wins: Int,
  val eliminations: Int,
  val rating: Int,
  val badge: String
)

data class MatchSummary(
  val place: Int,
  val totalPlayers: Int,
  val kills: Int,
  val damageDealt: Int,
  val survivalTimeSec: Int,
  val headshots: Int,
  val xpEarned: Int,
  val coinsEarned: Int,
  val isVictory: Boolean
)
