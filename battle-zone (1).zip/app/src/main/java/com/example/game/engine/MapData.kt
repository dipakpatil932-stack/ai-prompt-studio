package com.example.game.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.example.game.model.*
import kotlin.math.hypot
import kotlin.random.Random

data class MapPOI(
  val id: String,
  val name: String,
  val position: Offset,
  val radius: Float,
  val description: String,
  val color: Color
)

data class BuildingStructure(
  val id: String,
  val rect: Rect,
  val roofColor: Color,
  val name: String,
  val hasLoot: Boolean = true
)

data class CoverObstacle(
  val id: String,
  val x: Float,
  val y: Float,
  val radius: Float,
  val type: ObstacleType
)

enum class ObstacleType {
  TREE_PINE,
  TREE_OAK,
  BOULDER,
  CRATE_STACK,
  SANDBAG,
  HAY_BALE,
  WATCHTOWER
}

data class RoadSegment(
  val start: Offset,
  val end: Offset,
  val width: Float = 14f
)

data class BridgeStructure(
  val rect: Rect,
  val name: String
)

object TacticalIslandMap {
  const val WORLD_SIZE = 3000f
  const val CENTER_X = 1500f
  const val CENTER_Y = 1500f

  val POIs = listOf(
    MapPOI("alpha_town", "Sector Alpha (Main City)", Offset(1100f, 900f), 220f, "Dense multi-story urban quarter with residential blocks.", Color(0xFF64B5F6)),
    MapPOI("pebble_village", "Pebble Bay (Village)", Offset(700f, 650f), 180f, "Quiet seaside coastal hamlet and fishing settlement.", Color(0xFF80CBC4)),
    MapPOI("sunset_farm", "Sunset Farm (Farm)", Offset(1500f, 2100f), 250f, "Open golden wheat fields, grain silos, and rustic barns.", Color(0xFFFFD54F)),
    MapPOI("iron_foundry", "Iron Foundry (Industrial)", Offset(1900f, 800f), 240f, "Heavy industrial smelting plant and automated factories.", Color(0xFFFFB74D)),
    MapPOI("whispering_pines", "Whispering Pines (Forest)", Offset(850f, 1200f), 280f, "Dense alpine pine forest rich in natural rock cover.", Color(0xFF81C784)),
    MapPOI("highland_tower", "Highland Peak (Mountains)", Offset(2200f, 1600f), 200f, "Mountain observatory commanding expansive sniper sightlines.", Color(0xFFB0BEC5)),
    MapPOI("isla_river", "Isla River (River)", Offset(1250f, 1480f), 170f, "Deep rushing natural waterways separating the north and south.", Color(0xFF29B6F6)),
    MapPOI("central_crossing", "Steel Bridges (Bridge)", Offset(1450f, 1450f), 150f, "Twin fortified steel bridges spanning across Isla River.", Color(0xFFFF8A65)),
    MapPOI("warehouse_district", "Cargo Depot (Warehouse)", Offset(1700f, 1250f), 190f, "Massive logistics hangars and shipping container yards.", Color(0xFFA1887F)),
    MapPOI("harbor_bay", "Harbor Bay (Coastal)", Offset(600f, 1800f), 260f, "Deep water docks, shipping piers, and ocean containers.", Color(0xFF4FC3F7)),
    MapPOI("training_compound", "Training Grounds (Training)", Offset(1400f, 600f), 180f, "Military tactical test ranges, obstacle track, and bunker.", Color(0xFFCE93D8)),
    MapPOI("abandoned_quarry", "Outpost Ruins (Abandoned)", Offset(2200f, 2300f), 210f, "Overgrown ancient fortress ruins and abandoned excavation quarry.", Color(0xFFBCAAA4))
  )

  // River path crossing the island from East to West
  val RIVER_POINTS = listOf(
    Offset(200f, 1600f),
    Offset(600f, 1550f),
    Offset(1050f, 1500f),
    Offset(1450f, 1450f),
    Offset(1900f, 1380f),
    Offset(2400f, 1450f),
    Offset(2800f, 1500f)
  )

  val BRIDGES = listOf(
    BridgeStructure(Rect(1400f, 1420f, 1500f, 1480f), "Central Steel Bridge"),
    BridgeStructure(Rect(980f, 1480f, 1080f, 1530f), "West Highway Bridge")
  )

  // Primary roads connecting the major locations
  val ROADS = listOf(
    RoadSegment(Offset(1100f, 900f), Offset(1400f, 600f)),
    RoadSegment(Offset(700f, 650f), Offset(1100f, 900f)),
    RoadSegment(Offset(1400f, 600f), Offset(1900f, 800f)),
    RoadSegment(Offset(1100f, 900f), Offset(1450f, 1450f)),
    RoadSegment(Offset(1900f, 800f), Offset(1700f, 1250f)),
    RoadSegment(Offset(1700f, 1250f), Offset(1450f, 1450f)),
    RoadSegment(Offset(600f, 1800f), Offset(1050f, 1500f)),
    RoadSegment(Offset(1050f, 1500f), Offset(1450f, 1450f)),
    RoadSegment(Offset(1450f, 1450f), Offset(1500f, 2100f)),
    RoadSegment(Offset(1500f, 2100f), Offset(2200f, 2300f)),
    RoadSegment(Offset(1450f, 1450f), Offset(2200f, 1600f))
  )

  // Pre-configured building structures
  val BUILDINGS = listOf(
    // Alpha Town buildings (Main City)
    BuildingStructure("b_alpha_1", Rect(1020f, 820f, 1090f, 880f), Color(0xFF37474F), "Alpha HQ"),
    BuildingStructure("b_alpha_2", Rect(1120f, 820f, 1180f, 890f), Color(0xFF455A64), "Apartment Block A"),
    BuildingStructure("b_alpha_3", Rect(1040f, 920f, 1110f, 980f), Color(0xFF37474F), "Medical Clinic"),
    BuildingStructure("b_alpha_4", Rect(1130f, 930f, 1200f, 990f), Color(0xFF263238), "Comms Center"),

    // Pebble Bay Village
    BuildingStructure("b_village_1", Rect(660f, 610f, 730f, 670f), Color(0xFF455A64), "Fisherman Lodge"),
    BuildingStructure("b_village_2", Rect(740f, 620f, 800f, 680f), Color(0xFF37474F), "Village General Store"),

    // Iron Foundry (Industrial Area)
    BuildingStructure("b_foundry_1", Rect(1820f, 740f, 1920f, 840f), Color(0xFF4E342E), "Main Smelter"),
    BuildingStructure("b_foundry_2", Rect(1940f, 760f, 2020f, 850f), Color(0xFF3E2723), "Steel Warehouse"),
    BuildingStructure("b_foundry_3", Rect(1860f, 860f, 1950f, 920f), Color(0xFF5D4037), "Generator Depot"),

    // Warehouse District
    BuildingStructure("b_wh_1", Rect(1650f, 1200f, 1750f, 1290f), Color(0xFF37474F), "Cargo Hangar Alpha"),
    BuildingStructure("b_wh_2", Rect(1760f, 1210f, 1840f, 1280f), Color(0xFF455A64), "Logistics Center"),

    // Harbor Bay (Coastal Area)
    BuildingStructure("b_harbor_1", Rect(520f, 1720f, 620f, 1800f), Color(0xFF004D40), "Dock Customs"),
    BuildingStructure("b_harbor_2", Rect(640f, 1740f, 720f, 1840f), Color(0xFF00695C), "Shipping Depot"),

    // Sunset Farm (Farm Area)
    BuildingStructure("b_farm_1", Rect(1440f, 2020f, 1520f, 2100f), Color(0xFFBF360C), "Red Barn"),
    BuildingStructure("b_farm_2", Rect(1540f, 2040f, 1600f, 2120f), Color(0xFFD84315), "Grain Silo Depot"),

    // Highland Watchtower (Mountains)
    BuildingStructure("b_tower_1", Rect(2170f, 1570f, 2230f, 1630f), Color(0xFF263238), "Observatory Peak"),

    // Outpost Ruins & Quarry (Abandoned Area)
    BuildingStructure("b_ruins_1", Rect(2140f, 2240f, 2220f, 2320f), Color(0xFF37474F), "Bunker Vault"),
    BuildingStructure("b_ruins_2", Rect(2240f, 2260f, 2310f, 2330f), Color(0xFF4E342E), "Excavation Shed"),

    // Training Compound (Training Grounds)
    BuildingStructure("b_training_1", Rect(1340f, 540f, 1420f, 620f), Color(0xFF1B5E20), "Armory Hangar"),
    BuildingStructure("b_training_2", Rect(1440f, 550f, 1510f, 610f), Color(0xFF2E7D32), "Target Range Depot")
  )

  // Generate natural cover objects (trees, rocks, crates)
  val COVER_OBJECTS = generateCoverObstacles()

  private fun generateCoverObstacles(): List<CoverObstacle> {
    val list = mutableListOf<CoverObstacle>()
    val rng = Random(42) // Fixed seed for reproducible beautiful island terrain

    // Whispering Pines Forest trees
    for (i in 0 until 65) {
      val angle = rng.nextFloat() * (Math.PI.toFloat() * 2f)
      val dist = rng.nextFloat() * 260f
      list.add(
        CoverObstacle(
          id = "pine_$i",
          x = 850f + (kotlin.math.cos(angle) * dist),
          y = 1200f + (kotlin.math.sin(angle) * dist),
          radius = 12f,
          type = ObstacleType.TREE_PINE
        )
      )
    }

    // Highland boulders
    for (i in 0 until 40) {
      val angle = rng.nextFloat() * (Math.PI.toFloat() * 2f)
      val dist = rng.nextFloat() * 200f
      list.add(
        CoverObstacle(
          id = "boulder_$i",
          x = 2200f + (kotlin.math.cos(angle) * dist),
          y = 1600f + (kotlin.math.sin(angle) * dist),
          radius = 16f,
          type = ObstacleType.BOULDER
        )
      )
    }

    // Sunset Farm hay bales
    for (i in 0 until 30) {
      list.add(
        CoverObstacle(
          id = "hay_$i",
          x = 1400f + rng.nextFloat() * 250f,
          y = 2050f + rng.nextFloat() * 200f,
          radius = 14f,
          type = ObstacleType.HAY_BALE
        )
      )
    }

    // Harbor crate stacks
    for (i in 0 until 28) {
      list.add(
        CoverObstacle(
          id = "crate_$i",
          x = 550f + rng.nextFloat() * 180f,
          y = 1750f + rng.nextFloat() * 150f,
          radius = 15f,
          type = ObstacleType.CRATE_STACK
        )
      )
    }

    // Sandbags around buildings & roads
    BUILDINGS.forEachIndexed { index, b ->
      list.add(
        CoverObstacle(
          id = "sandbag_$index",
          x = b.rect.left - 18f,
          y = b.rect.top - 12f,
          radius = 10f,
          type = ObstacleType.SANDBAG
        )
      )
    }

    return list
  }

  /**
   * Collision check against building walls
   */
  fun checkCollision(x: Float, y: Float, radius: Float): Boolean {
    // World bounds
    if (x < 100f || x > WORLD_SIZE - 100f || y < 100f || y > WORLD_SIZE - 100f) {
      return true
    }

    // Building boundaries (padded by radius)
    for (b in BUILDINGS) {
      if (x >= b.rect.left - radius && x <= b.rect.right + radius &&
        y >= b.rect.top - radius && y <= b.rect.bottom + radius
      ) {
        return true
      }
    }

    // Natural cover obstacles
    for (c in COVER_OBJECTS) {
      val d = hypot(x - c.x, y - c.y)
      if (d < radius + c.radius) {
        return true
      }
    }

    return false
  }

  /**
   * Check if position is in deep water (river) unless on a bridge
   */
  fun isPositionInRiver(x: Float, y: Float): Boolean {
    // Check if on any bridge
    for (br in BRIDGES) {
      if (br.rect.contains(Offset(x, y))) return false
    }

    // Check distance to river segments
    for (i in 0 until RIVER_POINTS.size - 1) {
      val p1 = RIVER_POINTS[i]
      val p2 = RIVER_POINTS[i + 1]
      val dist = distancePointToSegment(x, y, p1.x, p1.y, p2.x, p2.y)
      if (dist < 42f) return true
    }
    return false
  }

  private fun distancePointToSegment(
    px: Float, py: Float,
    x1: Float, y1: Float,
    x2: Float, y2: Float
  ): Float {
    val dx = x2 - x1
    val dy = y2 - y1
    val lenSq = dx * dx + dy * dy
    if (lenSq == 0f) return hypot(px - x1, py - y1)
    val t = ((px - x1) * dx + (py - y1) * dy) / lenSq
    val clampedT = t.coerceIn(0f, 1f)
    val projX = x1 + clampedT * dx
    val projY = y1 + clampedT * dy
    return hypot(px - projX, py - projY)
  }
}
