package com.example.game.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.model.MatchSummary
import com.example.ui.theme.*

@Composable
fun MatchResultScreen(
  summary: MatchSummary,
  onPlayAgain: () -> Unit,
  onReturnToLobby: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isVictory = summary.isVictory

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = if (isVictory) {
            listOf(Color(0xFF261C02), CarbonDark, Color(0xFF101720))
          } else {
            listOf(Color(0xFF2B0B0E), CarbonDark, Color(0xFF121820))
          }
        )
      )
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.85f)
        .wrapContentHeight(),
      colors = CardDefaults.cardColors(containerColor = SlateNavy),
      shape = RoundedCornerShape(16.dp),
      border = BorderStroke(2.dp, if (isVictory) TacticalAmber else TacticalRed)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Banner Badge
        Box(
          modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(if (isVictory) TacticalAmber.copy(alpha = 0.2f) else TacticalRed.copy(alpha = 0.2f))
            .border(2.dp, if (isVictory) TacticalAmber else TacticalRed, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            if (isVictory) Icons.Default.EmojiEvents else Icons.Default.SentimentDissatisfied,
            contentDescription = null,
            tint = if (isVictory) TacticalAmber else TacticalRed,
            modifier = Modifier.size(34.dp)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = if (isVictory) "VICTORY! APEX SURVIVOR" else "DEFEATED // BETTER LUCK NEXT DROP",
          color = if (isVictory) TacticalAmberLight else TacticalRed,
          fontSize = 20.sp,
          fontWeight = FontWeight.Black,
          textAlign = TextAlign.Center
        )

        Text(
          text = if (isVictory) "#1 / ${summary.totalPlayers} SURVIVORS REMAINING" else "RANK #${summary.place} / ${summary.totalPlayers}",
          color = TextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Match Stats Grid
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          StatBox(label = "ELIMINATIONS", value = "${summary.kills}", color = TacticalAmber)
          StatBox(label = "DAMAGE DEALT", value = "${summary.damageDealt}", color = TacticalCyan)
          StatBox(label = "SURVIVAL TIME", value = "%02d:%02d".format(summary.survivalTimeSec / 60, summary.survivalTimeSec % 60), color = TacticalGreen)
          StatBox(label = "HEADSHOTS", value = "${summary.headshots}", color = TacticalPurple)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Rewards Earned
        Row(
          modifier = Modifier
            .background(SlateSurface, RoundedCornerShape(8.dp))
            .border(1.dp, SlateBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 20.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Star, contentDescription = null, tint = TacticalAmber, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("+${summary.xpEarned} XP", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

          Spacer(modifier = Modifier.width(24.dp))

          Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = TacticalAmberLight, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("+${summary.coinsEarned} COINS", color = TacticalAmberLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center
        ) {
          OutlinedButton(
            onClick = onReturnToLobby,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
            border = BorderStroke(1.dp, SlateBorder),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("result_lobby_button")
          ) {
            Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("RETURN TO LOBBY", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Spacer(modifier = Modifier.width(16.dp))

          Button(
            onClick = onPlayAgain,
            colors = ButtonDefaults.buttonColors(containerColor = TacticalAmber, contentColor = Color.Black),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("result_play_again_button")
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("PLAY AGAIN", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun StatBox(label: String, value: String, color: Color) {
  Column(
    modifier = Modifier
      .background(SlateSurface, RoundedCornerShape(6.dp))
      .padding(horizontal = 14.dp, vertical = 8.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
    Spacer(modifier = Modifier.height(2.dp))
    Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
  }
}
