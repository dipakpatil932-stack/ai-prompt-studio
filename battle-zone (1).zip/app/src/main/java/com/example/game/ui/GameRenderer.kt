package com.example.game.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.graphics.nativeCanvas
import com.example.game.engine.*
import com.example.game.model.*
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun GameRenderer(
  player: PlayerState,
  phase: MatchPhase,
  safeZone: SafeZoneState,
  bots: List<BotEntity>,
  vehicles: List<VehicleInstance>,
  lootItems: List<LootItem>,
  tracers: List<BulletTracer>,
  particles: List<CombatParticle>,
  damagePopups: List<DamageNumberPopup> = emptyList(),
  camX: Float = player.posX,
  camY: Float = player.posY,
  modifier: Modifier = Modifier
) {
  Canvas(modifier = modifier.fillMaxSize()) {
    val canvasW = size.width
    val canvasH = size.height
    val screenCenter = Offset(canvasW / 2f, canvasH / 2f)

    // Camera zoom: In ADS (aim down sights) zoom in; when parachuting zoom out
    val zoom = when {
      phase == MatchPhase.PARACHUTING -> 0.35f + (1f - (player.posZ / 700f)) * 0.45f
      player.isAimingDownSights -> 1.45f
      else -> 1.0f
    }

    // World to screen transform function (with smoothed camera)
    fun worldToScreen(wx: Float, wy: Float): Offset {
      val dx = (wx - camX) * zoom
      val dy = (wy - camY) * zoom
      return Offset(screenCenter.x + dx, screenCenter.y + dy)
    }

    // 1. Terrain Canvas Background (Atmospheric Island Ground)
    drawRect(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFF2A3A2C), Color(0xFF1E281F), Color(0xFF131A14)),
        center = screenCenter,
        radius = canvasW * 0.85f
      )
    )

    // Terrain grid / tactical contour lines
    val gridStep = 100f * zoom
    val startGridX = (screenCenter.x - (player.posX * zoom) % gridStep)
    val startGridY = (screenCenter.y - (player.posY * zoom) % gridStep)

    var gx = startGridX - gridStep * 2
    while (gx < canvasW + gridStep * 2) {
      drawLine(
        color = Color(0x184CAF50),
        start = Offset(gx, 0f),
        end = Offset(gx, canvasH),
        strokeWidth = 1f
      )
      gx += gridStep
    }

    var gy = startGridY - gridStep * 2
    while (gy < canvasH + gridStep * 2) {
      drawLine(
        color = Color(0x184CAF50),
        start = Offset(0f, gy),
        end = Offset(canvasW, gy),
        strokeWidth = 1f
      )
      gy += gridStep
    }

    // 2. River Rendering
    for (i in 0 until TacticalIslandMap.RIVER_POINTS.size - 1) {
      val p1 = TacticalIslandMap.RIVER_POINTS[i]
      val p2 = TacticalIslandMap.RIVER_POINTS[i + 1]
      val sp1 = worldToScreen(p1.x, p1.y)
      val sp2 = worldToScreen(p2.x, p2.y)
      drawLine(
        color = Color(0xFF1976D2),
        start = sp1,
        end = sp2,
        strokeWidth = 44f * zoom,
        cap = StrokeCap.Round
      )
      // River water ripple highlight
      drawLine(
        color = Color(0xFF42A5F5),
        start = sp1,
        end = sp2,
        strokeWidth = 8f * zoom,
        cap = StrokeCap.Round
      )
    }

    // 3. Roads
    for (road in TacticalIslandMap.ROADS) {
      val sp1 = worldToScreen(road.start.x, road.start.y)
      val sp2 = worldToScreen(road.end.x, road.end.y)
      drawLine(
        color = Color(0xFF37474F),
        start = sp1,
        end = sp2,
        strokeWidth = road.width * zoom,
        cap = StrokeCap.Round
      )
      // Road yellow center dashes
      drawLine(
        color = Color(0x66FFD54F),
        start = sp1,
        end = sp2,
        strokeWidth = 2f * zoom,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f * zoom, 15f * zoom))
      )
    }

    // 4. Bridges
    for (bridge in TacticalIslandMap.BRIDGES) {
      val tl = worldToScreen(bridge.rect.left, bridge.rect.top)
      val br = worldToScreen(bridge.rect.right, bridge.rect.bottom)
      drawRect(
        color = Color(0xFF455A64),
        topLeft = tl,
        size = Size(br.x - tl.x, br.y - tl.y)
      )
      drawRect(
        color = Color(0xFFFFB300),
        topLeft = tl,
        size = Size(br.x - tl.x, br.y - tl.y),
        style = Stroke(width = 2f * zoom)
      )
    }

    // 5. POI Area Glows
    for (poi in TacticalIslandMap.POIs) {
      val sp = worldToScreen(poi.position.x, poi.position.y)
      val r = poi.radius * zoom
      drawCircle(
        color = poi.color.copy(alpha = 0.08f),
        center = sp,
        radius = r
      )
      drawCircle(
        color = poi.color.copy(alpha = 0.25f),
        center = sp,
        radius = r,
        style = Stroke(width = 1.5f * zoom, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f * zoom, 10f * zoom)))
      )
    }

    // 6. Buildings with 3D Extruded Depth
    val extrudeOffset = Offset(8f * zoom, 12f * zoom)
    for (b in TacticalIslandMap.BUILDINGS) {
      val tl = worldToScreen(b.rect.left, b.rect.top)
      val bw = b.rect.width * zoom
      val bh = b.rect.height * zoom

      // Drop shadow / Extruded foundation wall
      drawRect(
        color = Color(0xFF10171E),
        topLeft = tl + extrudeOffset,
        size = Size(bw, bh)
      )
      // Building Roof Top
      drawRect(
        color = b.roofColor,
        topLeft = tl,
        size = Size(bw, bh)
      )
      // Rooftop ventilation and border
      drawRect(
        color = Color(0x44FFFFFF),
        topLeft = tl,
        size = Size(bw, bh),
        style = Stroke(width = 2f * zoom)
      )
      // Small AC unit on roof
      drawRect(
        color = Color(0xFF212121),
        topLeft = tl + Offset(6f * zoom, 6f * zoom),
        size = Size(bw * 0.25f, bh * 0.25f)
      )
    }

    // 7. Natural Cover Obstacles (Trees, Boulders, Crates)
    for (obs in TacticalIslandMap.COVER_OBJECTS) {
      val sp = worldToScreen(obs.x, obs.y)
      val r = obs.radius * zoom
      when (obs.type) {
        ObstacleType.TREE_PINE -> {
          // Shadow
          drawCircle(Color(0x33000000), radius = r * 1.1f, center = sp + Offset(4f * zoom, 6f * zoom))
          // Outer pine foliage
          drawCircle(Color(0xFF2E7D32), radius = r, center = sp)
          drawCircle(Color(0xFF388E3C), radius = r * 0.65f, center = sp)
          drawCircle(Color(0xFF1B5E20), radius = r * 0.25f, center = sp)
        }
        ObstacleType.BOULDER -> {
          drawCircle(Color(0x44000000), radius = r, center = sp + Offset(3f * zoom, 5f * zoom))
          drawCircle(Color(0xFF78909C), radius = r, center = sp)
          drawCircle(Color(0xFFB0BEC5), radius = r * 0.5f, center = sp - Offset(2f * zoom, 2f * zoom))
        }
        ObstacleType.CRATE_STACK -> {
          drawRect(Color(0xFF8D6E63), topLeft = sp - Offset(r, r), size = Size(r * 2, r * 2))
          drawRect(Color(0xFF5D4037), topLeft = sp - Offset(r, r), size = Size(r * 2, r * 2), style = Stroke(width = 2f * zoom))
        }
        ObstacleType.HAY_BALE -> {
          drawCircle(Color(0xFFFFD54F), radius = r, center = sp)
          drawCircle(Color(0xFFFFA000), radius = r, center = sp, style = Stroke(width = 1.5f * zoom))
        }
        ObstacleType.SANDBAG -> {
          drawRoundRect(
            color = Color(0xFFC2A679),
            topLeft = sp - Offset(r * 1.4f, r * 0.7f),
            size = Size(r * 2.8f, r * 1.4f),
            cornerRadius = CornerRadius(4f * zoom, 4f * zoom)
          )
        }
        else -> {
          drawCircle(Color(0xFF546E7A), radius = r, center = sp)
        }
      }
    }

    // 8. Ground Loot Items with Rarity Glowing Halos & Crates
    for (loot in lootItems) {
      val sp = worldToScreen(loot.posX, loot.posY)
      val haloColor = loot.rarity.color

      if (loot.type == LootType.SUPPLY_CRATE) {
        // Massive Tactical Supply Airdrop Crate
        val crateSize = 24f * zoom
        // Beacon ring
        drawCircle(
          color = Color(0xFFFFD54F).copy(alpha = 0.35f),
          radius = 32f * zoom,
          center = sp
        )
        // Crate shadow
        drawRect(
          color = Color(0x66000000),
          topLeft = sp - Offset(crateSize / 2f - 3f * zoom, crateSize / 2f - 3f * zoom),
          size = Size(crateSize, crateSize)
        )
        // Red container body
        drawRoundRect(
          color = Color(0xFFD32F2F),
          topLeft = sp - Offset(crateSize / 2f, crateSize / 2f),
          size = Size(crateSize, crateSize),
          cornerRadius = CornerRadius(4f * zoom, 4f * zoom)
        )
        // Tactical cross symbol & yellow corner brackets
        drawLine(
          color = Color.White,
          start = sp - Offset(crateSize * 0.3f, 0f),
          end = sp + Offset(crateSize * 0.3f, 0f),
          strokeWidth = 3f * zoom
        )
        drawLine(
          color = Color.White,
          start = sp - Offset(0f, crateSize * 0.3f),
          end = sp + Offset(0f, crateSize * 0.3f),
          strokeWidth = 3f * zoom
        )
        drawRect(
          color = Color(0xFFFFB300),
          topLeft = sp - Offset(crateSize / 2f, crateSize / 2f),
          size = Size(crateSize, crateSize),
          style = Stroke(width = 2f * zoom)
        )
      } else {
        // Pulsing rarity beacon ring
        drawCircle(
          color = haloColor.copy(alpha = 0.25f),
          radius = 16f * zoom,
          center = sp
        )
        drawCircle(
          color = haloColor,
          radius = 8f * zoom,
          center = sp
        )
        // Mini indicator dot
        drawCircle(
          color = Color.White,
          radius = 3f * zoom,
          center = sp
        )
      }
    }

    // 9. Vehicles
    for (veh in vehicles) {
      val sp = worldToScreen(veh.posX, veh.posY)
      val rad = Math.toRadians(veh.rotationDeg.toDouble())
      val dirX = cos(rad).toFloat()
      val dirY = sin(rad).toFloat()
      val perpX = -dirY
      val perpY = dirX

      val vehW = 28f * zoom
      val vehL = 48f * zoom

      rotate(degrees = veh.rotationDeg, pivot = sp) {
        // Shadow
        drawRoundRect(
          color = Color(0x55000000),
          topLeft = sp - Offset(vehW / 2f - 4f * zoom, vehL / 2f - 6f * zoom),
          size = Size(vehW, vehL),
          cornerRadius = CornerRadius(6f * zoom, 6f * zoom)
        )
        // Vehicle Chassis
        val bodyColor = when (veh.type) {
          VehicleType.DUNE_BUGGY -> Color(0xFFFF9800)
          VehicleType.OFF_ROAD_4X4 -> Color(0xFF37474F)
          VehicleType.TACTICAL_QUAD -> Color(0xFF00ACC1)
        }
        drawRoundRect(
          color = bodyColor,
          topLeft = sp - Offset(vehW / 2f, vehL / 2f),
          size = Size(vehW, vehL),
          cornerRadius = CornerRadius(6f * zoom, 6f * zoom)
        )
        // Windshield
        drawRect(
          color = Color(0xFF90CAF9),
          topLeft = sp - Offset(vehW * 0.35f, vehL * 0.15f),
          size = Size(vehW * 0.7f, vehL * 0.35f)
        )
        // Headlights
        drawCircle(Color(0xFFFFF9C4), radius = 3.5f * zoom, center = sp + Offset(-vehW * 0.3f, vehL * 0.45f))
        drawCircle(Color(0xFFFFF9C4), radius = 3.5f * zoom, center = sp + Offset(vehW * 0.3f, vehL * 0.45f))
      }

      // Overhead vehicle health bar if occupied or damaged
      if (veh.health < veh.type.maxHealth) {
        val barW = 36f * zoom
        val barH = 4f * zoom
        val hpPct = (veh.health / veh.type.maxHealth).coerceIn(0f, 1f)
        drawRect(Color.Black, topLeft = sp - Offset(barW / 2f, 32f * zoom), size = Size(barW, barH))
        drawRect(Color(0xFF00E676), topLeft = sp - Offset(barW / 2f, 32f * zoom), size = Size(barW * hpPct, barH))
      }
    }

    // 10. Bots (AI Opponents)
    for (bot in bots) {
      if (!bot.isAlive) {
        // Dead bot tactical loot crate marker
        val sp = worldToScreen(bot.posX, bot.posY)
        drawRect(Color(0xFF455A64), topLeft = sp - Offset(8f * zoom, 8f * zoom), size = Size(16f * zoom, 16f * zoom))
        drawRect(Color(0xFFFFB300), topLeft = sp - Offset(8f * zoom, 8f * zoom), size = Size(16f * zoom, 16f * zoom), style = Stroke(width = 1.5f * zoom))
        continue
      }

      val sp = worldToScreen(bot.posX, bot.posY)
      rotate(degrees = bot.rotationDeg, pivot = sp) {
        // Shadow
        drawCircle(Color(0x44000000), radius = 14f * zoom, center = sp + Offset(2f * zoom, 4f * zoom))
        // Outfit torso
        val outfitColor = Color(OutfitCatalog.OUTFITS[bot.outfitIndex % OutfitCatalog.OUTFITS.size].primaryColorHex)
        drawCircle(outfitColor, radius = 12f * zoom, center = sp)
        // Tactical Helmet
        drawCircle(Color(0xFF37474F), radius = 8f * zoom, center = sp)
        // Visor
        drawCircle(Color(0xFFFF334B), radius = 3f * zoom, center = sp + Offset(6f * zoom, 0f))
        // Weapon in hands
        drawRect(
          color = Color(0xFF212121),
          topLeft = sp + Offset(4f * zoom, -2.5f * zoom),
          size = Size(14f * zoom, 5f * zoom)
        )
      }

      // Health bar overhead
      val barW = 32f * zoom
      val barH = 3.5f * zoom
      val hpPct = (bot.health / 100f).coerceIn(0f, 1f)
      val barY = sp.y - 22f * zoom
      drawRect(Color(0xAA000000), topLeft = Offset(sp.x - barW / 2f, barY), size = Size(barW, barH))
      drawRect(Color(0xFFFF334B), topLeft = Offset(sp.x - barW / 2f, barY), size = Size(barW * hpPct, barH))
      if (bot.armor > 0f) {
        val armorPct = (bot.armor / 100f).coerceIn(0f, 1f)
        drawRect(Color(0xFF00E5FF), topLeft = Offset(sp.x - barW / 2f, barY - barH - 1f), size = Size(barW * armorPct, 2.5f * zoom))
      }
    }

    // 11. Player Character (Stylized 3D Realistic Third-Person)
    if (player.isAlive && player.currentVehicle == null) {
      val sp = worldToScreen(player.posX, player.posY)
      val jumpElevation = player.jumpYOffset * zoom * 0.75f
      val playerVisualPos = sp - Offset(0f, jumpElevation)

      // Ground Shadow (stays on the ground even when player jumps)
      val shadowScale = (1f - (player.jumpYOffset / 260f)).coerceIn(0.45f, 1f)
      drawCircle(
        color = Color(0x55000000),
        radius = 16f * zoom * shadowScale,
        center = sp + Offset(3f * zoom, 5f * zoom)
      )

      rotate(degrees = player.rotationDeg, pivot = playerVisualPos) {
        // Torso based on stance
        val bodyRadius = when (player.stance) {
          PlayerStance.PRONE -> 17f * zoom
          PlayerStance.CROUCH -> 13f * zoom
          else -> 14f * zoom
        }
        val outfit = OutfitCatalog.OUTFITS[0]

        // Legs animated by walk cycle
        if (player.walkCycle != 0f) {
          val legOffset = sin(player.walkCycle) * 4f * zoom
          drawCircle(Color(0xFF1E272E), radius = 4.5f * zoom, center = playerVisualPos + Offset(-6f * zoom, legOffset))
          drawCircle(Color(0xFF1E272E), radius = 4.5f * zoom, center = playerVisualPos + Offset(6f * zoom, -legOffset))
        }

        // Body Torso
        drawCircle(Color(outfit.primaryColorHex), radius = bodyRadius, center = playerVisualPos)

        // Kevlar Tactical Vest
        drawCircle(Color(0xFF263238), radius = bodyRadius * 0.8f, center = playerVisualPos)

        // Tactical Backpack on back
        drawRoundRect(
          color = Color(0xFF37474F),
          topLeft = playerVisualPos - Offset(6f * zoom, 12f * zoom),
          size = Size(12f * zoom, 7f * zoom),
          cornerRadius = CornerRadius(2f * zoom, 2f * zoom)
        )

        // Head & Helmet
        drawCircle(Color(0xFF37474F), radius = 9f * zoom, center = playerVisualPos)
        // Glowing Visor
        drawCircle(Color(outfit.accentColorHex), radius = 3.5f * zoom, center = playerVisualPos + Offset(7f * zoom, 0f))

        // Active weapon held in firing stance
        val activeWp = when (player.activeSlot) {
          0 -> player.primaryWeapon1 ?: WeaponCatalog.VX9_TEMPEST
          1 -> player.primaryWeapon2 ?: WeaponCatalog.BULLDOG12
          2 -> player.sidearmWeapon ?: WeaponCatalog.P9_SPECTRE
          else -> WeaponCatalog.COMBAT_CLEAVER
        }
        val wpLength = when (activeWp.category) {
          WeaponCategory.SNIPER, WeaponCategory.DMR -> 26f * zoom
          WeaponCategory.SMG, WeaponCategory.PISTOL -> 13f * zoom
          WeaponCategory.MELEE -> 9f * zoom
          else -> 19f * zoom
        }
        drawRect(
          color = Color(0xFF1E272E),
          topLeft = playerVisualPos + Offset(6f * zoom, -3f * zoom),
          size = Size(wpLength, 6f * zoom)
        )
        // Laser targeting beam when aiming ADS
        if (player.isAimingDownSights) {
          drawLine(
            color = Color(0x9900E5FF),
            start = playerVisualPos + Offset(6f * zoom + wpLength, 0f),
            end = playerVisualPos + Offset(450f * zoom, 0f),
            strokeWidth = 2f * zoom
          )
        }
      }

      // Parachute canopy above player if parachuting
      if (phase == MatchPhase.PARACHUTING) {
        val canopyW = 68f * zoom
        val canopyH = 26f * zoom
        drawArc(
          color = Color(0xFFFFB300),
          startAngle = 180f,
          sweepAngle = 180f,
          useCenter = true,
          topLeft = sp - Offset(canopyW / 2f, 40f * zoom + canopyH),
          size = Size(canopyW, canopyH)
        )
        // Parachute suspension lines
        drawLine(Color.White, sp - Offset(canopyW * 0.45f, 40f * zoom), sp, strokeWidth = 1f)
        drawLine(Color.White, sp + Offset(canopyW * 0.45f, -40f * zoom), sp, strokeWidth = 1f)
      }
    }

    // 12. Safe Zone Outer Energy Dome & Target Circle
    // White ring = target safe zone
    val targetCenterSp = worldToScreen(safeZone.targetCenterX, safeZone.targetCenterY)
    drawCircle(
      color = Color(0xBBFFFFFF),
      radius = safeZone.targetRadius * zoom,
      center = targetCenterSp,
      style = Stroke(width = 2.5f * zoom, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f * zoom, 12f * zoom)))
    )

    // Cyan/Blue shrinking ring = current safe zone
    val currentCenterSp = worldToScreen(safeZone.currentCenterX, safeZone.currentCenterY)
    drawCircle(
      color = Color(0xFF00E5FF),
      radius = safeZone.currentRadius * zoom,
      center = currentCenterSp,
      style = Stroke(width = 4f * zoom)
    )
    // Outside hazard boundary tint
    drawCircle(
      color = Color(0x2200E5FF),
      radius = safeZone.currentRadius * zoom + 8f * zoom,
      center = currentCenterSp,
      style = Stroke(width = 16f * zoom)
    )

    // 13. Bullet Tracers (Vivid tactical laser streaks)
    for (tr in tracers) {
      val s1 = worldToScreen(tr.startX, tr.startY)
      val s2 = worldToScreen(tr.endX, tr.endY)
      val tracerColor = if (tr.isCritHeadshot) Color(0xFFFF334B) else Color(0xFFFFD54F)
      drawLine(
        color = tracerColor,
        start = s1,
        end = s2,
        strokeWidth = 2.5f * zoom,
        cap = StrokeCap.Round
      )
    }

    // 14. Combat Particle Sparks
    for (pt in particles) {
      val sp = worldToScreen(pt.x, pt.y)
      drawCircle(
        color = pt.color.copy(alpha = pt.life.coerceIn(0f, 1f)),
        radius = 2.5f * zoom,
        center = sp
      )
    }

    // 15. Floating Tactical Damage Popups
    for (pop in damagePopups) {
      val sp = worldToScreen(pop.posX, pop.posY)
      val alphaFactor = (pop.lifeTime / 0.85f).coerceIn(0f, 1f)
      val paint = Paint().apply {
        color = if (pop.isHeadshot) android.graphics.Color.RED else android.graphics.Color.YELLOW
        textSize = (if (pop.isHeadshot) 20f else 15f) * zoom
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
        alpha = (alphaFactor * 255).toInt()
        textAlign = Paint.Align.CENTER
      }
      val text = if (pop.isHeadshot) "CRIT -${pop.damage}" else "-${pop.damage}"
      drawContext.canvas.nativeCanvas.drawText(text, sp.x, sp.y, paint)
    }
  }
}
