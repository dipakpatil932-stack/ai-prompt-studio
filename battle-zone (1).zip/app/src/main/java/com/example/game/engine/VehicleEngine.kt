package com.example.game.engine

import com.example.game.model.*
import kotlin.math.*

object VehicleEngine {

  fun updateVehicle(
    vehicle: VehicleInstance,
    dt: Float,
    throttleInput: Float, // -1 (reverse/brake) to +1 (accelerate)
    steerInput: Float,    // -1 (left) to +1 (right)
    bots: List<BotEntity>,
    killFeed: MutableList<KillFeedEntry>? = null
  ) {
    if (vehicle.health <= 0f) return

    val maxSpeed = vehicle.type.maxSpeed
    val accelRate = 24f
    val friction = 12f

    // Acceleration and braking
    if (throttleInput > 0.05f && vehicle.fuel > 0f) {
      vehicle.currentSpeed = (vehicle.currentSpeed + accelRate * throttleInput * dt).coerceAtMost(maxSpeed)
      vehicle.fuel = (vehicle.fuel - 0.8f * dt).coerceAtLeast(0f)
    } else if (throttleInput < -0.05f) {
      vehicle.currentSpeed = (vehicle.currentSpeed - accelRate * 1.5f * abs(throttleInput) * dt).coerceAtLeast(-maxSpeed * 0.4f)
    } else {
      // Natural deceleration / rolling friction
      if (vehicle.currentSpeed > 0f) {
        vehicle.currentSpeed = (vehicle.currentSpeed - friction * dt).coerceAtLeast(0f)
      } else if (vehicle.currentSpeed < 0f) {
        vehicle.currentSpeed = (vehicle.currentSpeed + friction * dt).coerceAtMost(0f)
      }
    }

    // Steering proportional to speed
    if (abs(vehicle.currentSpeed) > 0.5f) {
      val turnSpeed = 95f * (vehicle.currentSpeed / maxSpeed).coerceIn(-1f, 1f)
      vehicle.rotationDeg += steerInput * turnSpeed * dt
    }

    // Update position
    val rad = Math.toRadians(vehicle.rotationDeg.toDouble())
    val dirX = cos(rad).toFloat()
    val dirY = sin(rad).toFloat()

    val nextX = vehicle.posX + dirX * vehicle.currentSpeed * dt * 4.5f
    val nextY = vehicle.posY + dirY * vehicle.currentSpeed * dt * 4.5f

    // Collision check
    if (!TacticalIslandMap.checkCollision(nextX, nextY, 28f)) {
      vehicle.posX = nextX
      vehicle.posY = nextY
    } else {
      // Impact crash into wall/rock
      if (abs(vehicle.currentSpeed) > 8f) {
        vehicle.health = (vehicle.health - abs(vehicle.currentSpeed) * 3f).coerceAtLeast(0f)
      }
      vehicle.currentSpeed = -vehicle.currentSpeed * 0.3f
    }

    // Vehicle run-over check on bots if moving fast
    if (abs(vehicle.currentSpeed) > 12f) {
      for (bot in bots) {
        if (!bot.isAlive) continue
        val dist = hypot(bot.posX - vehicle.posX, bot.posY - vehicle.posY)
        if (dist < 34f) {
          val ramDmg = abs(vehicle.currentSpeed) * 8f
          bot.health -= ramDmg
          if (bot.health <= 0f) {
            bot.isAlive = false
            bot.health = 0f
            killFeed?.add(KillFeedEntry("Vehicle", bot.name, vehicle.type.displayName, true))
          }
        }
      }
    }
  }

  fun spawnInitialVehicles(): List<VehicleInstance> {
    return listOf(
      VehicleInstance("veh_1", VehicleType.DUNE_BUGGY, 1150f, 960f, 45f),
      VehicleInstance("veh_2", VehicleType.OFF_ROAD_4X4, 1850f, 880f, 180f),
      VehicleInstance("veh_3", VehicleType.TACTICAL_QUAD, 1420f, 1380f, 270f),
      VehicleInstance("veh_4", VehicleType.DUNE_BUGGY, 680f, 1720f, 90f),
      VehicleInstance("veh_5", VehicleType.OFF_ROAD_4X4, 1480f, 2040f, 0f)
    )
  }
}
